# This function is based on designs function from agricolae 1.3-2 package (Mendiburu, 2020)
# Details which ebs will not use were removed, as the randomization and kinds arguments (present in original agricolae function)
#' @export
#'
#' @importFrom Rdpack reprompt
#'
#' @title  Randomize a Completely Randomized Design
#' @name randCRAND
#'
#' @description Creates a randomized array for Completely Randomized Design. Requires a list of entries and a vector informing number of reps of each entry. Function based on "design.rcbd" function from agricolae R package \insertCite{agricolae}{ebsRtools}.
#'
#' @references
#'     \insertAllCited{}.
#'
#' @param trt Number of treatments
#' @param r List related to trt that informs the number of repetitions (plots) of each treatment
#' @param tag Format of plot number tag
#' @param seed Seed for randomization
#' @param continue TRUE or FALSE: continue the plot number sequence between reps
#' @param nTrial Number of experiment occurrences
#' @param entryOrder If the entries should be randomized or follow the entry order sequence
#' @param group Used if entryOrder = TRUE. If group is TRUE the reps will be grouped, and the entries not randomized within the rep
#'
#' @return A list with 2 items.
#' \enumerate{
#'   \item {parameters}{ All design parameters}
#'   \item {book}{ Randomized array, assign entries to plots}
#' }
#'
#' @usage randCRAND(trt, r, tag = 2, seed =0, nTrial = 1, entryOrder = F, group = F)
#'
#' @examples
#'
#' \dontrun{
#' library(ebsRtools)
#' entry <- c(1:45)
#' rep <- c(rep(3,5),rep(1,40))
#' exp1 <- randCRAND(trt = entry, r = rep, nTrial = 3)
#' exp1}
#'
#' @rdname randCRAND
randCRAND <- function (trt, r, tag = 2, seed = 0, nTrial = 1, entryOrder = F, group = F)
{
  number <- 10
  if (tag > 0)
    number <- 10^tag
  if (seed == 0) {
    genera <- runif(1)
    seed <- .Random.seed[3]
  }
  set.seed(seed)
  parameters <- list(design = if(!entryOrder){"Completely Randomized"}else{"Entry Order"}, trt = trt, r = r, seed = seed)

  for(w in c(1:nTrial)){
    if(w==1)
    {trials <- list()}
    ntr <- length(trt)
    trtN <- c(1:length(trt))
    unique <- data.frame(trtN = trtN, entry = trt, rep = r)
    list <- rep(trtN[1],r[1])
    for(i in 2:ntr){list <- c(list,rep(trtN[i], r[i]))}

    if(entryOrder){
      rand <- list
    } else {(rand <- sample(list,length(list), replace=F))}

    plots <- number + (1:length(rand))
    book <- data.frame(plots, trtN = rand)
    book$entry <- unique$entry[match(book$trtN,unique$trtN)]
    tmp <- book[order(book[,"trtN"]),]
    rep <- c(1:unique[1,"rep"])
    for(i in 2:ntr){
      rep <- c(rep, c(1:unique[i,"rep"]))
    }
    tmp$rep <- rep
    book <- tmp[order(tmp[,"plots"]),]
    if(entryOrder & group) {
      tmp <- book
      tmp <- tmp[with(tmp,order(rep,trtN)),]
      book[,c("entry","rep")] <- tmp[,c("entry","rep")]
    }
    book$trtN <- NULL
    book$rep <- as.factor(book$rep)
    book <- book[,c("plots","rep","entry")]
    names(book)[1] <- "plot_number"
    names(book)[2] <- "replicate"
    names(book)[3] <- c(paste(deparse(substitute(trt))))
    names(book)[3] <- c(paste(deparse(substitute(trt))))
    design <- list(parameters = parameters, book = book)
    trials[[w]] <- design
  }
  return(trials)
}
