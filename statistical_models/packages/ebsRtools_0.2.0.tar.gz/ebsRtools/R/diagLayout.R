#' @export
#'
#' @importFrom Rdpack reprompt
#'
#' @title Generate a layout for check in Diagonal
#' @name diagLayout
#'
#' @param nCol Number of columns in the field, columns are the X coordinates.
#' @param nRow Number of rows in the field, rows are the Y coordinates.
#' @param percentChk Percentage of the total plots that should be check plots. Values must be between 0 and 0.5
#' @param plot TRUE or FALSE. If should display the field layout in a chart. Default FALSE
#'
#' @return A matrix with dimensions nRow x nCol with 1 in the check plots and 0 in the non-check plots. And a simple chart, if plot=TRUE, indicating the check position.
#'
#' @export
#' @usage diagLayout(nCol, nRow, percentChk, plot = FALSE)
#'
#' @examples
#'
#' \dontrun{
#' layout <- diagLayout(nRow = 25, nCol = 25, percentChk = 0.12, plot = TRUE)
#' }
#' @rdname diagLayout
diagLayout <- function(nCol,nRow,percentChk,plot=FALSE){
  k <- as.integer(1/percentChk)

  if(percentChk%in%c(0.08,0.11,0.14,0.15)){
    if(percentChk == 0.11){l <- 8}
    if(percentChk == 0.14){l <- 3}
    if(percentChk%in%c(0.08,0.15)){l <- 6}
  } else{l <- 4}

  pattern <- c(1,rep(0,k-1))

  tmpnCol <- length(rep(pattern,(nCol/length(pattern))+1))
  layout <- matrix(NA,nRow,(tmpnCol))
  layout[1,] <- rep(pattern,(nCol/length(pattern))+1)

  for(i in c(2:nRow)){
    layout[i,] <- layout[i-1,][c(c(l:tmpnCol,c(1:(l-1))))]
    if(i == nRow){layout <- layout[,1:nCol]}
  }

  layout <- as.data.frame(layout)
  layout <- layout[with(layout, order(as.numeric(rownames(layout)),decreasing = F)),]
  layout <- as.matrix(layout)
  colnames(layout) <- c(1:nCol)
  realPrct<- sum(layout==1)/(sum(layout==1)+sum(layout==0))
  if(plot){
    heatmap(layout,
            Rowv = NA, Colv = NA, scale = "none",
            xlab="field col", ylab="field row", main=paste("check plots",realPrct*100,"%"),
            col = c("white","black"),
            add.expr = abline(h=0.5+c(1:nRow), v=0.5+c(1:nCol)),
            margins = c(3,3))
  }
  return(layout)
}
