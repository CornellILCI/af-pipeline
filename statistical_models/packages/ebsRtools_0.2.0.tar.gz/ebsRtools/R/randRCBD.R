# This function is based on "design.rcbd" function from agricolae 1.3-2 package (Mendiburu, 2020)
# Details which ebs will not use were removed, as the randomization and kinds arguments (present in original agricolae function)
#' @export
#'
#' @importFrom Rdpack reprompt
#'
#' @title  Randomize a RCBD experiment
#' @name randRCBD
#'
#' @description Creates a randomized array of a RCBD experiment  for as many entries and replications ordered. Function based on "design.rcbd" function from agricolae R package \insertCite{agricolae}{ebsRtools}.
#'
#' @references
#'     \insertAllCited{}.
#'
#' @param trt Number of treatments
#' @param r Number of replications (blocks)
#' @param tag Format of plot number tag
#' @param seed Seed for randomization
#' @param continue TRUE or FALSE: continue the plot number sequence between reps
#'
#' @return A list with 2 items.
#' \enumerate{
#'   \item {parameters}{ All design parameters}
#'   \item {book}{ Randomized array, assing entries to plots and plots to replications (block)}
#' }
#'
#' @usage randRCBD(trt, r, tag = 2, seed = 0, continue = FALSE)
#'
#' @examples
#'
#' \dontrun{
#' library(ebsRtools)
#' # run a RCBD for 10 entries in 3 blocks
#' exp1 <- randRCBD(trt = c(1:10), r = 3)
#' exp1}
#'
#' @rdname randRCBD
randRCBD <- function (trt, r, tag = 2, seed = 0, continue = FALSE)
{
  number <- 10
  if (tag > 0)
    number <- 10^tag
  ntr <- length(trt)
  if (seed == 0) {
    genera <- runif(1)
    seed <- .Random.seed[3]
  }
  set.seed(seed)
  parameters <- list(design = "rcbd", trt = trt, r = r,
                     tag = tag, seed = seed)
  mtr <- trt
  mtr <- sample(trt, ntr, replace = FALSE)
  block <- c(rep(1, ntr))
  for (y in 2:r) {
    block <- c(block, rep(y, ntr))
    mtr <- c(mtr, sample(trt, ntr, replace = FALSE))
  }
  plots <- block * number + (1:ntr)
  book <- data.frame(plot_number = plots, replicate = as.factor(block), trt = as.factor(mtr))
  names(book)[3] <- c(paste(deparse(substitute(trt))))
  names(book)[3] <- c(paste(deparse(substitute(trt))))
  if (continue) {
    start0 <- 10^tag
    if (tag == 0)
      start0 <- 0
    book$plot_number <- start0 + 1:nrow(book)
  }
  outdesign <- list(parameters = parameters, book = book)
  return(outdesign)
}
