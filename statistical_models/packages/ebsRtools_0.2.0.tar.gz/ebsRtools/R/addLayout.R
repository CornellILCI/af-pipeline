# This function add a layout to a list of occurrences
# Check ebs documentation
#' @export
#'
#' @importFrom Rdpack reprompt
#'
#' @title Generate a layout for a list of occurrences of an experiment.
#' @name addLayout
#'
#' @description Creates a layout for a given list of occurrences that belong to the same experiment. That is, generates the Design Array assigning X (column) and Y (row) coordinates to each plot, also providing the suggested field layout based on the arguments regarding the field dimensions. This function consumes outputs (grouped in a list) of ebsRtools randomization functions and agricolae package design functions \insertCite{agricolae}{ebsRtools}.
#'
#' @references
#'     \insertAllCited{}.
#'
#' @param trials A list of occurrences provide from the runDesign functions. Even if it is just one occurrence it should be storage in a list of 1
#' @param Vserpentine TRUE or FALSE. FALSE (default) assigns the plots in horizontal serpentine.
#' @param nFieldRow Number of rows in the field, rows are the Y coordinates.
#' @param nPlotsRepBarrier Number of plots until turn the serpentine.
#' @param save TRUE or FALSE. If the layout should be saved in a external csv document.
#' @param outputPath When save is TRUE it string indicates the path where the layout will be saved
#' @param outputFile String to be used as file name in the output
#'
#' @return For each occurrence of ebsRtools randomization (randALPHA, randRCBD, etc) output stored in a list the add.layout function adds an extra item called "layout" that contains a field layout dictated by user input arguments. It also adds the columns of row (Y field coordinate) and column (X field coordinate) to the book of each occurrence.
#' \enumerate{
#'   \item {book}{ Add row and col columns to the book}
#'   \item {layout}{ Generates field layouts showing the plots arranged by X,Y coordinates for 6 different tags: entry, entry name (useful for Augmented designs), role (useful for Augmented designs), block, plots and replication (useful when block and replication are not the same entity e.g. in Alpha-Lattice design)}
#' }
#'
#' @usage add.layout(trials, Vserpentine = F, nFieldRow, nPlotsRepBarrier = NULL, save = F, outputFile = NULL, outputPath = getwd())
#'
#' @examples
#'
#' \dontrun{
#' library(ebsRtools)
#' entry <- c(1:25)
#' reps <- 3
#' trials <- randRCBD(trt=entry, r=reps)
#' a <- add.layout(trials = trials,nFieldRow = 5,nPlotsRepBarrier = 5)
#' a}
#'
#' @rdname addLayout
add.layout <-  function(trials, Vserpentine = F, nFieldRow, nPlotsRepBarrier = NULL, save = F, outputFile =NULL, outputPath = getwd()) {
  layouts <- list()
  n <- length(trials[[1]]$book$plot_number) #number of plots
  c <- ceiling(n/nFieldRow) #number of columns
  t <- length(trials[[1]]$parameters$trt)
  nTrial <- length(trials)
  for(i in 1:nTrial){
    if(!Vserpentine){
      if(is.null(nPlotsRepBarrier)) {nPlotsRepBarrier = c}
      trials[[i]]$book$field_row <- rep(rep(1:nFieldRow, each = nPlotsRepBarrier),len = n)
      if(nPlotsRepBarrier == c){
        trials[[i]]$book$field_col <- rep(c(1:c,c:1),n)[1:n]
      } else {
        trials[[i]]$book$field_col <- rep(rep(c(1:nPlotsRepBarrier,nPlotsRepBarrier:1),n,length=nPlotsRepBarrier*nFieldRow),len=n) + rep(seq(0,c-1,nPlotsRepBarrier),each = (nFieldRow*nPlotsRepBarrier), len = n)
      }
    } else {
      if(is.null(nPlotsRepBarrier)) {nPlotsRepBarrier <- nFieldRow}
      trials[[i]]$book$field_col <- rep(rep(1:c, each = nPlotsRepBarrier),len = n)
      if(nPlotsRepBarrier == nFieldRow){
        trials[[i]]$book$field_row <- rep(c(1:nFieldRow,nFieldRow:1),n)[1:n]
      } else {
        trials[[i]]$book$field_row <- rep(rep(c(1:nPlotsRepBarrier,nPlotsRepBarrier:1),n,length=nPlotsRepBarrier*c),len=n) + rep(seq(0,nFieldRow-1,nPlotsRepBarrier),each = (c*nPlotsRepBarrier), len = n)
      }
    }

    trials[[i]]$book$R_C <- paste(trials[[i]]$book$field_row,"_",trials[[i]]$book$field_col,sep="")
    layout <- list()
    for(l in (setdiff(names(trials[[i]]$book),c("field_row","field_col","cols","R_C")))) {
      sketch <-  matrix(NA,max(trials[[i]]$book$field_row),max(trials[[i]]$book$field_col))
      for(j in 1:nrow(sketch)){
        for(k in 1:ncol(sketch)){
          sketch[j,k] <- ifelse(length(trials[[i]]$book[trials[[i]]$book$R_C %in% paste(j,"_",k,sep=""),l])==0,NA,trials[[i]]$book[trials[[i]]$book$R_C %in% paste(j,"_",k,sep=""),l])
        }
      }
      rownames(sketch) <- c(1:nrow(sketch))
      colnames(sketch) <- c(1:ncol(sketch))
      sketch <- as.data.frame(sketch)
      sketch <- sketch[with(sketch, order(as.numeric(rownames(sketch)),decreasing = T)),]
      layouts[[l]] <- as.matrix(sketch)
      #saving a csv for each layout tag
      if(save){
        write.csv(sketch, file = paste(paste(outputPath, outputFile, sep = "/"),"_Occurr_",i,"_","Layout","_",l,".csv", sep = ""), row.names = T)
      }
    }
    trials[[i]]$layouts <- layouts
    trials[[i]]$book$R_C <- NULL
    trials[[i]]$book$cols <- NULL
  }
  return(trials)
}
