getMidFloorFactor <- function(x) { #UseMethod("getMidFloorFactor") }

#getMidFloorFactor.default <- function(x) {
  factors <- NULL
  for(i in 1:x) {
    if((x %% i) == 0) {
      factors <- c(factors,i)
    }
  }
  
  if(length(factors) %% 2 == 0){
    return(as.numeric(factors[length(factors)/2]))
  } else{
    return(as.numeric(median(factors)))
  }
  
}