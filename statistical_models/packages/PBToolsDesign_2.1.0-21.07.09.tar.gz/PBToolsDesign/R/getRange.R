getRange <- function (index, topToBottom = TRUE, serpentine = FALSE,
                      numRowPerGrp, numColPerGrp, numGrpRow, numGrpCol,numRow, numCol,
                      rowIndexLL, rowIndexUL, colIndexLL, colIndexUL) { #UseMethod("getRange") }

#getRange.default <- function (index, topToBottom = TRUE, serpentine = FALSE,
#                      numRowPerGrp, numColPerGrp, numGrpRow, numGrpCol,numRow, numCol,
#                      rowIndexLL, rowIndexUL, colIndexLL, colIndexUL){
  
  if (topToBottom) {
    
    if(serpentine & numCol != 1){
      
      if (ceiling(index/numGrpRow)%%2 == 0){
        if (index%%numGrpRow != 0) { rowIndex <- index%%numGrpRow 
        } else { rowIndex <- numGrpRow }
        if (rowIndex == 1) { rowIndexUL <- numRow  
        } else { rowIndexUL <- rowIndexUL - numRowPerGrp }
        rowIndexLL <- rowIndexUL - numRowPerGrp + 1
      } else{
        if (index%%numGrpRow != 0) { rowIndex <- index%%numGrpRow 
        } else { rowIndex <- numGrpRow }
        if (rowIndex == 1) { rowIndexLL <- rowIndex  
        } else { rowIndexLL <- rowIndexLL + numRowPerGrp }
        rowIndexUL <- rowIndexLL + numRowPerGrp - 1
      }
      
    } else{
      
      if (index%%numGrpRow != 0) { rowIndex <- index%%numGrpRow 
      } else { rowIndex <- numGrpRow }
      if (rowIndex == 1) { rowIndexLL <- rowIndex  
      } else { rowIndexLL <- rowIndexLL + numRowPerGrp }
      rowIndexUL <- rowIndexLL + numRowPerGrp - 1
      
    }
    
    colIndex <- ceiling(index/numGrpRow)
    colIndexLL <- (colIndex * numColPerGrp) - numColPerGrp + 1
    colIndexUL <- colIndexLL + numColPerGrp - 1
    
  } else {
    
    if(serpentine & numRow != 1){
      
      if (ceiling(index/numGrpCol)%%2 == 0){
        if (index%%numGrpCol != 0) { colIndex <- index%%numGrpCol 
        } else { colIndex <- numGrpCol }
        if (colIndex == 1) { colIndexUL <- numCol } 
        else { colIndexUL <- colIndexUL - numColPerGrp }
        colIndexLL <- colIndexUL - numColPerGrp + 1
      } else{
        if (index%%numGrpCol != 0) { colIndex <- index%%numGrpCol 
        } else { colIndex <- numGrpCol }
        if (colIndex == 1) { colIndexLL <- colIndex  } 
        else { colIndexLL <- colIndexLL + numColPerGrp }
        colIndexUL <- colIndexLL + numColPerGrp - 1
      }
      
    } else{
      
      if (index%%numGrpCol != 0) { colIndex <- index%%numGrpCol 
      } else { colIndex <- numGrpCol }
      if (colIndex == 1) { colIndexLL <- colIndex  } 
      else { colIndexLL <- colIndexLL + numColPerGrp }
      colIndexUL <- colIndexLL + numColPerGrp - 1
      
    }
    
    rowIndex <- ceiling(index/numGrpCol)
    rowIndexLL <- (rowIndex * numRowPerGrp) - numRowPerGrp + 1
    rowIndexUL <- rowIndexLL + numRowPerGrp - 1
    
  }
  
  return(invisible(data.frame(rowIndexLL, rowIndexUL, colIndexLL, colIndexUL)))
  
}
