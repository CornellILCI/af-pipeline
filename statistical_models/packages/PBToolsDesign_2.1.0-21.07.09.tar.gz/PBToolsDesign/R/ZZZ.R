.onAttach <- function(...) {

	packageStartupMessage("\nWelcome to Plant Breeding Tools Design (PBToolsDesign)\n", "Copyright (c) 2021 International Rice Research Institute\n\n")
}

