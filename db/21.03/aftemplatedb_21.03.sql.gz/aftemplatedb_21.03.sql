--
-- PostgreSQL database dump
--

-- Dumped from database version 11.6
-- Dumped by pg_dump version 11.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: af; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA af;


ALTER SCHEMA af OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: analysis; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.analysis (
    name character varying(50),
    description character varying(100),
    prediction_id integer,
    status character varying(50),
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false,
    tenant_id integer,
    id integer DEFAULT nextval(('af."analysis_id_seq"'::text)::regclass) NOT NULL,
    model_id integer,
    request_id integer
);


ALTER TABLE af.analysis OWNER TO postgres;

--
-- Name: COLUMN analysis.name; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.analysis.name IS 'Name of the analysis';


--
-- Name: COLUMN analysis.description; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.analysis.description IS 'Description of the analysis';


--
-- Name: COLUMN analysis.prediction_id; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.analysis.prediction_id IS 'Id of the type of the prediction used in the analysis (Property table)';


--
-- Name: COLUMN analysis.status; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.analysis.status IS 'Status of the analysis ()';


--
-- Name: analysis_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.analysis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.analysis_id_seq OWNER TO postgres;

--
-- Name: job; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.job (
    name character varying(50),
    time_start character varying(50),
    time_end character varying(50),
    output_path character varying(50),
    status character varying(50),
    status_message character varying(50),
    size character varying(50),
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false,
    tenant_id integer,
    id integer DEFAULT nextval(('af."job_id_seq"'::text)::regclass) NOT NULL,
    analysis_id integer
);


ALTER TABLE af.job OWNER TO postgres;

--
-- Name: TABLE job; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON TABLE af.job IS 'Work unit for computation in the analysis. One analysis can have more than one job';


--
-- Name: COLUMN job.name; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.job.name IS 'Name of the job';


--
-- Name: COLUMN job.time_start; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.job.time_start IS 'Timestamp when the job was initiated.';


--
-- Name: COLUMN job.time_end; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.job.time_end IS 'Timestamp when the job was finalized.';


--
-- Name: COLUMN job.output_path; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.job.output_path IS 'Path where the results of the job are saved.';


--
-- Name: COLUMN job.status; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.job.status IS 'Status of the job';


--
-- Name: COLUMN job.status_message; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.job.status_message IS 'Message delivered to the client about the status.';


--
-- Name: COLUMN job.size; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.job.size IS 'Size';


--
-- Name: job_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.job_id_seq OWNER TO postgres;

--
-- Name: property; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.property (
    code character varying(50),
    name character varying(70),
    label character varying(70),
    description character varying(150),
    type character varying(50),
    data_type character varying(50),
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false,
    tenant_id integer,
    id integer DEFAULT nextval(('af."property_id_seq"'::text)::regclass) NOT NULL,
    statement character varying(250)
);


ALTER TABLE af.property OWNER TO postgres;

--
-- Name: TABLE property; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON TABLE af.property IS 'Single element of configuration for an analysis or a design (e.g. model, prediction, error, etc)';


--
-- Name: COLUMN property.code; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property.code IS 'Identifier of the property within its context, the context is found in the property_config table';


--
-- Name: COLUMN property.name; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property.name IS 'Name of the property';


--
-- Name: COLUMN property.label; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property.label IS 'Label displayed to the client';


--
-- Name: COLUMN property.description; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property.description IS 'Detail of the purpose/function of a property.';


--
-- Name: COLUMN property.type; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property.type IS 'Classifier of properties within it s context (e.g. catalog_item, catalog_root)';


--
-- Name: COLUMN property.data_type; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property.data_type IS 'Data type of the property (e.g. csv, character varying, integer, etc.)';


--
-- Name: COLUMN property.statement; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property.statement IS 'A command, instruction, piece of code, etc., associated to the property';


--
-- Name: property_acl; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.property_acl (
    property_item_id integer,
    breeding_program_id integer,
    phase_id integer,
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false,
    tenant_id integer,
    id integer DEFAULT nextval(('af."property_acl_id_seq"'::text)::regclass) NOT NULL,
    property_id integer
);


ALTER TABLE af.property_acl OWNER TO postgres;

--
-- Name: TABLE property_acl; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON TABLE af.property_acl IS 'Access Control List';


--
-- Name: COLUMN property_acl.property_item_id; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_acl.property_item_id IS 'identifier of the property to be filtered.';


--
-- Name: COLUMN property_acl.breeding_program_id; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_acl.breeding_program_id IS 'Breeding program with access to the property.';


--
-- Name: COLUMN property_acl.phase_id; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_acl.phase_id IS 'Identifier of the phase with access to a certain property.';


--
-- Name: property_acl_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.property_acl_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.property_acl_id_seq OWNER TO postgres;

--
-- Name: property_config; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.property_config (
    is_required boolean DEFAULT false,
    order_number integer DEFAULT 1,
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false,
    tenant_id integer,
    id integer DEFAULT nextval(('af."property_config_id_seq"'::text)::regclass) NOT NULL,
    property_id integer,
    config_property_id integer,
    property_ui_id integer,
    is_layout_variable boolean DEFAULT false NOT NULL
);


ALTER TABLE af.property_config OWNER TO postgres;

--
-- Name: TABLE property_config; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON TABLE af.property_config IS 'Provides context to use the properties (e.g. defines the required properties for a design, defines the elements of a catalogs or the output elements of a request)';


--
-- Name: COLUMN property_config.is_required; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_config.is_required IS 'Specify in the property is a required parameter for a design.';


--
-- Name: COLUMN property_config.order_number; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_config.order_number IS 'Defines an arbitrary order for configuration properties.';


--
-- Name: COLUMN property_config.is_layout_variable; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_config.is_layout_variable IS 'Specifies if a property is required to generate a layout in randomizations.';


--
-- Name: property_config_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.property_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.property_config_id_seq OWNER TO postgres;

--
-- Name: property_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.property_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.property_id_seq OWNER TO postgres;

--
-- Name: property_meta; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.property_meta (
    id integer DEFAULT nextval(('af."property_meta_id_seq"'::text)::regclass) NOT NULL,
    code character varying(30) NOT NULL,
    value character varying(255) NOT NULL,
    tenant_id integer,
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false,
    property_id integer NOT NULL
);


ALTER TABLE af.property_meta OWNER TO postgres;

--
-- Name: TABLE property_meta; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON TABLE af.property_meta IS 'Stores additional information of a property';


--
-- Name: COLUMN property_meta.code; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_meta.code IS 'Code of the property';


--
-- Name: COLUMN property_meta.value; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_meta.value IS 'Value of the property metadata';


--
-- Name: property_meta_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.property_meta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.property_meta_id_seq OWNER TO postgres;

--
-- Name: property_rule; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.property_rule (
    type character varying(50),
    expression character varying(100),
    "group" integer DEFAULT 0,
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false,
    tenant_id integer,
    id integer DEFAULT nextval(('af."property_rule_id_seq"'::text)::regclass) NOT NULL,
    property_id integer,
    property_config_id integer,
    order_number integer NOT NULL,
    notification character varying(255),
    action character varying(50)
);


ALTER TABLE af.property_rule OWNER TO postgres;

--
-- Name: TABLE property_rule; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON TABLE af.property_rule IS 'Defines custom validation rules for a property value (e.g. defines if a property is required based on the value of another property) The property rule is associated to the property_config.';


--
-- Name: COLUMN property_rule.type; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_rule.type IS 'Classifier of the rule (e.g. required if, allow value, etc.)';


--
-- Name: COLUMN property_rule.expression; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_rule.expression IS 'Definition of the rule to be applied.';


--
-- Name: COLUMN property_rule."group"; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_rule."group" IS 'Allows to group several rules as a singular composite rule.';


--
-- Name: property_rule_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.property_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.property_rule_id_seq OWNER TO postgres;

--
-- Name: property_ui; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.property_ui (
    is_visible boolean DEFAULT true,
    minimum integer,
    maximum integer,
    unit character varying(50),
    "default" character varying(50),
    is_disabled boolean DEFAULT false,
    is_multiple boolean DEFAULT false,
    is_catalogue boolean DEFAULT false,
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false,
    tenant_id integer,
    id integer DEFAULT nextval(('af."property_ui_id_seq"'::text)::regclass) NOT NULL
);


ALTER TABLE af.property_ui OWNER TO postgres;

--
-- Name: TABLE property_ui; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON TABLE af.property_ui IS 'Defines the behavior of a user interface component when its associated to a property';


--
-- Name: COLUMN property_ui.is_visible; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_ui.is_visible IS 'Set the property visible/invisible in the interface';


--
-- Name: COLUMN property_ui.minimum; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_ui.minimum IS 'Minimum value for a numeric property';


--
-- Name: COLUMN property_ui.maximum; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_ui.maximum IS 'Maximum value for a numeric property.';


--
-- Name: COLUMN property_ui.unit; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_ui.unit IS 'Defines the unit type of numeric properties. ';


--
-- Name: COLUMN property_ui."default"; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_ui."default" IS 'Default value of a property.';


--
-- Name: COLUMN property_ui.is_disabled; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_ui.is_disabled IS 'Defines if the property is disabled fro the user.';


--
-- Name: COLUMN property_ui.is_multiple; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_ui.is_multiple IS 'Defines if the property has more than one value (e.g define multiple error values for a single request)';


--
-- Name: COLUMN property_ui.is_catalogue; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.property_ui.is_catalogue IS 'Defines if the property is displayed in the user interface as a select list.';


--
-- Name: property_ui_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.property_ui_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.property_ui_id_seq OWNER TO postgres;

--
-- Name: request; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.request (
    uuid character varying(50),
    category character varying(50),
    type character varying(50),
    design character varying(50),
    requestor_id character varying(50),
    institute character varying(50),
    crop character varying(50),
    program character varying(50),
    status character varying(50),
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false,
    tenant_id integer,
    id integer DEFAULT nextval(('af."request_id_seq"'::text)::regclass) NOT NULL,
    method_id integer,
    engine character varying(20)
);


ALTER TABLE af.request OWNER TO postgres;

--
-- Name: TABLE request; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON TABLE af.request IS 'Stores the requests to execute a function of the analytical framework.';


--
-- Name: COLUMN request.uuid; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request.uuid IS 'Universal Unique Identifier for the request.';


--
-- Name: COLUMN request.category; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request.category IS 'Defines if the request is for a randomization or for an analysis.';


--
-- Name: COLUMN request.type; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request.type IS 'Subcategory of the request (e.g. trial design)';


--
-- Name: COLUMN request.design; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request.design IS 'Specific design of the request';


--
-- Name: COLUMN request.requestor_id; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request.requestor_id IS 'Identifier of the person that made the request.';


--
-- Name: COLUMN request.institute; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request.institute IS 'Name of the Institute where the request is coming from';


--
-- Name: COLUMN request.crop; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request.crop IS 'Crop of the request.';


--
-- Name: COLUMN request.program; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request.program IS 'Program of the request';


--
-- Name: COLUMN request.status; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request.status IS 'Status of the request, it can be New, Processed and Expired.';


--
-- Name: COLUMN request.engine; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request.engine IS 'Version of the R Engine to use in the request.';


--
-- Name: request_entry; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.request_entry (
    experiment_id integer NOT NULL,
    entry_id integer,
    tenant_id integer,
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false NOT NULL,
    id integer DEFAULT nextval(('af."request_entry_id_seq"'::text)::regclass) NOT NULL,
    request_id integer NOT NULL,
    entry_number integer
);


ALTER TABLE af.request_entry OWNER TO postgres;

--
-- Name: TABLE request_entry; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON TABLE af.request_entry IS 'Entries of a request';


--
-- Name: COLUMN request_entry.experiment_id; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request_entry.experiment_id IS 'Experiment id associated to the entries';


--
-- Name: COLUMN request_entry.entry_id; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request_entry.entry_id IS 'Entry_ids coming from b4r to be used in the analysis.';


--
-- Name: COLUMN request_entry.entry_number; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON COLUMN af.request_entry.entry_number IS 'Entry number coming from b4r.';


--
-- Name: request_entry_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.request_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.request_entry_id_seq OWNER TO postgres;

--
-- Name: request_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.request_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.request_id_seq OWNER TO postgres;

--
-- Name: request_parameter; Type: TABLE; Schema: af; Owner: postgres
--

CREATE TABLE af.request_parameter (
    value character varying(100),
    creation_timestamp timestamp without time zone DEFAULT now(),
    modification_timestamp timestamp without time zone,
    creator_id character varying(50),
    modifier_id character varying(50),
    is_void boolean DEFAULT false,
    tenant_id integer,
    id integer DEFAULT nextval(('af."request_parameter_id_seq"'::text)::regclass) NOT NULL,
    property_id integer,
    request_id integer
);


ALTER TABLE af.request_parameter OWNER TO postgres;

--
-- Name: TABLE request_parameter; Type: COMMENT; Schema: af; Owner: postgres
--

COMMENT ON TABLE af.request_parameter IS 'Parameter of the request that are provided to the AEO (Analysis Execute Object).';


--
-- Name: request_parameter_id_seq; Type: SEQUENCE; Schema: af; Owner: postgres
--

CREATE SEQUENCE af.request_parameter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE af.request_parameter_id_seq OWNER TO postgres;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO postgres;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO postgres;

--
-- Data for Name: analysis; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.analysis (name, description, prediction_id, status, creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, tenant_id, id, model_id, request_id) FROM stdin;
\.


--
-- Data for Name: job; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.job (name, time_start, time_end, output_path, status, status_message, size, creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, tenant_id, id, analysis_id) FROM stdin;
\.


--
-- Data for Name: property; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.property (code, name, label, description, type, data_type, creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, tenant_id, id, statement) FROM stdin;
objective	Objective	Objective	Objective	catalog_root	character varying	\N	\N	\N	\N	f	\N	1	\N
trait_pattern	Trait Pattern	Trait Analysis Pattern	Trait Analysis Pattern	catalog_root	character varying	\N	\N	\N	\N	f	\N	2	\N
exptloc_analysis_pattern	Exp Loc Analysis Pattern	Experiment/Location Analysis Pattern	Experiment/Location Analysis Pattern	catalog_root	character varying	\N	\N	\N	\N	f	\N	3	\N
model	Design Model	Model	Model configuration	catalog_root	character varying	\N	\N	\N	\N	f	\N	4	\N
prediction	Prediction	Prediction	Prediction	catalog_root	character varying	\N	\N	\N	\N	f	\N	5	\N
error	Error	Error	Error	catalog_root	character varying	\N	\N	\N	\N	f	\N	6	\N
obj_pred	Prediction	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	7	\N
uv	Univariate	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	10	\N
bv	Bivariate	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	11	\N
cv	Covariate	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	12	\N
mt	Multi trait	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	13	\N
se	Series	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	14	\N
SESL	Single Experiment - Single Location	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	15	\N
SEML	Single Experiment - Multiple Location	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	16	\N
MESL	Multiple Experiment - Single Location	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	17	\N
MEML	Multiple Experiment - Multiple Location	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	18	\N
gxt	GxT	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	21	\N
gxm	GxM	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	22	\N
AR1XAR1_2_0	AR1XAR1_2_0	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	23	\N
AR1XAR1_0_0	AR1XAR1_0_0	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	24	\N
NO_AR1XAR1_ID	NO_AR1XAR1_ID	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	25	\N
NO_AR1XAR1	NO_AR1XAR1	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	26	\N
nFieldRow	ROW	Rows	Total number of rows	input	integer	\N	\N	\N	\N	f	\N	69	\N
outputPath	OUTPUT_PATH	Output Path	Path where output will be saved	input	character varying	\N	\N	\N	\N	f	\N	73	\N
StatisticalDesignArray	StatisticalDesignArray	Statistical design array file	contains the arrangement of the treatments in the 	output	csv	\N	\N	\N	\N	f	\N	98	\N
TrmtLayout	TrmtLayout	Treatment arrangement file	contains the arrangement of the treatments per loc	output	csv	\N	\N	\N	\N	f	\N	101	\N
nRowPerBlk	NO_OF_ROWS_PER_BLOCK	No. of rows per block	Number of rows per block	input	integer	\N	\N	\N	\N	f	\N	111	\N
nRowBlk	ROW_BLOCK	No. of Row Blocks	Number of row blocks	input	integer	\N	\N	\N	\N	f	\N	112	\N
nCheckTreatment	ENTRY_COUNT_CONT	No. of Check Entries	Number of Check entries	input	integer	\N	\N	\N	\N	f	\N	113	\N
nTestTreatment	ENTRY_COUNT_CONT	No. of Test Entries	Number of test entries	input	integer	\N	\N	\N	\N	f	\N	114	\N
BlockLayout	BlockLayout	Block arrangement file (Layout)	contains the arrangement of the blocks within repl	output	csv	\N	\N	\N	\N	f	\N	115	\N
RowBlockLayout	RowBlockLayout	Row Block arrangement file (Layout)	contains the arrangement of the row blocks within 	output	csv	\N	\N	\N	\N	f	\N	116	\N
ColumnBlockLayout	ColumnBlockLayout	Column Block arrangement file (Layout)	contains the arrangement of the column blocks with	output	csv	\N	\N	\N	\N	f	\N	117	\N
LayoutBlock	LayoutBlock	Block arrangement file (Layout)	contains the arrangement of the blocks within repl	output	csv	\N	\N	\N	\N	f	\N	124	\N
rand1	FLD_ORDER	Randomize the 1st rep	Whether the first rep should be randomized	input	boolean	\N	\N	\N	\N	f	\N	128	\N
experimentId	EXPT_ID	Experiment Id	\N	request_meta	integer	\N	\N	\N	\N	f	\N	130	\N
g	G	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	19	entry !PRESENT entry !SED !TDIFF
gxe	Gx	\N	\N	catalog_item	integer	\N	\N	\N	\N	f	\N	20	loc.entry !PRESENT loc entry !SED !TDIFF
nTrial	OCCURRENCES	No. of Occurrences	Number of occurrances within the experiment	input	integer	\N	\N	\N	\N	f	\N	65	\N
nRep	REPLICATION_BLOCK	No. of Replicates	Number of replicates	input	integer	\N	\N	\N	\N	f	\N	67	\N
nRowPerRep	NO_OF_ROWS_PER_REPLICATE	No. of rows per rep	Number of rows per replicate	input	integer	\N	\N	\N	\N	f	\N	70	\N
nBlk	REPLICATION_BLOCK	No. of Blocks per Rep	Number of blocks per rep	input	integer	\N	\N	\N	\N	f	\N	110	\N
entryList	ENTRY_LIST	Entry List	CSV file with the entries information	input	string	\N	\N	\N	\N	f	\N	66	\N
genLayout	genLayout	Define Shape/Dimension	Define rows and columns along with the design	input	boolean	\N	\N	\N	\N	f	\N	68	\N
randALPHALATTICEcimmyt	Alpha-Lattice	Alpha-Lattice | CIMMYT	\N	catalog_item	integer	\N	\N	\N	\N	f	2	118	\N
randALPHALATTICEcimmytWHEAT	Alpha-Lattice	IWIN Design	\N	catalog_item	integer	\N	\N	\N	\N	f	2	119	\N
randRCBDcimmyt	RCBD	RCBD | CIMMYT	\N	catalog_item	integer	\N	\N	\N	\N	f	2	120	\N
randRCBDirri	RCBD	RCBD	\N	catalog_item	integer	\N	\N	\N	\N	f	1	8	\N
randALPHALATTICEirri	Alpha-Lattice	Alpha-Lattice	\N	catalog_item	integer	\N	\N	\N	\N	f	1	9	\N
randROWCOLUMNirri	Row-Column	Row-Column	\N	catalog_item	integer	2020-04-27 13:38:21.654	\N	\N	\N	f	2	38	\N
randAUGMENTEDRCBDirri	Augmented RCB	Augmented RCB	\N	catalog_item	integer	2020-04-27 13:38:21.654	\N	\N	\N	f	2	39	\N
LayoutPlots	LayoutPlots	Plot number arrangement file (Layout)	contains the arrangement of the plot numbers in a location rep, if genLayout is TRUE	output	csv	\N	\N	\N	\N	f	\N	125	\N
LayoutRep	LayoutRep	Replication arrangement file	contains the arrangement of the replicates (super-block) in a location rep , if genLayout is TRUE	output	csv	\N	\N	\N	\N	f	\N	126	\N
LayoutEntry	LayoutEntry	Treatment arrangement file	contains the arrangement of the treatments (entries) per location rep, if genLayout is TRUE	output	csv	\N	\N	\N	\N	f	\N	127	\N
Vserpentine	FLD_ORDER	Field Order	Whether plots will be assing in Vertical serpentine arrangement or Horizontal	input	boolean	\N	\N	\N	\N	f	\N	123	\N
outputFile	OUTPUT_FIL	Output File	Prefix to be used for the names of the output files	input	character varying	\N	\N	\N	\N	f	\N	72	\N
designInfo	designInfo	Design information file	contains information on the parameters used to generate the randomization	output	txt	\N	\N	\N	\N	f	\N	97	\N
PlotNumLayout	PlotNumLayout	Plot number arrangement file (Layout)	contains the arrangement of the plot numbers in a location rep, if genLayout is TRUE	output	csv	\N	\N	\N	\N	f	\N	99	\N
RepLayout	RepLayout	Replication arrangement file	contains the arrangement of the replicates in a location rep , if genLayout is TRUE	output	csv	\N	\N	\N	\N	f	\N	100	\N
fieldbook	fieldbook	Randomization Fieldbook file	spreadsheet file showing the result of  the randomization (and layout, if generated)	output	csv	\N	\N	\N	\N	f	\N	96	\N
occurrenceId	OCC_ID	Occurrence Id	\N	request_meta	integer	\N	\N	\N	\N	f	\N	131	\N
entryListName	ENT_LST_NAME	Entry List Name	\N	request_meta	character varying	\N	\N	\N	\N	f	\N	132	\N
RandOcc	RAND_OCC	Randomize each occurrence	Whether run a randomization for each occurrence or use the same randomization for all of them	input	boolean	2021-04-22 23:21:07.474128	\N	\N	\N	f	\N	133	\N
sBlk	BLOCK_SIZE	No. of plots per block	Block size, it is the number of plots per block. Consider using several small blocks instead of a few large blocks	input	integer	\N	\N	\N	\N	f	\N	121	\N
nPlotBarrier	ROW	Plots until turn the serpentine	Number of plots until turn the serpentine, it will follow the same direction of the serpentine (horizontal or vertical)	input	integer	\N	\N	\N	\N	f	\N	122	\N
serpentine	FLD_ORDER	Field Order	Plot arrangement	input	boolean	\N	\N	\N	\N	f	\N	71	\N
analysis_module_fields	Analysis Module Fields	Analysis Module Fields	Analysis Module Fields	catalog_root	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	159	\N
loc	\N	\N	\N	catalog_item	!A	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	160	\N
expt	\N	\N	\N	catalog_item	!A	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	161	\N
entry	\N	\N	\N	catalog_item	!A	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	162	\N
plot	\N	\N	\N	catalog_item	!A	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	163	\N
col	\N	\N	\N	catalog_item	!I	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	164	\N
row	\N	\N	\N	catalog_item	!I	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	165	\N
rep	\N	\N	\N	catalog_item	!A	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	166	\N
block	\N	\N	\N	catalog_item	!A	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	167	\N
analysis_config	Analysis Configuration	Analysis Configuration	Analysis Configuration	catalog_root	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	134	\N
asrmel_options	ASRMEL Options	ASRMEL Options	ASRMEL Options	catalog_root	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	137	\N
tabulate	Tabulate	Tabulate	Tabulate	catalog_root	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	138	\N
formula	Formula	Formula	Formula	catalog_root	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	139	\N
residual	Residual	Residual	Residual	catalog_root	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	140	\N
config_00001.cfg	RCBD univariate	RCBD univariate	RCBD single loc, single year and univariate trial with options for spatial adjustment	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	142	\N
config_00002.cfg	RCBD multi-location univariate	RCBD multi-location univariate	RCBD multi-location and univariate trial with options for spatial adjustment	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	143	\N
config_00003.cfg	Alpha-Lattice univariate	Alpha-Lattice univariate	Alpha-Lattice single loc, single year and univariate trial with options for spatial adjustment	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	144	\N
config_00004.cfg	Alpha-Lattice multi-location univariate	Alpha-Lattice multi-location univariate	Alpha-Lattice multi-location and univariate trial with options for spatial adjustment	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	145	\N
asrmel_opt1	\N	\N	\N	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	146	!CSV !SKIP 1 !AKAIKE !NODISPLAY 1 !MVINCLUDE !MAXIT 250 !EXTRA 10 !TXTFORM 1 !FCON !SUM !OUTLIER
tabulate_opt1	trait by entry	trait by entry	\N	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	147	{trait_name} ~ entry
formula_opt1	RCBD SESL Univariate entry as random	RCBD SESL Univariate entry as random	\N	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	148	{trait_name} ~ mu rep !r entry !f mv
formula_opt2	RCBD SEML Univariate	RCBD SEML Univariate	\N	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	149	{trait_name} ~ mu rep loc !r entry entry.loc loc.rep !f mv
formula_opt3	Alpha-Lattice single location, univariate, entry as random factor	Alpha-Lattice single location, univariate, entry as random factor	\N	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	150	{trait_name} mu rep !r entry rep.block !f mv
formula_opt4	Alpha-Lattice MET Univariate	Alpha-Lattice MET Univariate	\N	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	151	{trait_name} ~ mu loc loc.rep !r loc.rep.block entry entry.loc !f mv
residual_opt1	(AR1row x AR1col)	(AR1row x AR1col)	Autoregressive order 1 spatial structure (AR1row x AR1col)	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	152	ar1(row).ar1(col)
residual_opt2	(IDrow x AR1col)	(IDrow x AR1col)	Autoregressive order 1 spatial structure for columns (IDrow x AR1col)	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	153	idv(row).ar1(col)
residual_opt3	(AR1row x IDcol)	(AR1row x IDcol)	Autoregressive order 1 spatial structure for rows (AR1row x IDcol)	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	154	ar1(row).idv(col)
residual_opt4	No spatial adjustment	No spatial adjustment	\N	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	155	\N
residual_opt5	(AR1row x AR1col) by location	(AR1row x AR1col) by location	Autoregressive order 1 spatial structure (AR1row x AR1col), by location	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	156	sat(loc).idv(row).ar1(col)
residual_opt6	(IDrow x AR1col) by location	(IDrow x AR1col) by location	Autoregressive order 1 spatial structure for columns (IDrow x AR1col), by location	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	157	sat(loc).idv(row).ar1(col)
residual_opt7	(AR1row x IDcol) by location	(AR1row x IDcol) by location	Autoregressive order 1 spatial structure for rows (AR1row x IDcol), by location	catalog_item	character varying	2021-04-22 23:21:08.904814	\N	\N	\N	f	\N	158	sat(loc).ar1(row).idv(col)
\.


--
-- Data for Name: property_acl; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.property_acl (property_item_id, breeding_program_id, phase_id, creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, tenant_id, id, property_id) FROM stdin;
\.


--
-- Data for Name: property_config; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.property_config (is_required, order_number, creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, tenant_id, id, property_id, config_property_id, property_ui_id, is_layout_variable) FROM stdin;
t	1	2020-05-06 10:01:32.659649	\N	1	\N	f	\N	1	1	1	1	f
t	1	2020-05-06 10:01:32.659649	\N	1	\N	f	\N	2	2	2	2	f
t	1	2020-05-06 10:01:32.659649	\N	1	\N	f	\N	3	3	3	3	f
t	1	2020-05-06 10:01:32.659649	\N	1	\N	f	\N	4	4	4	4	f
t	1	2020-05-06 10:01:32.659649	\N	1	\N	f	\N	5	5	5	5	f
t	1	2020-05-06 10:01:32.659649	\N	1	\N	f	\N	6	6	6	6	f
f	1	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	7	1	7	1	f
f	1	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	8	2	10	\N	f
f	2	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	9	2	11	\N	f
f	3	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	10	2	12	\N	f
f	4	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	11	2	13	\N	f
f	5	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	12	2	14	\N	f
f	1	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	13	3	15	\N	f
f	2	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	14	3	16	\N	f
f	3	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	15	3	17	\N	f
f	4	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	16	3	18	\N	f
f	1	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	17	4	8	\N	f
f	2	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	18	4	9	\N	f
f	3	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	19	4	38	\N	f
f	4	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	20	4	39	\N	f
f	1	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	21	5	19	\N	f
f	2	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	22	5	20	\N	f
f	3	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	23	5	21	\N	f
f	4	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	24	5	22	\N	f
f	1	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	25	6	23	\N	f
f	2	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	26	6	24	\N	f
f	3	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	27	6	25	\N	f
f	4	2020-05-06 10:24:28.710509	\N	1	\N	f	\N	28	6	26	\N	f
t	3	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	63	8	67	9	f
t	4	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	64	8	68	10	f
t	1	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	71	8	96	\N	f
t	2	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	72	8	97	\N	f
t	3	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	73	8	98	\N	f
t	4	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	74	8	99	\N	f
t	5	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	75	8	100	\N	f
t	6	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	76	8	101	\N	f
t	2	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	77	9	66	17	f
t	3	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	78	9	67	18	f
t	5	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	79	9	68	20	f
t	4	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	85	9	110	19	f
t	1	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	87	9	96	\N	f
t	2	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	88	9	97	\N	f
t	3	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	89	9	98	\N	f
t	4	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	90	9	115	\N	f
t	5	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	91	9	99	\N	f
t	6	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	92	9	100	\N	f
t	7	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	93	9	101	\N	f
t	1	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	94	38	65	27	f
t	2	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	95	38	66	28	f
t	3	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	96	38	67	29	f
t	5	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	97	38	68	31	f
t	4	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	99	38	112	30	f
t	1	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	103	38	96	\N	f
t	2	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	104	38	97	\N	f
t	3	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	105	38	98	\N	f
t	4	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	106	38	99	\N	f
t	5	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	107	38	100	\N	f
t	6	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	108	38	101	\N	f
t	7	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	109	38	116	\N	f
t	8	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	110	38	117	\N	f
t	1	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	111	39	65	36	f
t	4	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	112	39	67	39	f
t	5	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	113	39	68	40	f
t	1	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	121	39	96	\N	f
t	2	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	122	39	97	\N	f
t	3	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	123	39	98	\N	f
t	4	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	124	39	99	\N	f
t	5	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	125	39	100	\N	f
t	6	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	126	39	101	\N	f
t	1	2020-05-08 04:18:20.463536	\N	1	\N	f	\N	127	118	65	46	f
t	2	2020-05-08 04:18:20.527963	\N	1	\N	f	\N	128	118	66	47	f
t	3	2020-05-08 04:18:20.591452	\N	1	\N	f	\N	129	118	67	48	f
t	4	2020-05-08 04:18:20.654985	\N	1	\N	f	\N	130	118	121	49	f
t	5	2020-05-08 04:18:20.712084	\N	1	\N	f	\N	131	118	68	50	f
t	1	2020-05-08 04:18:21.032683	\N	1	\N	f	\N	137	118	96	\N	f
t	2	2020-05-08 04:18:21.088955	\N	1	\N	f	\N	138	118	97	\N	f
t	3	2020-05-08 04:18:21.14754	\N	1	\N	f	\N	139	118	124	\N	f
t	4	2020-05-08 04:18:21.222166	\N	1	\N	f	\N	140	118	125	\N	f
t	5	2020-05-08 04:18:21.278981	\N	1	\N	f	\N	141	118	126	\N	f
t	1	2020-05-05 18:01:26	\N	1	\N	f	\N	70	9	65	16	f
t	1	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	61	8	65	7	f
t	2	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	62	8	66	8	f
t	7	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	67	8	71	13	t
f	8	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	80	9	69	23	t
t	7	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	81	9	70	22	t
t	9	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	82	9	71	24	t
t	6	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	86	9	111	21	t
f	6	2020-05-08 04:18:20.769203	\N	1	\N	f	\N	132	118	69	51	t
f	6	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	98	38	69	32	t
t	7	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	100	38	71	33	t
t	2	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	119	39	66	37	f
t	8	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	116	39	71	43	t
t	6	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	115	39	70	42	t
t	7	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	114	39	69	41	t
t	6	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	65	8	69	11	t
t	5	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	66	8	70	12	t
f	8	2020-05-08 04:18:20.828501	\N	1	\N	f	\N	133	118	122	52	t
t	7	2020-05-08 04:18:20.879662	\N	1	\N	f	\N	134	118	123	53	t
t	6	2020-05-08 04:18:21.355767	\N	1	\N	f	\N	142	118	127	\N	f
t	1	2020-05-08 04:26:19.623602	\N	1	\N	f	\N	143	119	65	56	f
t	2	2020-05-08 04:26:19.688013	\N	1	\N	f	\N	144	119	66	57	f
t	3	2020-05-08 04:26:19.746604	\N	1	\N	f	\N	145	119	67	58	f
t	4	2020-05-08 04:26:19.801966	\N	1	\N	f	\N	146	119	121	59	f
t	1	2020-05-08 04:26:20.258033	\N	1	\N	f	\N	154	119	96	\N	f
t	2	2020-05-08 04:26:20.320629	\N	1	\N	f	\N	155	119	97	\N	f
t	3	2020-05-08 04:26:20.376154	\N	1	\N	f	\N	156	119	124	\N	f
t	4	2020-05-08 04:26:20.433259	\N	1	\N	f	\N	157	119	125	\N	f
t	5	2020-05-08 04:26:20.484933	\N	1	\N	f	\N	158	119	126	\N	f
t	6	2020-05-08 04:26:20.54294	\N	1	\N	f	\N	159	119	127	\N	f
t	1	2020-05-08 04:36:24.22595	\N	1	\N	f	\N	160	120	65	67	f
t	2	2020-05-08 04:36:24.288933	\N	1	\N	f	\N	161	120	66	68	f
t	3	2020-05-08 04:36:24.339761	\N	1	\N	f	\N	162	120	67	69	f
t	4	2020-05-08 04:36:24.403205	\N	1	\N	f	\N	163	120	68	70	f
t	8	2020-05-08 04:36:24.627829	\N	1	\N	f	\N	167	120	128	74	f
t	1	2020-05-08 04:36:24.814428	\N	1	\N	f	\N	170	120	96	\N	f
t	2	2020-05-08 04:36:24.872988	\N	1	\N	f	\N	171	120	97	\N	f
t	3	2020-05-08 04:36:24.929998	\N	1	\N	f	\N	172	120	125	\N	f
t	4	2020-05-08 04:36:24.987216	\N	1	\N	f	\N	173	120	124	\N	f
t	5	2020-05-08 04:36:25.038036	\N	1	\N	f	\N	174	120	127	\N	f
f	5	2020-05-08 11:54:52.763361	\N	1	\N	f	\N	175	4	118	\N	f
f	6	2020-05-08 11:54:52.840587	\N	1	\N	f	\N	176	4	119	\N	f
f	7	2020-05-08 11:54:52.89629	\N	1	\N	f	\N	177	4	120	\N	f
f	8	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	68	8	72	14	f
f	9	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	69	8	73	15	f
f	10	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	83	9	72	25	f
f	11	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	84	9	73	26	f
f	8	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	101	38	72	34	f
f	9	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	102	38	73	35	f
f	9	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	117	39	72	44	f
f	10	2020-05-05 18:01:26.598593	\N	1	\N	f	\N	118	39	73	45	f
f	9	2020-05-08 04:18:20.930759	\N	1	\N	f	\N	135	118	72	54	f
f	10	2020-05-08 04:18:20.982546	\N	1	\N	f	\N	136	118	73	55	f
f	9	2020-05-08 04:36:24.682547	\N	1	\N	f	\N	168	120	72	75	f
f	10	2020-05-08 04:36:24.743379	\N	1	\N	f	\N	169	120	73	76	f
t	5	2020-05-08 04:36:24.463011	\N	1	\N	f	\N	164	120	69	71	t
f	11	2020-05-08 04:26:20.153808	\N	1	\N	f	\N	152	119	72	65	f
f	12	2020-05-08 04:26:20.204926	\N	1	\N	f	\N	153	119	73	66	f
t	7	2020-05-08 04:26:19.871626	\N	1	\N	f	\N	147	119	68	60	f
f	8	2020-05-08 04:26:19.933983	\N	1	\N	f	\N	148	119	69	61	t
f	10	2020-05-08 04:26:19.987132	\N	1	\N	f	\N	149	119	122	62	t
t	6	2021-04-22 23:21:07.474128	\N	1	\N	f	\N	178	119	133	77	f
t	9	2020-05-08 04:26:20.096482	\N	1	\N	f	\N	151	119	123	64	t
t	7	2020-05-08 04:36:24.517517	\N	1	\N	f	\N	165	120	122	72	t
t	6	2020-05-08 04:36:24.56831	\N	1	\N	f	\N	166	120	123	73	t
t	5	2020-05-08 04:26:20.044085	\N	1	\N	f	\N	150	119	128	63	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	179	159	159	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	180	159	160	\N	f
f	2	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	181	159	161	\N	f
f	3	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	182	159	162	\N	f
f	4	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	183	159	163	\N	f
f	5	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	184	159	164	\N	f
f	6	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	185	159	165	\N	f
f	7	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	186	159	166	\N	f
f	8	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	187	159	167	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	188	134	142	\N	f
f	2	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	189	134	143	\N	f
f	3	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	190	134	144	\N	f
f	4	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	191	134	145	\N	f
f	7	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	192	134	134	\N	f
f	7	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	193	137	137	\N	f
f	8	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	194	138	138	\N	f
f	9	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	195	139	139	\N	f
f	10	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	196	140	140	\N	f
f	9	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	197	142	160	\N	f
f	10	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	198	142	161	\N	f
f	11	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	199	142	162	\N	f
f	12	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	200	142	163	\N	f
f	13	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	201	142	164	\N	f
f	14	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	202	142	165	\N	f
f	15	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	203	142	166	\N	f
f	10	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	204	143	160	\N	f
f	11	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	205	143	161	\N	f
f	12	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	206	143	162	\N	f
f	13	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	207	143	163	\N	f
f	14	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	208	143	164	\N	f
f	15	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	209	143	165	\N	f
f	16	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	210	143	166	\N	f
f	9	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	211	144	160	\N	f
f	10	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	212	144	161	\N	f
f	11	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	213	144	162	\N	f
f	12	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	214	144	163	\N	f
f	13	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	215	144	164	\N	f
f	14	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	216	144	165	\N	f
f	15	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	217	144	166	\N	f
f	16	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	218	144	167	\N	f
f	10	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	219	145	160	\N	f
f	11	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	220	145	161	\N	f
f	12	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	221	145	162	\N	f
f	13	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	222	145	163	\N	f
f	14	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	223	145	164	\N	f
f	15	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	224	145	165	\N	f
f	16	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	225	145	166	\N	f
f	17	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	226	145	167	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	227	137	146	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	228	138	147	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	229	139	148	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	230	139	149	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	231	139	150	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	232	139	151	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	233	140	152	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	234	140	153	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	235	140	154	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	236	140	155	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	237	140	156	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	238	140	157	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	239	140	158	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	240	142	146	\N	f
f	2	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	241	142	147	\N	f
f	3	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	242	142	148	\N	f
f	4	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	243	142	152	\N	f
f	5	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	244	142	153	\N	f
f	6	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	245	142	154	\N	f
f	7	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	246	142	155	\N	f
f	8	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	247	142	19	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	248	143	146	\N	f
f	2	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	249	143	147	\N	f
f	3	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	250	143	149	\N	f
f	4	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	251	143	156	\N	f
f	5	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	252	143	157	\N	f
f	6	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	253	143	158	\N	f
f	7	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	254	143	155	\N	f
f	8	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	255	143	19	\N	f
f	9	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	256	143	20	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	257	144	146	\N	f
f	2	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	258	144	147	\N	f
f	3	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	259	144	150	\N	f
f	4	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	260	144	152	\N	f
f	5	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	261	144	153	\N	f
f	6	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	262	144	154	\N	f
f	7	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	263	144	155	\N	f
f	8	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	264	144	19	\N	f
f	1	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	265	145	146	\N	f
f	2	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	266	145	147	\N	f
f	3	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	267	145	151	\N	f
f	4	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	268	145	156	\N	f
f	5	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	269	145	157	\N	f
f	6	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	270	145	158	\N	f
f	7	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	271	145	155	\N	f
f	8	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	272	145	19	\N	f
f	9	2021-04-22 23:21:08.904814	\N	1	\N	f	\N	273	145	20	\N	f
\.


--
-- Data for Name: property_meta; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.property_meta (id, code, value, tenant_id, creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, property_id) FROM stdin;
1	Rversion	3.4.4	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	118
3	author	Pedro Barbosa | Alaine Gulles | Rose Imee Zhella Morantte	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	118
4	email	p.medeiros@cgiar.org	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	118
5	syntax	Rscript randALPHALATTICEcimmyt.R -e ALPHA_cimmyt_SD_0001.lst --nRep 2 --sBlk 4 --nTrial 2 --genLayout T --nFieldRow 6 --nPlotBarrier 4 --Vserpentine F	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	118
6	engine	R 3.4.4	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	118
7	modelVersion	2	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	118
8	organization_code	CIMMYT	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	118
9	note	Inherent design restrictions apply	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	118
10	Rversion	3.4.4	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	119
12	author	Pedro Barbosa | Alaine Gulles | Rose Imee Zhella Morantte	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	119
13	email	p.medeiros@cgiar.org	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	119
14	syntax	Rscript randALPHALATTICEcimmytWHEAT.R -e ALPHA_cimmyt_wheat_SD_0001.lst --nRep 2 --sBlk 4 --nTrial 2 --genLayout T --nFieldRow 6 --nPlotBarrier 4 --rand1 F --RandOcc T --Vserpentine F	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	119
15	engine	R 3.4.4	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	119
16	modelVersion	2	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	119
17	organization_code	CIMMYT	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	119
18	note	Inherent design restrictions apply	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	119
19	Rversion	3.4.4	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	120
21	author	Pedro Barbosa | Alaine Gulles | Rose Imee Zhella Morantte	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	120
22	email	p.medeiros@cgiar.org	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	120
23	syntax	Rscript randRCBDcimmyt.R -e RCBD_cimmyt_SD_0001.lst --nRep 3 --nTrial 2 --genLayout T --nFieldRow 7 --nPlotBarrier 2 --Vserpentine F	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	120
24	engine	R 3.4.4	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	120
25	modelVersion	2	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	120
26	organization_code	CIMMYT	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	120
27	Rversion	3.5.1	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
29	author	Alaine Gulles | Rose Imee Zhella Morantte	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
30	email	a.gulles@irri.org	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
31	syntax1	Rscript randALPHALATTICEirri.R --entryList "ALPHALATTICE_SD_0001.lst" --nTrial 3 --nRep 4 --nBlk 4 --genLayout F -o 'Output1' -p 'D:/Results'	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
32	syntax2	Rscript randALPHALATTICEirri.R --entryList "ALPHALATTICE_SD_0001.lst" --nTrial 3 --nRep 4 --nBlk 4 --genLayout T --nRowPerBlk 2 --nRowPerRep 4 --nFieldRow 8 --serpentine F -o 'Output2' -p 'D:/Results'	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
33	syntax3	Rscript randALPHALATTICEirri.R --entryList "ALPHALATTICE_SD_0001.lst" --nTrial 3 --nRep 4 --nBlk 4 --genLayout T --nRowPerBlk 2 --nRowPerRep 4 --nFieldRow 8 --serpentine T -o 'Output3' -p 'D:/Results'	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
34	engine	R 3.4.4	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
35	modelVersion	2	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
36	organization_code	IRRI	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
38	Rversion	3.5.1	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	8
40	author	Alaine Gulles | Rose Imee Zhella Morantte	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	8
41	email	a.gulles@irri.org	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	8
42	syntax	Rscript randRCBDirri.R --entryList 'RCBD_SD_0001.lst' --nTrial 3 --nRep 4 --genLayout T --nRowPerRep 5 --nFieldRow 5 --serpentine T -o 'Output' -p 'D:/Results'	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	8
43	engine	R 3.4.4	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	8
44	modelVersion	2	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	8
45	organization_code	IRRI	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	8
46	Rversion	3.5.1	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
48	author	Alaine Gulles | Rose Imee Zhella Morantte	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
49	email	a.gulles@irri.org	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
50	syntax1	Rscript randROWCOLUMNirri.R --entryList "ROWCOLUMN_SD_0001.lst" --nTrial 3 --nRep 4 --nRowBlk 4 --genLayout F -o "Output1" -p 'D:/Results'	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
51	syntax2	Rscript randROWCOLUMNirri.R --entryList "ROWCOLUMN_SD_0001.lst" --nTrial 3 --nRep 4 --nRowBlk 4 --genLayout T --nFieldRow 8 --serpentine F -o "Output2" -p 'D:/Results'	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
52	syntax3	Rscript randROWCOLUMNirri.R --entryList "ROWCOLUMN_SD_0001.lst" --nTrial 3 --nRep 4 --nRowBlk 4 --genLayout T --nFieldRow 8 --serpentine T -o "Output3" -p 'D:/Results'	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
53	engine	R 3.4.4	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
54	modelVersion	2	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
55	organization_code	IRRI	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
56	note	Total number of plots per occurrence should not exceed 1,500.	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
57	Rversion	3.5.1	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	39
59	author	Alaine Gulles | Rose Imee Zhella Morantte	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	39
60	email	a.gulles@irri.org	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	39
61	syntax1	Rscript randAUGMENTEDRCBDirri.R --entryList "AUGMENTEDRCBD_SD_0001.lst" --nTrial 3 --nRep 4 --genLayout F -o 'Output1' -p 'D:/Results'	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	39
62	syntax2	Rscript randAUGMENTEDRCBDirri.R --entryList "AUGMENTEDRCBD_SD_0001.lst" --nTrial 3 --nRep 4 --genLayout T --nRowPerRep 8 --nFieldRow 16 --serpentine F -o 'Output2' -p 'D:/Results'	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	39
63	syntax3	Rscript randAUGMENTEDRCBDirri.R --entryList "AUGMENTEDRCBD_SD_0001.lst" --nTrial 3 --nRep 4 --genLayout T --nRowPerRep 8 --nFieldRow 16 --serpentine T -o 'Output3' -p 'D:/Results'	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	39
64	engine	R 3.4.4	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	39
65	modelVersion	2	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	39
66	organization_code	IRRI	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	39
37	note	Total number of plots per Occurrence should not exceed 1,500.	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
67	note2	Total number of entries should not be a prime number.	1	2021-04-22 23:21:07.680833	\N	\N	\N	f	9
28	date	23-Oct-2020	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	9
68	note2	Total number of entries should not be a prime number.	1	2021-04-22 23:21:07.680833	\N	\N	\N	f	38
2	date	15-Oct-2020	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	118
11	date	15-Oct-2020	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	119
20	date	15-Oct-2020	2	2021-04-22 23:21:06.073515	\N	\N	\N	\N	120
58	date	23-Oct-2020	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	39
39	date	26-Oct-2020	1	2021-04-22 23:21:06.073515	\N	\N	\N	\N	8
47	date	23-Oct-2020	2	2021-04-22 23:21:06.722507	\N	\N	\N	\N	38
69	definition	loc_id	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	160
70	condition	!SORTALL !PRUNEALL	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	160
71	definition	expt_id	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	161
72	condition	!LL 32	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	161
73	definition	entry_id	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	162
74	definition	plot_id	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	163
75	definition	pa_x	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	164
76	definition	pa_y	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	165
77	definition	rep_factor	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	166
78	definition	blk	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	167
79	config_version	1.0.1	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
80	date	21-Sep-2020	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
81	author	Pedro Barbosa	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
82	email	p.medeiros@cgiar.org	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
83	engine	ASREML	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
84	design	RCBD	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
85	trait_level	plot	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
86	analysis_objective	prediction	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
87	exp_analysis_pattern	single	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
88	loc_analysis_pattern	single	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
89	year_analysis_pattern	single	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
90	trait_pattern	univariate	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	142
91	config_version	1.0.1	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
92	date	03-Sep-2020	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
93	author	Pedro Barbosa	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
94	email	p.medeiros@cgiar.org	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
95	engine	ASREML	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
96	design	RCBD	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
97	trait_level	plot	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
98	analysis_objective	prediction	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
99	exp_analysis_pattern	single	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
100	loc_analysis_pattern	multi	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
101	year_analysis_pattern	single	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
102	trait_pattern	univariate	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	143
103	config_version	1.0.1	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
104	date	21-Sep-2020	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
105	author	Pedro Barbosa	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
106	email	p.medeiros@cgiar.org	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
107	engine	ASREML	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
108	design	Alpha-Lattice	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
109	trait_level	plot	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
110	analysis_objective	prediction	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
111	exp_analysis_pattern	single	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
112	loc_analysis_pattern	single	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
113	year_analysis_pattern	single	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
114	trait_pattern	univariate	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	144
115	config_version	1.0.1	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
116	date	03-Sep-2020	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
117	author	Pedro Barbosa	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
118	email	p.medeiros@cgiar.org	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
119	engine	ASREML	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
120	design	Alpha-Lattice	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
121	trait_level	plot	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
122	analysis_objective	prediction	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
123	exp_analysis_pattern	single	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
124	loc_analysis_pattern	multi	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
125	year_analysis_pattern	single	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
126	trait_pattern	univariate	\N	2021-04-22 23:21:08.904814	\N	\N	\N	f	145
\.


--
-- Data for Name: property_rule; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.property_rule (type, expression, "group", creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, tenant_id, id, property_id, property_config_id, order_number, notification, action) FROM stdin;
validation-design	totalEntries>=6	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	48	\N	77	2	Number of entries should be at least 6.	error
validation-design	!prime(totalEntries)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	47	\N	77	1	Total number of entries should not be a prime number.	error
validation-design	value<=(1500/totalEntries)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	49	\N	78	1	Total number of experimental units should not exceed 1,500.	error
allowed-value	factor(totalEntries)	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	35	\N	85	1	\N	\N
allowed-value	value>1	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	50	\N	85	2	\N	\N
allowed-value	value<(totalEntries)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	51	\N	85	3	\N	\N
allowed-value	factor(totalEntries/nBlk)	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	36	\N	86	1	\N	\N
allowed-value	factor(nBlk)*nRowPerBlk	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	37	\N	81	1	\N	\N
allowed-value	factor(nRep)*nRowPerRep	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	38	\N	80	1	\N	\N
validation-design	nCheck>1	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	52	\N	119	1	Number of check entries should be greater than 1.	error
validation-design	nEntries>1	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	53	\N	119	2	Number of test entries should be greater than 1.	error
allowed-value	factor(nCheck+(nEntries/nRep))	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	34	\N	115	1	\N	\N
allowed-value	factor(totalEntries)	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	30	\N	66	1	\N	\N
validation-design	!prime(totalEntries)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	62	\N	95	1	Total number of entries should not be a prime number.	error
validation-design	value<=(1500/totalEntries)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	64	\N	96	1	Total number of plots should not exceed 1,500.	error
allowed-value	factor(totalEntries)	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	32	\N	99	1	\N	\N
allowed-value	value>1	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	65	\N	99	2	\N	\N
validation-design	!prime(totalEntries)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	67	\N	128	1	Total number of entries should not be a prime number. Kindly update the entry list or select an appropriated design	error
allowed-value	factor(totalEntries)	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	43	\N	130	1	\N	\N
allowed-value	value>1	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	68	\N	130	2	\N	\N
allowed-value	value<(totalEntries)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	69	\N	130	3	\N	\N
allowed-value	factor(totalEntries*nRep)	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	41	\N	132	1	\N	\N
allowed-value	if(!Vserpentine){value<=((totalEntries*nRep)/nFieldRow)}	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	42	\N	133	1	\N	\N
validation-design	!prime(totalEntries)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	71	\N	144	1	Total number of entries should not be a prime number. Kindly update the entry list or select an appropriated design	error
allowed-value	factor(totalEntries)	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	46	\N	146	1	\N	\N
allowed-value	value>1	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	72	\N	146	2	\N	\N
allowed-value	value<(totalEntries)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	73	\N	146	3	\N	\N
allowed-value	factor(totalEntries*nRep)	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	44	\N	148	1	\N	\N
allowed-value	if(!Vserpentine){value<=((totalEntries*nRep)/nFieldRow)}	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	45	\N	149	1	\N	\N
allowed-value	factor(totalEntries*nRep)	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	39	\N	164	1	\N	\N
allowed-value	factor(nRep)*nRowPerRep	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	58	\N	65	1	\N	\N
allowed-value	value<totalEntries	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	66	\N	99	3	\N	\N
allowed-value	if(Vserpentine){value<=(nFieldRow)}	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	70	\N	133	2	\N	\N
allowed-value	if(Vserpentine){value<=(nFieldRow)}	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	74	\N	149	2	\N	\N
validation-design	totalEntries>=9	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	63	\N	95	2	Number of entries should be at least 9.	error
validation-design	totalEntries<=30	0	2021-04-22 23:21:07.910511	\N	\N	\N	f	\N	78	\N	62	1	Total number of entries is too large for a RCBD. Consider selecting a more appropriate design.	warning
validation-design	totalEntries<=30	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	75	\N	161	1	Total number of entries is too large for a RCBD. Consider selecting a more appropriate design	warning
allowed-value	factor(nRep)*nRowPerRep	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	33	\N	114	1	\N	\N
allowed-value	factor(nRep)*nRowBlk	0	2021-04-22 23:21:06.906613	\N	\N	\N	f	\N	31	\N	98	1	\N	\N
default-value	min(factor(nEntries)) > 1	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	55	\N	112	2	\N	\N
allowed-value	if(!Vserpentine){value<=((totalEntries*nRep)/nFieldRow)}	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	76	\N	165	1	\N	\N
allowed-value	if(Vserpentine){value<=(nFieldRow)}	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	77	\N	165	2	\N	\N
validation-design	value>=((12/(nCheck-1))+1)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	56	\N	112	3	The error degrees of freedom associated with number of check entries should be at least 12.	warning
validation-design	factor(nEntries)	0	2021-04-22 23:21:07.680833	\N	\N	\N	f	\N	54	\N	112	1	Number of occurrences should be a factor of the number of test entries.	error
\.


--
-- Data for Name: property_ui; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.property_ui (is_visible, minimum, maximum, unit, "default", is_disabled, is_multiple, is_catalogue, creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, tenant_id, id) FROM stdin;
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	1
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	2
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	3
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	4
t	\N	\N	\N	\N	f	t	t	\N	\N	\N	\N	\N	\N	5
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	6
t	1	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	\N	7
t	2	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	\N	9
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	14
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	15
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	25
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	26
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	34
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	35
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	44
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	45
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	54
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	55
t	1	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	\N	56
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	65
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	66
f	\N	\N	\N	true	f	f	f	\N	\N	\N	\N	\N	\N	74
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	75
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	76
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	47
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	57
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	59
t	\N	\N	\N	true	f	f	f	\N	\N	\N	\N	\N	\N	63
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	68
t	1	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	61
f	\N	\N	\N	true	t	f	f	\N	\N	\N	\N	\N	\N	17
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	62
t	1	\N	\N	1	f	f	f	\N	\N	\N	\N	\N	\N	67
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	8
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	28
f	\N	\N	\N	\N	t	f	f	\N	\N	\N	\N	\N	\N	37
t	2	\N	\N	2	f	f	f	\N	\N	\N	\N	\N	\N	69
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	10
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	13
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	20
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	24
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	31
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	33
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	40
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	43
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	50
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	53
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	64
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	70
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	73
t	\N	\N	\N	false	f	f	f	\N	\N	\N	\N	\N	\N	60
t	1	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	11
t	1	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	12
t	1	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	42
t	1	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	71
t	\N	\N	\N	true	f	f	f	2021-04-22 23:21:07.474128	\N	1	\N	f	\N	77
t	1	\N	\N	1	f	f	f	\N	\N	\N	\N	\N	\N	16
t	2	166	\N	2	f	f	f	\N	\N	\N	\N	\N	\N	18
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	19
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	23
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	22
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	21
t	1	\N	\N	1	f	f	f	\N	\N	\N	\N	\N	\N	36
t	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	\N	\N	39
t	1	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	41
t	1	\N	\N	1	f	f	f	\N	\N	\N	\N	\N	\N	27
t	2	166	\N	2	f	f	f	\N	\N	\N	\N	\N	\N	29
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	30
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	32
t	1	\N	\N	1	f	f	f	\N	\N	\N	\N	\N	\N	46
t	2	4	\N	2	f	f	f	\N	\N	\N	\N	\N	\N	48
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	49
t	1	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	51
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	52
t	2	4	\N	2	f	f	f	\N	\N	\N	\N	\N	\N	58
t	\N	\N	\N	\N	f	f	t	\N	\N	\N	\N	\N	\N	72
\.


--
-- Data for Name: request; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.request (uuid, category, type, design, requestor_id, institute, crop, program, status, creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, tenant_id, id, method_id, engine) FROM stdin;
\.


--
-- Data for Name: request_entry; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.request_entry (experiment_id, entry_id, tenant_id, creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, id, request_id, entry_number) FROM stdin;
\.


--
-- Data for Name: request_parameter; Type: TABLE DATA; Schema: af; Owner: postgres
--

COPY af.request_parameter (value, creation_timestamp, modification_timestamp, creator_id, modifier_id, is_void, tenant_id, id, property_id, request_id) FROM stdin;
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
Create	postgres	changesets/baseline/schema/baseline.sql	2021-04-22 23:21:04.262881	1	EXECUTED	8:f642fc6d2c210472d300bc9e46fed983	sql	Create baseline database	\N	3.8.6	schema	\N	9151662718
config	postgres	changesets/baseline/data/template/config.sql	2021-04-22 23:21:04.881978	2	EXECUTED	8:3eea3ccfec77f3af83b1a36b18997837	sql	config	\N	3.8.6	template	\N	9151662718
longDescription	postgres	changesets/baseline/data/template/longDescription.sql	2021-04-22 23:21:05.109635	3	EXECUTED	8:290c942471287fd1989c6cce193bbb0e	sql	longDescription	\N	3.8.6	template	\N	9151662718
config-clean	postgres	changesets/baseline/data/template/config-clean.sql	2021-04-22 23:21:05.3309	4	EXECUTED	8:d12f23dbef76d1ac215507f8e6378b8c	sql	config-clean	\N	3.8.6	template	\N	9151662718
raw	includeAll	changesets/baseline/schema/change_lenght_in_analysis_description.sql	2021-04-22 23:21:05.493402	5	EXECUTED	8:51d6891032b6fc3c7c47f90b7df2bb3a	sql		\N	3.8.6	\N	\N	9151662718
insert_entry_lst_occ_id	postgres	changesets/baseline/data/template/insert_entry_lst_occ_id.sql	2021-04-22 23:21:05.627393	6	EXECUTED	8:201f2a799f31e396fbd7bd49a01f4582	sql	insert_entry_lst_occ_id	\N	3.8.6	template	\N	9151662718
raw	includeAll	changesets/baseline/schema/create_af_property_meta.sql	2021-04-22 23:21:05.968935	7	EXECUTED	8:06883ebf97d8dd0d6ab3cf1cbd9784bf	sql		\N	3.8.6	\N	\N	9151662718
update_af_data	postgres	changesets/baseline/data/template/update_af_data.sql	2021-04-22 23:21:06.154428	8	EXECUTED	8:a416fb74576590406b5deb2f6ba1f840	sql	update_af_data	\N	3.8.6	template	\N	9151662718
add_is_layout_variable	postgres	changesets/baseline/schema/add_is_layout_variable.sql	2021-04-22 23:21:06.294755	9	EXECUTED	8:cf237f5576d580952a2b51a45c9f06ef	sql	add_is_layout_variable	\N	3.8.6	schema	\N	9151662718
add_is_layout_variable_data	postgres	changesets/baseline/data/template/add_is_layout_variable_data.sql	2021-04-22 23:21:06.427237	10	EXECUTED	8:c8a61888ef8391fc1125ee2114924baf	sql	add_is_layout_variable_data	\N	3.8.6	template	\N	9151662718
Add_request_entry_table	postgres	changesets/baseline/schema/add_request_entry_table.sql	2021-04-22 23:21:06.615661	11	EXECUTED	8:92ce9cd236deff5d04fdc09655cfd9fd	sql	Add_request_entry_table	\N	3.8.6	schema	\N	9151662718
design_models_v2.1	postgres	changesets/baseline/data/template/design_models_v2.1.sql	2021-04-22 23:21:06.829925	12	EXECUTED	8:4801bf900ce0d246743d98f1c63b5a08	sql	design_models_v2.1	\N	3.8.6	template	\N	9151662718
add_new_rules	postgres	changesets/baseline/data/template/add_new_rules.sql	2021-04-22 23:21:06.995002	13	EXECUTED	8:daa22aa95b37dedb7b7bea8b6e1ef48c	sql	add_new_rules	\N	3.8.6	template	\N	9151662718
update_request_status	postgres	changesets/baseline/data/template/update_request_status.sql	2021-04-22 23:21:07.170435	14	EXECUTED	8:45363a61fabdea98d123b61afdc158af	sql	update_request_status	\N	3.8.6	template	\N	9151662718
raw	includeAll	changesets/baseline/schema/update_table_comments.sql	2021-04-22 23:21:07.410771	15	EXECUTED	8:beb66448cd04e67bd38cc9eed2dfe527	sql		\N	3.8.6	\N	\N	9151662718
change_model_rule_add_property	postgres	changesets/baseline/data/template/change_model_rule_add_property.sql	2021-04-22 23:21:07.597475	16	EXECUTED	8:e6aa85532897b58ec43141c7659680c5	sql	change_model_rule_add_property	\N	3.8.6	template	\N	9151662718
add-rules	postgres	changesets/baseline/data/template/add-rules.sql	2021-04-22 23:21:07.84714	17	EXECUTED	8:95e7f8c9d364db6c8c889aa3be31ced7	sql	add-rules	\N	3.8.6	template	\N	9151662718
update-rules-irri-models	postgres	changesets/baseline/data/template/update-rules-irri-models.sql	2021-04-22 23:21:07.977969	18	EXECUTED	8:6044244a82ceef40e6ce6575c36ba1d8	sql	update-rules-irri-models	\N	3.8.6	template	\N	9151662718
update-design-rules	postgres	changesets/baseline/data/template/update-design-rules.sql	2021-04-22 23:21:08.098289	19	EXECUTED	8:feeb2a821810b4cc7b71031eb57eff08	sql	update-design-rules	\N	3.8.6	template	\N	9151662718
updateRcbdRulesVserpentine	postgres	changesets/baseline/data/template/updateRcbdRulesVserpentine.sql	2021-04-22 23:21:08.214699	20	EXECUTED	8:465256d06407909a7fbfa4f6699859e2	sql	updateRcbdRulesVserpentine	\N	3.8.6	template	\N	9151662718
disable-layout-variable-rand1	postgres	changesets/baseline/data/template/disable-layout-variable-rand1.sql	2021-04-22 23:21:08.337683	21	EXECUTED	8:8fe86aa1cda2c3c4cc9329028680cdca	sql	disable-layout-variable-rand1	\N	3.8.6	template	\N	9151662718
update_property_name_label	postgres	changesets/baseline/schema/update_property_name_label.sql	2021-04-22 23:21:08.535808	22	EXECUTED	8:b3f65a711774ccef0c5fe743b41aba39	sql	BA-11 Add analysis configuration data	\N	3.8.6	schema	\N	9151662718
uBA-1	postgres	changesets/baseline/data/template/update_notifications_in_property_rule.sql	2021-04-22 23:21:08.670035	23	EXECUTED	8:d2b12efebf68b6976816c60435b2cced	sql	BA-1 Correct Property rule	\N	3.8.6	template	\N	9151662718
change_label_exp_design	postgres	changesets/baseline/data/template/change_label_exp_design.sql	2021-04-22 23:21:08.812493	24	EXECUTED	8:f29d0aa459048aa9d16170d396b8ed5c	sql	BA-72 Change the label of Experimental Design Model	\N	3.8.6	template	\N	9151662718
add_analysis_configuration_data	postgres	changesets/baseline/data/template/add_analysis_configuration_data.sql	2021-04-22 23:21:09.001235	25	EXECUTED	8:ac808d03bc192241cdffab025153d58f	sql	BA-11 Add analysis configuration data	\N	3.8.6	template	\N	9151662718
baseline_tag	postgres	changesets/baseline/tag/dev-tag.xml	2021-04-22 23:21:09.065203	26	EXECUTED	8:16003aa8d37ea966f3c356efbbc9241c	tagDatabase		baseline	3.8.6	\N	\N	9151662718
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- Name: analysis_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.analysis_id_seq', 1, false);


--
-- Name: job_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.job_id_seq', 1, false);


--
-- Name: property_acl_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.property_acl_id_seq', 1, false);


--
-- Name: property_config_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.property_config_id_seq', 273, true);


--
-- Name: property_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.property_id_seq', 133, true);


--
-- Name: property_meta_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.property_meta_id_seq', 126, true);


--
-- Name: property_rule_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.property_rule_id_seq', 78, true);


--
-- Name: property_ui_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.property_ui_id_seq', 77, true);


--
-- Name: request_entry_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.request_entry_id_seq', 1, false);


--
-- Name: request_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.request_id_seq', 1, false);


--
-- Name: request_parameter_id_seq; Type: SEQUENCE SET; Schema: af; Owner: postgres
--

SELECT pg_catalog.setval('af.request_parameter_id_seq', 1, false);


--
-- Name: analysis PK_analysis; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.analysis
    ADD CONSTRAINT "PK_analysis" PRIMARY KEY (id);


--
-- Name: job PK_job; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.job
    ADD CONSTRAINT "PK_job" PRIMARY KEY (id);


--
-- Name: property PK_property; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property
    ADD CONSTRAINT "PK_property" PRIMARY KEY (id);


--
-- Name: property_acl PK_property_acl; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_acl
    ADD CONSTRAINT "PK_property_acl" PRIMARY KEY (id);


--
-- Name: property_config PK_property_config; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_config
    ADD CONSTRAINT "PK_property_config" PRIMARY KEY (id);


--
-- Name: property_meta PK_property_meta; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_meta
    ADD CONSTRAINT "PK_property_meta" PRIMARY KEY (id);


--
-- Name: property_rule PK_property_rule; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_rule
    ADD CONSTRAINT "PK_property_rule" PRIMARY KEY (id);


--
-- Name: property_ui PK_property_ui; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_ui
    ADD CONSTRAINT "PK_property_ui" PRIMARY KEY (id);


--
-- Name: request PK_request; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.request
    ADD CONSTRAINT "PK_request" PRIMARY KEY (id);


--
-- Name: request_entry PK_request_entry; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.request_entry
    ADD CONSTRAINT "PK_request_entry" PRIMARY KEY (id);


--
-- Name: request_parameter PK_request_parameter; Type: CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.request_parameter
    ADD CONSTRAINT "PK_request_parameter" PRIMARY KEY (id);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: analysis FK_analysis_property; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.analysis
    ADD CONSTRAINT "FK_analysis_property" FOREIGN KEY (model_id) REFERENCES af.property(id);


--
-- Name: analysis FK_analysis_request; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.analysis
    ADD CONSTRAINT "FK_analysis_request" FOREIGN KEY (request_id) REFERENCES af.request(id);


--
-- Name: job FK_job_analysis; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.job
    ADD CONSTRAINT "FK_job_analysis" FOREIGN KEY (analysis_id) REFERENCES af.analysis(id);


--
-- Name: property_acl FK_property_acl_property; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_acl
    ADD CONSTRAINT "FK_property_acl_property" FOREIGN KEY (property_id) REFERENCES af.property(id);


--
-- Name: property_meta FK_property_meta_property; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_meta
    ADD CONSTRAINT "FK_property_meta_property" FOREIGN KEY (property_id) REFERENCES af.property(id);


--
-- Name: request_entry FK_request_entry_request; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.request_entry
    ADD CONSTRAINT "FK_request_entry_request" FOREIGN KEY (request_id) REFERENCES af.request(id);


--
-- Name: property_config property_config_property_id_fkey; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_config
    ADD CONSTRAINT property_config_property_id_fkey FOREIGN KEY (property_id) REFERENCES af.property(id);


--
-- Name: property_config property_config_property_ui_id_fkey; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_config
    ADD CONSTRAINT property_config_property_ui_id_fkey FOREIGN KEY (property_ui_id) REFERENCES af.property_ui(id);


--
-- Name: property_rule property_rule_property_config_id_fkey; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_rule
    ADD CONSTRAINT property_rule_property_config_id_fkey FOREIGN KEY (property_config_id) REFERENCES af.property_config(id);


--
-- Name: property_rule property_rule_property_id_fkey; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.property_rule
    ADD CONSTRAINT property_rule_property_id_fkey FOREIGN KEY (property_id) REFERENCES af.property(id);


--
-- Name: request request_method_id_fkey; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.request
    ADD CONSTRAINT request_method_id_fkey FOREIGN KEY (method_id) REFERENCES af.property(id);


--
-- Name: request_parameter request_parameter_property_id_fkey; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.request_parameter
    ADD CONSTRAINT request_parameter_property_id_fkey FOREIGN KEY (property_id) REFERENCES af.property(id);


--
-- Name: request_parameter request_parameter_request_id_fkey; Type: FK CONSTRAINT; Schema: af; Owner: postgres
--

ALTER TABLE ONLY af.request_parameter
    ADD CONSTRAINT request_parameter_request_id_fkey FOREIGN KEY (request_id) REFERENCES af.request(id);


--
-- PostgreSQL database dump complete
--

