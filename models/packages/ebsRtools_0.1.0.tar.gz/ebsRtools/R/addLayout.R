add.layout <-  function(trials, Vserpentine = F, nFieldRow, nPlotsRepBarrier = NULL, save = F, outputPath = getwd(), outputFile =NULL) {
  layouts <- list()
  n <- length(trials[[1]]$book$plots) #number of plots
  c <- ceiling(n/nFieldRow) #number of columns
  t <- length(trials[[1]]$parameters$trt)
  nTrial <- length(trials)
  for(i in 1:nTrial){
    if(!Vserpentine){
      if(is.null(nPlotsRepBarrier)) {nPlotsRepBarrier = c}
      trials[[i]]$book$row <- rep(rep(1:nFieldRow, each = nPlotsRepBarrier),len = n)
      if(nPlotsRepBarrier == c){
        trials[[i]]$book$col <- rep(c(1:c,c:1),n)[1:n]
      } else {
        trials[[i]]$book$col <- rep(rep(c(1:nPlotsRepBarrier,nPlotsRepBarrier:1),n,length=nPlotsRepBarrier*nFieldRow),len=n) + rep(seq(0,c-1,nPlotsRepBarrier),each = (nFieldRow*nPlotsRepBarrier), len = n)
      }
    } else {
      if(is.null(nPlotsRepBarrier)) {nPlotsRepBarrier <- nFieldRow}
      trials[[i]]$book$col <- rep(rep(1:c, each = nPlotsRepBarrier),len = n)
      if(nPlotsRepBarrier == nFieldRow){
        trials[[i]]$book$row <- rep(c(1:nFieldRow,nFieldRow:1),n)[1:n]
      } else {
        trials[[i]]$book$row <- rep(rep(c(1:nPlotsRepBarrier,nPlotsRepBarrier:1),n,length=nPlotsRepBarrier*c),len=n) + rep(seq(0,nFieldRow-1,nPlotsRepBarrier),each = (c*nPlotsRepBarrier), len = n)
      }
    }

    trials[[i]]$book$R_C <- paste(trials[[i]]$book$row,"_",trials[[i]]$book$col,sep="")
    layout <- list()
    for(l in (setdiff(names(trials[[i]]$book),c("row","col","cols","R_C")))) {
      sketch <-  matrix(NA,max(trials[[i]]$book$row),max(trials[[i]]$book$col))
      for(j in 1:nrow(sketch)){
        for(k in 1:ncol(sketch)){
          sketch[j,k] <- ifelse(length(trials[[i]]$book[trials[[i]]$book$R_C %in% paste(j,"_",k,sep=""),l])==0,NA,trials[[i]]$book[trials[[i]]$book$R_C %in% paste(j,"_",k,sep=""),l])
        }
      }
      rownames(sketch) <- c(1:nrow(sketch))
      colnames(sketch) <- c(1:ncol(sketch))
      sketch <- as.data.frame(sketch)
      sketch <- sketch[with(sketch, order(as.numeric(rownames(sketch)),decreasing = T)),]
      layouts[[l]] <- as.matrix(sketch)
      #saving a csv for each layout tag
      if(save){
        write.csv(sketch, file = paste(paste(outputPath, outputFile, sep = "/"),"Occurr_",i,"_","Layout","_",l,".csv", sep = ""), row.names = T)
      }
    }
    trials[[i]]$layouts <- layouts
    trials[[i]]$book$R_C <- NULL
    occurrence <- rep(i,length=length(trials[[i]]$book$plots))
    trials[[i]]$book <- cbind(occurrence,trials[[i]]$book)
  }
  return(trials)
}
