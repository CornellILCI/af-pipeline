# -------------------------------------------------------------------------------------
# Name             : layoutIBD 
# Description      : Generate layout for Incomplete Block Designs
# R Version        : 3.5.1 
# -------------------------------------------------------------------------------------
# Author           : Alaine A. Gulles 
# Author Email     : a.gulles@irri.org
# Date             : 2012.04.11
# Maintainer       : Alaine A. Gulles 
# Maintainer Email : a.gulles@irri.org
# Script Version   : 2
# -------------------------------------------------------------------------------------
#' @name layoutIBD
#' @aliases layoutIBD
#' @aliases layoutIBD.default
#' @title Layout Creation for Incomplete Block Designs
#'
#' @description Creates layout Incomplete Block Designs including Alpha Lattice and Row-Column Design.
#'
#' @param fieldbook a dataframe which is a result from the function \code{randomizeIBD} 
#' @param trmtLayout a list which is a result from the function \code{randomizeIBD} 
#' @param numFieldRow number of field rows
#' @param numFieldCol number of field columns
#' @param numRowPerRep number of rows per replicate
#' @param numColPerRep number of columns per replicate
#' @param numRowPerBlk number of rows per block
#' @param numColPerBlk number of columns per block
#' @param serpentine a logical variable indicating whether plot number will be arranged as serpentine order
#' 
#' @return list containing a fieldbook, the layout and plot numbers.
#' 
# -------------------------------------------------------------------------------------

layoutIBD <- function(fieldbook, trmtLayout,
                      numFieldRow, numFieldCol,
                      numRowPerRep, numColPerRep, numBlk = NULL,
                      numRowPerBlk = NULL, numColPerBlk = NULL,
                      serpentine = FALSE) UseMethod("layoutIBD")

layoutIBD.default <- function(fieldbook, trmtLayout, 
                              numFieldRow, numFieldCol,
                              numRowPerRep, numColPerRep, 
                              numBlk = NULL, numRowPerBlk = NULL, numColPerBlk = NULL,
                              serpentine = FALSE) {
  
  # plotNumOrient = c("topToBottom", "bottomToTop", "leftToRight")
  # plotNumOrient <- match.arg(plotNumOrient)
  
  numRepRow <- numFieldRow/numRowPerRep
  numRepCol <- numFieldCol/numColPerRep
  
  if (!is.null(numRowPerBlk) && !is.null(numColPerBlk)) {
    # Design == Alpha Lattice
    numBlkRow <- numRowPerRep/numRowPerBlk
    numBlkCol <- numColPerRep/numColPerBlk
    blksize <- length(unique(fieldbook$ID))/numBlk
  }

  # if (plotNumOrient == "topToBottom" || plotNumOrient == "bottonToTop") {
    repNum <- matrix(fieldbook$REP, nrow = numFieldRow, ncol = numFieldCol, byrow = FALSE)
    plotNum <- matrix(as.numeric(paste(fieldbook$REP, paste(rep(0,nchar(nlevels(fieldbook$ID))), collapse = ""), sep = "")), 
                      nrow = numFieldRow, ncol = numFieldCol, byrow = FALSE)
  # } else {
  #   repNum <- repNum <- matrix(fieldbook$REP, nrow = numFieldRow, ncol = numFieldCol, byrow = TRUE)
  #   plotNum <- matrix(as.numeric(paste(fieldbook$REP, paste(rep(0,nchar(nlevels(fieldbook$ID))), collapse = ""), sep = "")), 
  #                     nrow = numFieldRow, ncol = numFieldCol, byrow = TRUE)
  # }

  if (!is.null(numRowPerBlk) && !is.null(numColPerBlk)) {
    # Design == Alpha Lattice   
    plotNumPerRep <- matrix(0, nrow = numRowPerRep, ncol = numColPerRep)
    blkNum <- matrix(0, nrow = numFieldRow, ncol = numFieldCol)
    blkNumPerRep <- matrix(0, nrow = numRowPerRep, ncol = numColPerRep)
    plotNumPerBlk <- matrix(1:blksize, nrow = numRowPerBlk, ncol = numColPerBlk)
    
    # if (plotNumOrient == "topToBottom" || plotNumOrient == "bottonToTop") {
    
    if (serpentine) { for (z in seq(2, numColPerBlk, by = 2)) { plotNumPerBlk[,z] <- rev(plotNumPerBlk[,z]) }} # serpentine per block
    
    tmp <- writePlotNumInfo(info = plotNumPerBlk, table =  plotNumPerRep, tableGrp = blkNumPerRep, 
                            # plotNumOrient = plotNumOrient, 
                            numGrpRow = numBlkRow, numGrpCol = numBlkCol, 
                            numRowPerGrp = numRowPerBlk, numColPerGrp = numColPerBlk, 
                            incrementWithin = TRUE, increment = blksize)
    plotNumPerRep <- tmp$table
    blkNumPerRep <- tmp$tableGrp
    
    # serpentine blkinfo
    # if (serpentine) {
    #   for (y in seq(2, numBlkRow, by = 2)) {
    #     sIndex <- (y * numColPerBlk) - numColPerBlk + 1
    #     fIndex <- sIndex + numColPerBlk - 1
    #     for (z in (sIndex:fIndex)) { 
    #       blkNumPerRep[,z] <- rev(blkNumPerRep[,z]) 
    #       plotNumPerRep[,z] <- rev(plotNumPerRep[,z])
    #     } ## end stmt -- for (z in (sIndex:fIndex))
    #   } ## end stmt -- for (y in seq(2, numBlkRow, by = 2))
    # } ## end stmt -- if (serpentine)
    # } ## end stmt -- if (plotNumOrient == "topToBottom" || plotNumOrient == "bottonToTop")
    
    plotNum <- writePlotNumInfo(info = plotNumPerRep, table =  plotNum, tableGrp = NULL, 
                                # plotNumOrient = plotNumOrient, 
                                numGrpRow = numRepRow, numGrpCol = numRepCol, 
                                numRowPerGrp = numRowPerRep, numColPerGrp = numColPerRep, incrementWithin = FALSE)[[1]]
    
    # block information, if design == AlphaLattice
    blkNum <- writePlotNumInfo(info = blkNumPerRep, table =  blkNum, tableGrp = NULL, 
                               # plotNumOrient = plotNumOrient,
                               numGrpRow = numRepRow, numGrpCol = numRepCol, 
                               numRowPerGrp = numRowPerRep, numColPerGrp = numColPerRep, incrementWithin = FALSE)[[1]]
  } else {
    # Design == Row-Column
    plotNumPerRep <- matrix(1:nlevels(fieldbook$ENTRY), nrow = numRowPerRep, ncol = numColPerRep)
    rowBlkNum <- matrix(1:numRowPerRep, nrow = numFieldRow, ncol = numFieldCol)
    colBlkNum <- matrix(rep(1:numColPerRep, each = numFieldRow), nrow = numFieldRow, ncol = numFieldCol)
    # if (plotNumOrient == "topToBottom" || plotNumOrient == "bottonToTop") {
    if (serpentine) { for (z in seq(2, numColPerRep, by = 2)) { plotNumPerRep[,z] <- rev(plotNumPerRep[,z]) }} # serpentine per rep
    
    plotNum <- writePlotNumInfo(info = plotNumPerRep, table =  plotNum, tableGrp = NULL, 
                                # plotNumOrient = plotNumOrient, 
                                numGrpRow = numRepRow, numGrpCol = numRepCol, 
                                numRowPerGrp = numRowPerRep, numColPerGrp = numColPerRep, incrementWithin = FALSE)[[1]]
    
  } ## end stmt -- if (!is.null(numRowPerBlk) && !is.null(numColPerBlk)) - else stmt

  # repInformation
  # if (serpentine) {
  #   for (y in seq(2, numRepRow, by = 2)) {
  #     sIndex <- (y * numColPerRep) - numColPerRep + 1
  #     fIndex <- sIndex + numColPerRep - 1
  #     for (z in (sIndex:fIndex)) { 
  #       plotNum[,z] <- rev(plotNum[,z]) 
  #       repNum[,z] <- rev(repNum[,z])
  #     } ## end stmt -- for (z in (sIndex:fIndex))
  #   } ## end stmt -- for (y in seq(2, numRepRow, by = 2))
  # } ## end stmt -- if (serpentine)
  
  if (!is.null(numRowPerBlk) && !is.null(numColPerBlk)) {
    grpInfo <- merge(as.data.frame.table(repNum), as.data.frame.table(blkNum), 
                     by.x = c("Var1", "Var2"), by.y = c("Var1", "Var2"))
    grpInfo <- merge(grpInfo, as.data.frame.table(plotNum),by.x = c("Var1", "Var2"), by.y = c("Var1", "Var2"))
    names(grpInfo)[3:ncol(grpInfo)] <- c("Rep", "Block", "PlotNumber")  
  } else {
    grpInfo <- merge(as.data.frame.table(repNum), as.data.frame.table(rowBlkNum), 
                     by.x = c("Var1", "Var2"), by.y = c("Var1", "Var2"))
    grpInfo <- merge(grpInfo, as.data.frame.table(colBlkNum), by.x = c("Var1", "Var2"), by.y = c("Var1", "Var2"))
    grpInfo <- merge(grpInfo, as.data.frame.table(plotNum), 
                     by.x = c("Var1", "Var2"), by.y = c("Var1", "Var2"), 
                     suffixes = c(".1", ".2"))
    names(grpInfo)[3:ncol(grpInfo)] <- c("Rep", "RowBlock", "ColumnBlock", "PlotNumber")
  } ## end stmt -- if (!is.null(numRowPerBlk) && !is.null(numColPerBlk)) - else stmt
    
  for (i in (1:length(trmtLayout))) {
    if (i == 1) { tmpfbook <- data.frame(Trial = i, merge(grpInfo, as.data.frame.table(trmtLayout[[i]]), 
                                              by.x = c("Var1", "Var2"), by.y = c("Var1", "Var2")))
    } else {
      tmpfbook <- rbind(tmpfbook,
                        cbind(Trial = i, merge(grpInfo, as.data.frame.table(trmtLayout[[i]]), 
                                               by.x = c("Var1", "Var2"), by.y = c("Var1", "Var2"))))
    } ## end stmt -- if (i == 1) - else stmt 
  } ## end stmt -- for (i in (1:length(trmtLayout)))
  
  tmpfbook[,"Var1"] <- as.numeric(tmpfbook[,"Var1"])
  tmpfbook[,"Var2"] <- as.numeric(tmpfbook[,"Var2"])
  
  exptLayout <- list()
  exptLayout[[1]] <- trmtLayout
  names(exptLayout[[1]]) <- paste("Trial", 1:length(trmtLayout), sep = "")
  exptLayout[[2]] <- plotNum
  exptLayout[[3]] <- repNum
  
  if (!is.null(numRowPerBlk) && !is.null(numColPerBlk)) {
    newfbook <- merge(fieldbook, tmpfbook, by.x = c("Trial", "ID", "ROW", "RANGE"), by.y = c("Trial", "Freq", "Var1", "Var2"))  
    exptLayout[[4]] <- blkNum
    names(exptLayout) <- c("TrmtLayout", "PlotNumLayout", "RepLayout", "BlockLayout")
  } else {
    newfbook <- merge(fieldbook, tmpfbook, 
                      by.x = c("Trial", "ID", "ROW", "RANGE", "RowBlock", "ColumnBlock"), 
                      by.y = c("Trial", "Freq", "Var1", "Var2","RowBlock", "ColumnBlock"))
    exptLayout[[4]] <- rowBlkNum
    exptLayout[[5]] <- colBlkNum
    names(exptLayout) <- c("TrmtLayout", "PlotNumLayout", "RepLayout", "RowBlockLayout","ColumnBlockLayout")
  } ## end stmt -- if (!is.null(numRowPerBlk) && !is.null(numColPerBlk)) - else stmt
  
  return(list(fieldbook = newfbook, plan = exptLayout))
  
} ## end of layoutIBD function
