# -------------------------------------------------------------------------------------
# Name             : designAlphaLattice
# Description      : Generate randomization for alpha lattice design. For 1500 or less
#                    experimental units, the function uses the series formulated by
#                    Patterson and Williams (alpha[0-1-2]) of the DiGGer package version 0.2-31.
#                    For experimental units of more than 1500, it uses the alpha[0-1]
#                    from the agricolae package.
# R Version        : 3.5.1
# -------------------------------------------------------------------------------------
# Author           : Alaine A. Gulles
# Author Email     : a.gulles@irri.org
# Date             : 2013.07.16
# Maintainer       : Alaine A. Gulles
# Maintainer Email : a.gulles@irri.org
# Script Version   : 2
# -------------------------------------------------------------------------------------
#' @title Alpha Lattice Design
#' @aliases designAlphaLattice
#' @aliases designAlphaLattice.default
#'
#' @description Generate randomization and layout for Alpha Lattice Design.
#'
#' @param generate list of entries to be randomized
#' @param numRep number of replicates or blocks
#' @param numTrial number of trials (randomization set-ups with the complete set of entries)
#' @param genLayout logical, whether a layout of the design will be generated
#' @param numRowPerBlk number of rows per block
#' @param numRowPerRep number of rows per replicate
#' @param numFieldRow number of field rows
#' @param serpentine a logical variable indicating whether plot number will be arranged as serpentine order
#' @param display a logical variable indicating whether randomization parameters will be displayed
#'
#' @details
#' If \code{genLayout} is \code{TRUE}, then parameters \code{numFieldRow}, \code{numRowPerRep}  and \code{numRowPerBlk}
#' must be specified.  Values of \code{numRowPerBlk} should be a factor of \code{numRowPerRep} while values of
#' \code{numRowPerRep} should be a factor of \code{numFieldRow}.
#'
#' @return A list containing the following components:
#' \item{fieldbook}{a data frame}
#' \item{plan}{a data frame, if \code{genLayout} is \code{FALSE} or a list containing the following components
#' if \code{genLayout} is \code{TRUE}}
#' \item{TrmtLayout}{a data frame, if \code{genLayout} is \code{FALSE} or a list whose length is equal to the
#'      number of trials containing the treatment layout for each trial, if \code{genLayout} is \code{TRUE}}
#' \item{PlotNumLayout}{a matrix containing the plot number layout of the experiment, if \code{genLayout} is \code{TRUE}}
#' \item{RepLayout}{a matrix containing the replication layout of the experiment, if \code{genLayout} is \code{TRUE}}
#' \item{BlockLayout}{a matrix containing the block layout of the experiment}
#'
#' @examples
#' ## Generate randomization for an experiment with 24 treatment levels in Alpha Lattice replicated
#' ## 4 times. Each replicate will have 4 blocks.
#' alpha1 <- designAlphaLattice(generate = list(Entry = 24), numBlk = 4, numRep = 4, numTrial = 1,
#'    genLayout = FALSE)
#'
#' ## Generate randomization and layout for an experiment with 24 levels in Alpha Lattice replicated
#' ## 4 times. Each replicate will have 4 blocks. The experiment will be arranged in a 8 x 12 field.
#' ## Each replicate will be arranged in a 4 x 6, while each block will be arranged in 2 x 3.
#' alpha2 <- designAlphaLattice(generate = list(Entry = 24), numBlk = 4, numRep = 4, numTrial = 1,
#'    genLayout = TRUE, numRowPerBlk = 2, numRowPerRep = 4, numFieldRow = 8)
#'
# -------------------------------------------------------------------------------------

designAlphaLattice <- function(generate, numBlk = 2, numRep = 2, numTrial = 1,
                               genLayout = FALSE, numRowPerBlk = 1, numRowPerRep = 1, numFieldRow = 1,
                               serpentine = FALSE, display = TRUE) UseMethod("designAlphaLattice")

designAlphaLattice.default <- function(generate, numBlk = 2, numRep = 2, numTrial = 1,
                                       genLayout = FALSE, numRowPerBlk = 1, numRowPerRep = 1, numFieldRow = 1,
                                       serpentine = FALSE, display = TRUE) {

  # --- check inputs --- #

  if (numRep < 2) { stop("The number of replicates should be greater than or equal to 2.")} # check number of replicates, should be
  if (numBlk == 1) { stop("Number of blocks per replicate should be greater than 1.") }
  if (length(generate[[1]]) == 1) { tempComb <- FactorList(generate) } else { tempComb <- generate }

  blksize <- length(tempComb[[1]])/numBlk

  if (!genLayout) {
    numFieldRow <- length(tempComb[[1]])
    numRowPerRep <- length(tempComb[[1]])
    numRowPerBlk <- blksize
  }

  if (numRowPerBlk == 1 || numRowPerBlk == blksize) serpentine <- FALSE

  # determine the total number of experimental units
  if ((numRep * length(tempComb[[1]])) > 1500) { stop("The maximum number of experimental units that can be generated is 1500.") }

  # check if the number of treatment is divisible by the block size
  if (length(tempComb[[1]])%%blksize != 0) { stop("The number of treatments should be divisible by the number of plots per block.") }
  # numBlk <- length(tempComb[[1]])/blksize                # determine the number of block per replicate

  # if (numBlk == 1) { stop("The block size should not be equal to the levels of the treatments.") }

  if (blksize%%numRowPerBlk != 0) { stop("The number of plots per block should be divisible by the number of rows per block.") }
  numColPerBlk <- blksize/numRowPerBlk                         # determine the number of columns per block with a replicate

  # check if # of rows per replicate is divisible by the # of rows per block
  if (numRowPerRep%%numRowPerBlk != 0) { stop("The number of rows per replicate should be divisible by the number of rows per block.") }

  # check if the quotient of # of rows per replicate and # of rows per block is a factor to number of blocks per replicate
  if (!((numRowPerRep/numRowPerBlk) %in% allFactors(numBlk))) { stop("The quotient of the number of rows in each replicate and number of rows in each block should be a factor of the number of blocks per replicate.") }

  # check if the treatment is divisible by the number of rows per Rep
  if (length(tempComb[[1]])%%numRowPerRep != 0) { stop("The number of treatment should be divisible by the number of rows in each replicate.") }
  numColPerRep <- length(tempComb[[1]])/numRowPerRep           # determine the number of columns per replicate


  if (numFieldRow%%numRowPerRep != 0) { stop("The total number of plots should be divisible by the number of field rows.") }
  numRepRow <- numFieldRow/numRowPerRep                     # determine the number of rep along the length of the field layout

  if (!(numRepRow %in% allFactors(numRep))) { stop("The quotient of the number of field rows and number of rows in each replicate should be a factor of the number of the replicates.") }

  if((length(tempComb[[1]])*numRep)%%numFieldRow != 0) { stop("The total number of plots should be divisible by the number of field rows.") }
  numFieldCol <- (length(tempComb[[1]])*numRep)/numFieldRow    # determine the number of field column in the experiment

  numRepCol <- numFieldCol/numColPerRep                     # determine the number of blocks along the length of each replicate
  numBlkRow <- numRowPerRep/numRowPerBlk                       # determine the number of blocks along the length of each replicate
  numBlkCol <- numColPerRep/numColPerBlk

  fieldbook <- NULL
  trmtLayout <- NULL

  # totalEU <- r * length(tempComb[[1]])

  if (numRep * length(tempComb[[1]]) != numFieldRow * numFieldCol) { stop("Total of plots cannot be accomodated in the field experiment.") }

  for (i in (1:numTrial)) {
    tmpResult <- randomizeIBD(numTrmt = length(tempComb[[1]]),
                              numFieldRow, numFieldCol,
                              numRep, numRowPerRep, numColPerRep,
                              numBlk, blksize, numRowPerBlk, numColPerBlk,
                              trmtList = tempComb[[1]])

    fieldbook <- rbind(fieldbook, data.frame(Trial = i, tmpResult$fieldbook))
    if (!genLayout) {
      trmtLayout <- rbind(trmtLayout, data.frame(Trial = i, tmpResult$plan))
    } else {
      if (i == 1) trmtLayout <- list()
      trmtLayout[[i]] <- tmpResult$plan
    }
  } ## end stmt for (i in (1:trial))

  if (!genLayout) {
    fieldbook$Block <- rep(rep(c(1:numBlk), each = blksize), times = numTrial)
    fieldbook$PlotNumber <- as.numeric(paste(fieldbook$REP, paste(rep(0,nchar(length(tempComb[[1]]))), collapse=""), sep = "")) + 1:length(tempComb[[1]])
    fieldbook <- fieldbook[,c("Trial", "REP", "Block", "ID", "PlotNumber")]
    fieldbook <- fieldbook[order(fieldbook$Trial, fieldbook$PlotNumber),]
    names(fieldbook) <- c("Trial", "Rep", "Block", names(tempComb)[1], "PlotNumber")
    names(trmtLayout)[2:ncol(trmtLayout)] <- paste("Rep", 1:numRep, sep = "")
    blkLayout <- trmtLayout
    for (i in 2:ncol(blkLayout)) blkLayout[,i] <- rep(1:numBlk, each = blksize, times = numTrial)
    exptLayout <- list()
    exptLayout[[1]] <- trmtLayout
    exptLayout[[2]] <- blkLayout
    names(exptLayout) <- c("TrmtLayout", "BlockLayout")
  } else {
    tmpResult2 <- layoutIBD(fieldbook, trmtLayout,
                            numFieldRow, numFieldCol,
                            numRowPerRep, numColPerRep,
                            numBlk, numRowPerBlk, numColPerBlk,
                            serpentine = serpentine)

    tmpResult2$fieldbook <- tmpResult2$fieldbook[,c("Trial", "REP", "Block", "ID", "PlotNumber", "ROW","RANGE")]
    names(tmpResult2$fieldbook) <- c("Trial", "Rep", "Block", names(tempComb)[1],"PlotNumber", "FieldRow", "FieldColumn")
    tmpResult2$fieldbook <- tmpResult2$fieldbook[order(tmpResult2$fieldbook$Trial, tmpResult2$fieldbook$PlotNumber),]

    for (i in 1:length(tmpResult2$plan$TrmtLayout)) {
      dimnames(tmpResult2$plan$TrmtLayout[[i]]) <- list(paste("FieldRow",1:nrow(tmpResult2$plan$TrmtLayout[[i]]), sep = ""),
                                                        paste("FieldColumn",1:ncol(tmpResult2$plan$TrmtLayout[[i]]), sep = ""))
    }
    for (i in 2:length(tmpResult2$plan)) {
      dimnames(tmpResult2$plan[[i]]) <- list(paste("FieldRow",1:nrow(tmpResult2$plan[[i]]), sep = ""),
                                             paste("FieldColumn",1:ncol(tmpResult2$plan[[i]]), sep = ""))
    }
  } ## end stmt -- if (!genLayout) - else stmt

  if (display) {
    cat(toupper("Design Properties:"),"\n",sep = "")
    cat("\t","Incomplete Block Design","\n",sep = "")
    cat("\t","Alpha Lattice Design","\n\n",sep = "")
    cat(toupper("Design Parameters:"),"\n",sep = "")
    cat("\t","Number of Trials = ", numTrial, "\n",sep = "")
    cat("\t","Number of Treatments = ", length(tempComb[[1]]), "\n",sep = "")
    cat("\t","Number of Replicates = ", numRep, "\n",sep = "")
    cat("\t","Number of Plots per Block = ", blksize, "\n",sep = "")
    cat("\t","Number of Blocks per Replicate = ", numBlk, "\n\n",sep = "")

    if (genLayout) {
      cat("\t","Number of Field Rows = ", numFieldRow, "\n",sep = "")
      cat("\t","Number of Field Columns = ", numFieldCol, "\n\n",sep = "")
    }
  }

  if (!genLayout) { return(invisible(list(fieldbook = fieldbook, plan = exptLayout)))
  } else { return(invisible(list(fieldbook = tmpResult2$fieldbook, plan = tmpResult2$plan))) }

} ## end -- designAlphaLattice function
