# -------------------------------------------------------------------------------------
# Name             : designRCBD 
# Description      : Generate randomization and layout for randomized complete block 
#                    design (RCBD) for single factor or factorial experiments.
# R Version        : 3.5.1 
# -------------------------------------------------------------------------------------
# Author           : Alaine A. Gulles 
# Author Email     : a.gulles@irri.org
# Date             : 04.11.2012
# Maintainer       : Alaine A. Gulles 
# Maintainer Email : a.gulles@irri.org
# Script Version   : 2
# -------------------------------------------------------------------------------------
#' @title Randomized Complete Block Design (RCBD)
#' @aliases designRCBD
#' @aliases designRCBD.default
#'  
#' @description Generate randomization and layout for randomized complete block design (RCBD)
#' for single factor or factorial experiments.
#'
#' @param generate list of entries to be randomized
#' @param r number of replicates or blocks
#' @param trial number of trials (randomization set-ups with the complete set of entries)
#' @param genLayout logical, whether a layout of the design will be generated
#' @param numFieldRow number of field rows
#' @param rowPerRep number of rows per replicate or block
#' @param serpentine a logical variable indicating whether plot number will be arranged as serpentine order
#' @param topToBottom a logical variable indicating whether plot number will be written from to to bottom
#' @param display a logical variable indicating whether randomization parameters will be displayed
#' 
#' @return list containing a fieldbook and plan.
#' 
#' @examples
#' designRCBD(generate = list(Entry = 1:10), r = 4, trial = 1, genLayout = FALSE)
#' designRCBD(generate = list(Entry = 1:10), r = 4, trial = 2, genLayout = TRUE, numFieldRow = 10, 
#'      rowPerRep = 5, display = TRUE)
#' 
# -------------------------------------------------------------------------------------

designRCBD <- function(generate, r = 2, trial = 1, 
                       genLayout = FALSE, numFieldRow = 1, rowPerRep = 1, 
                       serpentine = FALSE, topToBottom = TRUE, 
                       display = TRUE) UseMethod("designRCBD")

designRCBD.default <- function(generate, r = 2, trial = 1, 
                               genLayout = FALSE, numFieldRow = 1, rowPerRep = 1, 
                               serpentine = FALSE, topToBottom = TRUE, 
                               display = TRUE) {
  
  if (is.null(trial) || trial < 1 || is.character(trial) || length(trial) > 1) { 
    stop("The argument 'trial' should be a single value greater than or equal to 1.") 
  }
  if (is.null(r) || r < 2 || is.character(r) || length(r) > 1) { stop("The argument 'r' should be a single value greater than or equal to 2.") }
  if (missing(generate)) { stop("The argument 'generate' is missing.") }
  if (!is.list(generate)) { stop("The argument 'generate' must be a list.") }
  if (genLayout) {if (rowPerRep > numFieldRow) { stop("Number of field row should be equal to greater than the number or row per rep.") }}
  tempComb <- GenerateFactor(generate, times = 1)
  if (genLayout) {
    if (rowPerRep == 1) serpentine <- FALSE
    
    # numBlkRow <- numFieldRow/rowPerRep
    # numBlkCol <- r/numBlkRow
    # colPerBlk <- (nrow(tempComb)/rowPerRep)
    
    if (nrow(tempComb)%%rowPerRep != 0) { stop("Total number of plots per replicate should be divisible by the number of rows within replicate.") }
    if ((nrow(tempComb)*r)%%numFieldRow != 0) { stop("Total number of plots should be divisible by the number of field rows.") }
  }

  fieldbook <- randomizeRCBD(generate, r, trial)
  
  if (display) {
    cat(toupper("Design Properties:"),"\n",sep = "")
    if (ncol(tempComb) == 1) { cat("\t","Single Factor","\n",sep = "") } else { cat("\t","Factorial Design","\n",sep = "") }
    cat("\t","Randomized Complete Block Design","\n\n",sep = "")
    cat(toupper("Design Parameters:"),"\n",sep = "")
    cat("\t","Number of Trials = ", trial, "\n",sep = "")
    cat("\t","Number of Replicates = ", r, "\n",sep = "")
    if (ncol(tempComb) == 1) {
      cat("\t","Treatment Name = ", names(tempComb)[1], "\n",sep = "")
      cat("\t","Treatment Levels = ", sep = "")
      if (nlevels(tempComb[,1]) <= 5) { cat(paste(levels(tempComb[,1]), collapse = ", ", sep = ""), sep = "")
      } else {
        cat(paste(levels(tempComb[,1])[1:3], collapse = ", ", sep = ""), sep = "")
        cat(paste(", ...,", levels(tempComb[,1])[nlevels(tempComb[,1])]), sep = "")
      }
      cat("\n\n")
    } else {
      for (i in (1:ncol(tempComb))) {
        cat("\t","Factor ",i," = ", names(tempComb)[i], "\n",sep = "")
        cat("\t","Levels = ", sep = "")
        if (nlevels(tempComb[,i]) <= 5) { cat(paste(levels(tempComb[,i]), collapse = ", ", sep = ""), sep = "")
        } else {
          cat(paste(levels(tempComb[,i])[1:3], collapse = ", ", sep = ""), sep = "")
          cat(paste(", ...,", levels(tempComb[,i])[nlevels(tempComb[,i])]), sep = "")
        }
        cat("\n")
      }
      cat("\n")
    }
  }
  
  if (!genLayout) {
    fieldbook <- data.frame(index = rep(1:nlevels(fieldbook[,"trmtLabel"]), r*trial), fieldbook)
    plan <- reshape(fieldbook, v.names = "trmtLabel", idvar = c("index","Trial"), 
                    timevar = "Rep", direction = "wide",
                    drop = names(fieldbook)[c(4:(match("trmtLabel", names(fieldbook))-1), ncol(fieldbook))])
    plan <- plan[2:ncol(plan)]
    names(plan)[2:ncol(plan)] <- paste("Rep",1:r, sep = "")
    fieldbook <- fieldbook[,-I(c(match(c("trmtLabel", "index"), names(fieldbook))))]
    return(invisible(list(fieldbook = fieldbook, plan = plan)))
  } else {
    result <- generateLayout(fieldbook, numFieldRow, rowPerRep, serpentine, topToBottom)
    if (display) {
      cat("\t","Number of Field Row = ", numFieldRow, "\n",sep = "")
      cat("\t","Number of Field Column = ", ncol(result[[2]][[2]]), "\n\n",sep = "")
    }
    
    return(result)
  }

}  
  