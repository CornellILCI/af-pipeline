# -------------------------------------------------------------------------------------
# Name             : designAugmentedRCBD
# Description      : Generate randomization for Augmented RCBD
# R Version        : 3.5.1 
# -------------------------------------------------------------------------------------
# Author           : Alaine A. Gulles 
# Author Email     : a.gulles@irri.org
# Date             : 2010.09.21
# Maintainer       : Alaine A. Gulles 
# Maintainer Email : a.gulles@irri.org
# Script Version   : 3
# -------------------------------------------------------------------------------------
#' @title Augmented Randomized Complete Block Design
#' @aliases designAugmentedRCBD
#' @aliases designAugmentedRCBD.default
#'  
#' @description Generate randomization and layout for Augmented Randomized Complete
#'       Block Design.
#'
#' @param numCheck number of replicated treatments
#' @param numTest number of unreplicated treatments
#' @param trmtName NULL or a character string which indicate the name of the treatment to be displayed 
#'      in the output dataframe
#' @param numBlock number of blocks
#' @param numTrial number of trials (randomization set-ups with the complete set of entries)
#' @param genLayout logical, whether a layout of the design will be generated or not
#' @param numRowPerBlk number of rows per block, if genLayout is TRUE 
#' @param numFieldRow number of field rows, if genLayout is TRUE
#' @param serpentine a logical variable indicating whether plot number will be arranged as serpentine order,
#'      , if genLayout is TRUE
#' @param checkTrmtList a character vector indicating the names of the replicated treatment
#' @param checkTrmtList a character vector indicating the names of the unreplicated treatment     
#' @param display a logical variable indicating whether randomization parameters will be displayed
#' 
#' @return list containing a fieldbook, the layout and plot numbers.
#' 
#' @examples
#' designAugmentedRCB(numCheck = 6, numTest = 8, trmtName = "Variety", numBlock = 4, numTrial = 2, 
#'      genLayout = FALSE)
#' designAugmentedRCB(numCheck = 6, numTest = 8, trmtName = "Variety", numBlock = 4, numTrial = 2, 
#'      genLayout = TRUE, numRowPerBlk = 2, numFieldRow = 4, serpentine = TRUE, checkTrmtList = NULL, 
#'      testTrmtList = NULL, display = TRUE)
# -------------------------------------------------------------------------------------

designAugmentedRCB <- function(numCheck, numTest, trmtName = NULL, numBlock = 2, numTrial = 1, 
                               genLayout = FALSE, numRowPerBlk = 1, numFieldRow = 1, 
                               serpentine = FALSE, checkTrmtList = NULL, testTrmtList = NULL, 
                               display = TRUE) UseMethod("designAugmentedRCB")

designAugmentedRCB.default <- function(numCheck, numTest, trmtName = NULL, numBlock = 2, numTrial = 1, 
                                       genLayout = FALSE, numRowPerBlk = 1, numFieldRow = 1, 
                                       serpentine = FALSE, checkTrmtList = NULL, testTrmtList = NULL, 
                                       display = TRUE) {
  
  # check user input
  if (numBlock < 2) { stop("The number of blocks (or replicates) should be greater than or equal to 2.") }  # -- check the number of replicates
  
  # -- determine if the number of elements in checkTrmtList/testTrmtList is equal to numCheck/numTest
  if (is.null(checkTrmtList)) { checkTrmtList <- paste("check", 1:numCheck, sep = "")
  } else {
      if (length(checkTrmtList) != numCheck) { stop("Error: The number of elements of the arg 'checkTrmtList' is not equal to numCheck.") } 
  }
  
  if (is.null(testTrmtList)) { testTrmtList <- paste("new",1:numTest, sep = "")
  } else {
    if (length(testTrmtList) != numTest) { stop("Error: The number of elements of the arg 'testTrmtList' is not equal to numTest.") }          
  }

  numTrmt <- numCheck + numTest                        # -- determine the total number of treatment in the experiment
  numTestPerBlk <- numTest/numBlock                    # -- determine the number of test entries per blk
  numPlots <- (numCheck * numBlock) + numTest          # -- determine the total number of experimental units 
  errorDF <- (numBlock - 1) * (length(checkTrmtList) - 1)  # -- compute the error df for a complete experiment
  numPlotPerBlk <- numPlots/numBlock                   # -- assume equal number of plots per block
  
  if (genLayout) {
    numFieldCol <- numPlots/numFieldRow                  # -- determine the number of columns in the design
    numColPerBlk <- numPlotPerBlk/numRowPerBlk           # -- determine the number of columns per block
    
    # -- determine the orientation of blocks
    numBlkRow <- numFieldRow/numRowPerBlk
    numBlkCol <- numFieldCol/numColPerBlk
    if (numBlkRow * numBlkCol != numBlock) { stop("Number of field rows not divisible by the number of rows per block.") }
  }
  
  # generate randomization and fieldbook
  # capture.output(result <- designRCBD(generate = list(EntryNo = 1:numPlotPerBlk), r, trial, numFieldRow, rowPerBlk, serpentine, display = FALSE))
  
  capture.output(tmpResult <- designRCBD(generate = list(Entry = 1:numPlotPerBlk), 
                                         r = numBlock, trial = numTrial,
                                         genLayout = genLayout, 
                                         numFieldRow = numFieldRow, 
                                         rowPerRep = numRowPerBlk,
                                         serpentine = serpentine))
  if(genLayout) {
    fbook <- tmpResult$fieldbook[order(tmpResult$fieldbook$Trial, 
                                       tmpResult$fieldbook$FieldCol, 
                                       tmpResult$fieldbook$FieldRow),]  
  } else {
    fbook <- tmpResult$fieldbook[order(tmpResult$fieldbook$Trial, 
                                       tmpResult$fieldbook$PlotNum),]
  }
  fbook[,"Entry"] <- as.numeric(fbook[,"Entry"])
  
  #-- recoding the entry number for augmented design in RCB
  tmpCheckIDNum <- sample(numPlotPerBlk, numCheck)
  tmpTestIDNum <- setdiff(1:numPlotPerBlk, tmpCheckIDNum)
  fbook$tmpEntryCode <- mapvalues(fbook$Entry, from = c(tmpCheckIDNum, tmpTestIDNum), 
                                  to = c(checkTrmtList, rep(NA, each = numTestPerBlk)))
  # tmpTestIDNum <- sample(c(tmpTestIDNum,setdiff(1:numTrmt, 1:numPlotPerBlk)), numTest)
  tmpTestList <- sample(testTrmtList, numTest)
  # fbook[is.na(fbook$tmpEntryCode),"tmpEntryCode"] <- sample(testTrmtList, numTest)
  fbook[is.na(fbook$tmpEntryCode),"tmpEntryCode"] <- tmpTestList
  fbook$Entry <- fbook$tmpEntryCode
  fbook$tmpEntryCode <- NULL
  fbook <- fbook[order(fbook$Trial, fbook$PlotNum),]

  if (display) {
    cat(toupper("Design Properties:"), "\n", sep = "")
    cat("\t", "Augmented Randomized Complete Block Design (Augmented RCBD)", "\n\n", sep = "")
    cat(toupper("Design Parameters"), "\n", sep = "")
    cat("\t", "Number of Trials = ", numTrial, "\n", sep = "")
    cat("\t", "Number of Replicated Treatments = ", numCheck, "\n", sep = "")
    cat("\t", "Levels of Replicated Treatments = ", sep = "")
    if (numCheck <= 5) { cat(paste(checkTrmtList, collapse = ", ", sep = ""), "\n", sep = "") 
    } else {
      cat(paste(checkTrmtList[1:3], collapse = ", ", sep = ""), sep = "") 
      cat(", ..., ", checkTrmtList[numCheck], "\n", sep = "") 
    }
    cat("\t", "Number of Blocks = ", numBlock, "\n", sep = "")
    cat("\t", "Number of UnReplicated Treatments = ", numTest, "\n", sep = "")
    cat("\t", "Levels of UnReplicated Treatments = ", sep = "")
    if (numTest <= 5) { cat(paste(testTrmtList, collapse = ", ", sep = ""), "\n", sep = "") 
    } else {
      cat(paste(testTrmtList[1:3], collapse = ", ", sep = ""), sep = "") 
      cat(", ..., ", testTrmtList[numTest], "\n\n", sep = "") 
    }
    if (genLayout) {
      cat("\t", "Number of Field Rows = ", numFieldRow,"\n", sep = "")
      cat("\t", "Number of Field Columns = ", numFieldCol, "\n\n", sep = "")
    }
    if (errorDF < 12) { cat("WARNING: Too few error df.","\n\n") }
  } ## end stmt -- if (display)
  
  if (!genLayout) {
    tmp1 <- data.frame(index = rep(1:numPlotPerBlk, numBlock*numTrial), fbook)
    plan <- reshape(tmp1, v.names = "Entry", idvar = c("index","Trial"),
                    timevar = "Rep", direction = "wide",
                    drop = "PlotNum")
    plan <- plan[2:ncol(plan)]
    names(plan)[2:ncol(plan)] <- paste("Rep",1:numBlock, sep = "")
    rownames(plan) <- 1:nrow(plan)
    if (!is.null(trmtName)) names(fbook)[match("Entry", names(fbook))] <- trmtName
    return(invisible(list(fieldbook = fbook, plan = plan)))
  } else {
    for (i in 1:numTrial) {
      tmp1 <- tmpResult$plan$TrmtLayout[[i]]
      tmp2 <- mapvalues(tmp1, from = c(tmpCheckIDNum, tmpTestIDNum), 
                        to = c(checkTrmtList, rep(NA, each = numTestPerBlk)))
      tmp2[is.na(tmp2)] <- tmpTestList
      tmpResult$plan$TrmtLayout[[i]] <- tmp2
    } 
    if (!is.null(trmtName)) names(fbook)[match("Entry", names(fbook))] <- trmtName
    return(invisible(list(fieldbook = fbook, plan = tmpResult$plan)))
  }
} ## end stmt -- designAugmentedRCBD function

