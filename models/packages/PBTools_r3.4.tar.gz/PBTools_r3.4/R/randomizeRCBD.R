# -------------------------------------------------------------------------------------
# Name             : randomizeRCBD 
# Description      : Generate randomization for randomized complete block design (RCBD)
#                    for single factor or factorial experiments.
# R Version        : 3.5.1 
# -------------------------------------------------------------------------------------
# Author           : Alaine A. Gulles 
# Author Email     : a.gulles@irri.org
# Date             : 04.12.2012
# Maintainer       : Alaine A. Gulles 
# Maintainer Email : a.gulles@irri.org
# Script Version   : 1
# -------------------------------------------------------------------------------------
#' @name randomizeRCBD
#' @aliases randomizeRCBD
#' @aliases randomizeRCBD.default
#' @title Randomization for Randomized Complete Block Design (RCBD)
#'
#' @description Generate randomization for randomized complete block design (RCBD)
#'             for single factor or factorial experiments.
#'
#' @param generate list of entries to be randomized
#' @param r number of replicates or blocks
#' @param trial number of trials (randomization set-ups with the complete set of entries)
#' 
#' @return a dataframe .
#'
#' @examples
#' randomizeRCBD(generate = list(Variety = 4), r = 2, trial = 1)
#' 
# -------------------------------------------------------------------------------------

randomizeRCBD <- function(generate, r = 2, trial = 1) UseMethod("randomizeRCBD") 

randomizeRCBD.default <- function(generate, r = 2, trial = 1) {
  
  if (is.null(trial) || trial < 1 || is.character(trial) || length(trial) > 1) { stop("The argument 'trial' should be a single value greater than or equal to 1.") }
  if (is.null(r) || r < 2 || is.character(r) || length(r) > 1) { stop("The argument 'r' should be a single value greater than or equal to 2.") }
  if (missing(generate)) { stop("The argument 'generate' is missing.") }
  if (!is.list(generate)) { stop("The argument 'generate' must be a list.") }
  
  tempComb <- GenerateFactor(generate, times = 1)
  randomize <- NULL
  
  for (i in (1:trial)) {
    for (j in (1:r)) {
      temp <- data.frame(Trial = as.character(i), Rep = as.character(j), tempComb, tempPlotNum = sample(nrow(tempComb), nrow(tempComb), replace = FALSE))
      temp <- temp[order(temp[,"tempPlotNum"]),]
      plotLabel <- as.numeric(paste(j, paste(c(rep(0, max(nchar(1:nrow(tempComb))))), collapse = ""), sep = ""))+1:nrow(tempComb)
      if (ncol(tempComb) > 1) { trmtLabel <- eval(parse(text = paste("paste(temp[,'", paste(names(temp)[3:(ncol(temp)-1)], collapse = "'],' ',temp[,'", sep = ""),"'], sep = '')", sep = "")))
      } else { trmtLabel <- temp[,3] }
      randomize <- rbind(randomize, cbind(temp, trmtLabel, plotLabel))
    }
  }
  # randomize <- randomize[,-I(c(match(c("trmtLabel", "tempPlotNum"), names(randomize))))]
  randomize <- randomize[,-I(c(match(c("tempPlotNum"), names(randomize))))]
  names(randomize)[ncol(randomize)] <- c("PlotNum")
  randomize <- randomize[order(randomize$Trial, randomize$Rep, randomize$PlotNum),]
  rownames(randomize) <- 1:nrow(randomize)

  return(fieldbook = randomize)
}
