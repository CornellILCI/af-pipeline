# This function is based on "design.rcbd" function from agricolae 1.3-2 package (Mendiburu, 2020)
# Details which ebs will not use were removed, as the randomization and kinds arguments (present in orginal agricolae function)
randRCBD <- function (trt, r, tag = 2, seed = 0, continue = FALSE)
{
  number <- 10
  if (tag > 0)
    number <- 10^tag
  ntr <- length(trt)
  if (seed == 0) {
    genera <- runif(1)
    seed <- .Random.seed[3]
  }
  set.seed(seed)
  parameters <- list(design = "rcbd", trt = trt, r = r,
                     tag = tag, seed = seed)
  mtr <- trt
  mtr <- sample(trt, ntr, replace = FALSE)
  block <- c(rep(1, ntr))
  for (y in 2:r) {
    block <- c(block, rep(y, ntr))
    mtr <- c(mtr, sample(trt, ntr, replace = FALSE))
  }
  plots <- block * number + (1:ntr)
  book <- data.frame(plots, block = as.factor(block), trt = as.factor(mtr))
  names(book)[3] <- c(paste(deparse(substitute(trt))))
  names(book)[3] <- c(paste(deparse(substitute(trt))))
  if (continue) {
    start0 <- 10^tag
    if (tag == 0)
      start0 <- 0
    book$plots <- start0 + 1:nrow(book)
  }
  outdesign <- list(parameters = parameters, book = book)
  return(outdesign)
}
