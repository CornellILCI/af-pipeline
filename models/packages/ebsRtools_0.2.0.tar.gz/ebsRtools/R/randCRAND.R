# This function is based on "design.rcbd" and "design.crd" functions from agricolae 1.3-2 package (Mendiburu, 2020)
# The plot naming and seed logics and the output format were the features based on agricolae. The options of entry order and group are new features.
# Some more small modifications were also implemented to fit ebs needs.
randCRAND <- function (trt, r, tag = 2, seed =0, nTrial = 1, entryOrder = F, group = F)
{
  number <- 10
  if (tag > 0)
    number <- 10^tag
  if (seed == 0) {
    genera <- runif(1)
    seed <- .Random.seed[3]
  }
  set.seed(seed)
  parameters <- list(design = if(!entryOrder){"Completely Randomized"}else{"Entry Order"}, trt = trt, r = r, seed = seed)

  for(w in c(1:nTrial)){
    if(w==1)
    {trials <- list()}
    ntr <- length(trt)
    trtN <- c(1:length(trt))
    unique <- data.frame(trtN = trtN, entry = trt, rep = r)
    list <- rep(trtN[1],r[1])
    for(i in 2:ntr){list <- c(list,rep(trtN[i], r[i]))}

    if(entryOrder){
      rand <- list
    } else {(rand <- sample(list,length(list), replace=F))}

    plots <- number + (1:length(rand))
    book <- data.frame(plots, trtN = rand)
    book$entry <- unique$entry[match(book$trtN,unique$trtN)]
    tmp <- book[order(book[,"trtN"]),]
    rep <- c(1:unique[1,"rep"])
    for(i in 2:ntr){
      rep <- c(rep, c(1:unique[i,"rep"]))
    }
    tmp$rep <- rep
    book <- tmp[order(tmp[,"plots"]),]
    if(entryOrder & group) {
      tmp <- book
      tmp <- tmp[with(tmp,order(rep,trtN)),]
      book[,c("entry","rep")] <- tmp[,c("entry","rep")]
    }
    book$trtN <- NULL
    book$rep <- as.factor(book$rep)
    design <- list(parameters = parameters, book = book)
    trials[[w]] <- design
  }
  return(trials)
}
