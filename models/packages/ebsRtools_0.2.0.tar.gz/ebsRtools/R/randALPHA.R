# This function is based on:
# Patterson & Williams (1976). A new class of resolvable incomplete block design. Biometrika.
# and
# Agricolae function "design.alpha" : agricolae 1.3-2 package (Mendiburu, 2020)
# The some arguments, tag method, errors messages and result structure were base on agricolae function.
# We made changes to fit the ebs needs and to be able to run alpha-lattice (0,1,2)

randALPHA <- function (trt, k, r, tag = 2, nTrial = 1)
{
  number <- 10
  if (tag > 0)
  {number <- 10^tag}
  name.trt <- c(paste(deparse(substitute(trt))))
  v <- length(trt)
  if(!any(v %% 2:(v-1) == 0))
  {stop("nTreatment is a prime number. The implemented Alpha-lattice designs (with equal block size) can not handle this")}
  else{
    s <- v/k
    if (v%%k != 0)
      stop("\nThe block size is not appropriate. nTreatments must be multiple of k (block size).")
    else{
      for(w in c(1:nTrial)){
        if(w==1)
        {trials <- list()}
        E <- ((v-1)*(r-1))/((v-1)*(r-1)+((r)*(s-1)))
        res.mod.s <- rep(c(0:s)[1:s],times = s)
        serie <- NA
        ex <- sample(res.mod.s,k*r,replace = T)

        #alpha-lattice, serie I
        if(r==2 & k<=s){
          serie <- "I"
          ex <- c(rep(0,k),seq(0,(k-1)))
        }

        #alpha-lattice, serie II
        if(r==3){
          if(s%%2 != 0 & k <= s){
            serie <- "II"
            ex <- c(rep(0,k),seq(0,(k-1)),c(0,seq(max(res.mod.s),0)[c(1:k-1)]))
          }
          if(s%%2 == 0 & k <= s-1){
            serie <- "III"
            ex <- c(rep(0,k), seq(0,(k-1)),as.vector(rbind(seq(0,k)[seq(k/2)],seq(s/2,k*2)[seq(k/2)])))
          }
        }

        #alpha-lattice, serie IV
        if(r == 4 & s%%2 != 0 & s%%3 != 0 & k<=s){
          serie <- "IV"
          ex <- c(rep(0,k),
                  seq(0,(k-1)),
                  c(0,seq(s-1,1))[c(1:(k))],
                  as.vector(rbind(seq(0,(k+1)),seq((s+1)/2,k*2)))[1:k])
        }

        alpha <- matrix(ex,k,r)
        alphax <- matrix(NA,k,s)
        for(o in c(1:r)){ #for each rep (col in alpha)
          for(l in c(1:s)){ #and each block (col in alphax)
            alphax[,l] <- alpha[,o] + res.mod.s[l] #sum the respective res.mod.s
          }
          if(o==1){
            tmp <- alphax}
          else{
            tmp <- cbind(tmp,alphax)}
        }

        alphax <- tmp%%s
        plan <- alphax
        for(o in c(0:k-1)){
          plan[o+1,] <- alphax[o+1,]+(o*s)
        }
        if(v<=1000){
          M <- matrix(NA,v,v)
          rownames(M) <- c(1:v)-1
          colnames(M) <- c(1:v)-1
          for(i in as.numeric(rownames(M))){
            for(j in as.numeric(colnames(M))){
              if(j>i){
                pi <- as.integer(i/s)+1
                pj <- as.integer(j/s)+1
                #setconcur <- matrix(NA,1,r)
                # for(q in c(1:r)){
                #   setconcur[q] <- (alpha[pj,q]-alpha[pi,q])%%4
                # }
                setconcur <- alpha[pj,]-alpha[pi,]
                M[i+1,j+1] <- sum((j-i)%%s==setconcur)
              }
            }
          }
          gs <- sort(unique(c(M))[!is.na(unique(c(M)))])
          alphaType <- paste("Alpha-Latice (",paste(gs,collapse=","),")", sep="")
          report_gs <- matrix(NA,1,length(gs))
          for(i in (1:length(gs))){
            report_gs[i] <- sum(M==gs[i], na.rm = T)
          }
          Concurrences <- paste(gs,"(",report_gs,")", sep="")
        }else{
          alphaType <- "Alpha-Lattice"
          Concurrences <- "nTreatment too large, value not calculated"
        }

        #fieldbook
        book <- data.frame(origem = c(1:(r*v)),
                           trt = as.numeric(plan)+1,
                           block = rep(c(1:(r*s)), each=k),
                           rep = rep(c(1:r), each=v),
                           randK = c(sample(1:(r*v),r*v)),
                           randS = c(rep(sample(1:(s*r)),each =k)))

        book <- book[with(book, order(rep,randS,randK)),c("trt","block","rep")]
        book$block <- rep(c(1:(r*s)), each=k)
        book$plots <- book$rep * number + (1:v)
        book$entry <- trt[book$trt]
        book <- book[,c("plots","block","rep","entry")]
        rownames(book) <- c(1:nrow(book))
        parameters <- list(design = alphaType, Efficiency = E, trt = trt,
                           k = k, r = r, Concurrences = Concurrences)
        design <- list(parameters = parameters, book = book)
        trials[[w]] <- design
      }
    }
  }
  return(trials)
}
