// -*- mode: c++ -*-
///////////////////////////////////////////////////////////////////////////
/*
  This file is part of MABC, a R package for marker assisted back cross

  Copyright (C) 2020 Fernando H. Toledo CIMMYT
              
  * Filename: MABC.cpp
 
  * Description: C++ implementations to be used by MABC R package
 
  * Author: Fernando H. Toledo
 
  * Maintainer: Fernando H. Toledo
 
  This program is free software; you can redistribute it and/or modify 
  it under the terms of the GNU General Public License as published by 
  the Free Software Foundation; either version 2 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software Foundation, 
  Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
                                                         
  `` Far better an approximate answer to the right question, which is 
  often vague, than the exact answer to the wrong question, which can
  always be made precise ''
  --John Tukey, Ann. Math. Stat. 33(1):13 1962
*/
//////////////////////////////////////////////////////////////////////////

# include <MABC.h>

// [[Rcpp::export(name = .RPP, rng = false)]]
vecd RPP(vecd p, double w) {

  auto r(range(p.begin(), p.end())) ;

  vecd v(p.size(), .0) ;

  for (auto it = 0; it < p.size(); it++) {

    if (p.at(it) == p.at((r.first - p.begin()))) {

      v.at(it) = smaller(w / 2., (p.at(it + 1) - p.at(it)) / 2.) ;

    } else if (p.at(it) == p.at((r.second - p.begin()))) {

      v.at(it) = smaller(w / 2., (p.at(it) - p.at(it - 1)) / 2.) ;

    } else {

      v.at(it) = smaller(w / 2., (p.at(it) - p.at(it - 1)) / 2.)
               + smaller(w / 2., (p.at(it + 1) - p.at(it)) / 2.) ;

    }

  }

  return v ;

}


// \EOF
///////////////////////////////////////////////////////////////////////////
