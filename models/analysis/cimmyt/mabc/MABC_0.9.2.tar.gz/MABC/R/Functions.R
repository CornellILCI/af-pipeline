## -*- mode: R -*-
###########################################################################
## This file is part of MABC, a R package for marker assisted back cross
##
##              Copyright (C) 2020 Fernando H. Toledo CIMMYT
##              
## * Filename: Functions.R
## 
## * Description: Package Interface
## 
## * Author: Fernando H. Toledo
## 
## * Maintainer: Fernando H. Toledo
## 
##   This program is free software; you can redistribute it and/or modify 
##   it under the terms of the GNU General Public License as published by 
##   the Free Software Foundation; either version 2 of the License, or 
##  (at your option) any later version.
##
##   This program is distributed in the hope that it will be useful, but 
##   WITHOUT ANY WARRANTY; without even the implied warranty of 
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
##   General Public License for more details.
##
##   You should have received a copy of the GNU General Public License
##   along with this program; if not, write to the Free Software Foundation, 
##   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
##                                                        
##   `` Far better an approximate answer to the right question, which is 
##   often vague, than the exact answer to the wrong question, which can
##   always be made precise ''
##                          --John Tukey, Ann. Math. Stat. 33(1):13 1962
##
###########################################################################

##' @export
##' @title Recurrent Parent Percentage
##'
##' @name RPP
##'
##' @description Obtains recurrent parent percentage statistics (RPP).
##'
##' @details Marker Assisted Back Cross. Recurrent Parent Percentage.  
##' Reproduce procedures found in Flapjack. Details of the implementation 
##' are described in \insertCite{flapjack;textual}{MABC}.
##'
##' @references
##'     \insertAllCited{}
##'
##' @return Data.table with results.
##'
##' @param MAPFILE string with the file name containing the map information.
##' @param MKRFILE string with the file name containing the marker information.
##' @param W numeric scalar with the windows to be used for calculations.
##' @param RP,DP strings with the identification of recurrent and donor parents.
##' @param OUTFILE string with the file name where outputs will be saved.
##'
##' @examples
##'
##' \dontrun{
##' ## inputs:
##' mapvalf <- system.file("extdata", "map.csv", package = "MABC") 
##' markerf <- system.file("extdata", "mkr.csv", package = "MABC") 
##' windows <- 20 
##' recupar <- 'P1'
##' donopar <- 'P2'
##' outputf <- 'out.csv' 
##' RPP(mapvalf, markerf, windows, recupar, donopar, outputf)
##' }
##' 
##' @rdname RPP
RPP <- function(MAPFILE, MKRFILE, W, RP, DP, OUTFILE) {
  
    ## **no visible binding for global variable**
    chr <- pos <- mkr <- .N <- weight <- N <- GT <- GID <- gen <- GC <- NULL 

    ## loading files
    MAP <- data.table::fread(file = MAPFILE, header = TRUE, sep = ',')
    MKR <- data.table::fread(file = MKRFILE, header = TRUE, sep = ',')

    ## ordering by chromosome and positions
    MAP <- MAP[order(chr, pos),]

    ## get genome length by chromosome
    GL <- MAP[, list(GL = diff(range(pos))), by = chr]

    ## adding weights to map **call C++ code**
    WGH <- MAP[, list(mkr = mkr, weight = .RPP(pos, w = W)), by = chr]

    ## obtain genome size and coverage by chromosome
    GCN <- data.table::merge.data.table(WGH[, list(N  = .N, 
                                                   GT = sum(weight)), 
                                            by = chr], 
                                        GL, by = "chr")[, list(chr = chr, 
                                                               N   = N, 
                                                               GT  = GT, 
                                                               GC  = GT / GL)]

    ## join coverage with weights **marker statistics**
    STT <- data.table::merge.data.table(WGH, GCN, by = "chr")

    ## marker data in long format
    MKL <- data.table::melt(MKR, id.vars = "GID", variable.name = "mkr", value.name = "gen")

    ## joint with marker statistics
    MKW <- data.table::merge.data.table(STT, MKL, by = "mkr")

    ## get parent information
    RPV <- MKL[GID == RP, list(mkr = mkr, RP = gen)]
    DPV <- MKL[GID == DP, list(mkr = mkr, DP = gen)]
    PSV <- data.table::merge.data.table(RPV, DPV, by = "mkr")

    ## marker full information **working data**
    MKF <- data.table::merge.data.table(MKW, PSV, by = "mkr")

    ## get recurrent parent information
    MKR <- MKF[, list(chr = chr, RPP = ifelse(gen == RP, weight, ifelse(gen == DP, 0, weight / 2)) / GT), by = GID]

    ## genotype statistics
    MKS <- MKF[, list(dat_count = length(which(!is.na(gen))),
                      dat_perct = 100 * length(which(!is.na(gen))) / 61,
                      het_count = length(which(gen == "AB")),
                      het_perct = 100 * length(which(gen == "AB")) / length(which(!is.na(gen))),
                      coverage = mean(GC)),
               by = list(GID)]

    ## recurrent parent information by chromosome
    RPC <- MKR[, list(RPP = sum(RPP)), by = list(GID, chr)]

    ## recurrent parent information total
    RPT <- RPC[, list(RPP_Total = mean(RPP)), by = GID]

    ## recurrent parent summary
    RPS <- data.table::merge.data.table(data.table::dcast(RPC, GID ~ chr, value.var = "RPP"), RPT, by = "GID")

    ## output table
    OUT <- data.table::merge.data.table(MKS, RPS, by = "GID")

    ## save output
    data.table::fwrite(OUT, file = OUTFILE,
                       append = FALSE, quote = FALSE,
                       sep = ',', eol = "\n", na = ".", dec = ".",
                       row.names = FALSE, col.names = TRUE)

    return(invisible(OUT))

}

## \EOF
###########################################################################
