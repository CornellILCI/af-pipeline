// -*- mode: c++ -*-
///////////////////////////////////////////////////////////////////////////
/*
 This file is part of MABC, a R package for marker assisted back cross

              Copyright (C) 2020 Fernando H. Toledo CIMMYT
              
 * Filename: MABC.h
 
 * Description: exposed C++ infrastructure of MABC package
 
 * Author: Fernando H. Toledo
 
 * Maintainer: Fernando H. Toledo
 
  This program is free software; you can redistribute it and/or modify 
  it under the terms of the GNU General Public License as published by 
  the Free Software Foundation; either version 2 of the License, or 
  (at your option) any later version.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software Foundation, 
  Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
                                                        
  `` Far better an approximate answer to the right question, which is 
  often vague, than the exact answer to the wrong question, which can
  always be made precise ''
                         --John Tukey, Ann. Math. Stat. 33(1):13 1962
*/
///////////////////////////////////////////////////////////////////////////

# ifndef _MABC_INTERFACE_H_
# define _MABC_INTERFACE_H_

// --Rcpp attributes--
// [[Rcpp::plugins(cpp14)]]

# include <Rcpp.h>
# include <vector>
# include <algorithm>

// type alias
typedef std::vector<double> vecd ;

// function alias
template <typename... Args>
auto range(Args&&... args) -> decltype(std::minmax_element(std::forward<Args>(args)...)) {
  return std::minmax_element(std::forward<Args>(args)...) ;
}

// function alias
template <typename... Args>
auto smaller(Args&&... args) -> decltype(std::min(std::forward<Args>(args)...)) {
  return std::min(std::forward<Args>(args)...) ;
}

// forward declaration for **recurent parent percentage**
vecd RPP(vecd, double) ;

# endif // _MABC_INTERFACE_H_

// \EOF
///////////////////////////////////////////////////////////////////////////
