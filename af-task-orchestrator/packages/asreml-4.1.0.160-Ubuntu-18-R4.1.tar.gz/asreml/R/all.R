#' Fit the linear mixed model.
#'
#' asreml estimates variance components under a general linear mixed
#' model by residual maximum likelihood (REML).
#'
#' Models for \code{asreml} are specified symbolically in the formula
#' objects \code{fixed, random, sparse} and \code{residual}. A typical
#' model has the form \code{response} \eqn{\sim} \code{terms},
#' \code{fixed} only, or \eqn{\sim} \code{terms} for \code{random},
#' \code{sparse} and \code{residual}, where \code{response} is the
#' (usually numeric) response vector and \code{terms} is a linear
#' predictor for \code{response}. An exception is raised if the
#' response is a factor and \code{family} is not multinomial.
#'
#' The formulae objects are parsed in the context of the data frame,
#' all internal data structures are constructed in \pkg{R} or compiled
#' code, and the model is fitted by calls to the underlying
#' \code{Fortran} \code{REML} routines (\cite{Gilmour et al.,
#' 1995}). Variance models for random model terms are specified using
#' \emph{special} functions in the \code{random} and \code{residual}
#' formulae. If not specified, the variance models default to (scaled)
#' identity structures. A table of special model functions is included
#' below; see the reference guide or appropriate vignette for further
#' details and examples of their use.  Some of these model functions
#' require the formula arguments to be partially evaluated before the
#' final model frame is computed; it is recommended that all names
#' used in the formulae be resolvable in a data frame named by the
#' \code{data} argument.
#'
#' If the response is a matrix, a multivariate linear model is fitted
#' to the columns unless \code{family} = \code{asr_multinomial()} is
#' declared.
#'
#' The terms in the \code{fixed} formula are re-ordered by default so
#' that main effects preceed interactions in increasing order. The
#' option \code{keep.order} (see \code{asreml.options}) can be used to
#' modify this behaviour.
#'
#' A formula has an implied intercept term. To remove the intercept
#' use \code{y} \eqn{\sim}{~} \code{-1 + ...}. This is only effective
#' in the \code{fixed} formula; in all other formula arguments any
#' reference to the intercept is ignored. Note that currently there
#' must be at least one fixed effect in the model.
#'
#' In addition to the formal arguments, various options can be set
#' with \code{\link{asreml.options}}; these are stored in an
#' environment for the duration of the \code{R} session.
#'
#' \code{asreml} uses either a \code{"gamma"} (ratio) or \code{"sigma"}
#' (component) scale
#' parameterization for estimation depending on the residual model
#' specification. The current default for single section analyses is
#' the gamma parameterization if the error model specifies a
#' correlation structure. In this case, all scale parameters are
#' estimated as a ratio with respect to the residual variance, with
#' correlation parameters unchanged. If the residual model specifies a
#' variance structure then variance parameters are estimated on the
#' sigma scale. For models with more than one residual section,
#' \code{asreml} always estimates variance parameters on the sigma
#' scale.
#'
#' @param fixed
#'
#' A formula object specifying the fixed terms in the model, with the
#' response on the left of a \eqn{\sim}{~} operator, and the terms,
#' separated by + operators, on the right. If \code{data} is given,
#' all names used in all formulae should appear in the data frame. A
#' model with the intercept as the only fixed effect can be specified
#' as \eqn{\sim}{~}1; there must be at least one fixed effect
#' specified. If the response (\emph{y}) evaluates to a matrix then a
#' factor \code{trait} with levels \code{dimnames(y)[[2]]} is added to
#' the model frame, and must be explicitly included in the model
#' formulae.
#'
#' @param random
#'
#' A formula object specifying the random effects in the model. This
#' argument has the same general characteristics as \code{fixed}, but
#' there can be no left side to the \eqn{\sim}{~} operator. Variance
#' structures imposed on random terms are specified using
#' special model functions.
#'
#' @param sparse
#'
#' A formula object, specifying the fixed effects for which the full
#' variance-covariance matrix is not required. This argument has the
#' same general characteristics as \code{fixed}, but there can be no
#' left side to the \eqn{\sim}{~} expression. Wald statistics are not
#' available for sparse fixed terms in order to reduce the computing
#' load.
#'
#' @param residual
#'
#' A formula object specifying the residual model; any term specified
#' on the left of the \eqn{\sim}{~} expression is ignored. The default
#' is \eqn{\sim}{~}\code{units}, where the reserved word \code{units}
#' is defined as \code{seq(1,nrow(data))} and is automatically included
#' in the model frame.  Variance models for the residual component of
#' the model can be specified using special model functions.
#'
#' For single-section univariate models, the residual variance model
#' determines the computational mode: If the residual variance model
#' specifies a correlation structure (includes \code{id()}), then the
#' model is fitted on the gamma scale, otherwise the model is
#' fitted on the sigma scale. The default is \code{id(units)} if
#' not explicitly specified.
#'
#' @param G.param
#'
#' Either,
#'
#' \itemize{
#'
#' \item a list object derived from the
#' \code{random} formula, holding initial parameter estimates and
#' boundary constraints for each term, or
#'
#' \item a character string naming a comma delimited file with a
#' header line and three columns for the variance component name,
#' initial value and constraint code, respectively. This file can be
#' created using the \code{start.values} argument; the internal list
#' object is then generated from the contents of this file.
#' }
#'
#' On termination, \code{G.param} is updated with the final
#' \code{random} component estimates.
#'
#' @param R.param
#'
#' Either,
#' \itemize{
#' \item a list object derived from the \code{random} formula, holding
#' initial parameter estimates and boundary constraints, or
#'
#' \item a character string naming a comma delimited file with a
#' header line and three columns for the variance component name,
#' initial value and constraint code, respectively. This file can be
#' created using the \code{start.values} argument; the internal list
#' object is then generated from the contents of this file.
#' }
#'
#' On termination, \code{R.param} is updated with the final
#' \code{residual} component estimates.
#'
#' @param data
#'
#' A data frame in which to interpret the variables named in
#' \code{fixed}, \code{random}, \code{sparse} and \code{residual}. If
#' the \code{data} argument is missing, the default is
#' \code{sys.parent()}. The data frame is converted
#' internally to a \code{data.table} object and returned as such by
#' \code{model.frame}.
#'
#' @param na.action
#'
#' A call to \code{na.method()} specifying the action to be taken when
#' missing values are encountered in the response (\code{y}) or
#' explanatory variables (\code{x}). The function definition for
#' \code{na.method} is:
#'
#' \code{function(y=c("include","omit","fail"),}
#' \code{x=c("fail","include","omit"))}
#'
#' The default action is to include (and estimate) missing values in
#' the response, and raise an error if there are missing values in the
#' explanatory variables.
#'
#' @param subset
#'
#' A logical vector identifying which subset of the rows of \code{data}
#' should be used in the fit. All observations are included by
#' default.
#'
#' @param weights
#'
#' A character string or name identifying the column of \code{data} to
#' use as weights in the fit.
#'
#' @param predict
#'
#' A list object specifying the classifying factors and related
#' options when forming predictions from the model. This list would
#' normally be the value returned by a call to the method
#' \code{predict} for \code{asreml} objects.
#'
#' @param vcm
#'
#' A matrix defining relationships among variance parameters. The
#' matrix has a row for each original variance parameter and a column
#' for each new parameter. The default is the identity matrix, that
#' is, no action. See \code{vcm.lm} for further information
#' and an example.
#'
#' @param vcc
#'
#' Equality constraints between variance parameters; a two-column
#' numeric matrix with a \code{dimnames} attribute. The first column
#' defines the \emph{grouping} structure of equated components, that
#' is, components within an equality \emph{group} are given the same
#' numeric index, and the second column contains the scaling
#' coefficients. The \code{dimnames()[[1]]} attribute must match the
#' component names in the \code{asreml} parameter vector; see
#' \code{start.values}.
#'
#' The parameters are scaled relative to the first parameter in its
#' group, so the scaling of the first parameter in each group is one.
#'
#' For example, the following \code{vcc} matrix
#' \tabular{ll}{
#' 1 \tab 1 \cr
#' 2 \tab 1 \cr
#' 2 \tab 2 \cr
#' 3 \tab 1 \cr
#' }
#'
#' is equivalent to the \code{vcm} matrix
#'
#' \tabular{lll}{
#' 1 \tab 0 \tab 0 \cr
#' 0 \tab 1 \tab 0 \cr
#' 0 \tab 2 \tab 0 \cr
#' 0 \tab 0 \tab 1 \cr
#' }
#'
#' @param family
#'
#' A list of functions and expressions for defining the link and
#' variance functions. Optionally a list of such structures for a
#' multivariate analysis involving non-normal variates. Currently this
#' is restricted to a bivariate model where the first variate
#' (excluding the multinomial distribution) is non-normal.
#'
#' Supported families are \emph{gaussian}, \emph{inverse Gaussian},
#' \emph{binomial}, \emph{negative binomial}, \emph{poisson},
#' \emph{Gamma} and \emph{multinomial}. Family objects are generated
#' from the \code{asreml} \link[=asr_families]{family functions} which
#' prefix the usual function names with \code{"asr_"}; for example
#' \code{asr_gaussian()}, \code{asr_binomial()} etc. In addition to
#' the link argument, these functions take an additional
#' \code{dispersion} argument and a \code{total} argument where
#' relevent; for example:
#'
#'   \code{asr_binomial(dispersion=1.0, total=counts)}.
#'
#' The default for \code{asr_gaussian()} is \code{dispersion=NA},
#' which implies that \code{asreml} will estimate the dispersion
#' parameter, otherwise the scale is fixed at the nominated value.
#'
#' @param asmv
#'
#' A character string or name specifying the column in the data that
#' identifies the traits in a multivariate analysis. If not
#' \code{NULL}, \code{asmv} implies that the data for a multivariate
#' analysis is set up as though it were for a univariate analysis with
#' the response in a single variate.
#'
#' @param mbf
#'
#' A named list specifying sets of covariates to be included with one
#' or more \code{mbf()} model functions. Each component of the list
#' must in turn contain components named \code{key} and \code{cov},
#' where \code{cov} is a character string naming the data frame
#' holding the covariates, and \code{key} is a character vector of
#' length 2 naming the columns in \code{data} and \code{cov},
#' respectively, used to match corresponding records in the two data
#' frames. The default is an empty list.
#'
#' @param group
#'
#' A named list where each component is a numeric vector specifying
#' contiguous fields in \code{data} that are to be considered as a
#' single term. The component names can then appear in asreml model
#' formulae using the \code{grp()} special function. The default is an
#' empty list.
#'
#' @param equate.levels
#'
#' A character vector of factor names whose levels are to be
#' \emph{equated}. If factor \code{A} has levels \emph{a,b,c,d} and
#' factor \code{B} has levels \emph{a,b,c,e}, the effect of
#' \code{equate.levels(A, B)} is that both \code{A} and \code{B} have
#' 5 levels, with \code{as.numeric(A)} = \emph{1,2,3,4} and
#' \code{as.numeric(B)} = \emph{1,2,3,5.} This may be necessary if
#' using the \code{and} model function to overlay columns of the
#' model's design matrix in forming a compound term. The default is a
#' zero length character vector.
#'
#' @param start.values
#'
#' If \code{TRUE}, \code{asreml} exits prior to the fitting process
#' and returns a list of length 3: the \code{G.param} and
#' \code{R.param} lists, and a data frame containing variance
#' parameter names, initial values and boundary constraints. Initial
#' values or constraints can then be set in the list or data frame
#' objects.
#'
#' If a character string, then a file of that name is created and the
#' data frame object containing initial parameter values is written
#' out in comma separated form. This file can be edited externally and
#' subsequently specified in the \code{G.param} or \code{R.param}
#' arguments.
#'
#' @param knot.points
#'
#' A named list where each component is a vector of user supplied knot
#' points for a particular spline term; the component name is the
#' object of the \code{spl()} model function.
#'
#' @param pwr.points
#'
#' A named list with each component containing a vector of distances
#' to be used in a one-dimensional power model. The component
#' names must correspond to the \code{object} arguments of the power
#' function model terms.
#'
#' @param wald
#'
#' A named list with four components: \code{denDF}, \code{ssType},
#' \code{Ftest} and \code{kenadj}.
#'
#' \describe{
#'
#' \item{denDF}{a character string from the set \code{["none"},
#' \code{"numeric"}, \code{"algebraic"}, \code{"default"]} specifying
#' the calculation of approximate denominator degrees of freedom. The
#' default \code{"none"} is to suppress the computations. Algebraic
#' computations are not feasible in large analyses, use
#' \code{"default"} to autommatically choose numeric or algebraic
#' computations depending on problem size. The denominator degrees of
#' freedom are calculated according to \cite{Kenward and Roger, 1997}
#' for terms in the \code{fixed} model formula.}
#'
#' \item{ssType}{can be \code{"incremental"} for incremental sum of
#' squares (the default) or \code{"conditional"} for F-tests that
#' respect both structural and intrinsic marginality.}
#'
#' \item{Ftest}{a one sided formula of the form \eqn{\sim}\code{test_term |
#' background_terms} specifying a conditional Wald test of the
#' contribution of \code{test_term} conditional on those fixed terms
#' listed in \code{background_terms}, and the those in the
#' \code{random} and \code{sparse} model formulae.}
#' 
#' \item{kenadj}{a character string from the set \code{["none"},
#' \code{"expected"}, \code{"observed]"}, specifying any adjustment to
#' the variance matrix for fixed effects.}}
#'
#' @param prune
#'
#' A named list with each component generated from a call to
#' \code{Subset()}. \code{prune}, in conjunction with \code{Subset}
#' and the model function \code{sbs()}, forms a new factor from an
#' existing one by selecting a subset of its levels. The function
#' \code{Subset} is defined as:
#'
#' \code{function(f, x)}
#'
#' where \code{f} is the name of an existing factor and \code{x} is a
#' character or numeric vector of levels to select. The name of the
#' list component is the new factor that may appear in the model
#' formulae as the argument to the \code{sbs()} model function. For
#' example,
#'
#' \code{prune=list(A=Subset(Site, c(2,3)))}
#'
#' creates a new factor \code{A} by selecting the second and third
#' levels of \code{Site}, and would be included in the model as
#' \code{sbs(A)}. While the actions of \code{prune} can be duplicated
#' outside \code{asreml}, \code{sbs()} is necessary if the
#' \code{asreml} method \code{predict()} is to be used.
#'
#' @param combine
#'
#' A named list with each component generated from a call to
#' \code{Levels()}. \code{combine}, in conjunction with \code{Levels}
#' and the model function \code{gpf()} forms a new factor from an
#' existing one by merging a subset of its levels. The function
#' \code{Levels} is defined as:
#'
#' \code{function(f, x)}
#'
#' where \code{f} is the name of an existing factor and \code{x} is a
#' vector of length \cr \code{length(levels(f))} defining the levels
#' of \code{f} to merge. The name of the list component is the new
#' factor that may appear in the model formulae as the argument to the
#' \code{gpf()} model function. For example, if \code{Site} has levels
#' \code{"1"}, \code{"2"} and \code{"3"},
#'
#' \code{combine=list(A=Levels(Site, c("1","2","1")))}
#'
#' creates a new factor \code{A} with levels \code{"1"} and \code{"2"}
#' by merging levels \code{"1"} and \code{"3"} of \code{Site}, and
#' would be included in the model as \code{gpf(A)}. While the actions
#' of \code{combine} can be duplicated outside \code{asreml},
#' \code{gpf()} is necessary if the \code{asreml} method
#' \code{predict()} is to be used.
#'
#' @param uid
#'
#' A named list with each component generated from a call to
#' \code{Units()}. \code{uid}, in conjunction with \code{Units} and
#' the model function \code{uni()} forms a new factor by selecting a
#' subset of records for an existing one. The function \code{Units} is
#' defined as:
#'
#' \code{function(f, n=0)}
#'
#' where \code{f} is the name of an existing factor and \code{n} is a
#' character or numeric scalar that determines which records are
#' selected. The default, \code{n=0}, forms a factor with a level for
#' each record where \code{f} is non-zero (strictly, \code{f} !=
#' 0). Otherwise, a factor with a level for each record in
#' \code{data} where \code{f} has the value \code{n} is formed. For example,
#'
#' \code{uid = list(A = Units(group, 1))}
#'
#' creates a new factor \code{A} with levels from
#' \code{row.names(data)} where \code{group} = 1, and would be
#' included in the model as \code{uni(A)}. While the actions of
#' \code{uid} can be duplicated outside \code{asreml}, \code{uni()} is
#' necessary if the \code{asreml} method \code{predict()} is to be
#' used.
#'
#' @param mef
#'
#' A named list linking a relationship matrix (or its inverse) as
#' specified in the \code{vm()} special function with the original
#' matrix of \emph{subject} x \emph{regressor} (typically molecular
#' marker) scores. If not an empty list (the default), \code{mef}
#' flags the computation of the \emph{regressor} (marker) effects from
#' the \emph{subject} effects. For example,
#'
#' \code{mef=list(MM = snp.mat)}
#'
#' links the relationship matrix \code{MM} to the original marker
#' scores in \code{snp.mat}.
#'
#' The \code{mef} list would typically be set from a call to the \code{asreml}
#' \code{meff()} method.
#'
#' @param last
#'
#' A named list restricting the order equations are solved in the sparse
#' partition for the nominated model terms. Each component of the list is
#' named by a model term and contains a scalar \eqn{n} specifying that
#' the first \eqn{n} levels of the term be solved after all others in the
#' sparse set. It is intended for use when there are multiple fixed terms
#' in the sparse equations so that \code{asreml} will be consistent in
#' which efects are identified as singular. A maximum of three factor/level
#' pairs can be specified.
#'
#' @param model.frame
#'
#' If \code{TRUE} (the default) the model frame (a \code{data.table}
#' object with additional attributes derived from the model
#' specification) is included in the returned object.
#'
#' The model frame is required by the \code{asreml} \code{summary},
#' \code{plot}, \code{resid} and \code{fitted} methods.
#'
#' In large analyses, the model frame is likely to be a large
#' object. If \code{model.frame} is a character string, the model
#' frame is saved in a file as an \code{RDS} object by a call to
#' \code{saveRDS()}, and named by the supplied string with the
#' extension \code{.RDS}. If the model frame is not included in the
#' returned \code{asreml} object, this \code{RDS} file is searched for
#' by the methods noted above.
#'
#' @param ...
#'
#' Additional arguments to \code{asreml} from \code{asreml.options()}:
#' \code{maxit}, \code{workspace}, \code{pworkspace}, \code{fixgammas},
#' \code{trace}, \code{aom}.
#'
#' @return
#'
#' An object of class \code{asreml} containing the results of the
#' fitted model. Instances of generic methods such as \code{plot()},
#' \code{predict()} and \code{summary()} return various derived
#' results of the fit; \code{resid()}, \code{coef()} and
#' \code{fitted()} extract some of its components. See
#' \code{\link{asreml.object}} for the components of the returned
#' list.
#'
#' @seealso
#'
#' \code{\link{asreml.options}} \code{\link{asreml.object}}
#' \code{\link{asr_families}}
#'
#' @section Special functions:
#'
#' Special model functions are used in \code{asreml} formulae objects
#' to create new or modify existing model terms, or more often to
#' specify the variance model associated with one or more terms. These
#' functions can be broadly categorised as
#' \link[=modelFunctions]{constructor-type} functions, or (default)
#' \link[=id]{identity}, \link[=timeSeries]{time-series},
#' \link[=unstructured]{general-structure}, \link[=metric-1d]{1d
#' metric}, \link[=metric-2d]{2d metric}, \link[=knownStruc]{known}
#' relationship, general variance structures that span more than one
#' term (\link[=str]{str}), or \link[=own]{user-defined} structures.
#'
#' The special model functions that are available in
#' \code{asreml} model formulae are introduced below; see the user
#' guide, relevent vignette or the man pages for selected functions
#' for more details or illustration.
#'
#' The symbols used in the following tables are defined as:
#'
#' \tabular{ll}{
#' obj  \tab a factor in \code{data}. \cr
#' n    \tab \code{length(levels(obj))}. \cr
#' p    \tab number of parameters estimated by the base function. \cr
#' v    \tab number of parameters estimated by the homogeneous function form. \cr
#' h    \tab number of parameters estimated by the heterogeneous function form.
#' }
#'
#' \strong{Constructor type functions}
#'
#' \tabular{ll}{
#' \strong{Call} \tab \strong{Description} \cr
#' con(obj)   \tab Apply sum-to-zero constraints to factor \code{obj}. \cr
#' C(obj, contr) \tab Define contrasts among the levels of \code{obj} from
#' the coefficients in \code{contr}.\cr
#' lin(obj)  \tab Fits factor \code{obj} as a variate.\cr
#' pow(obj, p, offset)   \tab Create the term \code{(offset+obj)}\eqn{^p}. \cr
#' pol(x, t)  \tab Orthogonal polynomials to degree \eqn{t};
#' \eqn{-t} omits the intercept polynomial. \cr
#' leg(x, t)  \tab Legendre polynomials to degree \eqn{t};
#' \eqn{-t} omits the intercept polynomial. \cr
#' spl(x, k) \tab The \emph{random} component of a cubic spline;
#' optionally \eqn{k} knot points.\cr
#' dev(x) \tab Fit variate \code{x} as a factor;
#' typically used for spline deviations.\cr
#' ma(obj) \tab Forms a moving average (1) design matrix from factor \code{obj}\cr
#' at(obj, vec) \tab Form conditioning covariables for the levels in \code{obj}
#' given in \code{vec}.\cr
#' dsum(~term | obj, ~model) \tab Direct sum of \code{term} for the
#' levels of \code{obj} with variance structure \code{model}. \cr
#' \tab Used in \code{residual} to define multiple \emph{sections}.\cr
#' and(obj, k) \tab Add \eqn{k} times the design matrix for \code{obj}
#' to the previous columns.\cr
#' grp(name) \tab Include the term defined by \code{name} in
#' the \code{group} argument in the model. \cr
#' mbf(name) \tab Include the covariates defined by \code{name} in
#' the \code{mbf} argument as a factor.\cr
#' sbs(name) \tab Include the term defined in the \code{prune} argument
#' in the model. \cr
#' gpf(name) \tab Include the term defined in the \code{combine} argument
#' in the model. \cr
#' uni(name) \tab Include the term defined in the \code{uid} argument
#' in the model.
#' }
#'
#' \strong{Default identity}
#'
#' \tabular{llrrr}{
#' \strong{Call} \tab \strong{Description} \tab
#' \strong{p} \tab \strong{v} \tab \strong{h} \cr
#' id(obj) \tab identity \tab 0 \tab 1 \tab n
#' }
#'
#' \strong{Time series type models}
#'
#' \tabular{llrrr}{
#' \strong{Call} \tab \strong{Description} \tab
#' \strong{p} \tab \strong{v} \tab \strong{h} \cr
#' ar1(obj)  \tab autoregressive order 1        \tab 1 \tab 2 \tab 1+n\cr
#' ar2(obj)  \tab autoregressive order 2        \tab 2 \tab 3 \tab 2+n\cr
#' ar3(obj)  \tab autoregressive order 3        \tab 3 \tab 4 \tab 3+n\cr
#' sar(obj)  \tab symmetric autoregressive           \tab 1 \tab 2 \tab 1+n\cr
#' sar2(obj) \tab symmetric autoregressive order 2   \tab 2 \tab 3 \tab 2+n\cr
#' ma1(obj)  \tab moving average order 1        \tab 1 \tab 2 \tab 1+n\cr
#' ma2(obj)  \tab moving average order 2        \tab 2 \tab 3 \tab 2+n\cr
#' arma(obj) \tab autoregressive-moving average \tab 2 \tab 3 \tab 2+n\cr
#' }
#'
#' \strong{General structure models}
#'
#' \tabular{llrrr}{
#' \strong{Call} \tab \strong{Description} \tab
#' \strong{p} \tab \strong{v} \tab \strong{h} \cr
#' cor(obj)      \tab simple correlation \tab 1 \tab 2 \tab 1+n\cr
#' corb(obj, b)  \tab banded correlation; b bands \tab b \tab b+1 \tab b+n\cr
#' corg(obj)     \tab general correlation \tab n(n-1)/2 \tab 1+n(n-1)/2 \tab n(n+1)/2\cr
#' diag(obj)     \tab heterogeneous variance \tab n \tab \tab \cr
#' us(obj)       \tab unstructured variance \tab n(n+1)/2 \tab \tab \cr
#' sfa(obj, k)   \tab factor analytic; k factors \tab kn+n \tab \tab \cr
#' fa(obj, k)    \tab sparse factor analytic \tab kn+n \tab \tab \cr
#' facv(obj, k)  \tab factor analytic, covariance form \tab kn+n \tab \tab \cr
#' rr(obj, k)    \tab reduced rank variant of fa \tab kn+n \tab \tab \cr
#' chol(obj, k)  \tab Cholesky order k \tab (k+1)(n-k/2) \tab \tab \cr
#' cholc(obj, k) \tab Cholesky \tab (k+1)(n-k/2) \tab \tab \cr
#' ante(obj, k)  \tab antedependence order k \tab (k+1)(n-k/2) \tab \tab \cr
#' mthr(obj)     \tab multinomial models only \tab \tab
#' }
#'
#' \strong{Metric based models in 1D or 2D}
#'
#' \tabular{llrrr}{
#' \strong{Call} \tab \strong{Description} \tab
#' \strong{p} \tab \strong{v} \tab \strong{h} \cr
#' exp(x)     \tab exponential 1D \tab 1 \tab 2 \tab 1+n\cr
#' iexp(x, y) \tab isotropic exponential 2D \tab 1 \tab 2 \tab 1+n\cr
#' aexp(x, y) \tab anisotropic exponential 2D \tab 2 \tab 3 \tab 2+n\cr
#' gau(x)     \tab gaussian 1D \tab 1 \tab 2 \tab 1+n\cr
#' igau(x, y) \tab isotropic gaussian 2D \tab 1 \tab 2 \tab 1+n\cr
#' agau(x, y) \tab anisotropic gaussian 2D \tab 2 \tab 3 \tab 2+n\cr
#' ieuc(x, y) \tab isotropic euclidean 2D \tab 1 \tab 2 \tab 1+n\cr
#' isp(x, y)  \tab isotropic spherical 2D \tab 1 \tab 2 \tab 1+n\cr
#' cir(x, y)  \tab isotropic circular 2D\tab 1 \tab 2 \tab 1+n\cr
#' mtrn(x, y, ...) \tab Matern class 2D \tab * \tab * \tab *
#' }
#' \eqn{^*}See the user guide for an extended discussion of the Matern class.
#'
#' \strong{Known relationship structures}
#'
#' \tabular{ll}{
#' \strong{Call} \tab \strong{Description} \cr
#' vm(obj, source, singG) \tab Create a term based on \code{obj} with known
#' variance structure in \code{source}.\cr
#' ide(obj) \tab Identity term based on \code{obj} with levels as for
#' \code{vm(obj)}.\cr
#' }
#'
#' \strong{General variance structures}
#'
#' \tabular{ll}{
#' \strong{Call} \tab \strong{Description} \cr
#' str(~terms, ~model) \tab Apply the direct product variance structure
#' in \code{~model} \cr
#' \tab to the set of terms in \code{~terms}.
#'}
#'
#' \strong{User defined structures}
#'
#' \tabular{ll}{
#' \strong{Call} \tab \strong{Description} \cr
#' own(obj, fun, init, type) \tab Call \code{fun} with the parameter
#' estimates in \code{init} \cr \tab to compute the variance matrix
#' and its derivatives.  }
#'
#'
#' @examples
#'
#'
#' \dontrun{
#' data(oats)
#' oats.asr <- asreml(yield ~ Variety*Nitrogen, random = ~ Blocks/Wplots, data=oats)
#' }
#'
#' @references
#' % bibentry: Gilmour:1995
#' % bibentry: Kenward:1997
#'
asreml <- function(fixed = y ~ 1, random=~NULL, sparse=~NULL, residual=~NULL,
                   G.param=list(), R.param=list(), data=sys.parent(),
                   na.action=na.method(), subset, weights,
                   predict = predict.asreml(), vcm = vcm.lm(),
                   vcc = matrix(NA), family=asr_gaussian(), asmv = NULL,
                   mbf = list(), group = list(), equate.levels = character(0),
                   start.values = FALSE, knot.points = list(), pwr.points = list(),
                   wald = list(), prune = list(), combine = list(), uid = list(),
                   mef = list(), last = list(), model.frame = TRUE, ...)
{
  ## Fits general linear mixed models by residual maximum likelihood
  ## using the Aireml algorithm.
  ## Global missing value constant for SA
  dpmv <- -1e-37
  ##
  ddd <- list(...)
  options <- asreml.options()
  if(options$about) {
    message("Package built: ", packageDescription("asreml")$Built)
  }

  if(!is.null(ddd$rcov)) stop("Argument 'rcov' is deprecated, replace with 'residual'.")
  ## return this in the object; useful for update etc if formulae in variables???
  tt <- list(fixed = trimSpc(Terms(fixed, keep.order=TRUE)),
             random = trimSpc(Terms(random, keep.order=TRUE)),
             sparse = trimSpc(Terms(sparse, keep.order=TRUE)),
             residual = trimSpc(Terms(residual, keep.order=TRUE)),
             Csparse = trimSpc(Terms(options$Csparse, keep.order=TRUE)),
             dense = trimSpc(Terms(options$dense, keep.order=TRUE)))
  ## return call as well
  call <- match.call()

  ##

  debug <- ifelse(is.null(ddd$debug), options$debug, ddd$debug)
  if(debug) {
    cat("   Checking args... ","\n")
    ptime <- proc.time()[1]
  }
  chkArgs(tt, call)
  ##
  ## some (more) hidden args
  options$workspace <- mem(ifelse(is.null(ddd$workspace), options$workspace, ddd$workspace))
  options$pworkspace <- mem(ifelse(is.null(ddd$pworkspace), options$pworkspace, ddd$pworkspace))
  options$maxit <- ifelse(is.null(ddd$maxit), options$maxit, ddd$maxit)
  options$trace <- ifelse(is.null(ddd$trace), options$trace, ddd$trace)
  ## fixgammas
  ## options set to trap fixgammas=TRUE in rgParam; reset later
  fgset <- !is.null(ddd$fixgammas)
  fgdflt <- options$fixgammas
  options$fixgammas <- ifelse(is.null(ddd$fixgammas), options$fixgammas, ddd$fixgammas)
  asreml.options(fixgammas=options$fixgammas)
  options$aom <- ifelse(is.null(ddd$aom), options$aom, ddd$aom)
  options$step.size <- ifelse(is.null(ddd$step.size), options$step.size, ddd$step.size)
  ## from predict
  if(is.null(predict$design.points))
    design.points <- list()
  else
    design.points <- predictpoints(predict$design.points)

  if(missing(data))
    data <- data.table()
  else if(!inherits(data, "data.table"))
    data <- as.data.table(data)

  ## !SUBSET and !GROUPFACTOR
  setattr(data, "Subset", prune_fac(prune, data))
  setattr(data, "Combine", combine_lev(combine, data))
  setattr(data, "Units", uid_lev(uid, data))

  ## Things that must be done to make a model.(data)frame:
  ##
  ## 0. check for any vm PSD to invert and add nsing to levels
  ## 1. process 'group' and 'mbf' before data is potentially mangled
  ## 2. resolve variable names from special functions
  ## 3. add 'units' if necessary
  ## 4. honour 'na.action' rules
  ## 5. add factor(s) for 2-d power models
  ## 6. multivariate analysis:
  ##    if no "residual" given then
  ##       assume Arthur's std multivariate analysis IxUS
  ##       do not fit missing value (mv) factor
  ##    else
  ##       proceed as for !ASUV in standalone and fit mv
  ##       this is the default behaviour of release 3
  ##    endif
  ##    data to be expanded in either case.
  ##    "asmv" assumes the data is already expanded
  ##                      and identifies the "trait" factor;
  ##                      the above "residual" rules still apply.
  ## 7. add missing value factor (mv) to sparse.
  ## 8. 'offset' for glm in fixed form
  ## 9. weights
  ## 10. xfa terms from any struc calls
  ##
  ##    Add 'total' to family functions where appropriate
  ##    & extract them before model.frame.

  ## do this now????
  ## family may be a list for bivariate bin/norm or bin/bin
  if(!inherits(family, "asreml.family")) {
    ## assume a list
    asr.glm <- lapply(family, function(x) {
      if(!inherits(x,"asreml.family"))
        stop("'family' must be an object or list of objects of class 'asreml.family'")
      asr_glm(x)
    })
  }
  else {
    asr.glm <- list(asr_glm(family))
  }
  asr.glm <- lapply(asr.glm,function(x) {
    if(is.null(x$phi)) x$phi <- 1.0
    x})

  ## make design points & friends (IBV etc) an environment
  ## do this before model frame to resolve spline & power model functions
  ## update later in asrInter.
  points.env <- ijbv(data, design.points, knot.points, pwr.points)
  setattr(data, "points.env", points.env)

  ## model frame

  if(debug) cat("   Making model.frame... ",proc.time()[1]-ptime,"\n")
  ##return(lineprof(modelFrame(tt,call,options,asr.glm,data,na.action)))
  data <- modelFrame(tt, call, options, asr.glm, data, na.action)

  attr(data,"Response.col") <- as.integer(match(response.col(data),names(data)))
  attr(data,"Offset.col") <- as.integer(offset.col(data))
  attr(data,"Weights.col") <- as.integer(weights.col(data))
  attr(data,"dpmv") <- as.double(dpmv)

  ## Cancel gammaPar if multivariate
  if(is.element(attr(data, "traits")$mvar.method, c("ISMV", "ASMV")))
    options$gammaPar <- FALSE

  ## Update any ibv or jbv structures
  update_ijbv(data)

  if(debug) cat("   Making ASReml inter list... ",proc.time()[1]-ptime,"\n")
  asrInter <- asr.inter(data, options)
  ## Add last list
  if(length(last) > 3) {
    stop("'last' list must have less than three components.")
  }
  asrInter$last <- last

  if(debug) cat("   Making R structure... ",proc.time()[1]-ptime,"\n")
  ## Set up Gcov & Residual (using model frame)
  ##

  if(length(R.param) == 0) {
    R.param <- Rparam(data)
    if(options$gammaPar) {
      R.param <- resetCon(R.param, data)
    }
  }
  else {
    Rdflt <- Rparam(data)
    R.param <- updateV(Rdflt, R.param, which="R", update.con=TRUE)
    ## May need to reset gamma/sigma "scale.fit" flag in mf
    resetPar(R.param, data)
  }

  if(debug) cat("   Making G structure... ",proc.time()[1]-ptime,"\n")

  if(length(G.param) == 0)
    G.param <- Gparam(data)
  else {
    Gdflt <- Gparam(data)
    G.param <- updateV(Gdflt, G.param, which="G", update.con=TRUE)
   }

  if((is.logical(start.values) && start.values==TRUE) || is.character(start.values)) {
    sv.list <- list(G.param=G.param, R.param=R.param,
                    vparameters.table=gammas2df(list(G.param=G.param, R.param=R.param)))
    if(is.character(start.values))
      write.table(sv.list$vparameters.table,start.values,row.names=FALSE,sep=",")
    return(sv.list)
  }
  if(debug) cat((proc.time()[1]-ptime),"seconds\n")

  ## Predict

  asr.predict <- prdStruc(predict,data,asrInter,asr.glm)
  ## From asreml.call v3
  pvrow <- asr.predict$lenPrdvals
  pvcol <- 3
  if(any(unlist(lapply(asr.glm,function(x)x$link)) > 1))
    pvcol <- 5
  asr.predict$pvcol <- pvcol
  asr.predict$lenx <- options$workspace # MFX
  asr.predict$lenxp <- options$pworkspace # MFX

  ## Wald tests
  if(length(wald) > 0) {
    whichDF <- c(-1,0,1,6)
    names(whichDF) <- c("none","default","numeric","algebraic")
    whichSS <- c(0,2)
    names(whichSS) <- c("incremental","conditional")
    whichKA <- c(0,1,2)
    names(whichKA) <- c("none","expected","observed")
    if(is.null(wald$Ftest)) {
      options$Ftest <- Fown(formula("~NULL"), asrInter)
    } else {
      options$Ftest <- Fown(wald$Ftest, asrInter)
      wald$ssType <- "conditional"
      wald$denDF <- "default"
      wald$kenadj <- "none"
    }
    ## wald overrides
    options$denDF = ifelse(is.null(wald$denDF),-1,whichDF[wald$denDF])
    options$ssType <- ifelse(is.null(wald$ssType),0,whichSS[wald$ssType])
    options$kenadj <- ifelse(is.null(wald$kenadj),0,whichKA[wald$kenadj])
    options$aodev <- ifelse(is.null(wald$aovdev),0,wald$aodev)
  }
  else { ## defaults
    options$denDF <- -1
    options$ssType <- 0
    options$kenadj <- 0
    options$Ftest <- 0
    options$aodev <- 0
  }
  if(options$kenadj != 0) {
    warning("Option 'kenadj' not available.")
  }

  storage.mode(options$Ftest) <- "integer"

  ## set up call to asreml-R/K

  ## Ginverse
  if(length(attr(data,"model.terms")$mixed)) {
    ginverse <- lapply(attr(data,"model.terms")$mixed$Vars,function(x){
      if(x$Fun=="vm")
        attributes(x$Call)
      else
        NULL})
    ginverse <- ginverse[sapply(ginverse,function(x)!is.null(x))]
  }
  else
    ginverse <- list()
  ## levels of vm (ped/giv/ide) terms
  if(length(ginverse)) {
    x <- unique(asrInter$inter[3,][is.element(asrInter$inter[1,],c(-1,-2))])+1
    for(i in x)
      data[[i]] <- factor(as.character(data[[i]]),levels=attr(data[[i]],"rowNames"))
  }

  storage.mode(vcm) <- "double"
  if(length(dimnames(vcm)[[2]]) == 0)
    dimnames(vcm)[[2]] <- paste0("V", seq(1, ncol(vcm)))
  attr(data,"vcm") <- vcm
  if(prod(dim(vcc)) == 1)
    dimnames(vcc) <- list('kappa','gequal')
  storage.mode(vcc) <- "double"
  attr(data,"vcc") <- vcc

  ## ASREML-R
  options$debug <- debug
  if(is.logical(debug) && debug) {
    lapply(mkr(mef), str)
    rl <- list(inter=asrInter,R.param=R.param,G.param=G.param,
               predict=asr.predict, options=options, terms=tt, call=call,
               formulae=tt, mef=mef, mf=data)
    if(length(ginverse) > 0)
      rl$ginverse=list(info=ginverse, obj=asr_grm(ginverse))
    return(rl)
  }
  else if(length(ginverse) > 0) { # Save a memory copy/duplication??
    asr <- .Call("aidata", data, asrInter, list(info=ginverse, obj=asr_grm(ginverse),
                                                mef = mkr(mef)),
                 R.param, G.param, options, asr.predict, PACKAGE="asreml")
  }
  else {
    asr <- .Call("aidata", data, asrInter, list(info=NULL,obj=NULL,mef=NULL),
                 R.param, G.param, options, asr.predict, PACKAGE="asreml")
  }
  ## License
  asr$license <- format_lic(asr$license)
  ## predict
  if(asr.predict$npred > 0)
    asr$predictions <- prdList(asr.predict,asr$prdvals,asr$vpvmat,asr$avsed)
  ## Rub these out anyway
  asr$prdvals <- NULL
  asr$vpvmat <- NULL
  asr$avsed <- NULL

  ## Reset fixgammas
  if(fgset) asreml.options(fixgammas=fgdflt)

  ## aom<
  if(options$aom) {
    asr$aom <- vector(mode="list",length=2)
    asr$aom[[1]] <- asr$residuals[, c(2,3)]
    asr$aom[[2]] <- asr$coefficients[eqr(asrInter$equations), c(2,3)]
    for(i in seq(1,2)) {
      asr$aom[[i]][, 2][asr$aom[[i]][, 2] <= 0] <- NA
      asr$aom[[i]][, 2] <- asr$aom[[i]][, 1]/sqrt(asr$aom[[i]][, 2])
    }
    names(asr$aom) <- c("R", "G")
    asr$residuals <- asr$residuals[, 1, drop=FALSE]
    asr$coefficients <- asr$coefficients[, 1, drop=FALSE]
  }
  ## soln & vsoln
  f <- function(x){ if(length(x)==0) NULL else x }
  asr$coefficients <- list(
    fixed = f(asr$coefficients[eqf(asrInter$equations), , drop=FALSE]),
    random = f(asr$coefficients[eqr(asrInter$equations), , drop=FALSE]),
    sparse = f(asr$coefficients[eqs(asrInter$equations), , drop=FALSE]))
  ## this for list form of coef()
  for(i in c("fixed","random","sparse")) {
    if(!is.null(asr$coefficients[[i]])) {
      attr(asr$coefficients[[i]], "terms") <- data.frame(
        tname = dimnames(asrInter$equations[[i]])[[1]],
        n = asrInter$equations[[i]][,2],
        stringsAsFactors = FALSE)
    }
  }
  asr$vcoeff <- list(fixed = f(asr$vcoeff[eqf(asrInter$equations)]),
                     random = f(asr$vcoeff[eqr(asrInter$equations)]),
                     sparse = f(asr$vcoeff[eqs(asrInter$equations)]))
  ## The design
  if(!is.null(asr$design)) {
    # Maximal columns
    x <- eqns(asrInter$equations)
    asr$design <- asr$design[((asr$design[,2] > 0) & (asr$design[,2] <= max(x))),]
    asr$design <- sparseMatrix(i = asr$design[,1],
                         j = asr$design[,2],
                         x = asr$design[,3],
                         dims = c(max(asr$design[,1]), max(x)))
    dimnames(asr$design) <- list(NULL, names(x))
  }

  ## Cfixed
  if(options$Cfixed) {
    eqf1 <- eqf(asrInter$equations)-1
    xy <- expand.grid(eqf1,eqf1)
    xy <- xy[xy$Var1 <= xy$Var2,]
    nd <- max(xy$Var1)
    asr$Cfixed <- new("dspMatrix",uplo="U", Dim=as.integer(c(nd,nd)),
                      x=asr$Cfixed[(xy$Var2*(xy$Var2-1)/2)+xy$Var1])
    dimnames(asr$Cfixed) <- list(dimnames(asr$coefficients$fixed)[[1]],
                                 dimnames(asr$coefficients$fixed)[[1]])
  }
  else
    asr$Cfixed <- NULL
  ## gammas: trim leading nfactp "<NA>"s
  asr$gammas.con <- asr$gammas.con[names(asr$gammas) != "<NA>"]
  asr$gammas.type <- asr$gammas.type[names(asr$gammas) != "<NA>"]
  asr$gammas.pc <- asr$gammas.pc[names(asr$gammas) != "<NA>"]
  asr$gammas <- asr$gammas[names(asr$gammas) != "<NA>"]

  ## update starting values in Rparam & Gparam lists
  ## default is to update boundary constraints
  gtab <- data.frame(Component=names(asr$gammas),
                     Value=asr$gammas,
                     Constraint=guzpfx(asr$gammas.con),
                     stringsAsFactors=FALSE)
  asr$G.param <- updateV(G.param, gtab, "G", asreml.options()$update.Gcon, TRUE)
  asr$R.param <- updateV(R.param, gtab, "R", asreml.options()$update.Rcon, TRUE)

    ## models like ante & chol have unestimated gammas
    ne <- grep("<NotEstimated>$",names(asr$gammas))
    print.gammas <- {if(length(ne) > 0)
                       seq(along=asr$gammas)[-ne]
                     else
                       seq(along=asr$gammas)}
    ne <- rep(FALSE, length=length(asr$gammas))
    ne[print.gammas] <- TRUE
    asr$gammas <- asr$gammas[print.gammas]
    asr$gammas.con <- asr$gammas.con[print.gammas]
    asr$gammas.type <- asr$gammas.type[print.gammas]
    asr$gammas.pc <- asr$gammas.pc[print.gammas]
    asr$trace <- asr$trace[c(1,2,3,4,print.gammas+4),] #loglik,s2,df,step
    asr$score <- asr$score[print.gammas]

    ## AI
    ai <- matrix(as.logical(ne %o% ne),nrow=length(ne))
    asr$ai <- new("dspMatrix",uplo="U", Dim=as.integer(c(sum(ne),sum(ne))),
                  x=asr$ai[seq(1,asr$nwv*(asr$nwv+1)/2)][ ai[!lower.tri(ai)] ]  )
    dimnames(asr$ai) <- list(names(asr$gammas), names(asr$gammas))
    ## noeff & yssqu
    asr$noeff <- asr$noeff[as.logical(asrInter$aov$whichTrm)]
    asr$yssqu <- asr$yssqu[as.logical(asrInter$aov$whichTrm)]

    ## Remove rows in aov with zero df
    ## These rows are actually never set in g5vaovcalc
    zdf <- which(rev(asr$noeff[seq(1,nrow(asr$aov))]) == 0) # should be the dense set
    if(length(zdf) > 0){
      zdf.names <- rev(names(asr$noeff[seq(1,nrow(asr$aov))]))[zdf]
      asr$aov <- asr$aov[asr$aov[,'df']!=0,, drop=FALSE]
      attr(asr$aov, "zerodf") <- zdf.names
      message("Terms with zero df listed in attribute 'zerodf' of the wald table.")
    }

    ## save model frame
    if(is.logical(model.frame)) {
      if(model.frame) asr$mf <- data
    }
    else if(is.character(model.frame)) {
      asr$RDS <- if(tools::file_ext(model.frame) == "RDS") model.frame else paste(model.frame,"RDS",sep=".")
      saveRDS(data, file=asr$RDS, compress=TRUE)
    }
    else
      warning("invalid type for 'model.frame', data not saved")
    ## Change "gammas" to "vparameters"
    names(asr)[match(c("gammas","gammas.con","gammas.type","gammas.pc"),names(asr))] <-
      paste("vparameters",c("",".con",".type",".pc"),sep="")

    asr$converge <- as.logical(asr$converge)
    asr$call <- call
    asr$formulae <- tt
    asr$factor.names <- asrInter$facnam[asrInter$neword]

    class(asr) <- "asreml"
    return(asr)
}
gammas2df <- function(object)
{
  ## Return a default boundary constraints data frame

  if(mode(object) != "list")
    stop("\n object must be of mode list\n")
  if(is.na(match("G.param",names(object))))
    stop("\n object must have a component named G.param\n")
  if(is.na(match("R.param",names(object))))
    stop("\n object must have a component named R.param\n")

  gammas <- vector(mode="numeric")
  gmcstr <- vector(mode="character")

  gcov.list <- object[["G.param"]]
  rcov.list <- object[["R.param"]]

  if(length(gcov.list) > 0)  {
    nterm <- length(gcov.list)
    for(n in seq(1,nterm)) {
      nfact <- length(gcov.list[[n]])
      for(j in 1:nfact) {
        gammas <- c(gammas,gcov.list[[n]][[j]]$initial)
        gmcstr <- c(gmcstr,gcov.list[[n]][[j]]$con)
      }
    }
  }

  if(length(rcov.list) > 0) {
    nsect <- length(rcov.list)
     for(n in seq(1,nsect)) {
      ndim <- length(rcov.list[[n]])
      for(j in 1:ndim) {
        gammas <- c(gammas,rcov.list[[n]][[j]]$initial)
        gmcstr <- c(gmcstr,rcov.list[[n]][[j]]$con)
      }
    }
  }

  if(length(gammas)==0)
    stop("\n No variance components found - missing G & R lists?\n")

  not.id <- !is.na(gammas)
  gammas <- gammas[not.id]
  gmcstr <- gmcstr[not.id]

  x <- data.frame(Component=names(gammas),
                  Value=gammas,
                  Constraint=gmcstr,row.names=NULL,stringsAsFactors=FALSE)
  return(x)
}
asr_grm <- function(ginverse) {
  ## ginverse is list object from asreml of the attributes
  ## from the call to vm()

  ## Set storage.mode to double
  ## Convert Matrix objects to coordinate form

  obj <- vector(mode="list", length=length(ginverse))
  for(i in seq(1,length(ginverse))) {
    if(is.expression(ginverse[[i]]$Expr) || is.call(ginverse[[i]]$Expr)) {
      obj[[i]] <- eval(ginverse[[i]]$Expr)
    } else if(is.name(ginverse[[i]]$Expr) || is.character(ginverse[[i]]$Expr)) {
      givEnv <- where.env(ginverse[[i]]$Source)
      obj[[i]] <- get(ginverse[[i]]$Source, envir=givEnv)
    } else {
      stop("asr_grm: Source not expression, call, name or character")
    }
  }
  names(obj) <- sapply(ginverse,function(x)x$Source)


  # ginv.obj <- as.character(sapply(ginverse,function(x)x$Source))
  # obj <- mget(ginv.obj, envir=where.env(ginv.obj[1]))

  for(i in seq(1,length(obj))) {
    if(is.data.frame(obj[[i]])) {
      storage.mode(obj[[i]][,1]) <- "double"
      storage.mode(obj[[i]][,2]) <- "double"
    }
    else if(is.matrix(obj[[i]])) {
      if(ncol(obj[[i]]) == 3 && !ginverse[[i]]$inverse) {
        if(is.null(rn <- attr(obj[[i]], "rowNames"))) {
          stop(as.character(ginv.obj[i])," has no 'rowNames' attribute")
        }
        attr(obj[[i]], "rowNames") <- rn
      }
      storage.mode(obj[[i]]) <- "double"
    }
    else if(inherits(obj[[i]], "Matrix")) {
      if(is.null(rn <- rownames(obj[[i]]))) {
        if(is.null(rn <- attr(obj[[i]], "rowNames"))) {
          stop(as.character(ginv.obj[i])," has no 'dimnames' or 'rowNames' attribute")
        }
      }
      if(inherits(obj[[i]],"TsparseMatrix")) {
        obj[[i]] <- as.matrix(summary(obj[[i]]))
        obj[[i]] <- obj[[i]][base::order(obj[[i]][,1],obj[[i]][,2]),]
      }
      else if(inherits(obj[[i]],"dsparseMatrix")) {
        obj[[i]] <- as.matrix(summary(as(obj[[i]],"dgTMatrix")))
        obj[[i]] <- obj[[i]][(obj[[i]][,1] >= obj[[i]][,2]),] #lower tri
        obj[[i]] <- obj[[i]][base::order(obj[[i]][,1],obj[[i]][,2]),]
      }
      else if(inherits(obj[[i]],"ddenseMatrix")) {
        if(inherits(obj[[i]],"dgeMatrix")) {
          obj[[i]] <- as.matrix(obj[[i]])
        }
        else if(inherits(obj[[i]],"dsyMatrix") || inherits(obj[[i]],"dspMatrix")) {
          if(obj[[i]]@uplo == "U")
            obj[[i]] <- as.vector(obj[[i]])[!lower.tri(obj[[i]],diag=FALSE)]
          else
            obj[[i]] <- as.vector(t(obj[[i]]))[!lower.tri(obj[[i]],diag=FALSE)]
        }
        else {
          stop("Objects from 'ddenseMatrix' must be ",
               "'dgeMatrix', 'dspMatrix' or 'dsyMatrix'")
        }
      }
      else {
        stop("Objects from the Matrix class must be ",
             "'TsparseMatrix', 'dsparseMatrix','dgeMatrix', 'dspMatrix' or 'dsyMatrix'")
      }
      attr(obj[[i]],"rowNames") <- rn
      storage.mode(obj[[i]]) <- "double"
    }
  }
  obj
}
mkr <- function(mef) {
  ## mef is list object from asreml call: list(source="markerfile")
  ## Leave the 'effects' component alone

  ## target is almost certainly a dense matrix
  ## - assume and enforce this

  if(length(mef) == 0)
    return(list())

  M.char <- as.character(unlist(lapply(mef[-which(names(mef) == "effects" |
                                                    names(mef) == "se")],function(x)x)))

  obj <- mget(M.char, envir=where.env(M.char[1]))
  ## check
  obj <- lapply(obj,function(x){
    if(!is.matrix(x))
      stop("Target in 'mef' must be a matrix")
    if(length(dimnames(x)) == 0)
      stop("Missing 'dimnames' attribute in 'mef' matrix")
    if(!is.null(attr(x, "scale"))) attr(x, "scale") <- as.double(attr(x, "scale"))
    storage.mode(x) <- "double"
    x
  })

  obj$effects <- mef$effects
  obj$se <- mef$se
  names(obj) <- names(mef)
  obj
}
## Expose this for guzpfx
#' Variance parameter constraint codes
#'
#' Character vector of variance parameter constraint codes corresponding
#' to the numeric values returned in the \code{vparameters.con} component
#' of the \code{asreml} object.
#'
#' @param object An \code{asreml} object with a \code{vparameters.con} component;
#' the vector of numeric variance parameter constraint codes.
#'
#' @return
#'
#' A character vector of constraint codes. Common values are \code{"P" (=1)},
#' \code{"U" (=3)} and \code{"F" (=4)} for positive, unrestricted and fixed,
#' respectively.
#'
vpc.char <- function(object){
  if(!inherits(object, "asreml"))
    stop("'object' must be of class 'asreml'")
  ## keep the names
  nm <- names(object$vparameters.con)
  ch <- guzpfx(object$vparameters.con)
  names(ch) <- nm
  return(ch)
}
guzpfx <- function(i) {
  con <-  c(' ','P','?','U','F','C','S','B')

  pc <- apply(matrix((i+1),ncol=1),1,function(x) {
    if(is.na(x)) return(3)
    y <- max(x,1)
    if(y > 8 && y%%10 == 2) y <- 3
    if(y > 8) y <- 8
    y})
  con[pc]
}
#' Variance parameter type codes
#'
#' Character vector of variance parameter type codes corresponding
#' to the numeric values returned in the \code{vparameters.type} component
#' of the \code{asreml} object.
#'
#' @param object An \code{asreml} object with a \code{vparameters.type} component;
#' the vector of numeric variance parameter type codes.
#'
#' @return
#'
#' A character vector of type codes from the set
#' \code{"V"}, \code{"G"}, \code{"R"}, \code{"C"}, \code{"P"} and
#' \code{"L"}, identifying each parameter as type \emph{variance},
#' \emph{variance ratio}, \emph{correlation}, \emph{covariance},
#' \emph{positive correlation} or \emph{loading}, respectively.
#'
vpt.char <- function(object) {
  if(!inherits(object, "asreml"))
    stop("'object' must be of class 'asreml'")
  ## keep the names
  nm <- names(object$vparameters.type)
  typeCode <- c("V","G","R","C","P","L")
  ch <- typeCode[object$vparameters.type]
  names(ch) <- nm
  attr(ch, 'legend') <- data.frame(Code=typeCode,
                                   Type=c('variance','variance ratio','correlation',
                                          'covariance','positive correlation','loading'),
                                          stringsAsFactors=FALSE)
  return(ch)
}
##
#' Subset a factor.
#'
#' Forms a new model term from an existing factor by selecting a
#' subset of its levels.
#'
#' @param f A factor in the data.
#'
#' @param x A character or numeric vector of levels to select. See the
#' \code{prune} argument to \code{\link{asreml}}.
#'
Subset <- function(f, x) {
  ## returns f as a symbol
  list(substitute(f), eval(x))
}
prune_fac <- function(prune, data) {
  ## prune is an evaluated list with original elements like
  ## A = Subset(f,x)
  ## where f is a factor and x is a char or int vector of levels to keep

  if(!length(prune))
    return(list())

  lapply(prune, function(a, data) {
    Subset_spc(a[[1]], a[[2]], data)}, data)
}
#' Combine factor levels.
#'
#' Forms a new model term from an existing factor by merging a
#' subset of its levels.
#'
#' @param f A factor in the data.
#'
#' @param x A vector of length \code{length(levels(f))} defining the
#' levels of \code{f} to merge. See the \code{combine} argument to
#' \code{\link{asreml}}.
#'
Levels <- function(f, x) {
  ## returns f as a symbol
  list(substitute(f), eval(x))
}
combine_lev <- function(combine, data) {
  ## combine is an evaluated list with original elements like
  ## A = Levels(f,x)
  ## where f is a factor and x is a vector of new levels

  if(!length(combine))
    return(list())

  lapply(combine, function(a, data) {
    Levels_spc(a[[1]], a[[2]], data)}, data)
}
#' Unit level numbers.
#'
#' Forms a new model term from an existing factor by choosing a
#' subset of its record numbers.
#'
#' @param f A factor in the data.
#'
#' @param n A character or numeric scalar defining the records of
#' \code{f} to select. See the \code{uid} argument to
#' \code{\link{asreml}}.
#'
Units <- function(f, n=0) {
  ## returns f as a symbol
  list(substitute(f), eval(n))
}
uid_lev <- function(uid, data) {
  ## uid is an evaluated list with original elements like
  ## A = Units(f,n)
  ## where f is a factor and n is a scalar

  if(!length(uid))
    return(list())

  lapply(uid, function(a, data) {
     Units_spc(a[[1]], a[[2]], data)}, data)
}
mem <- function(space) {
  if(nchar(as.character(space)) < 3)
    stop("Insufficient memory; increase workspace")
  units <- casefold(substring(as.character(space), first=nchar(space)-1, last=nchar(space)))
  if(is.element(units, c('kb','mb','gb')))
    n <- as.numeric(substring(space,first=1,last=nchar(space)-2))
  return(switch(units,
                kb = n*(2^10)/8,
                mb = n*(2^20)/8,
                gb = n*(2^30)/8,
                space
                ))
}
predictpoints <- function(plist) {
  ## each element of plist should be a matrix M of "coordinate" vectors
  ## stored in columns.
  ## if(grid) then expand to a full grid of points - in this case short
  ## coordinate vectors must be padded out with NAs to fill M
  ## if(!grid) assume parallel - no NAs allowed
  ##
  ## predict assumes any expansion has been done and sets the parallel flag.
  ##
  ## ijbv stores these in a 'points' vector in the 'points.env' environment;
  ## getPpoints retrieves them transposed for ainv.
  if(length(plist) == 0)
    return(list())

  grid <- asreml.options()$grid
  if(length(grid) < length(plist))
    grid <- rep(grid, length.out=length(plist))
  ## plist and grid in parallel
  for(i in 1:length(plist)) {
    if(is.list(plist[[i]])) {
      plist[[i]] <- sapply(plist[[i]],'[',1:max(sapply(plist[[i]],length)))
    }
    else if(is.vector(plist[[i]])) {
      plist[[i]] <- matrix(plist[[i]],ncol=1)
      dimnames(plist[[i]]) <- list(names(plist[[i]]), names(plist)[i])
    }
    else if(!is.matrix(plist[[i]]))
      stop("Component of 'design.points' must be a list, matrix or vector", call. = FALSE)
    dn <- dimnames(plist[[i]])
    if(grid[i]) {
      v <- expand.grid(apply(plist[[i]],2,function(x)x[!is.na(x)]))
      plist[[i]] <- as.matrix(v[do.call(order, v),]) # outer is fastest
      dimnames(plist[[i]]) <- dn
    }
    else {
      if(any(is.na(plist[[i]])))
        stop("Component of 'design.points' has NAs but grid is FALSE", call. = FALSE)
    }
    ## simple rounding
    plist[[i]] <- apply(plist[[i]],2,function(x)as.numeric(as.character(x)))
    dimnames(plist[[i]]) <- dn
  }
  return(plist)
}

## Document the data (inc the exported 'captions' vector)
#' Axis captions
#'
#' Vector of axis labels for each residual type.
#'
#' @format A named vector of axis label strings.
#'
"captions"
#'
#' Slate Hall farm wheat variety trial.
#'
#' Data from a field experiment to compare 25 varieties of wheat at
#' Slate Hall farm, UK, 1976.
#'
#' The trial was a balanced lattice with 25 varieties in 6 replicates,
#' arranged in a 15 column by 10 row grid of plots.
#'
#' @format A data frame with 7 columns and 150 rows:
#' \describe{
#' \item{Rep}{Complete field replicates, factor with 6 levels}
#' \item{RowBlk}{Incomplete row blocks; factor with 30 levels}
#' \item{ColBlk}{Incomplete column blocks; factor with 30 levels}
#' \item{Row}{Long row blocks; factor with 10 levels}
#' \item{Column}{Long column blocks; factor with 15 levels}
#' \item{Variety}{Variety names; factor with 25 levels}
#' \item{yield}{Grain yield in grams}
#' }
#' @references
#' % bibentry: Kempton:1997
#'
"shf"
#' Split plot design.
#'
#' Yield of oats with four fertilizer treatments.
#'
#' The yield of oats from a split-plot field trial with three
#' varieties and four levels of nitrogen fertilizer. The experiment was
#' a split plot with 6 blocks of 3 main plots (varieties), each split into 4
#' sub-plots (nitrogen).
#'
#' @format A data frame with 9 columns and 72 rows:
#' \describe{
#' \item{Blocks}{Complete field replicates, factor with 6 levels}
#' \item{Nitrogen}{Factor with 4 levels}
#' \item{Subplots}{Factor with 4 levels}
#' \item{Variety}{Factor with 3 levels}
#' \item{Wplots}{Factor with 3 levels}
#' \item{yield}{Grain yield in 1/4 lbs.}
#' \item{Column}{Field column index factor}
#' \item{Row}{Field row index factor}
#' \item{nrate}{Numeric nitrogen rates}
#' }
#' @references
#' % bibentry: Yates:1935
#'
"oats"
#' Reproductive study on rats
#'
#' Litter weights of pups from rats given three doses (control, low
#' and high) of an experimental compound affecting reproductive
#' performance.
#'
#' Thirty female rats (dams) were randomly split into three groups of
#' 10 and each group randomly assigned a dosing level. Three litters
#' had to be dropped from the high dose level.
#'
#' @format A data frame with 6 columns and 322 rows:
#' \describe{
#' \item{Dose}{A factor with 3 levels}
#' \item{Sex}{A factor with 2 levels}
#' \item{littersize}{A covariate}
#' \item{Dam}{A factor with 27 levels}
#' \item{Pup}{A factor with 18 levels}
#' \item{weight}{Individual pup weights in grams}
#' }
#' @references
#' % bibentry: Dempster:1984
#'
"rats"
#' Voltage regulators
#'
#' Vehicle regulator voltage is measured after setting and testing
#' operations; regulators out of range are returned.
#'
#' Sixty-four regulators were tested at four testing stations, and the
#' voltage for individual regulators was set at a total of 10 setting
#' stations. A variable number of regulators (4-8) were set at each
#' station, however each regulator was tested at every testing
#' station.
#'
#' @format A data frame with 4 columns and 256 rows:
#' \describe{
#' \item{Teststat}{A factor with 4 levels}
#' \item{Setstat}{A factor with 10 levels}
#' \item{Regulatr}{A factor with 8 levels}
#' \item{voltage}{Reading in volts}
#' }
#' @references
#' % bibentry: Cox:1981
#'
"voltage"
#' Plant height
#'
#' Plant height measurements on 14 plants at 5 occasions.
#'
#' The 14 plants were either diseased or healthy and were arranged in
#' a glasshouse in a completely random design. Plant heights were
#' measured 1, 3, 5, 7 and 10 weeks after the plants were placed in
#' the glasshouse. There were 7 plants in each treatment.
#'
#' @format A data frame with 7 columns and 14 rows:
#' \describe{
#' \item{Tmt}{A factor with 2 levels, diseased or healthy}
#' \item{Plant}{A factor with 14 levels}
#' \item{y1}{Plant height at week 1}
#' \item{y3}{Plant height at week 3}
#' \item{y5}{Plant height at week 5}
#' \item{y7}{Plant height at week 7}
#' \item{y10}{Plant height at week 10}
#' }
#' @source J. Lamptey, Rothamsted Experimental Station, UK.
#'
"grass"
#' Plant height (univariate form)
#'
#' Plant height measurements on 14 plants at 5 occasions.
#'
#' The 14 plants were either diseased or healthy and were arranged in
#' a glasshouse in a completely random design. Plant heights were
#' measured 1, 3, 5, 7 and 10 weeks after the plants were placed in
#' the glasshouse. There were 7 plants in each treatment.
#'
#' @format A data frame with 5 columns and 70 rows:
#' \describe{
#' \item{Tmt}{A factor with 2 levels, diseased or healthy}
#' \item{Plant}{A factor with 14 levels}
#' \item{Time}{A factor with 5 levels}
#' \item{HeightID}{A factor with 5 levels}
#' \item{y}{Plant height}
#' }
#' @source J. Lamptey, Rothamsted Experimental Station, UK.
#'
"grassUV"
#'
#' Wheat variety trial
#'
#' Unreplicated early generation wheat variety trial conducted at
#' Tullibigeal in south-western NSW.
#'
#' The experiment consisted of 525 test lines which were randomly
#' assigned to plots in a 67 row by 10 column array. There was a check
#' plot variety every 6 plots within each column. That is, the check
#' variety was sown on rows 1,7,13,. . . ,67 of each column. This
#' variety was numbered 526. A further 6 replicated commercially
#' available varieties (numbered 527 to 532) were also randomly
#' assigned to plots with between 3 to 5 plots of each.
#'
#' @format A data frame with 5 columns and 670 rows:
#' \describe{
#' \item{yield}{Grain yield in kg/ha}
#' \item{weed}{A covariate}
#' \item{Column}{A factor with 10 levels}
#' \item{Row}{A factor with 67 levels}
#' \item{Variety}{A factor with 532 levels}
#' }
#' @source NSW Department of Primary Industries
#'
"wheat"
#' Advanced breeding trial.
#'
#' An advanced Nebraska Intrastate Nursery (NIN) breeding trial
#' conducted at Alliance in 1988/89.
#'
#' Four replicates of 19 released cultivars, 35 experimental wheat
#' lines and 2 additional triticale lines were laid out in a 22 row by
#' 11 column rectangular array of plots; the varieties were allocated
#' to the plots using a randomised complete block (RCB) design.
#'
#' @format A data frame with 11 colums and 242 rows:
#' \describe{
#' \item{Variety}{A factor with 56 levels}
#' \item{Id}{A factor with 56 integral levels}
#' \item{pid}{A numeric variate containing plot numbers}
#' \item{raw}{Plot weights}
#' \item{Rep}{A factor with 4 levels}
#' \item{nloc}{Trial location (4)}
#' \item{yield}{Grain yield in t/ha}
#' \item{lat}{Spatial coordinate}
#' \item{long}{Spatial coordinate}
#' \item{Row}{A factor with 22 levels}
#' \item{Column}{A factor with 11 levels}
#' }
#'
#' @references
#' % bibentry: Stroup:1994
"nin89"
#' Growth curve study on rats
#'
#' Weekly body weights of three treatment groups of rats.
#'
#' A total of 27 rats was divided randomly into 3 groups of 10, 7 and
#' 10, respectively. Group 1 were kept as a control, group 2 had
#' thyroxin and group 3 had thiouracil added to their drinking
#' water. Five weekly measurements were taken on each individual.
#'
#' @format A data frame with 6 columns and 27 rows:
#' \describe{
#' \item{Treatment}{A factor with 3 levels}
#' \item{wt0}{Body weight at week 1}
#' \item{wt1}{Body weight at week 2}
#' \item{wt2}{Body weight at week 3}
#' \item{wt3}{Body weight at week 4}
#' \item{wt4}{Body weight at week 5}
#' }
#' @references
#' % bibentry: Box:1950
#'
"wolfinger"
#' Footrot scores on lambs.
#'
#' Incidence of two footshape classes on 2513 lambs.
#'
#' The feet of 2513 lambs born in 1980 and 1981 from 5 mating groups
#' were scored in two footshape classes: 1) all four feet are normal,
#' and 2) one foot is deformed. Two indicator variables were also
#' recorded for the presence of the disease conditions scald and rot.
#'
#' @format A data frame with 10 columns and 2513 rows:
#' \describe{
#' \item{record}{An integer vector of record numbers}
#' \item{year}{Cross year, an integer vector with values 1 and 2}
#' \item{Grp}{A factor with 5 levels}
#' \item{Sex}{A factor with 2 levels}
#' \item{Sire}{A factor with 18 levels}
#' \item{score4}{Incidence of footshape class 1}
#' \item{score5}{Incidence of footshape class 2}
#' \item{scald}{Incidence of scald disease}
#' \item{rot}{Incidence of rot disease}
#' \item{norm}{A random normal variate}
#' }
#' @references
#' % bibentry: Gilmour:1985
#'
"binnor"
#' Footrot counts on lambs.
#'
#' Counts of two footshape classes on 2513 lambs.
#'
#' The feet of 2513 lambs born in 1980 and 1981 from 5 mating groups
#' were scored in two footshape classes: 1) all four feet are normal,
#' and 2) one foot is deformed. Two indicator variables were also
#' recorded for the presence of the disease conditions scald and
#' rot. The data is grouped into 68 sex, sire and mating group
#' combinations.
#'
#' @format A data frame with 12 columns and 68 rows:
#' \describe{
#' \item{cyr}{Cross year, an integer vector with values 1 and 2}
#' \item{Grp}{A factor with 5 levels}
#' \item{Sex}{A factor with 2 levels}
#' \item{Sire}{A factor with 18 levels}
#' \item{xxx}{A numeric vector}
#' \item{tot}{Binomial totals for each sex, sire, group combination}
#' \item{l5}{Incidence of footshape class 2}
#' \item{l4}{Incidence of footshape class 1}
#' \item{ls}{Incidence of scald disease}
#' \item{lr}{Incidence of rot disease}
#' \item{prop}{Footshape class 2 (\code{l5}) as a proportion}
#' \item{fail}{Footshape class 2 \emph{failure} counts (\code{1-l5})}
#' }
#' @references
#' % bibentry: Gilmour:1985
#'
"lamb"
#' Cheese tasting.
#'
#' Tasting category counts on four cheeses.
#'
#' Four cheeses were scored on a nine point scale by 52 judges.
#'
#' @format A data frame with 11 columns and 4 rows:
#' \describe{
#' \item{Cheese}{A factor with 4 levels}
#' \item{cat1}{Taste category 1 counts}
#' \item{cat2}{Taste category 2 counts}
#' \item{cat3}{Taste category 3 counts}
#' \item{cat4}{Taste category 4 counts}
#' \item{cat5}{Taste category 5 counts}
#' \item{cat6}{Taste category 6 counts}
#' \item{cat7}{Taste category 7 counts}
#' \item{cat8}{Taste category 8 counts}
#' \item{cat9}{Taste category 9 counts}
#' \item{tot}{Total counts for each cheese}
#' }
#' @references
#' % bibentry: McCullagh:1989
#'
"cheese"
#' Cheese tasting incidence.
#'
#' Tasting incidences on four cheeses.
#'
#' Four cheeses were scored on a nine point scale by 52 judges. This
#' is the \code{\link{cheese}} data in \emph{incidence} form, where
#' each taste category and cheese combination is recorded.
#'
#' @format A data frame with 2 columns and 208 rows:
#' \describe{
#' \item{Taste}{A factor with 9 levels}
#' \item{Cheese}{A factor with 4 levels}
#' }
#' @references
#' % bibentry: McCullagh:1989
#'
"cheese.cat"
#' Weights of cattle.
#'
#' Average daily gain for 65 Hereford steers.
#'
#' The age at weaning, initial weight at the start of the test feeding
#' period and average daily gain were recorded on 65 steers from 9
#' sires and 3 breeding lines; all of the steers were fed for the same
#' length of time.
#'
#' @format A data frame with 8 columns and 65 rows:
#' \describe{
#' \item{Calf}{A factor with 65 levels}
#' \item{Sire}{A factor with 9 levels}
#' \item{Dam}{A factor with 1 level}
#' \item{Line}{A factor with 3 levels}
#' \item{ageOfDam}{An integer vector}
#' \item{y1}{Age at weaning}
#' \item{y2}{Initial weight}
#' \item{y3}{Average daily gain (\eqn{\times 100})}
#' }
#' @references
#' % bibentry: Harvey:1960
#'
"harvey"
#' Pedigree of cattle.
#'
#' Crossing history for 65 Hereford steers.
#'
#' Calf, sire and dam identities for 65 Hereford steers; the first
#' three columns of \code{\link{harvey}}.
#'
#' @format A data frame with 3 columns and 65 rows:
#' \describe{
#' \item{Calf}{An integer vector}
#' \item{Sire}{A character vector}
#' \item{Dam}{An integer vector}
#' }
#' @references
#' % bibentry: Harvey:1960
#'
"harvey.ped"
#' Pedigree of cattle.
#'
#' Crossing history for 65 Hereford steers with genetic groups.
#'
#' Calf, sire and dam identities for 65 Hereford steers in 3 genetic
#' groups. Additional rows to \code{\link{harvey.ped}} describe the
#' genetic group structure.
#'
#' @format A data frame with 3 columns and 77 rows:
#' \describe{
#' \item{Calf}{A character vector}
#' \item{Sire}{A character vector}
#' \item{Dam}{A character vector}
#' }
#'
#' @seealso \code{\link{harvey}} \code{\link{harvey.ped}}
#'
#' @references
#' % bibentry: Harvey:1960
#'
"harveyg.ped"
#' Rice bloodworms.
#'
#' An investigation of the tolerance of rice varieties to attack by
#' the larvae of bloodworms.
#'
#' The experiment commenced with the transplanting of rice seedlings
#' into trays. Each tray contained a total of 32 seedlings and the
#' trays were paired so that a control tray (no bloodworms) and a
#' treated tray (bloodworms added) were grown in a controlled
#' environment room for the duration of the experiment. After this,
#' rice plants were carefully extracted, the root system washed and
#' root area determined for the tray using an image analysis
#' system. Two pairs of trays, each pair corresponding to a different
#' variety, were included in each run. A new batch of bloodworm larvae
#' was used for each run. A total of 44 varieties was investigated
#' with three replicates of each. The variety concurrence was such
#' that: eight varieties occurred with only one other variety, 22 with
#' two other varieties and the remaining 14 with three different
#' varieties.
#'
#' @format A data frame with 6 columns and 264 rows:
#' \describe{
#' \item{Pair}{A factor with 132 levels}
#' \item{rootwt}{Root weight}
#' \item{Run}{A factor with 66 levels}
#' \item{sqrtroot}{The square root of \code{rootwt}}
#' \item{Tmt}{A factor with 2 levels}
#' \item{Variety}{A factor with 44 levels}
#' }
#'
#' @references
#' % bibentry: Stevens:1999
#'
"rice"
#' Rice bloodworms (multivariate form).
#'
#' An investigation of the tolerance of rice varieties to attack by
#' the larvae of bloodworms.
#'
#' Multivariate form of \code{\link{rice}} with root weight in two
#' variates corresponding to the levels of the applied treatment
#' (control or exposed to bloodworms).
#'
#' @format A data frame with 7 columns and 132 rows:
#' \describe{
#' \item{Pair}{A factor with 132 levels}
#' \item{Run}{A factor with 66 levels}
#' \item{Variety}{A factor with 44 levels}
#' \item{yc}{Root weight for the control treatment}
#' \item{ye}{Root weight for the exposed treatment}
#' \item{syc}{The square root of \code{yc}}
#' \item{sye}{The square root of \code{ye}}
#' }
#'
#' @seealso \code{\link{rice}}
#'
#' @references
#' % bibentry: Stevens:1999
#'
"riceMV"
#' Tree circumference.
#'
#' Trunk circumferences (mm) of each of 5 trees recorded at 7 times;
#' all trees were measured at the same time. Age of tree (in days
#' since 31 December 1968) when measured and the corresponding season
#' (spring or autumn) were also recorded.
#'
#' @format A data frame with 4 columns and 35 rows:
#' \describe{
#' \item{Tree}{A factor with 5 levels}
#' \item{x}{Age of tree}
#' \item{circ}{Trunk circumference (mm)}
#' \item{Season}{A factor with 2 levels}
#' }
#'
#' @references
#' % bibentry: Draper:1998
#'
"orange"
#' Nested correlated observations.
#'
#' Hypothetical bids within 15 auctions.
#'
#' @format A data frame with 3 columns and 2500 rows:
#' \describe{
#' \item{seq}{An integer vector of record numbers}
#' \item{auc}{An integer vector of auction identifiers}
#' \item{val}{Numeric vector of bid values}
#' }
#'
"ebay"
#' Clone data.
#'
#' Height of Loblolly pine trees at age 6.
#'
#' @format A data frame with 5 columns and 6795 rows:
#' \describe{
#'
#' \item{Rep}{Factor with 8 levels}
#' \item{IncBlock}{Factor with 80 levels}
#' \item{CultureID}{Factor with 2 levels}
#' \item{clonefv}{Factor with 860 levels}
#' \item{ht6}{Tree height}
#' }
#'
#' @references
#' % bibentry: Resende:2012
#'
"nassau"
#' Genetic relationship matrix.
#'
#' Genetic relationship matrix for 963 Loblolly pine clones derived
#' from 4854 snp markers.
#'
#' @format A numeric matrix with 963 rows and 963 columns with
#' attributes \code{"dimnames"} and \code{"scale"}. The relationship
#' matrix is non-positive definite.
#'
#' @seealso \code{\link{nassau}} \code{\link{nassau.snp}}
#'
"nassau.grm"
#' Genetic marker scores.
#'
#' Genetic marker matrix for 963 Loblolly pine clones and 4854 snp
#' markers.
#'
#' @format A numeric matrix with 963 rows and 4854 columns with a
#' \code{"dimnames"} attribute.
#'
#' @seealso \code{\link{nassau}} \code{\link{nassau.grm}}
#'
"nassau.snp"
#' MBF example
"naf"
#' naf marker scores
"naf31H"
#' naf marker scores
"naf32H"
#' Orange whether trial
"owt"
ijbv <- function(data,design.points,knot.points,pwr.points)
{
  ## stack these into a single vector "points" as used in the core
  ## addrs: internal address table in relational form:
  ## term | dimension | index | n | type
  ##   where index = start addresses in points;
  ##             n = size
  ##          type = 2 addresses knot points
  ##          type = 3 addresses 1-d power points
  ##          type = 1 addresses predict(design) points
  ## all adresses are base 1 pointing to first element
  ##
  ## 1. design points
  ##    Each element is a (full) matrix with ncol >= 1
  ##    from 'predictpoints' in asreml.R

  points <- 0 # careful! inter(2) is a base addr for knots, so start at 2
  ptr <- 2
  size <- sum(unlist(lapply(design.points,function(x)ncol(x)))) +
    length(knot.points) + length(pwr.points)

  addrs <- matrix(0, ncol=3, nrow=size) # index, n, type
  term <- matrix("", ncol=2, nrow=size)  # term, dim
  a <- 1
  IBV <- JBV <- matrix(0,nrow=0,ncol=0)

  if(length(design.points) > 0) {
    extent <- sapply(design.points,function(x)ncol(x))
    dims <- sapply(design.points,function(x)dimnames(x)[[2]])
    size <- sapply(design.points,function(x)nrow(x))
    ## ibv as per 'inter' for dim 1
    IBV <- matrix(0,nrow=4,ncol=length(design.points))
    dimnames(IBV) <- list(c("flag","loc","data","len"),names(design.points))
    ## jbv as per 'inter' for dim 2
    JBV <- matrix(0,nrow=4,ncol=length(design.points))
    dimnames(JBV) <- list(c("flag","loc","data","len"),names(design.points))
    ## At this point we don't know 'data' - set in inter or fun call
    points <- c(points, vector(mode="numeric",length=sum(extent*size)))
    for(i in 1:length(design.points)) {
      for(j in 1:extent[i]) {
        addrs[a,] <- c(ptr, size[i], 1)
        points[seq(ptr,ptr+size[i]-1)] <- design.points[[i]][,j]
        if(j == 1) {
          IBV[,i] <- c(1, ptr, 0, size[i])
          dimnames(IBV)[[2]][i] <- dims[j]
        }
        else if(j == 2) {
          JBV[,i] <- c(1, ptr, 0, size[i])
          dimnames(JBV)[[2]][i] <- dims[j]
        }
        term[a, 1] <- names(design.points)[i]
        term[a, 2] <- dims[j]
        ptr <- ptr+size[i]
        a <- a+1
      }
    }
  } # end design points

  ## 2. spline knot points
  if(length(knot.points) > 0) {
    size <- sapply(knot.points,function(x){length(x)})
    if(any(size < 3))
      stop("Insufficient knot points for spline")
    points <- c(points, vector(mode="numeric",length=sum(size)))
    for(i in 1:length(knot.points)) {
      addrs[a,] <- c(ptr, size[i], 2)
      points[seq(ptr,ptr+size[i]-1)] <- knot.points[[i]]

      term[a, 1] <- names(knot.points)[i]
      term[a, 2] <- names(knot.points)[i]
      ptr <- ptr+size[i]
      a <- a+1
    }
  } # end knot points

  ## 3. One dimensional power models
  if(length(pwr.points) > 0) {
    size <- sapply(pwr.points,function(x){length(x)})
    points <- c(points, vector(mode="numeric",length=sum(size)))
    for(i in 1:length(pwr.points)) {
      addrs[a,] <- c(ptr, size[i], 3)
      points[seq(ptr,ptr+size[i]-1)] <- pwr.points[[i]]
      term[a, 1] <- names(pwr.points)[i]
      term[a, 2] <- names(pwr.points)[i]
      ptr <- ptr+size[i]
      a <- a+1
    }
  } # end power points

  addrs <- cbind(data.frame(term, stringsAsFactors=FALSE), data.frame(addrs))
  names(addrs) <- c('term','dimension','index','n','type')

  ## keep in an environment
  if(!exists(".ptsEnv", inherits=TRUE))
    .ptsEnv <- new.env()
  storage.mode(points) <- "double"
  storage.mode(IBV) <- "integer"
  storage.mode(JBV) <- "integer"
  assign("points",points,envir=.ptsEnv)
  assign("addrs",addrs,envir=.ptsEnv)
  assign("IBV",IBV,envir=.ptsEnv)
  assign("JBV",JBV,envir=.ptsEnv)

  return(.ptsEnv)
}
update_ijbv <- function(mf) {
  ## update row 3 of IBV & JBV

  pe <- attr(mf, "points.env")
  if(prod(dim(pe$IBV)) > 0)
    pe$IBV[3,] <- as.integer(match(dimnames(pe$IBV)[[2]], names(mf)) - 1) ## base addr
  if(prod(dim(pe$JBV)) > 0)
    pe$JBV[3,] <- as.integer(match(dimnames(pe$JBV)[[2]], names(mf))) ## actual addr

  invisible()
}
#' Missing value action for asreml dataframes.
#'
#' Function to deal with missing values in the \code{data} argument to
#' \code{asreml}. \code{"include"} retains \code{NAs} in the data,
#' \code{"omit"} drops records with \code{NAs} and \code{"fail"}
#' raises an exception if \code{NAs} are present.
#'
#' @param y
#'
#' Action to take if there are missing values in the response; default
#' is \code{"include"}.
#'
#' @param x
#'
#' Action to take if missing values are present in covariates; default
#' is \code{"fail"}.
#'
#' @return
#'
#' A list with components \code{x} and \code{y}.
#'
na.method <- function(y=c("include","omit","fail"),
                      x=c("fail","include","omit"))
{
  return(list(x=x,y=y))
}
mv.method <- function(object, y=c("include","omit","fail"),
                      x=c("fail","include","omit"), ...)
{
  na.exclude.data.table <- function (object,vars, ...)
    {
      keep <- complete.cases(object[,vars,with=FALSE])
      if (any(keep))
        attr(keep, "class") <- "exclude"
      else
        stop("All observations excluded")
      keep
    }

  na.omit.data.table <- function (object, vars, ...)
    {
      keep <- complete.cases(object[,vars,with=FALSE])
       if (any(keep))
        attr(keep, "class") <- "omit"
      else
        stop("All observations omitted")
      keep
    }

  na.fail.default <- function (object, vars, ...)
    {
      if(!all(complete.cases(object[,vars,with=FALSE]))) {
        if(length(vars)==1)
          stop("missing values in ",vars,".")
        else
          stop("missing values among ",paste(vars,collapse=","),".")
      }
      return(invisible())
    }

  ##----------------------------------------------------
  keep <- rep(TRUE,nrow(object))
  if(!is.null(tt <- attr(object,"terms"))) {
    if(resp <- attr(tt,"response")) {
      object.X <- dimnames(attr(tt,"factors"))[[1]][-resp]
      object.Y <- all.vars(parse(text=dimnames(attr(tt,"factors"))[[1]][resp]))
    }
    else {
      object.X <- dimnames(attr(tt,"factors"))[[1]]
      object.Y <- character(0)
    }
  }
  else {
    ddd <- list(...)
    object.X <- ddd$xvar
    object.Y <- ddd$yvar
  }
  if(y == "fail") {
    na.fail.default(object,object.Y)
    if(x == "fail")
      na.fail.default(object,object.X)
    else if(x == 'omit' || x=="exclude")
      keep <- do.call(paste("na",x,"data.table",sep="."),
                      args=list(object=object,vars=object.X))
  }
  if(y=="include") {
    if(x == "fail")
      na.fail.default(object,object.X)
    else if(x == 'omit' || x=="exclude")
      keep <- do.call(paste("na",x,"data.table",sep="."),
                      args=list(object=object,vars=object.X))
  }
  if(y=="omit" || y=="exclude") {
    if(x=="include")
      keep <- na.exclude.data.table(object,object.Y)
    else if(x=="omit" || x=="exclude")
      keep <- do.call(paste("na",x,"data.table",sep="."),
                      args=list(object=object,vars=c(object.Y,object.X)))
    else if(x=="fail") {
      na.fail.default(object,object.X)
      keep <- do.call(paste("na",y,"data.table",sep="."),
                      args=list(object=object,vars=object.Y))
    }
  }
  keep
}
asr_getOption <- function(name)
{
    get("asr_options", envir = .asremlEnv)[[name]]
}
#' Set asreml options.
#'
#' Set less frequently used \code{asreml()} options.
#'
#' The following settings can be altered:
#' \describe{
#' 
#' \item{\code{about=FALSE}}{If \cite{TRUE} the date packaged is printed
#' for identification; the default is \code{FALSE}.}
#'
#' \item{\code{ai.loadings=0}}{Controls modification to AI updates of
#' loadings in extended factor-analytic (\code{fa}) models. After
#' ASReml calculates updates for variance parameters, it checks
#' whether the updates are reasonable and sometimes reduces them over
#' and above any \code{step.size} shrinkage. The extra shrinkage has
#' two levels. Loadings that change sign are restricted to doubling in
#' magnitude, and if the average change in magnitude of loadings is
#' greater than 10-fold, they are all shrunk. Unless the user
#' specifies constraints, ASReml sets them and rotates the loadings
#' each iteration. When \code{ai.loadings} \eqn{i} is specified
#' (default \eqn{i=-1} specifies no action), it also prevents AI
#' updates of some loadings during the first \eqn{i} iterations. For
#' \eqn{f > 1} factors, only the last factor is estimated (conditional
#' on the earlier ones) in the first \eqn{f-1} iterations. Then pairs,
#' including the last, are estimated until iteration \eqn{i}.}
#'
#' \item{\code{ai.penalty=10}}{The algorithm for updating loadings in
#' factor analytic models has been improved. The original update
#' procedure sometimes produced unreasonable updates, or exhibited
#' drift. The present strategy modifys the average information matrix
#' by increasing the diagonal elements pertaining to loadings by a
#' percentage, \eqn{p}. The default is to start with \eqn{p = 10}\%
#' and reduce it by 1 or 2\% each iteration down to 1\%. If the
#' starting values are poor, 10\% may not be a suficient initial
#' retardation. If it appears the updates are unreasonable, the value
#' of \eqn{p} is increased by 10\%. The default is \eqn{p=10}\%. After
#' the penalty has reduced to 1\%, it is further reduced to
#' 0.2\%. \code{ai.penalty} can be set to 0 if desired.
#' }
#'
#' \item{\code{ai.sing=FALSE}}{Force continuation if a singularity is
#' detected in the average information matrix.}
#'
#' \item{\code{aodev=FALSE}}{If \code{TRUE}, return an analyais of deviance.}
#'
#' \item{\code{aom=FALSE}}{If \code{TRUE}, return standardized
#' conditional residuals and standardized conditional BLUPs
#' in the \code{aom} component of the \code{asreml} object.}
#'
#' \item{\code{Cfixed=FALSE}}{If \code{TRUE}, return the computed part of the
#' \eqn{C^{-1}} matrix in component \code{Cfixed}; the default is \code{FALSE}.
#' The inverse coefficient matrix is fully formed for terms in the dense
#' set.}
#'
#' \item{\code{colourise=TRUE}}{If \code{TRUE} (the default) the header text produced
#' by functions such as \code{wald} and \code{predict} will be displayed in a different
#' colour if supported by the output terminal device.}
#'
#' \item{\code{Csparse=~NULL}}{If a formula is specified, return the
#' computed part of \eqn{C^{-1}} for those terms given in the
#' formula. \code{asreml} does not compute the whole of \eqn{C^{-1}},
#' only that which is sufficient to calculate the REML solution.}
#'
#' \item{\code{debug=FALSE}}{Return internal data structures.}
#'
#' \item{\code{dense=~NULL}}{Include the equation(s) for the term(s)
#' in the formula in the dense set. This results in faster processing
#' if the term is associated with a known dense inverse relationship
#' matrix.}
#'
#' \item{\code{design=FALSE}}{If \code{TRUE}, return the design matrix
#' in component \code{design} of the \code{asreml} object.}
#'
#' \item{\code{drop.unused.levels=TRUE}}{If \code{TRUE} (the default),
#' levels of simple factors that do not appear in the data are dropped.}
#'
#' \item{\code{eqorder=3}}{Set the algorithm used for ordering the
#' mixed-model equations prior to solution. \code{eqorder}\code{=-1}
#' processes the equations in \emph{user} order; generally this will
#' run much slower, if at all in real time for large analyses.}
#'
#' \item{\code{extra = n}}{Forces another \code{mod(n, maxit)} iterations
#' after apparent convergence; the default is \code{n=0}.}
#'
#' \item{\code{fail="hard"}}{If \code{"hard"} (the default) fatal
#' errors will terminate execution, otherwise if \code{"soft"} such
#' conditions will be reported as warnings, allowing simulation runs,
#' for example, to continue. In both cases the \code{converge} component
#' of the \code{asreml} object will be set to \code{FALSE} and the results
#' will be erroneous.}
#'
#' \item{\code{fixgammas=FALSE}}{If \code{TRUE}, all variance
#' parameters are constrained to be fixed at their starting values.}
#'
#' \item{\code{font.scale=1.0}}{Scale axis text and labels (relative to
#' the \code{asreml} default settings) in the graphs generated by
#' \code{plot.asreml()}. }
#'
#' \item{\code{gammaPar=FALSE}}{If \code{TRUE} (the default is \code{FALSE}),
#' single section models will be fitted using the \code{gamma} parameterization
#' irrespective of whether the \code{residual} formula specifies a correlation
#' or variance model. The default behaviour for single section models is to fit
#' on the \code{gamma} scale if the \code{residual} formula specifies a correlation
#' structure, and on the \code{sigma} scale if the \code{residual} formula
#' specifies a variance structure.}
#'
#' \item{\code{glmminloop=1}}{Sets the number of inner iterations
#' performed in an iteratively weighted least squares analysis. These
#' estimate the effects in the linear model for the current set of
#' variance parameters; outer iterations are the AI updates to the
#' variance parameters. The default is to perform 4 inner iterations
#' in the first round and 2 in subsequent rounds of the outer
#' iteration. Set to 2 or more to increase the number of inner
#' iterations.}
#'
#' \item{\code{grid=TRUE}}{A logical vector of length 1 or
#' \code{length(design.points)} (see \link[=predict.asreml]{predict})
#' controlling the expansion of coordinates for 2 dimensional
#' kriging. For a given term, the coordinates for prediction in 2
#' dimensions \eqn{(x,y)} are given as a list of two vectors or a two
#' column matrix component of \code{design.points}. If \code{TRUE},
#' the coordinates are expanded to form an \eqn{(x,y)} grid of all
#' possible combinations, otherwise the columns of the matrix and are
#' taken in parallel.}
#'
#' \item{\code{keep.order=FALSE}}{If \code{TRUE}, the order of terms
#' in the \code{fixed} formula is retained. Set to \code{TRUE} if the
#' special model function \code{and()} is present.}
#'
#' \item{\code{knots=50}}{The default number of knot points for spline
#' terms. For a variate \code{x}, the number of knot points is
#' \code{min(length(unique(x)), knots).}}
#'
#' \item{\code{maxit=13}}{Maximum number of iterations.}
#'
#' \item{\code{nsppoints=21}}{Influences the number of points used
#' when predicting splines and polynomials. The design matrix
#' generated by the \code{pol(x)} and \code{spl(x)} functions are
#' modified to include extra rows for points used in prediction. The
#' range of \eqn{x} is divided by \eqn{nsppoints-1} to give a step size
#' \eqn{i}. For each point \eqn{p} in \eqn{x}, a predict point is
#' inserted at \eqn{p+i} if there is no data value in the interval
#' \eqn{[p, p+1.1i]}. \code{nsppoints} is ignored if the
#' \code{predict.asreml()} argument \code{design.points} is set (or the
#' \code{design.points} component of the \code{predict} list argument
#' to \code{asreml()} is not empty). This process also affects the
#' number of levels identified by \code{dev(x)}.}
#'
#' \item{\code{oscillate=TRUE}}{Test for oscillating log-likelihood
#' (default=TRUE).}
#'
#' \item{\code{pxem=1}}{(PX)EM update strategy for unstructured (US)
#' variance models when Average Information updates cause them to be
#' non-positive definite (see \code{uspd}). Valid values are:
#'
#' \tabular{ll}{
#' \code{pxem} \tab Action \cr
#' 1 \tab standard EM + 10 local EM steps \cr
#' 2 \tab standard EM + 10 local PXEM steps \cr
#' 3 \tab standard EM + 10 local EM steps\eqn{^*} \cr
#' 4 \tab standard EM + 10 local PXEM steps\eqn{^*} \cr
#' 5 \tab standard EM only \cr
#' 6 \tab single local PXEM \cr
#' 7 \tab standard EM + 1 local EM step \cr
#' 8 \tab standard EM + 1 local PXEM step
#' }
#' \eqn{^*}Options 3 and 4 cause all US structures to be updated by
#' (PX)EM if any particular one requires EM updates.}
#'
#' \item{\code{pworkspace="128mb"}}{Sets the workspace needed by the
#' \code{predict()} method; follows the same convention as
#' \code{workspace}. Ignored if the \code{predict} argument to
#' \code{asreml()} is not set. Note that the total workspace used for
#' prediction is \code{workspace}+\code{pworkspace}.}
#'
#' \item{\code{random.order="noeff"}}{Reorder terms in the
#' \code{random} and \code{sparse} formulae in increasing order of
#' number of effects. This is almost always desirable, especially if
#' the stratum variance decomposition is required. Other options are
#' \code{"user"} to retain the order given, or \code{"R"} for the
#' default \pkg{R} rules.}
#'
#' \item{\code{rotate.fa=FALSE}}{If \code{FALSE} (the default),
#' \code{asreml()} initially constrains the first \eqn{k-1} loadings
#' for higher order (\eqn{k>1}) factors in factor analytic models to
#' zero. If constraints are not set for factor analytic models with
#' more than one factor, \code{asreml()} will set them internally and
#' rotate the loadings each iteration (\code{rotate.fa=TRUE}). This
#' option also modifies the action of \code{update.Gcon} such that
#' rotation, if specified, is applied on an update.}
#'
#' \item{\code{scale=1.0}}{Overall scale parameter.}
#'
#' \item{\code{score=FALSE}}{If \code{TRUE}, the score vector is 
#' returned in a component \code{score} of the \code{asreml}
#' object; the default is \code{FALSE}.}
#'
#' \item{\code{spline.scale=-1}}{When forming a design matrix for a
#' \code{spl()} term, a standardised scale is used. Setting
#' \code{spline.scale = 1} forces \code{asreml} to use the scale of
#' the variable. The default (-1) is recommended in most cases.}
#'
#' \item{\code{spline.step=list(spl=10000,dev=10000,pol=10000)}}{A list
#' with components named \code{spl}, \code{dev} and \code{pol}
#' specifying the resolution for spline deviations and polynomial
#' functions, respectively. Points closer together than
#' \code{1/spline.step} of the range will be treated as a single
#' point.}
#'
#' \item{\code{step.size=0.316}}{Update shrinkage factor, reduces the
#' update step sizes of the variance parameters. The step size is
#' incremented each iteration to a maximum of 1.0.}
#'
#' \item{\code{tol=c(0,0)}}{A vector of length two that modifies the
#' sensitivity of \code{asreml} to detect singularities in the mixed
#' model equations. This is intended for the rare occasions when
#' singularities are detected after the first iteration.
#'
#' Normally a singularity is declared if the adjusted sum of squares
#' of a covariable is less than \eqn{e}, or less than the uncorrected
#' sum of squares \eqn{\times e}, where \eqn{e=10^{-8}} in the first
#' iteration and \eqn{10^{-10}} thereafter. If \code{tol=c(a,b)},
#' \eqn{e} is scaled by \eqn{10^a} for the the first iteration, and
#' \eqn{10^b} for subsequent iterations. Once a singularity is
#' detected, the corresponding equation is dropped (forced to be zero)
#' in subsequent iterations. If the problem of later singularities
#' arises because of the low coefficient of variation of a covariable,
#' it may be advisable to centre and rescale the covariable. If the
#' degrees of freedom are correct in the first iteration, the problem
#' lies with the variance parameters and a different variance model
#' (or constraint) is needed.}
#'
#' \item{\code{trace=TRUE}}{Report convergence monitoring in the console.}
#'
#' \item{\code{update.Gcon=TRUE}}{Update the constraint status of
#' variance parameters in the \code{G.param} list component on
#' termination; this may influence subsequent updates to the model fit
#' (the default is \code{TRUE}).}
#'
#' \item{\code{update.Rcon=TRUE}}{Update the constraint status of
#' variance parameters in the \code{R.param} list component on
#' termination; this may influence subsequent updates to the model fit
#' (the default is \code{TRUE}).}
#'
#' \item{\code{update.step.size=0.316}}{Update shrinkage factor to use
#' in a call to \code{update()}. Ignored if set to the default (0.316)
#' or if \code{step.size} is explicitly specified on the \code{update()}
#' call; otherwise the shrinkage factor is set to \code{update.step.size}
#' in the call to \code{asreml()} constructed by \code{update()}.}
#'
#' \item{\code{uspd=TRUE}}{If TRUE, (the default) set the boundary constraint for
#' each parameter in unstructured variance models to \code{"P"}. Under
#' these conditions, \code{asreml} checks whether the updated matrix
#' is positive definite; if not, the average information update
#' is replaced with an EM update (see \code{pxem}).}
#'
#' \item{\code{workspace="128mb"}}{Sets the workspace for the core \code{REML}
#' routines in the form of a number optionally followed directly by a
#' valid measurement unit. Valid units are \code{kb}, \code{mb} or
#' \code{gb}; if no units are given then the value is interpreted as
#' double-precision words (groups of 8 bytes).}
#'
#' }
#'
#' @param ...
#'
#' Arguments in the form \code{name} = \code{value}, where \code{name}
#' is the name of the option to set.
#'
asreml.options <- function(...)
{
  args <- list(...)
  if (is.null(names(args)) && length(args) == 1 && is.list(args[[1]])) args <- args[[1]]
  old <- get("asr_options", envir = .asremlEnv)

  ## if no args supplied, returns full options list
  if (length(args) == 0)
    return(old)

  nm <- names(args)

  if (is.null(nm))
    return(old[unlist(args)]) ## typically getting options, not setting
  isNamed <- nm != "" ## typically all named when setting, but could have mix

  if (any(!isNamed)) nm[!isNamed] <- unlist(args[!isNamed])

  ## so now everything has non-"" names, but only the isNamed ones should be set
  ## everything should be returned, however
  out <- old[nm]
  names(out) <- nm
  nm <- nm[isNamed]

  .asremlEnv$asr_options <- updateList(old, args)

  ## return changed entries invisibly
  invisible(out)
}
.control <- function() {
  list(about = FALSE,
       scale = 1.0,
       workspace="120mb",
       pworkspace="120mb",
       maxit=13,
       step.size = 0.316,
       update.step.size = 0.316,
       tol = c(0,0),
       uspd = TRUE,
       oscillate = TRUE,
       pxem = 1,
       extra = 0,
       eqorder = 3,
       threads = 1,
       random.order = "noeff", #user, R, noeff
       keep.order = FALSE, #for fixed terms
       fail = "hard", #else "soft"
       fixgammas = FALSE,
       gammaPar = FALSE,
       knots=50,
       nsppoints=21,
       grid=TRUE,
       score=FALSE,
       spline.step=list(spl=10000,dev=10000,pol=10000),
       spline.scale=-1.0,
       font.scale=1.0,
       Cfixed=FALSE,
       aodev = FALSE,
       aom = FALSE,
       trace=TRUE,
       debug=FALSE,
       drop.unused.levels = TRUE,
       update.Gcon = TRUE,
       update.Rcon = TRUE,
       ai.loadings = 0,
       ai.penalty = 10,
       rotate.fa = FALSE,
       ai.sing = FALSE,
       ai.scale = 0,
       glmminloop = 1,
       dense = ~NULL,
       Csparse = ~NULL,
       design = FALSE,
       colourise = TRUE
       )
}
updateList <- function(x, val)
{
    if (is.null(x)) x <- list()
    utils::modifyList(x, val)
}
chkArgs <- function(tt, call)
{
  ## simple checks - stop on error
  ##
  ## formula arguments
  ##
  if(length(tt$fixed) != 3)
    stop("\nfixed model formula must be of the form \"resp ~ pred\"", call. = FALSE)

  if(!is.null(tt$random) && length(tt$random) != 2)
    stop("\nrandom model formula must be of form \" ~ pred\"", call. = FALSE)

  if(!is.null(tt$sparse) && length(tt$sparse) != 2)
    stop("\nsparse model formula must be of form \" ~ pred\"", call. = FALSE)

  if(!is.null(tt$residual) && length(tt$residual) != 2)
    stop("\nresidual model formula must be of the form \" ~ pred\"", call. = FALSE)

  call <- as.list(call)[-1]

  ## check form of mbf arg
  if(length(mbf <- eval(call$mbf)) > 0) {
    if(!is.list(mbf))
      stop("mbf must be a list\n")
    lapply(mbf, function(x) {
      nn <- names(x)
      if(is.na(match("cov",nn)) | is.na(match("key",nn)))
        stop("Elements of mbf must have components 'cov' and 'key'\n", call. = FALSE)
    })
  }
  ## VCM
  if(!is.null(call$vcm)) { #else default
    if(!is.matrix(eval(call$vcm)) || is.null(dimnames(eval(call$vcm))))
      stop("'vcm' must be a matrix with dimnames.", call. = FALSE)
  }
  ## VCC
  if(!is.null(call$vcc)) {
    if(!is.matrix(m <- eval(call$vcc)))
      stop("'vcc' must be a two column matrix", call. = FALSE)
    if(nrow(m) > 1) {
      if(ncol(m) != 2)
        stop("'vcc' must be a two column matrix", call. = FALSE)
      if(is.null(dimnames(m)))
        stop("'vcc' must have a 'dimnames' attribute", call. = FALSE)
    }
  }

  ## Old arguments
  if(!is.null(call[['as.multivariate']]))
    stop("'as.multivariate' replaced with 'asmv'.", call. = FALSE)
  if(!is.null(call[['constraints']]))
    stop("'constraints' replaced with 'vcc' and 'vcm'.", call. = FALSE)
  if(!is.null(call[['control']]))
    stop("'control' argument removed; see 'asreml.options'.", call. = FALSE)
  if(!is.null(call[['dump.model']]))
    stop("'dump.model' has been deleted.", call. = FALSE)
  if(!is.null(call[['ginverse']]))
    stop("'ginverse' removed; see 'vm()'.", call. = FALSE)
  if(!is.null(call[['model']]))
    stop("'model' has been deleted.", call. = FALSE)
  if(!is.null(call[['na.method.X']]))
    stop("'na.method.X' removed; see the 'na.action' argument.", call. = FALSE)
  if(!is.null(call[['na.method.Y']]))
    stop("'na.method.Y' removed; see the 'na.action' argument.", call. = FALSE)
  if(!is.null(call[['predictpoints']]))
    stop("'predictpoints' removed; see the 'design.points' predict() argument.", call. = FALSE)
  if(!is.null(call[['pwrpoints']]))
    stop("'pwrpoints' removed; see the 'pwr.points' asreml() argument.", call. = FALSE)
  if(!is.null(call[['splinepoints']]))
    stop("'splinepoints' removed; see the 'knot.points' asreml() argument.", call. = FALSE)
  if(!is.null(call[['splinescale']]))
    stop("'splinescale' removed; see 'asreml.options()$spline.scale'.", call. = FALSE)
  invisible()
}
asr_glm <- function(fm)
{
  ## Parse family argument to asreml

  asr.id <- c(1,2,3,4,-1,-1,5,9,
              1,2,3,4,-1,-1,5,9)
  names(asr.id) <- c("Gaussian","Binomial","Poisson","Gamma",
                     "Inverse Gaussian","Log Normal","Negative Binomial","Multinomial",
                     "gaussian","binomial","poisson","gamma",
                     "inverse.gaussian","log.normal","negative.binomial","multinomial")
  asr.link <- c(2,3,4,1,7,5,-1,6,
                2,3,4,1,7,5,-1,6)
  names(asr.link) <- c("Logit", "Probit", "Complementary Log", "Identity", "Inverse", "Log",
		       "Inverse Square","Square Root",
                       "logit", "probit", "cloglog", "identity", "inverse", "log",
		       "1/mu^2","sqrt")

  dist <- fm$family[1]
  lnk <- substring(fm$family[2],1,
			    match(":",
				  substring(fm$family[2],
					    1:nchar(fm$family[2]),
					    1:nchar(fm$family[2])))-1)
  id <- asr.id[match(dist,names(asr.id))]
  link <- asr.link[match(lnk,names(asr.link))]

  if(is.null(fm$dispersion))
    dispersion <- as.numeric(ifelse(id==1,NA,1.0))
  else
    dispersion <- as.numeric(fm$dispersion)
  names(dispersion) <- names(id)
  phi <- ifelse(is.null(fm$phi),1.0,fm$phi)

  list(id = id, link = link, dispersion = dispersion,
       total = if(is.null(fm$total)) NULL else as.character(fm$total), phi=phi)
}
getFamily <- function(thing) {
  if(is.null(thing))
    list(asr_gaussian())
  else if (is.call(thing)) {
    family <- eval(thing)
    if(thing[[1]] == quote(list))
      family
    else
      list(family)
  }
}
asr_makeFamily <- function(dist,link,phi=NA)
{
  variance.name <- switch(dist,
                          binomial="mu(1-mu)",
                          gaussian="constant",
                          Gamma="mu^2",
                          inverse.gaussian="mu^3",
                          poisson="mu",
                          negative.binomial="mu+mu^2/phi",
                          multinomial="mu(1-mu)")
  if(is.null(variance.name))
    stop(paste(dist,"not implemented\n"))

  fam.obj <- switch(dist,
                    negative.binomial = do.call(dist,list(link=link,phi=phi)),
                    do.call(dist,list(link=link)))

  ## Make it look more like S
  fam <- list()
  fam$family <- c(fam.obj$family,paste(fam.obj$link,":",sep=""))
  fam$link <- fam.obj$linkfun
  fam$inverse <- fam.obj$linkinv
  fam$deriv <- asr_glmDeriv(link)
  fam$initialize <- fam.obj$initialize
  fam$variance <- fam.obj$variance
  fam$deviance <- asr_glmDeviance(variance.name)
  fam$weight <- switch(dist,
                       binomial=parse(text="w*mu*(1.0-mu)"),
                       gaussian=parse(text="w"),
                       Gamma=parse(text="w*mu^2"),
                       inverse.gaussian=parse(
                         text="w/((sqrt(family$variance(mu))*family$deriv(mu))^2.)"),
                       poisson=parse(text="w*mu"))

  oldClass(fam) <- "asreml.family"
  fam
}
asr_glmDeriv <- function(linkname)
{
  switch(linkname,
         identity=function(mu){1},
         logit=function(mu)
         {
           d <- mu * (1 - mu)
           if(any(tiny <- (d < .Machine$double.eps))) {
             warning("Model unstable; fitted probabilities of 0 or 1")
             d[tiny] <- .Machine$double.eps
           }
           1/d
         },
         cloglog=function(mu)
         {
           mu2 <- 1 - mu
           d <-  - (mu2 * log(mu2))
           if(any(tiny <- (d < .Machine$double.eps))) {
             warning("Model unstable; fitted probabilities of 0 or 1")
             d[tiny] <- .Machine$double.eps
           }
           1/d
         },
         probit=function(mu){sqrt(2 * pi) * exp((qnorm(mu)^2)/2)},
         log=function(mu){1/mu},
         inverse=function(mu){-1/mu^2},
         "1/mu^2"=function(mu){-2/mu^3},
         sqrt=function(mu){1/(2 * sqrt(mu))})
}
asr_glmDeviance <- function(variance, residuals=FALSE)
{
  switch(variance,
         constant=function(mu, y, w, residuals = substitute(residuals),phi=NULL)
         {
           if(residuals)
             sqrt(w) * (y - mu)
           else
             sum(w * (y - mu)^2)
         },
         "mu(1-mu)"=function(mu, y, w, residuals = substitute(residuals),phi=NULL)
         {
           ## counts or proportions?
           if(max(y, na.rm=TRUE) > 1) {
             y[w !=0 ] <- y[w != 0 ] / w[ w != 0 ]
             y[ w==0 ] <- 0
           }
           devy <- y
           nz <- y != 0
           devy[nz] <- y[nz] * log(y[nz])
           nz <- (1 - y) != 0
           devy[nz] <- devy[nz] + (1 - y[nz]) * log(1 - y[nz])
           devmu <- y * log(mu) + (1 - y) * log(1 - mu)
           if(any(small <- mu * (1 - mu) < .Machine$double.eps)) {
             warning("fitted values close to 0 or 1")
             smu <- mu[small]
             sy <- y[small]
             smu <- ifelse(smu < .Machine$double.eps, .Machine$double.eps,
                           smu)
             onemsmu <- ifelse((1 - smu) < .Machine$double.eps, .Machine$
                               double.eps, 1 - smu)
             devmu[small] <- sy * log(smu) + (1 - sy) * log(onemsmu)
           }
           devi <- 2 * (devy - devmu)
           if(residuals) {
             sign(y - mu) * sqrt(abs(devi) * w)
           }
           else sum(w * devi)
         },
         mu=function(mu, y, w, residuals = substitute(residuals),phi=NULL)
         {
           nz <- y > 0
           devi <-  - (y - mu)
           devi[nz] <- devi[nz] + y[nz] * log(y[nz]/mu[nz])
           if(residuals)
             sign(y - mu) * sqrt(2 * abs(devi) * w)
           else 2 * sum(w * devi)
         },
         "mu^2"=function(mu, y, w, residuals = substitute(residuals),phi=NULL)
         {
           nz <- y > 0
           devi <- (y - mu)/mu + log(mu)
           devi[nz] <- devi[nz] - log(y[nz])
           if(residuals)
             sign(y - mu) * sqrt(2 * abs(devi) * w)
           else
             2 * sum(w * devi)
         },
         "mu^3"=function(mu, y, w, residuals = substitute(residuals),phi=NULL)
         {
           devi <- ((y - mu)^2)/(mu^2 * y)
           if(residuals)
             sign(y - mu) * sqrt(w * abs(devi))
           else
             sum(w * devi)
         },
         "mu+mu^2/phi"=function(mu,y,w,residuals=substitute(residuals),phi=1.0)
         {
           devi <- 2*w*(y*log(pmax(1,y)/mu)-(y+phi)*log((y+phi)/(mu+phi)))
           if(residuals)
             sign(y-mu)*sqrt(abs(devi))
           else
             sum(devi)
         })
}
#' GLM family objects for asreml.
#'
#' Family functions specify the details of the models accepted by the
#' \code{family} argument to \code{asreml}.
#'
#' @param link
#'
#' A character string identifying the link function; valid values are:
#' \describe{
#' \item{Gaussian:}{identity, log, inverse}
#' \item{Gamma:}{identity, log, inverse}
#' \item{inverse.gaussian:}{1/mu^2}
#' \item{binomial:}{logit, probit, cloglog}
#' \item{multinomial:}{logit, probit, cloglog}
#' \item{negative.binomial:}{identity, log, inverse}
#' \item{poisson:}{identity, log, sqrt}
#'
#' }
#'
#' @param dispersion
#'
#' If \code{NA}, the default for Gaussian and inverse Gaussian models,
#' the dispersion parameter is estimated, otherwise it is fixed at the
#' nominated value (default 1.0).
#'
#' @param phi The known value of the additional parameter \code{phi}.
#'
#' @param total A character string or name giving the column in
#' \code{data} containing the total counts.
#'
#' @return
#'
#' A list of functions and expressions needed by the \code{family}
#' argument.
#'
#' @name asr_families
NULL
#' @describeIn asr_families The Gaussian model (default).
asr_gaussian <- function(link = "identity", dispersion=NA)
{
  ## gaussian family

  link <- as.character(substitute(link))
  misnames <- c("inverse", "log", "identity", "reciprocal", "1/mu",
		"Inverse", "Reciprocal", "Log", "Identity")
  corresp <- c(1, 2, 3, 1, 1, 1, 1, 2, 3)
  lmatch <- pmatch(link, misnames, FALSE)
  if(!lmatch)
    stop('Gaussian links are "log", "inverse" or "identity"\n')
  link <- misnames[corresp[lmatch]]
  fam <- asr_makeFamily("gaussian",link=link)
  fam$dispersion <- dispersion
  fam
}
#' @describeIn asr_families The gamma model.
asr_Gamma <- function(link = "inverse", dispersion=1.0, phi=1.0)
{
  ## Gamma family

  link <- as.character(substitute(link))

  misnames <- c("inverse", "log", "identity", "reciprocal", "1/mu",
		"Inverse", "Reciprocal", "Log", "Identity")
  corresp <- c(1., 2., 3., 1., 1., 1., 1., 2., 3.)
  lmatch <- pmatch(link, misnames, FALSE)
  if(!lmatch)
    stop("Gamma links are \"inverse\",  \"log\" or \"identity\"")
  link <- misnames[corresp[lmatch]]
  fam <- asr_makeFamily("Gamma", link=link, phi=phi)
  fam$dispersion <- dispersion
  fam$phi <- phi
  fam
}
#' @describeIn asr_families The inverse Gaussian  model.
asr_inverse.gaussian <- function(link = "1/mu^2", dispersion=NA)
{
  ##
  ## inverse gaussian family
  ##

  link <- as.character(substitute(link))

  misnames <- c("1/mu^2")
  corresp <- c(1)
  lmatch <- pmatch(link, misnames, FALSE)
  if(!lmatch)
    stop("Inverse gaussiann link is \"1/mu^2\"")
  link <- misnames[corresp[lmatch]]
  fam <- asr_makeFamily("inverse.gaussian", link=link)
  fam$dispersion <- dispersion
  fam
}
#' @describeIn asr_families The binomial model. If the response is
#' between 0 and 1 it is interpreted as the proportion of successes,
#' otherwise, if not a binary (0,1) variate, it is interpreted as
#' counts of successes; the total number of cases is given by the
#' \code{total} argument. If \code{total} is \code{NULL}, a binary
#' (0,1) response is expected.
asr_binomial <- function(link = "logit", dispersion=1, total=NULL)
{
  ## binomial family

  link <- as.character(substitute(link))
  misnames <- c("logit", "probit", "cloglog", "Logit", "Probit",
		"clog-log", "Cloglog", "Clog-log")
  corresp <- c(1., 2., 3., 1., 2., 3., 3., 3.)
  lmatch <- pmatch(link, misnames, FALSE)
  if(!lmatch)
    stop('Binomial links are "logit", "probit", or "cloglog"\n')
  link <- misnames[corresp[lmatch]]
  fam <- asr_makeFamily("binomial", link=link)
  fam$dispersion <- dispersion
  fam$total <- substitute(total)
  fam
}
#' @describeIn asr_families The multinomial model. The response can
#' either be a matrix of counts with the response categories as
#' columns, with an additional column for the total number of cases in
#' each row, or in univariate style with the response as a factor. If
#' the response is a matrix and \code{total=NULL}, the total counts
#' are calculated from the category columns.
asr_multinomial <- function(link = "logit", dispersion=1, total=NULL)
{
  ## dummy for multinomial family

  link <- as.character(substitute(link))
  misnames <- c("logit", "probit", "cloglog", "Logit", "Probit",
		"clog-log", "Cloglog", "Clog-log")
  corresp <- c(1., 2., 3., 1., 2., 3., 3., 3.)
  lmatch <- pmatch(link, misnames, FALSE)
  if(!lmatch)
    stop('Multinomial links are "logit", "probit", or "cloglog"\n')
  link <- misnames[corresp[lmatch]]
  fam <- asr_makeFamily("multinomial", link=link)
  fam$dispersion <- dispersion
  fam$total <- substitute(total)
  fam
}
#' @describeIn asr_families The negative-binomial model.
asr_negative.binomial <- function(link = "log", dispersion=1, phi=1.0)
{
  ## negative binomial family

  link <- as.character(substitute(link))
  misnames <- c("log", "identity", "inverse", "reciprocal",
                "Log", "Identity", "Inverse", "Reciprocal")
  corresp <- c(1., 2., 3., 3., 1., 2., 3., 3.)
  lmatch <- pmatch(link, misnames, FALSE)
  if(!lmatch)
    stop('Negative binomial links are \"log\", \"identity\", or \"inverse\"')
  link <- misnames[corresp[lmatch]]
  fam <- asr_makeFamily("negative.binomial", link=link, phi=phi)
  fam$dispersion <- dispersion
  fam$phi <- phi
  fam
}
#' @describeIn asr_families The poisson model.
asr_poisson <- function(link = "log", dispersion=1.0)
{
  ##
  ## poisson family
  ##

  link <- as.character(substitute(link))

  misnames <- c("log", "identity", "sqrt", "Log", "Identity", "Sqrt")
  corresp <- c(1, 2, 3, 1, 2, 3)
  lmatch <- pmatch(link, misnames, FALSE)
  if(!lmatch)
    stop("Poisson links are \"log\", \"identity\" or \"sqrt\"")
  link <- misnames[corresp[lmatch]]
  fam <- asr_makeFamily("poisson", link=link)
  fam$dispersion <- dispersion
  fam
}
multinomial <- function (link = "logit")
{
  linktemp <- substitute(link)
  if (!is.character(linktemp))
    linktemp <- deparse(linktemp)

  okLinks <- c("logit", "probit", "cloglog")
  if (linktemp %in% okLinks)
    stats <- make.link(linktemp)
  else if (is.character(link)) {
    stats <- make.link(link)
    linktemp <- link
  }
  else {
    if (inherits(link, "link-glm")) {
      stats <- link
      if (!is.null(stats$name))
        linktemp <- stats$name
    }
    else {
      stop(gettextf("link \"%s\" not available for multinomial; available links are %s",
                    linktemp, paste(sQuote(okLinks), collapse = ", ")),
           domain = NA)
    }
  }
  variance <- function(mu) mu * (1 - mu)
  validmu <- function(mu) all(mu > 0) && all(mu < 1)
  ##dev.resids <- function(y, mu, wt) .Call("binomial_dev_resids",
  ##                                        y, mu, wt, PACKAGE = "stats")
  aic <- function(y, n, mu, wt, dev) {
    m <- if (any(n > 1))
      n
    else wt
    -2 * sum(ifelse(m > 0, (wt/m), 0) * dbinom(round(m *
                                                     y), round(m), mu, log = TRUE))
  }
  initialize <- expression({
    if (NCOL(y) == 1) {
      if (is.factor(y)) y <- y != levels(y)[1]
      n <- rep.int(1, nobs)
      if (any(y < 0 | y > 1)) stop("y values must be 0 <= y <= 1")
      mustart <- (weights * y + 0.5)/(weights + 1)
      m <- weights * y
      if (any(abs(m - round(m)) > 0.001)) warning("non-integer successes in multinomial glm!")
    } else if (NCOL(y) == 2) {
      if (any(abs(y - round(y)) > 0.001)) warning("non-integer counts in multinomial glm!")
      n <- y[, 1] + y[, 2]
      y <- ifelse(n == 0, 0, y[, 1]/n)
      weights <- weights * n
      mustart <- (n * y + 0.5)/(n + 1)
    } else stop("for the binomial family, y must be a vector of 0 and 1's\n",
                "or a 2 column matrix where col 1 is no. successes and col 2 is no. failures")
  })
  structure(list(family = "multinomial", link = linktemp, linkfun = stats$linkfun,
                 linkinv = stats$linkinv, variance = variance, #dev.resids = dev.resids,
                 aic = aic, mu.eta = stats$mu.eta, initialize = initialize,
                 validmu = validmu, valideta = stats$valideta), class = "family")
}
negative.binomial <- function (link = "log", phi = 1.0)
{
  linktemp <- substitute(link)
  if (!is.character(linktemp))
    linktemp <- deparse(linktemp)
  if (linktemp %in% c("log", "identity", "inverse"))
    stats <- make.link(linktemp)
  else if (is.character(link)) {
    stats <- make.link(link)
    linktemp <- link
  }
  else {
    if (inherits(link, "link-glm")) {
      stats <- link
      if (!is.null(stats$name))
        linktemp <- stats$name
    }
    else stop(linktemp, " link not available for negative binomial family; available links are \"identity\", \"log\" and \"inverse\"")
  }
  negbin.env <- new.env(parent = .GlobalEnv)
  .Phi <- NULL # Rcheck
  assign(".Phi", phi, envir = negbin.env)
  variance <- function(mu) mu + mu^2/.Phi
  validmu <- function(mu) all(mu > 0)
  dev.resids <- function(y, mu, wt) 2 * wt * (y * log(pmax(1, y)/mu) - (y + .Phi) * log((y + .Phi)/(mu + .Phi)))
  aic <- function(y, n, mu, wt, dev) {
    term <- (y + .Phi) * log(mu + .Phi) - y * log(mu) +
      lgamma(y + 1) - .Phi * log(.Phi) + lgamma(.Phi) -
        lgamma(.Phi + y)
    2 * sum(term * wt)
  }
  initialize <- expression({
    if (any(y < 0)) stop("negative values not allowed for the negative binomial family")
    n <- rep(1, nobs)
    mustart <- y + (y == 0)/6
  })
  environment(variance) <- environment(validmu) <- environment(dev.resids) <- environment(aic) <- negbin.env
  ##famname <- paste("Negative Binomial(", format(round(phi,4)), ")", sep = "")
  famname <- "negative.binomial"
  structure(list(family = famname, link = linktemp, linkfun = stats$linkfun,
                 linkinv = stats$linkinv, variance = variance,
                 dev.resids = dev.resids,
                 aic = aic, mu.eta = stats$mu.eta, initialize = initialize,
                 validmu = validmu, valideta = stats$valideta),
            class = "family")
}
is.special <- function(x) {
  match(as.character(x), Spcls$Fun, nomatch=0)
}
narg <- function(x) {
  n <- is.special(x)
  if(n > 0)
    ifelse(Spcls$ObjArgs[n] == -1, NA, Spcls$ObjArgs[n])
  else
    NA
}
spc_args <- function(x, arg, skip=FALSE) {
  if(is.atomic(x)) {
    if(is.character(x)) {
      arg <- c(arg, x)
    }
  }
  else if(is.name(x)) {
    arg <- c(arg, as.character(x))
  }
  else if(is.call(x)) {
    # also includes formulae like "~dsum()"
    if(!skip) {
      if(!is.element(all.names(x)[1], c("~", ":", "|")) 
         && !is.element(all.names(x)[1], Spcls$Fun)) { ## allows for I() and factor()
        return(c(arg, deparse(x)))
      }
    }
    n <- narg(x[[1]])
    if(length(x) > 1) {
      ulim <- ifelse(is.na(n), length(x), n+1)
      if(ulim > 1) {
        for(i in seq(2,ulim)) {
          arg <- spc_args(x[[i]], arg, TRUE)
        }
      }
    }
  }
  else if(is.pairlist(x)) {
  }
  else {
    stop("Don't know what to do with ", typeof(x))
  }
  arg
}
keep.subset <- function(DT, sub) {
  ## does a subset keeping attributes
  std <- names(attributes(data.table())) #attr(DT, "std.attr")
  attrib <- attributes(DT)[symdiff(names(attributes(DT)), std)]
  DT <- subset(DT, sub)
  if(length(attrib) > 0) {
    for(a in names(attrib))
      setattr(DT, a, attrib[[a]])
  }
  DT
}
modelNames <- function(form)
{
  ## Base factors for model frame

  if(form.null(form)) return(NULL)
  ignore <- seq(1,(1+(attr(form,"response") > 0)))
  if(!is.null(dim(attr(form, "factors")))) {
    also <- which(apply(attr(form, "factors"), 1, sum) == 0) + 1 # first elem of variables is "list"
    ignore <- unique(c(ignore, also))
  }
  vv <- attr(form,"variables")
  unlist(lapply(vv[-ignore], function(x) {
                  arg <- character(0)
                  spc_args(x, arg)}))
}
modelNames2 <- function(form)
{
  ## just want the vars from specials; rest untouched
  ## grp & mbf special cases if nested

  if(form.null(form)) return(NULL)
  ignore <- seq(1,(1+(attr(form,"response") > 0)))
  vv <- attr(form,"variables")
  unlist(lapply(vv[-ignore], function(x,y) {
                  if(is.call(x) && is.element(as.character(x[[1]]),y$Fun)) {
                    v <- all.vars(x)
                    if((n <- y[as.character(x[[1]]),'ObjArgs']) > 0)
                      {if(length(v) > 0) v[1:n] else NULL}
                    else if(n == 0)
                      v
                    else
                      NULL
                  }
                  else
                    my.dparse(x)}, Spcls))
}
form.null <- function(ff) {
  ifelse(is.null(ff[[length(ff)]]), TRUE, FALSE)
}
modelFrame <- function(tt,call,options,asr.glm,data,na.action)
{
  ## data is a data.table, NOT data.frame !!!!
  ## Strategy:
  ##  1. identify the response (may be a matrix, or factor for multinom)
  ##  2. add units
  ##  3. get 'group' and 'mbf' field names
  ##  4. glm total
  ##  4a check any PSD G-inverses to get additional levels
  ##  5. call modelTerms to get base factors from specials (pass 1)
  ##  6. eval base terms from 5, and drop unused columns
  ##  7. subset rows
  ##  8. filter missing values
  ##  9. expand if multivariate
  ## 10. drop unused levels in factors
  ## 11. add missing value factor
  ## 12. call modelTerms if multivariate or missing values

  ## Hack to suppress R CMD CHECK warnings
  total <- trait <- NULL

  fixed <- tt$fixed
  if(!form.null(tt$random))
    random <- tt$random
  else
    random <- terms(~NULL)
  if(!form.null(tt$sparse))
    sparse <- tt$sparse
  else
    sparse <- terms(~NULL)
  if(!form.null(tt$Csparse))
    Csparse <- tt$Csparse
  else
    Csparse <- terms(~NULL)
  if(!form.null(tt$dense))
    dense <- tt$dense
  else
    dense <- terms(~NULL)

  ## Get the response
  ## Known to fail: matrix response embedded in a single df column
  ##          --->  fails because data.table mangles it.
  asreml4Env <- attr(tt$fixed,".Environment")
  tf <- Terms(fixed)
  vars <- attr(tf,"variables")
  rsp <- attr(tf,"response")
  response <- vars[[rsp+1]]
  if(is.null(lhs <- dimnames(as.matrix(eval(response, data, asreml4Env)))[[2]]))
    lhs <- my.dparse(vars[[rsp+1]])

  LHS <- lhs
  multivariate <- ((nycol <- length(lhs)) > 1)
  multinomial <- any(unlist(lapply(asr.glm,function(x)x$id)) == 9)
  thrlevels <- 0;
  ## check if response is a factor
  if(!multivariate) {
    if(!multinomial) {
      if(ncol(data))
        yf <- is.factor(eval(response, envir=data))
      else # no data frame given
        yf <- is.factor(eval(response, enclos=asreml4Env))
      if(yf) stop("Response can only be a factor for multinomial models")
    }
  }
  ## Set residual formula and multivariate form flag while we're at it.
  ## multivariate data stays in matrix form unless presented 'asmv'.
  ##              logically expanded in aidsgn.
  ## ISUV --> std univariate
  ## ASUV --> fit mv; can have residual other than IxUS
  ## ASMV --> asmv factor replaces 'trait'; fit mv
  ## ISMV --> residual must be IxUS; do not include mv; includes multinomial
  ## ASMN --> univariate multinomial with response in a factor

  ## get families; vector for bivariate GLM
  familyID <- unlist(lapply(asr.glm,function(x)x$id))

  mvar.method <- "ISUV"
  if(multivariate) {
    mvar.method <- "ISMV"
    if(form.null(tt$residual))
      residual <- trimSpc(Terms(~ units:us(trait)))
    if(multinomial) {
      thrlevels <- nycol - 1
      if(is.null(asr.glm[[1]]$total)) { ## returns NULL if total not set
        data[, total:=apply(data[,lhs,with=FALSE],1,sum) ]
        asr.glm[[1]]$total <- "total"
      }
      if(form.null(tt$residual)) {
        residual <- trimSpc(Terms(~ units:mthr(trait)))
      }
    }
    else if(familyID[1] != 1) {
      mvar.method <- "ASUV"
    }
    else if(!form.null(tt$residual) &&
            !all(is.element(c("units","us","trait"), all.names(tt$residual)))) {
      mvar.method <- "ASUV"
    }
  }
  else {
    if(multinomial) {
      mvar.method <- "ASMN"
      thrlevels <- length(levels(data[[lhs]])) - 1
      if(form.null(tt$residual)) {
        residual <- trimSpc(Terms(~ units:mthr(trait)))
      }
    }
    else if(form.null(tt$residual)) {
      residual <- trimSpc(Terms(~ units))
    }
  }

  as.multivariate <- as.character(call$asmv)
  if(length(as.multivariate) > 0)
    mvar.method <- "ASMV"

  if(!form.null(tt$residual))
     residual <- tt$residual

  ## Add a 'trait' factor as a placeholder (to eval us(trait) etc)
  if(is.element(mvar.method, c("ASUV", "ISMV", "ASMN"))) {
    ## data may be a null data table
    if(ncol(data)) {
      if(mvar.method == "ASMN")
        data[, trait:=factor(as.numeric(data[[lhs]]))]
      else
        data[, trait:=factor(rep(lhs,length.out=nrow(data)),levels=lhs)]
    }
    else {
      if(mvar.method == "ASMN")
        data <- data.table(trait=factor(as.numeric(as.factor(lhs))))
      else
        data <- data.table(trait=factor(rep(lhs,
                             length.out=nrow(eval(response, enclos=asreml4Env))),levels=lhs))
    }
  }
  ## add units
  ## data may be a null data table
  if(ncol(data)) {
    ## data.table seems to have a problem if any columns are named "data"
    nr.yxz = nrow(data)
    data[,units:=factor(1:nr.yxz)]
  }
  else {
    data <- data.table(units=factor(1:length(eval(response, enclos=asreml4Env))))
  }
  if(any(is.element("data", names(data)))) {
    stop("'data.table': column name 'data' cannot match internal data.table object name ('data')")
  }
  ## Set an attribute giving the 'standard' attributes of a data table
  ## Used to (re)set attributes after a copy, such as subsetting
  ##setattr(data, "std.attr", names(attributes(data)))

  ## Set 'traits' attribute (needed in eval(mthr) )
  setattr(data,"traits",list(lhs=LHS,
                             family=unlist(lapply(asr.glm,function(x)names(x$id))),
                             mvar.method=mvar.method,
                             thrlevels=thrlevels))

  ## groups & mbf
  ## Set as attributes of data here for eval()
  if(!is.null(call$group)) {
      group <- eval(call$group)
      varNames <- names(data)
    for(i in names(group)) {
      if(is.numeric(group[[i]]))
        group[[i]] <- varNames[group[[i]]]
      else {
        if(any(is.na(match(group[[i]],varNames))))
          stop(paste("Object in group",i,"not in data."))
       }
    }
      gnames <- unique(unlist(group))
  }
  else {
    group <- list()
    gnames <- NULL
  }
  setattr(data,"GROUP",group)
  ## mbf
  ## keep data tables in a new environment
  mbf.env <- new.env()
  if(!is.null(call$mbf)) {
    mbf.env <- mbfEnv(eval(as.list(call)$mbf),data)
  }
  mbfKeys <- mbf.env$mbfAttr
  if(length(mbfKeys) > 0)
    knames <- unlist(lapply(mbfKeys,function(x)x$key[1]))
  else
    knames <- NULL
  setattr(data,"mbf.env",mbf.env)

  # GLM total, weights, offset

  glmTotal <- unlist(lapply(asr.glm,function(x)x$total))
  if((!is.null(call$weights)) && (length(glmTotal)))
    stop("Cannot specify glm total and weights")

  glmOffset <- attr(fixed, "offset")
  glmOffsetName <- NULL
  if(!is.null(glmOffset)) {
    glmOffsetName <- dimnames(attr(fixed, "factors"))[[1]][glmOffset]
  }

  xtras <-  c(gnames, knames, as.character(call$weights),
              glmTotal, glmOffsetName, "units", as.multivariate)

  xs <- unique(c(modelNames(fixed),
                 modelNames(random),
                 modelNames(sparse),
                 modelNames(residual),
                 xtras)) # for mv
  ## Ignore trait if not ASUV
  ##if(mvar.method != "ASUV") {
  ##  if(!is.na(x <- match("trait", xs)))
  ##    xs <- xs[-x]
  ##}
  vv <- c(lhs,xs)
  ## Assume vv is a character vector of:
  ## 1. base variable names
  ## 2. std functions like "log(x)"
  ## 3. special functions

  ## Evaluate vv in data
  ## for(col in vv){ data[, col := eval(parse(text=col),data,asreml4Env), with=FALSE]}
  ## (9007) this worked in 1.9.6. apparently 'with=FALSE' was deprecated in 1.9.4
  ## replace with parentheses
  ##data[, vv:= lapply(vv, function(x)eval(parse(text=x), envir=data, enclos=asreml4Env)),
  ##   with=FALSE]
  data[, (vv):= lapply(vv, function(x)eval(parse(text=x), envir=data, enclos=asreml4Env))]

  ## subset the data
  if(!is.null(call$subset)) {
    sub <- eval(call$subset,data,asreml4Env)
    if(length(sub) != nrow(data))
      stop("size of subset (",length(sub), ") does not match size of data (",
           nrow(data),").")
    data <- keep.subset(data, sub)
  }

  ## Drop any unused columns (by ref)
  if(any(!is.element(names(data),vv)))
    data[, (names(data)[!is.element(names(data),vv)]) := NULL]

  ## filter missing values
  ## All records are retained for multivariate analyses
  ## keep is a logical vector (stored as integer for C) of records to retain
  ## filter out any NaNs first
  data[, (names(data)):= lapply(.SD, function(x) replace(x, is.nan(x), NA))]
  keep <- do.call("mv.method",args=list(object=data,x=na.action$x[1],y=na.action$y[1],
                  xvar=xs, yvar=lhs))
  if((multivariate || length(as.multivariate) > 0) && !all(keep))
    stop("Attempt to ",attr(keep,"class")," missing values in multivariate analysis.")
  data <- keep.subset(data,keep)
  storage.mode(keep) <- "integer"
  setattr(data,"keep",keep)

  if(length(as.multivariate) > 0) {
    traits <- as.multivariate
    ny <- length(unique(data[[traits]]))
    ## Redo units
    if((nrow(data) %% ny) !=0)
      stop("Number of observations must be a multiple of the number of traits")
    nu <- nrow(data)/ny
    if(all(!duplicated(data[[traits]][ny])))
      data[, units := factor(rep(seq(1,nu),rep(ny,nu)))]
    else
      data[, units := factor(rep(seq(1,nu),ny))]
    setattr(data,"Trait.col",match(traits,names(data)))
  }

  ## drop unused levels by reference
  if (options$drop.unused.levels) {
    for (nm in names(data)) {
      x <- data[[nm]]
      if (is.factor(x) && length(unique(x[!is.na(x)])) <
          length(levels(x)))
        data[, (nm):= droplevels(data[[nm]])]
    }
  }

  ## Resolve levels in 'equate.levels'
  if(length(eql <- eval(call$equate.levels)) > 1) {
    ## Check all exist and are factors
    if(any(is.na(match(eql,names(data)))))
      stop("Elements of 'equate.levels' not in data")
    if(!all(sapply(subset(data,select=eql),function(x)is.factor(x))))
      stop("Not all elements of 'equate.levels' are factors")

    ulev <- unique(unlist(lapply(subset(data,select=eql),function(x)levels(x))))
    for(i in eql)
      data[, (i):= factor(as.character(data[[i]]),levels=ulev)]
  }

  ## add the 'mv' missing value factor to sparse
  ## dummy mv column here - mv included in a4dsgn
  ##
  mv <- 0
  if(na.action$y == "include" && any(is.na(data[,lhs, with=FALSE]))) {
    full.size <- nrow(data) * length(lhs)
    mv <- matrix(NA, nrow = nrow(data), ncol = length(lhs))
    mvlev <- seq(1,sum(is.na(data[,lhs,with=FALSE])))
    mv[is.na(data[,lhs, with=FALSE])] <- mvlev
    if(mvar.method != "ISMV") {
    data[, mv:= factor(rep(1,nrow(data)), levels=seq(1,length(levels(factor(mv)))))]
    sparse <- update.formula(sparse, formula("~.+mv"))
    }
    mv <- seq(1,full.size)[as.vector(!is.na(t(mv)))]
  }

  ## eval specials to get levels, data cols etc, correct.
  mixed <- formOrder(random, sparse, data, options$random.order)
  random <- formOrder(random, ~NULL, data, options$random.order)
  ## expand str()
  mixed <- expandStr(mixed, data)
  ## check PSD here too
  model.terms <- modelTerms(fixed, mixed, random, residual, Csparse, dense, data)

  ## kept record nos
  ## For multivariate data (ex as.multivariate)
  ##     residuals, hat & fitted values are in vec form.
  rkeep <- which(as.logical(keep))
  storage.mode(rkeep) <- "integer"
  setattr(data, "rkeep", rkeep)
  setattr(data, "mvUnits", mv)

  ## need this when "grp" is eval'd ???????????
  ##attr(data,"GROUP") <- group
  setattr(data, "model.terms", model.terms)
  if(!is.null(call$weights)) {
    setattr(data, "weights", as.character(call$weights))
    data[, as.character(call$weights) := as.double(data[[as.character(call$weights)]])]
  }
  for(i in 1:length(asr.glm)) {
    if(length(asr.glm[[i]]$total) > 0) {
      data[, asr.glm[[i]]$total := as.double(data[[asr.glm[[i]]$total]])]
    }
  }
  setattr(data,"family",asr.glm)
  setattr(data,"traits",list(lhs=LHS,
                             family=unlist(lapply(asr.glm,function(x)names(x$id))),
                             mvar.method=mvar.method,
                             thrlevels=thrlevels))
  class(data) <- c(class(data),"asr.model.frame")

  data
}
expandStr <- function(random,data)
{
  ## generate terms for str()
  ## 13/6/14
  ## Note str() returns a 'terms' object in obj !!!!!!!!!!!!!

  as.vec <- function(string) {
    return(strsplit(string,"+",fixed=TRUE)[[1]])
  }

  fix.types <- function(form) {
    ## fix attributes tType and vType
    ## str() can only be used in 'random' !!!!
    tType <- attr(form,"tType")
    vType <- attr(form,"vType")
    stg <- attr(form,"str.group")
    x <- seq(along=stg)[nchar(stg) > 0]
    ## 1. tType
    ff <- attr(Terms(form,keep.order=TRUE),"factors")
    t.new <- rep("random",length(x))
    names(t.new) <- dimnames(ff)[[2]][x]
    tType <- c(tType,t.new)
    tType <- tType[unique(names(tType))]
    ## 2. vType
    v <- unique(unlist(apply(ff,2,function(x)which(x>0,arr.ind=TRUE))))
    v.new <- rep("random",length(v))
    names(v.new) <- dimnames(ff)[[1]][v]
    vType <- c(vType,v.new)
    vType <- vType[unique(names(vType))]
    attr(form,"tType") <- tType
    attr(form,"vType") <- vType
    return(form)
  }

  ## ----------------------> START

  if(length(random[[2]])==0) return(random)

  tt <- Terms(random,specials=Spcls$Fun, keep.order = TRUE)
  which <- attr(tt,"specials")$str

  terms.fac <- attr(tt,"factors")
  terms.var <- dimnames(terms.fac)[[1]]
  terms.lab <- dimnames(terms.fac)[[2]]

  str.group <- character(0)

  if(all(is.null(which))) {
    form <- random
    str.group <- rep("",length(terms.lab))
    ##names(str.group) <- terms.lab
    attr(form,"str.group") <- str.group
    return(form)
  }
  ## preserve attributes
  tType <- attr(random,"tType")
  vType <- attr(random,"vType")

  str <- numeric(0)
  for(w in which)
    str <- c(str,seq(1,length(terms.lab))[terms.fac[w,] > 0])

  terms.use <- character(0)

  for(i in 1:length(terms.lab)) {
    if(any(str==i)) {
      ## split term
      ## work out which is str & get obj
      ## check if at & expand
      ## paste back together
      tts <- Terms(formula(paste("~",terms.lab[i])),
                   specials=Spcls$Fun, keep.order = TRUE)
      trm <- dimnames(attr(tts,"factors"))[[1]]
      ww <- attr(tts,"specials")$str
      if(length(ww) > 1)
        stop("Direct product of 'str' terms not allowed")
      wa <- attr(tts,"specials")$at
      outer <- NULL
      if(length(ww)+length(wa) != length(trm)) {
        outer <- paste(trm[-ww],collapse=":")
        ##stop("Direct product with 'str' not allowed")
      }
      ## If outer term is "at", generate multiple str instances
      atTrm <- character(0)
      if(length(wa)) {
        if(length(wa) > 1)
          stop("Multiple at' terms not allowed")
        A <- evalWithData((dimnames(attr(tts,"factors"))[[1]])[wa],data)
        ## A term for each level of at() ##
        ## eval str
        Y <- evalWithData((dimnames(attr(tts,"factors"))[[1]])[ww],data)
        tt.use <- dimnames(attr(Y$Obj,"factors"))[[2]]
        atLvls <- getLevels(A$Lvls)
        for(a in atLvls) {
          atTrm <- c(atTrm,paste("at(",A$Obj,", ","'",a,"'",")",sep=""))
        }
      }
      else {
        ## eval str
        Y <- evalWithData(dimnames(attr(tts,"factors"))[[1]][ww],data)
        tt.use <- dimnames(attr(Y$Obj,"factors"))[[2]]
      }
      ## paste back and expand at
      if(length(atTrm)) {
        tmp.group <- paste(atTrm,Y$FacNam,collapse=":")
        temp <- paste(atTrm,
                      paste("(",paste(tt.use,collapse="+"),")",sep=""),
                      sep=":")
        tt.use <- attr(Terms(formula(paste("~",paste(temp,collapse="+"))),
                             keep.order=TRUE),"term.labels")
        str.group <- c(str.group,rep(tmp.group,each=length(attr(Y$Obj,"term.labels"))))
      }
      else if(length(outer)) {
        tmp.group <- paste(outer,Y$FacNam,sep=":")
        temp <- paste(outer,
                      paste("(",paste(tt.use,collapse="+"),")",sep=""),
                      sep=":")
        tt.use <- attr(Terms(formula(paste("~",paste(temp,collapse="+"))),
                             keep.order=TRUE),"term.labels")
        str.group <- c(str.group,rep(tmp.group,each=length(attr(Y$Obj,"term.labels"))))
      }
      else {
        tt.use <- paste(tt.use,collapse="+")
        str.group <- c(str.group,rep(Y$FacNam,each=length(attr(Y$Obj,"term.labels"))))
      }
      terms.use <- c(terms.use,tt.use)
    }
    else {
      terms.use <- c(terms.use,terms.lab[i])
      str.group <- c(str.group,"")
    }
  }
  form <- formula(paste("~",paste(terms.use,collapse="+")))
  ## set/fix attributes
  attr(form,"str.group") <- str.group
  attr(form,"tType") <- tType
  attr(form,"vType") <- vType
  form <- fix.types(form)
  return(form)
}
checkPSD <- function(vars)
{
  ## Add attributes "nsing","nneg" and "nzp" to PSD/NSD G matrices
  ## Adjust/set the "rowNames" attribute

  if(length(vars) == 0)
    return(invisible())

  ginverse <- vector(mode="list")
  for(i in 1:length(vars)) {
    if(vars[[i]]$Fun == "vm") {
      ginverse <- c(ginverse, list(attributes(vars[[i]]$Call)))
    } else if(vars[[i]]$Fun == "str") {
      ginverse <- c(ginverse,
        lapply(vars[[i]]$Call, function(y){
        if(y$Fun == "vm") {
          attributes(y$Call)
        } else {
          NULL
        }
        })
      )
    }
  }
  if(length(ginverse) > 0) {
    ginverse <- ginverse[sapply(ginverse,function(x)!is.null(x))]  
  }
  if(length(ginverse) == 0)
    return(invisible())

  ## Convert Matrix objects
  ginverse <- ginverse[sapply(ginverse,function(x){
    is.element(casefold(x$singG),c("psd","nsd")) && !x$inverse})]
  if(length(ginverse) == 0)
    return(invisible())

  ## validated by vm()
  ## save rowNames, convert Matrix objects & check singG
  ginv.obj <- as.character(sapply(ginverse,function(x)x$Source))
  ginv.typ <- unlist(lapply(ginverse,function(x)casefold(x$singG)))
  asreml4Env <- where.env(ginv.obj[1])
  obj <- mget(ginv.obj, envir=asreml4Env)

  for(i in seq(1,length(obj))) {
    if(inherits(obj[[i]], "Matrix")) {
      if(is.null(rn <- rownames(obj[[i]]))) {
        stop("'dimnames' not found in vm() source.\n")
      }
      if(inherits(obj[[i]],"TsparseMatrix")) {
        obj[[i]] <- cbind(obj[[i]]@i+1, obj[[i]]@j+1, obj[[i]]@x)
        obj[[i]] <- obj[[i]][base::order(obj[[i]][,1],obj[[i]][,2]),]
      }
      else if(inherits(obj[[i]],"dsparseMatrix")) {
        obj[[i]] <- as(obj[[i]], "dgTMatrix")
        obj[[i]] <- cbind(obj[[i]]@i+1, obj[[i]]@j+1, obj[[i]]@x)
        obj[[i]] <- obj[[i]][(obj[[i]][,1] >= obj[[i]][,2]),] #lower tri
        obj[[i]] <- obj[[i]][base::order(obj[[i]][,1],obj[[i]][,2]),]
      }
      else if(inherits(obj[[i]],"ddenseMatrix")) {
        if(inherits(obj[[i]],"dgeMatrix")) {
          obj[[i]] <- as.matrix(obj[[i]])
        }
        else if(inherits(obj[[i]],"dsyMatrix") || inherits(obj[[i]],"dspMatrix")) {
          if(obj[[i]]@uplo == "U")
            obj[[i]] <- as.vector(obj[[i]])[!lower.tri(obj[[i]],diag=FALSE)]
          else
            obj[[i]] <- as.vector(t(obj[[i]]))[!lower.tri(obj[[i]],diag=FALSE)]
        }
        else {
          stop("Objects from 'ddenseMatrix' must be ",
               "'dgeMatrix', 'dspMatrix' or 'dsyMatrix'")
        }
      }
      else {
        stop("Objects from the Matrix class must be ",
             "'TsparseMatrix', 'dsparseMatrix','dgeMatrix', 'dspMatrix' or 'dsyMatrix'")
      }
      storage.mode(obj[[i]]) <- "double"
    }
    else if(is.data.frame(obj[[i]])) {
      rn <- attr(obj[[i]], "rowNames")
      for(col in 1:3) storage.mode(obj[[i]][, col]) <- "double"
    }
    else {
      storage.mode(obj[[i]]) <- "double"
      if(is.matrix(obj[[i]])) {
        if(ncol(obj[[i]]) == 3) {
          rn <- attr(obj[[i]], "rowNames")
        }
        else {
          rn <- dimnames(obj[[i]])[[1]]
        }
      }
      else {
        rn <- attr(obj[[i]], "rowNames")
      }
      if(is.null(rn)) {
        stop("'rowNames' or 'dimnames' not found in vm() source.")
      }
    }
    nrow <- .Call("smisg",obj[i], ginv.typ[i], PACKAGE="asreml")
    extra <- nrow-length(rn)
    if(extra > 0)
      rn <- c(rn,paste(ginv.obj[i],seq(1,extra),sep="_"))
    attr(asreml4Env[[ginv.obj[i]]],"rowNames") <- rn
  }
  invisible()
}
mbfEnv <- function (mbfr, data) 
{
  ## make asreml "compatible" mbf dataframes
  ## ultimately contents stored as a vector in x, addressed by kzbkey
  ## this set up in compiled code
  ##
  ## keep in a new environment ".mbfEnv"

  nn <- names(mbfr)
  mbfAttr <- vector(mode = "list", length = length(nn))
  mbFrames <- vector(mode = "list", length = length(nn))

  for (i in seq(along = nn)) {
    cov.env <- where.env(mbfr[[i]]$cov)
    mdf <- as.data.table(eval(as.name(mbfr[[i]]$cov), envir = cov.env))
    minus <- match(mbfr[[i]]$key[2], names(mdf))
    colNames <- names(mdf)[-minus]
    # data key first so it gets included in the model frame
    colNames <- c(mbfr[[i]]$key[1], colNames)
    # match key columns
    k1 <- mbfr[[i]]$key[1]
    k2 <- mbfr[[i]]$key[2]

    ky1 <- unique(as.character(data[[k1]][!is.na(data[[k1]])]))
    idx <- match(ky1, as.character(mdf[[k2]]))
    # in data but not in mbf
    if (any(which <- is.na(idx))) {
      LL <- vector(mode = "list", length = ncol(mdf))
      names(LL) <- names(mdf)
      LL[[k2]] <- ky1[which]
      for (j in seq(along = LL)[-match(k2, names(LL))]) {
        LL[[j]] <- rep(0.0, length(which[which]))
      }
      mdf <- rbindlist(list(mdf, LL))
    }
    if (is.factor(data[[k1]])) {
      what <- match(as.character(mdf[[k2]]), levels(data[[k1]]))
      mdf[, `:=`((k2), what)]
    } else if (is.numeric(data[[k1]])) {
      what <- match(as.character(mdf[[k2]]), as.character(data[[k1]]))
      mdf[, `:=`((k2), data[[k1]][what])]
    } else {
      mdf[, `:=`((k2), as.numeric(factor(data[[k1]])))]
    }
    setkeyv(mdf, k2)
    mbfAttr[[i]]$colNames <- colNames
    mbfAttr[[i]]$key <- mbfr[[i]]$key
    mbfAttr[[i]]$ncz <- length(colNames) - 1
    mbfAttr[[i]]$nux <- nrow(mdf)
    kk <- seq(1, ncol(mdf))
    kk[seq(1, minus)] <- kk[seq(1, minus)] - 1
    kk[1] <- minus
    setcolorder(mdf, kk)
    mbFrames[[i]] <- as.matrix(mdf)
    storage.mode(mbFrames[[i]]) <- "double"
  }
  names(mbFrames) <- nn
  names(mbfAttr) <- nn
  .mbfEnv <- new.env()
  assign("mbFrames", mbFrames, envir = .mbfEnv)
  assign("mbfAttr", mbfAttr, envir = .mbfEnv)
  return(.mbfEnv)
}

mbfEnv2 <- function(mbfr,data)
{
  ## make asreml "compatible" mbf dataframes
  ## ultimately contents stored as a vector in x, addressed by kzbkey
  ## this set up in compiled code
  ##
  ## keep in a new environment ".mbfEnv"

  nn <- names(mbfr)
  mbfAttr <- vector(mode="list",length=length(nn))
  mbFrames <- vector(mode="list",length=length(nn))

  for(i in seq(along=nn)) {
    cov.env <- where.env(mbfr[[i]]$cov)
    mdf <- as.data.table(eval(as.name(mbfr[[i]]$cov), envir=cov.env))
    minus <- match(mbfr[[i]]$key[2],names(mdf))
    colNames <- names(mdf)[-minus]
    # data key first so it gets included in the model frame
    colNames <- c(mbfr[[i]]$key[1],colNames)
    # match key columns
    k1 <- mbfr[[i]]$key[1]
    k2 <- mbfr[[i]]$key[2]

    ky1 <- unique(as.character(data[[k1]][!is.na(data[[k1]])]))
    idx <- match(ky1, as.character(mdf[[k2]]))
    # in data but not in mbf
    if(any(which <- is.na(idx))) {
      warning("There are levels in the data not referenced in the mbf table.")
      LL <- vector(mode="list",length=ncol(mdf))
      names(LL) <- names(mdf)
      LL[[k2]] <- ky1[which]
      for (j in seq(along = LL)[-match(k2, names(LL))]) {
        LL[[j]] <- rep(0.0, length(which[which]))
      } 
      mdf <- rbindlist(list(mdf, LL))
    }
    # Replace mdf[,1] with (matching) numeric factor level
    # subset mdf to data size
    what <- match(as.character(mdf[[k2]]),unique(as.character(data[[k1]])))
    if(any(is.na(what))) {
       warning("There are levels in the mbf table not referenced in the data.")
     }
    mdf <- subset(mdf, !is.na(what))
    if(is.factor(data[[k1]])) {
      what <- match(as.character(mdf[[k2]]),levels(data[[k1]]))
      mdf[, (k2):= what] #as.numeric(data[[k1]][what])]
    }
    else if(is.numeric(data[[k1]])) {
      what <- match(as.character(mdf[[k2]]),as.character(data[[k1]]))
      mdf[, (k2):= data[[k1]][what]]
    }
    else
      mdf[, (k2):= as.numeric(factor(data[[k1]]))]

    # Sort into ascending key order
    setkeyv(mdf, k2)

    mbfAttr[[i]]$colNames <- colNames
    mbfAttr[[i]]$key <- mbfr[[i]]$key
    mbfAttr[[i]]$ncz <- length(colNames)-1
    mbfAttr[[i]]$nux <- nrow(mdf)

    # put key field first
    kk <- seq(1,ncol(mdf))
    kk[seq(1,minus)] <- kk[seq(1,minus)]-1
    kk[1] <- minus
    setcolorder(mdf,kk)
    mbFrames[[i]] <- as.matrix(mdf)
    storage.mode(mbFrames[[i]]) <- "double"
  }
  names(mbFrames) <- nn
  names(mbfAttr) <- nn

  .mbfEnv <- new.env()
  assign("mbFrames", mbFrames, envir = .mbfEnv)
  assign("mbfAttr", mbfAttr, envir = .mbfEnv)

  return(.mbfEnv)
}

## 5.9.8 Finding and setting variables
## -----------------------------------
##
## It will be usual that all the R objects needed in our C computations
## are passed as arguments to `.Call' or `.External', but it is possible
## to find the values of R objects from within the C given their names.
## The following code is the equivalent of `get(name, envir = rho)'.
##
##      SEXP getvar(SEXP name, SEXP rho)
##      {
##        SEXP ans;
##
##        if(!isString(name) || length(name) != 1)
##          error("name is not a single string");
##        if(!isEnvironment(rho))
##          error("rho should be an environment");
##        ans = findVar(install(CHAR(STRING_ELT(name, 0))), rho);
##        Rprintf("first value is %f\n", REAL(ans)[0]);
##        return(R_NilValue);
##      }
##
##    The main work is done by `findVar', but to use it we need to install
## `name' as a name in the symbol table.  As we wanted the value for
## internal use, we return `NULL'.
##
##    Similar functions with syntax
##
##      void defineVar(SEXP symbol, SEXP value, SEXP rho)
##      void setVar(SEXP symbol, SEXP value, SEXP rho)
##
## can be used to assign values to R variables.  `defineVar' creates a new
## binding or changes the value of an existing binding in the specified
## environment frame; it is the analogue of `assign(symbol, value, envir =
## rho, inherits = FALSE)', but unlike `assign', `defineVar' does not make
## a copy of the object `value'.(1)  `setVar' searches for an existing
## binding for `symbol' in `rho' or its enclosing environments.  If a
## binding is found, its value is changed to `value'.  Otherwise, a new
## binding with the specified value is created in the global environment.
## This corresponds to `assign(symbol, value, envir = rho, inherits =
## TRUE)'.
##
##    ---------- Footnotes ----------
##
##    (1) You can assign a _copy_ of the object in the environment frame
## `rho' using `defineVar(symbol, duplicate(value), rho)').
formulaTerms <- function (form, sep = "+")
{
    if (inherits(form, "formula") || mode(form) == "call" &&
        form[[1]] == as.name("~"))
        return(formulaTerms(form[[length(form)]], sep = sep))
    if (mode(form) == "call" && form[[1]] == as.name(sep))
        return(do.call("c", lapply(as.list(form[-1]), formulaTerms,
            sep = sep)))
    if (mode(form) == "(")
        return(formulaTerms(form[[2]], sep = sep))
    if (length(form) < 1)
        return(NULL)
    list(asRhsFormula(form))
}

asRhsFormula <- function (object)
{
    if ((mode(object) == "call") && (object[[1L]] == "~")) {
        object <- eval(object)
    }
    if (inherits(object, "formula")) {
        if (length(object) != 2L) {
            stop(gettextf("formula '%s' must be of the form '~expr'",
                my.dparse(as.vector(object))), domain = NA)
        }
        return(object)
    }
    do.call("~", list(switch(mode(object), name = , numeric = ,
        call = object, character = as.name(object), expression = object[[1L]],
        stop(gettextf("'%s' cannot be of mode '%s'", substitute(object),
            mode(object)), domain = NA))))
}

Terms <- function(form, specials=NULL, keep.order=FALSE)
{
  ## Strategy to retain factor order in interactions
  ## 1. Split form on "+"
  ## 2. terms() on each to expand any / or * operators
  ## 3. terms(form)
  ## 4. Replace attributes of terms(form)

  ## trap y~1 etc
  if(length(attr(terms(form),"term.labels"))==0)
    return(terms(form))

  ff <- formulaTerms(form)
  trm <- lapply(ff,function(x){attr(terms(x,keep.order=TRUE),"term.labels")})

  tt <- terms(form,specials=Spcls$Fun,keep.order=TRUE)

  fac <- attr(tt,"factors")
  trm <- unique(unlist(trm))
  dimnames(fac)[[2]] <- trm

  if(!keep.order) {
    odr <- attr(tt,"order")
    idx <- base::order(odr)
    fac <- fac[,idx,drop=FALSE]
    attr(tt,"order") <- odr[idx]
    trm <- trm[idx]
  }
  attr(tt,"factors") <- fac
  attr(tt,"term.labels") <- trm
  return(tt)
}
formOrder <- function(random,sparse,data,ran.order)
{
  Form <- function(r,s,keep.order=TRUE) {
    if(length(r[[2]]) == 0) {
      if(length(s[[2]]) == 0)
        out <- ~NULL
      else
        out <- formula(paste("~",paste(attr(Terms(s,keep.order=keep.order),"term.labels"),
                                       collapse="+")))
    }
    else {
      if(length(s[[2]]) == 0)
        out <- formula(paste("~",paste(attr(Terms(r,keep.order=keep.order),"term.labels"),
                                       collapse="+")))
      else {
        out <- formula(paste("~",paste(c(attr(Terms(r,keep.order=keep.order),"term.labels"),
                                                attr(Terms(s,keep.order=keep.order),"term.labels")),
                                       collapse="+")))
      }
    }
    if(length(out[[2]]) > 0) {
      tto <- Terms(out,keep.order=keep.order)
      tts <- Terms(s,keep.order=keep.order)
      ttype <- ifelse(is.element(attr(tto,"term.labels"),
                                 attr(tts,"term.labels")),
                      "sparse","random")
      vtype <- ifelse(is.element(dimnames(attr(tto,"factors"))[[1]],
                                 dimnames(attr(tts,"factors"))[[1]]),
                     "sparse","random")
      names(ttype) <- attr(tto,"term.labels")
      names(vtype) <- dimnames(attr(tto,"factors"))[[1]]
      attr(out,"tType") <- ttype
      attr(out,"vType") <- vtype
      if(!is.null(x <- attr(r,"str.group"))) {
        x <- x[base::order(match(names(x),attr(tto,"term.labels")))]
        attr(out,"str.group") <- x
      }
    }
    return(out)
  }
  rs.form <- Form(random, sparse)

  if(length(rs.form[[2]]) == 0)
    return(random)

  keep.order <- switch(ran.order,
                       user = TRUE,
                       R = FALSE,
                       noeff = TRUE, ## exit here and order in asreml.inter
                       stop("ran.order must be one of 'user','R','noeff'"))
  ## user (or noeff) order

  if(keep.order) return(rs.form)

  ## R default
  if(ran.order == "R")
    return(Form(rs.form, ~NULL, keep.order=FALSE))
}
modelTerms <- function(fixed=~NULL, mixed=~NULL, random=~NULL, 
                      residual=~NULL, Csparse=~NULL, dense=~NULL, data)
{
  ##
  ##                           model
  ##                           /  \
  ##             fixed --------    -------- mixed --------- rnd ------- res
  ##             /  \                        / \            / \         / \
  ##        Terms() vars               Terms() vars
  ##                /  \                       /  \
  ##             var1 var2 ...               var1 var2 ...
  ##              |    |                       |    |
  ##           eval() eval()                eval() eval()
  ##
  ##
  ## Fixed terms: model == 'id' && param = Inf ??

  ## Set Rcov flag 'globally' as an attribute of data
  ##     needed to get power models correct

  ## Fixed, Mixed, Random,Residual
  setattr(data, "Rcov", FALSE)
  fxd <- list()

  ## reset keep,order if and() used
  ko <- ifelse(!is.null(attr(Terms(formula(fixed),specials=Spcls$Fun), "specials")$and), TRUE,
               asreml.options()$keep.order)
  fxd$Terms.obj <- trimSpc(Terms(formula(fixed),specials=Spcls$Fun,
                                 keep.order=ko))
  fxd$Vars <- modelList(fxd$Terms.obj, data)

  keep.order <- ifelse(asreml.options()$random.order=="R",FALSE,TRUE)

  rnd <- list()
  setattr(data, "Rcov", FALSE)
  rnd$Terms.obj <- trimSpc(Terms(formula(random),specials=Spcls$Fun,
                                 keep.order=keep.order))
  ## Ginverse(s)
  checkPSD(modelList(rnd$Terms.obj, data))
  rnd$Vars <- modelList(rnd$Terms.obj, data)

  mxd <- list()
  setattr(data, "Rcov", FALSE)
  if(length(mixed[[2]])) {
    mxd$Terms.obj <- trimSpc(Terms(formula(mixed),specials=Spcls$Fun,
                                   keep.order=keep.order))
    mxd$Vars <- modelList(mxd$Terms.obj, data)
    attr(mxd$Terms.obj,"str.group") <- attr(mixed,"str.group")
    attr(mxd$Terms.obj,"tType") <- attr(mixed,"tType")
    attr(mxd$Terms.obj,"vType") <- attr(mixed,"vType")
  }

  res <- list()
  setattr(data, "Rcov", TRUE)
  if(length(residual[[2]])) {
    res$Terms.obj <- trimSpc(Terms(formula(residual),specials=Spcls$Fun,
                                   keep.order=TRUE))
    res$Vars <- modelList(res$Terms.obj, data)
  }

  Csp <- list()
  setattr(data, "Rcov", FALSE)
  Csp$Terms.obj <- trimSpc(Terms(formula(Csparse),specials=Spcls$Fun,
                                 keep.order=keep.order))
  Csp$Vars <- modelList(Csp$Terms.obj, data)

  den <- list()
  setattr(data, "Rcov", FALSE)
  den$Terms.obj <- trimSpc(Terms(formula(dense),specials=Spcls$Fun,
                                 keep.order=keep.order))
  den$Vars <- modelList(den$Terms.obj, data)

  ## unset Rcov flag
  setattr(data, "Rcov", NULL)

  model <- list(fixed=fxd, mixed=mxd, random=rnd, residual=res,
                Csparse=Csp, dense=den)

  model
}
specials.df <- function() {
  ##Fun, Code (inter), Type, ObjArgs, Struc3, FunGroup
  ## ObjArgs could be used in modelFrame to get just the "variables"
  ##         in a call to a special function.
  ## FunGroup used to group into classes for initial value routines.
  spcls <- data.frame(matrix(c(
    "con",1,0,1,0,"con",
    "C",-25,0,1,0,"C",
    "lin",1,0,1,0,"lin",
    "pow",1,0,1,0,"pow",
    "pol",-7,0,1,0,"pol",
    "leg",-13,0,1,0,"leg",
    "spl",-3,0,1,0,"spl",
    "dev",-5,0,1,0,"dev",
    "ped",-1,0,1,0,"ped",
    "ide",-2,0,1,0,"ide",
    "giv",-2,0,1,0,"giv",
    "vm",-2,1,1,-1,"vm",
    "ma",-6,0,1,0,"ma",
    "at",-15,0,1,0,"at",
    "dsum",-98,0,1,0,"dsum",
    "and",-12,0,-1,0,"and",
    "grp",-99,0,0,0,"grp",
    "mbf",-24,0,0,0,"mbf",
    "sbs",-27,0,0,0,"sbs",
    "gpf",-37,0,0,0,"gpf",
    "uni",-9,0,0,0,"uni",
    "id",0,1,1,0,"id",
    "idv",0,1,1,0,"idv",
    "idh",0,1,1,8,"diag",
    "ar1",0,1,1,1,"ar1",
    "ar1v",0,1,1,1,"corv",
    "ar1h",0,1,1,1,"corh",
    "ar2",0,1,1,1,"ar2",
    "ar2v",0,1,1,1,"corv",
    "ar2h",0,1,1,1,"corh",
    "ar3",0,1,1,1,"ar3",
    "ar3v",0,1,1,1,"corv",
    "ar3h",0,1,1,1,"corh",
    "sar",0,1,1,14,"sar",
    "sarv",0,1,1,14,"corv",
    "sarh",0,1,1,14,"corh",
    "sar2",0,1,1,14,"sar2",
    "sar2v",0,1,1,14,"corv",
    "sar2h",0,1,1,14,"corh",
    "ma1",0,1,1,2,"ma1",
    "ma1v",0,1,1,2,"corv",
    "ma1h",0,1,1,2,"corh",
    "ma2",0,1,1,2,"ma2",
    "ma2v",0,1,1,2,"corv",
    "ma2h",0,1,1,2,"corh",
    "arma",0,1,1,3,"arma",
    "armav",0,1,1,3,"corv",
    "armah",0,1,1,3,"corh",
    "cor",0,1,1,5,"cor",
    "corv",0,1,1,5,"corv",
    "corh",0,1,1,5,"corh",
    "corb",0,1,1,5,"corb",
    "corbv",0,1,1,5,"corbv",
    "corbh",0,1,1,5,"corbh",
    "corg",0,1,1,5,"corg",
    "corgv",0,1,1,5,"corgv",
    "corgh",0,1,1,5,"corgh",
    "diag",0,1,1,8,"diag",
    "us",0,1,1,9,"us",
    "sfa",-40,1,1,10,"fa",
    "chol",0,1,1,11,"us",
    "cholc",0,1,1,11,"us",
    "ante",0,1,1,12,"us",
    "exp",0,1,1,6,"exp",
    "expv",0,1,1,6,"corv",
    "exph",0,1,1,6,"corh",
    "iexp",0,2,2,6,"iexp",
    "iexpv",0,2,2,6,"corv",
    "iexph",0,2,2,6,"corh",
    "aexp",0,2,2,6,"aexp",
    "aexpv",0,2,2,6,"corv",
    "bexpv",0,2,2,6,"corv",
    "aexph",0,2,2,6,"corh",
    "gau",0,1,1,6,"gau",
    "gauv",0,1,1,6,"corv",
    "gauh",0,1,1,6,"corh",
    "lvr",0,1,1,6,"lvr",
    "lvrv",0,1,1,6,"corv",
    "lvrh",0,1,1,6,"corh",
    "igau",0,2,2,6,"igau",
    "igauv",0,2,2,6,"corv",
    "igauh",0,2,2,6,"corh",
    "agau",0,2,2,6,"agau",
    "agauv",0,2,2,6,"corv",
    "agauh",0,2,2,6,"corh",
    "ieuc",0,2,2,6,"ieuc",
    "ieucv",0,2,2,6,"corv",
    "ieuch",0,2,2,6,"corh",
    "ilv",0,2,2,6,"ilv",
    "ilvv",0,2,2,6,"corv",
    "ilvh",0,2,2,6,"corh",
    "sph",0,2,2,6,"sph",
    "sphv",0,2,2,6,"corv",
    "sphh",0,2,2,6,"corh",
    "cir",0,2,2,6,"cir",
    "cirv",0,2,2,6,"corv",
    "cirh",0,2,2,6,"corh",
    "mtrn",0,2,2,6,"mtrn",
    "mtrnv",0,2,2,6,"mtrnv",
    "mtrnh",0,2,2,6,"mtrnh",
    "mthr",0,1,1,9,"mthr",
    "facv",-40,1,1,13,"fa",
    "fa",-40,1,1,15,"xfa",
    "rr",-40,1,1,15,"xfa",
    "str",-101,0,-1,0,"str",
    "own",0,1,1,1,"own"),byrow=TRUE,ncol=6),
                      stringsAsFactors=FALSE)
  names(spcls) <- c("Fun","Code","Type","ObjArgs","Struc3","FunGroup")
  row.names(spcls) <- spcls$Fun
  spcls$Struc3 <- as.numeric(spcls$Struc3)
  spcls$Code <- as.numeric(spcls$Code)
  spcls$Type <- as.numeric(spcls$Type)
  spcls$ObjArgs <- as.numeric(spcls$ObjArgs)

  invisible(spcls)
}
## unique(spcls$FunGroup)
##  [1] "con"   "C"     "lin"   "pow"   "pol"   "leg"   "spl"   "dev"   "ped"
## [10] "ide"   "giv"   "vm"    "ma"    "at"    "dsum"  "and"   "grp"   "mbf"
## [19] "sbs"   "gpf"   "uni"   "id"    "idv"   "diag"  "ar1"   "corv"  "corh"
## [28] "ar2"   "ar3"   "sar"   "sar2"  "ma1"   "ma2"   "arma"  "cor"   "corb"
## [37] "corgv" "corgh" "corg"  "us"    "fa"    "exp"   "iexp"  "aexp"  "gau"
## [46] "igau"  "agau"  "ieuc"  "sph"   "cir"   "mtrn"  "mtrnv" "mtrnh" "mthr"
## [55] "str"   "own" "xfa"
spc <- function(fun,fam,ncor,nvar,k,obj,init,data)
{
  out <- vector(mode="list",length=15)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma",
                  "Struc","Inter","Coords","Argv","isVariance","FacNam","Bounds")
  uspd <- asreml.options()$uspd
  ## "model" functions
  if(fam == "mdl") {
    obj <- as.character(obj)
    out[[1]] <- fun
    out[[2]] <- spCall(sys.call(-1))
    out[[3]] <- obj
    out[[14]] <- out[[2]]
    if(is.factor(data[[obj]])) {
      lvls <- levels(data[[obj]])
      out[[4]] <- lvls #as.integer(length(lvls))
    }
    else
      out[[4]] <- obj #1
    out[[5]] <- as.numeric(NA)
    out[[6]] <- ""
    out[[7]] <- ""
    out[[8]] <- as.integer(2)
    out[[9]] <- as.integer(c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))
    ## Trap 'trait' - not in data as per V3
    if(obj == "trait")
      out[[10]] <- c(-8,0,0,0)
    else
      out[[10]] <- as.integer(c(length(out[[4]]),0,match(obj,names(data))-1,-1))
    out[[11]] <- list()
    out[[12]] <- obj
    out[[13]] <- NA
    out[[15]] <- matrix(nrow=1,ncol=1)
    oldClass(out) <- "asr.special"
    return(out)
  }
  ## variance/correlation functions
  nest <- inherits(obj,"asr.special")
  if(nest) {
    out[[1]] <- obj[[1]] #fun
    out[[2]] <- spCall(sys.call(-1))
    lab <- obj[[14]]
    out[[3]] <- obj[[3]]
    out[[14]] <- obj[[14]]
    out[[4]] <- obj[[4]]
    lvls <- obj[[4]]
    out[[10]] <- as.integer(obj[[10]])
    out[[11]] <- obj[[11]]
    out[[12]] <- obj[[12]]
    out[[15]] <- obj[[15]]
  }
  else {
    if(is.numeric(obj)) {
      lvls <- as.character(seq(1,obj))
      lab <- paste(fun,"(",obj,")",sep="")
      cal <-  spCall(sys.call(-1))
      obj <- as.character(obj)
    }
    else {
      obj <- as.character(obj)
      cal <- spCall(sys.call(-1)) #obj
      if(is.factor(data[[obj]]))
        lvls <- levels(data[[obj]])
      else if(fun == "id" || fun == "idv")
        lvls <- obj
      else
        stop(paste(obj,"must be a factor"))
      lab <- obj
    }

    ## Fun
    out[[1]] <- fun
    ## Call
    out[[2]] <- cal
    ## Obj
    out[[3]] <- obj
    out[[14]] <- out[[3]]
    ## Lvls
    out[[4]] <- lvls #as.integer(length(lvls))
  }
  n <- length(out[[4]])
  what.var <- eval(parse(text=as.character(nvar)))
  if(is.vector(what.var))
    Nv <- length(what.var)
  else if(is.matrix(what.var))
    Nv <- n*(n+1)/2
  else if(is.null(what.var))
    Nv <- 0
  else
    stop("Unrecognised mode for nvar")
  what.cor <- eval(parse(text=as.character(ncor)))
  if(is.vector(what.cor))
    Nc <- length(what.cor)
  else if(is.matrix(what.cor))
    Nc <- n*(n-1)/2
  else if(is.null(what.cor))
    Nc <- 0
  else
    stop("Unrecognised mode for ncor")

  IniFlag <- ifelse(all(is.na(init)),FALSE,TRUE)
  if(IniFlag) {
    if(is.character(init)) init <- eval(parse(text=init))
    if(length(init) != Nc+Nv)
      stop(paste(fun,"- Wrong number of initial values\n"))
  }
  ## Correlation models
  if(fam == "cor") {
    if(!IniFlag) {
      init <- c(rep(0.1,Nc),rep(0.1,Nv))
      if(length(init)==0)
        init <- NA
    }

    out[[5]] <- as.numeric(init)
    con <- matchCon(init)
    if(length(con)==0)
      out[[6]] <- c(rep("U",Nc),rep("P",Nv))
    else
      out[[6]] <- con
    attr(out[[5]], "set") <- IniFlag

    if(is.matrix(what.cor)) {
      x <- (row(what.cor) < col(what.cor))
      corLab <- c(paste(paste("!",lab,"!",lvls[col(x)[x]],sep=""),
                        ":",
                        paste("!",lab,"!",lvls[row(x)[x]],sep=""),
                        ".cor",sep=""))
    }
    else if(Nc > 1)
      corLab <- paste("!",lab,paste("!cor",seq(1,Nc),sep=""),sep="")
    else if(Nc == 1)
      corLab <- paste("!",lab,"!cor",sep="")
    else
      corLab <- character(0)

    if(Nv > 1)
      varLab <- paste("!",lab,"_",lvls,sep="")
    else if(Nv == 1 && Nc > 0)
      varLab <- paste("!",lab,"!var",sep="")
    else
      varLab <- character(0)

    out[[7]] <- c(corLab,varLab)
    if(length(out[[7]]) == 0) out[[7]] <- paste("!",lab,sep="")
    out[[8]] <- as.integer(c(rep(3,Nc),rep(2,Nv)))
    out[[13]] <- ifelse(Nv==0,FALSE,TRUE)
    ## catch id
    if(Nc+Nv == 0) {
      out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
      dimnames(out[[15]]) <- list("id",c("LB","UB"))
    }
    else {
      out[[15]] <- matrix(c(rep(-0.999, Nc),rep(0.0001, Nv),
                            rep(0.999, Nc),rep(1e37, Nv)),ncol=2,byrow=FALSE)
      dimnames(out[[15]]) <- list(out[[7]],c("LB","UB"))
    }
  }
  ## Variance models
  else if(fam == "var") {
    if(is.matrix(what.var)) {
      if(!IniFlag)
        init <- what.var[t(lower.tri(what.var,diag=TRUE))]
      out[[5]] <- as.numeric(init)
      con <- matchCon(init)
      if(length(con)==0)
        out[[6]] <- rep("U",Nv)
      else
        out[[6]] <- con
      ## EM updates for us structures
      if(fun=="us" && uspd)
        out[[6]] <- rep("P",Nv)
      attr(out[[5]], "set") <- IniFlag
      labels <- switch(fun,
                       us = {x <- t(lower.tri(matrix(nrow=n,ncol=n),diag=TRUE))
                             paste("!",lab,"_",
                                   paste(lvls[col(x)[x]],lvls[row(x)[x]],sep=":"),sep="")},
                       chol = {x <- t(lower.tri(what.var,diag=TRUE))
                               y <- col(x)-row(x) > k
                               temp <- paste("!",lab,"_",
                                             paste(lvls[col(x)[x]],lvls[row(x)[x]],sep=":"),sep="")
                               temp[y[!lower.tri(y)]] <- paste(temp[y[!lower.tri(y)]],"<NotEstimated>",sep="")
                               temp},
                       cholc = {x <- t(lower.tri(what.var,diag=TRUE))
                                y <- (col(x)-row(x) >= k) & row(x) > k
                                temp <- paste("!",lab,"_",
                                              paste(lvls[col(x)[x]],lvls[row(x)[x]],sep=":"),sep="")
                                temp[y[!lower.tri(y)]] <- paste(temp[y[!lower.tri(y)]],"<NotEstimated>",sep="")
                                temp},
                       ante = {x <- t(lower.tri(what.var,diag=TRUE))
                               y <- col(x)-row(x) > k
                               temp <- paste("!",lab,"_",
                                             paste(lvls[col(x)[x]],lvls[row(x)[x]],sep=":"),sep="")
                               temp[y[!lower.tri(y)]] <- paste(temp[y[!lower.tri(y)]],"<NotEstimated>",sep="")
                               temp}
                       )
      out[[7]] <- labels
      tgam <- matrix(4,nrow=n,ncol=n)-diag(2,nrow=n)
      out[[8]] <- tgam[t(lower.tri(tgam, diag=TRUE))]
    } # end if matrix
    else {
      if(!IniFlag)
        init <- what.var
      out[[5]] <- as.numeric(init)
      con <- matchCon(init)
      if(length(con)==0)
        out[[6]] <- {if(Nv == 1) "P" else rep("P",Nv)} # "U"
      else
        out[[6]] <- con
      attr(out[[5]], "set") <- IniFlag
      if(Nv > 1)
        out[[7]] <- paste("!",lab,"_",lvls,sep="")
      else
        out[[7]] <- character()
      out[[8]] <- as.integer(rep(2,Nv))
    }
    out[[13]] <- TRUE
    out[[15]] <- matrix(nrow=Nv,ncol=2)
    out[[15]][out[[6]] == "U",1] <- -1e37
    out[[15]][out[[6]] == "U",2] <- 1e37
    out[[15]][out[[6]] == "P",1] <- 0.0001
    out[[15]][out[[6]] == "P",2] <- 1e37
    dimnames(out[[15]]) <- list(out[[7]],c("LB","UB"))
  }
  ## trap special case idv (fam=cor)
  if(fun == "idv")
    out[[9]] <- as.integer(c(n,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0))
  else
    out[[9]] <- as.integer(c(n,sum(!is.na(out[[5]])),struc3(fun),0,0,as.numeric(fam=="cor"),
                             0,0,0,0,0,0,as.numeric(fam=="cor" && Nv==1),0,0,0))
  if(!nest) {
    out[[10]] <- as.integer(c(n,0,match(obj,names(data))-1,0))
    out[[11]] <- list()
    out[[12]] <- obj
  }
  if(length(out[[6]])==0) out[[6]] <- ""
  if(length(out[[8]])==0) out[[8]] <- as.integer(NA)
  oldClass(out) <- "asr.special"
  out
}
struc3 <- function(x) {
  return(Spcls$Struc3[match(x,Spcls$Fun)])
}
## special functions

## June 2014: Lvls changed to be a vector, list, expression or function
## Feb 2015: drop prefix, assign functions to an environment
## March 2015: revert to original form in asreml environment.

#' Model term constructor functions.
#'
#' This class of special functions constructs model terms with specific
#' properties.
#'
#' @param obj An object in the data frame.
#' \describe{
#' \item{\code{mbf}}{A component name from the \code{asreml()} \code{mbf}
#' list argument.}
#' \item{\code{grp}}{A component name from the \code{asreml()} \code{group}
#' list argument.}
#' }
#'
#' @param t
#' \describe{
#'
#' \item{pol:}{The maximum degree of a set of orthogonal polynomials
#' formed from \code{obj}. If negative, the intercept polynomial is
#' omitted.}
#'
#' \item{leg:}{The maximum degree of a set of Legendre polynomials
#' formed from \code{obj}. If negative, the intercept polynomial is
#' omitted.}  }
#'
#' @param init
#'
#' Optional initial value for the default identity variance model
#' (\code{idv}) when used in the \code{random} formula.
#'
#' @aliases con lin pow pol leg spl dev ma at and mbf grp dsum C
#' @name modelFunctions
NULL
#' @describeIn modelFunctions Sum to zero constraints.
#'
#' @usage con(obj)
#'
asr_con <- function(obj, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to con() must be a factor\n")

  out <- spc("con","mdl",0,0,NA,substitute(obj),NA,data)
  ## Levels
  ## From the SA User Guide: The formal effect of the con() function is to
  ## form a model term with the highest level formally equal to minus the sum
  ## of the preceding terms.
  out[[4]] <- out[[4]][-length(out[[4]])]
  out[[10]] <- as.integer(c(length(out[[4]]),0,match(out$Obj,names(data))-1,-1))
  out
}
#' @describeIn modelFunctions Create a variate from \code{obj}.
#'
#' @usage lin(obj)
#'
asr_lin <- function(obj, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to lin() must be a simple object (factor or variate)\n")

  out <- spc("lin","mdl",0,0,NA,substitute(obj),NA,data)
  ## Levels
  out[[4]] <- out[[2]] #as.integer(1)
  ## Inter
  if(out$Inter[1] > 0)
    out[[10]] <- as.integer(c(1,0,match(out$Obj,names(data))-1,0))
  out
}
#' @param p The exponent in a power function term (\code{pow}).
#' @param offset Constant added to \code{obj}; default 0.
#'
#' @describeIn modelFunctions Creates the model term
#' \code{(obj+offset)}\eqn{^p}.
#'
#' @usage pow(obj, p=1, offset=0)
#'
asr_pow <- function(obj, p=1, offset=0, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to pow() must be a simple object\n")

  out <- spc("pow","mdl",0,0,NA,substitute(obj),NA,data)
  ## Levels
  out[[4]] <- out[[2]] #as.integer(1)
  ## Inter
  out[[10]] <- as.integer(c(-30,0,match(out$Obj,names(data))-1,p*1000))
  attr(out$Inter,"faconst") <- offset
  out
}
#' @describeIn modelFunctions Orthogonal polynomials.
#'
#' @usage pol(obj, t=1, init=NA)
#'
asr_pol <- function(obj, t=1, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to pol() must be a simple object (variate or factor)\n")

  out <- vector(mode="list",length=15)

  ## Fun
  out[[1]] <- "pol"
  ## Call
  out[[2]] <- spCall(sys.call())
  ## Obj
  obj <- as.character(substitute(obj))
  out[[3]] <- obj
  out[[14]] <- out[[2]]

  knots <- asreml.options()$knots  ## just for call to spline.f

  ibv <- getIBV(data, obj)
  jbv <- getJBV(data, obj)
  inter <- c(-7,0,0,t)
  if(sum(abs(ibv)) > 0)
    ibv[3] <- 1

  splstp <- rep(0,10)
  splstp[c(3,5,7)] <- unlist(asreml.options()$spline.step)

  nux <- length(unique(data[[obj]]))
  ncz <- min(abs(t),nux)+1
  N <- min(splstp[7],nux)+ncz+ibv[4]+asreml.options()$nsppoints

  Z <- .Call("splinek", list(x=data[[obj]], inter=inter, ibv=ibv,
                             jbv=jbv, splstp=splstp, knots=knots,
                             nsppoints=asreml.options()$nsppoints,
                             splinescale=asreml.options()$spline.scale,
                             points=attr(data,"points.env")$points,
                             N=N, silent=1), PACKAGE="asreml")


  ## Flag how to generate levels sequence if necessary:
  ## if(t < 0) generate as seq(0,Lvls-1)
  if(t <= 0)
    out[[4]] <- paste("order",seq(1,Z$ncz),sep="")
  else
    out[[4]] <- paste("order",seq(0,Z$ncz-1),sep="")

  n <- length(out[[4]])

  ## Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <-""

  # Lab
  out[[7]] <- paste("!",out[[2]],sep="")

  # Tgamma

  out[[8]] <- as.integer(2)

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(length(out[[4]]),length(out[[5]]),0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  # Inter

  out[[10]] <- as.integer(c(-7,0,match(obj,names(data))-1,t))

  #Coords
  out[[11]] <- Z$knotpoints

  # Argv
  out[[12]] <- obj

  # isVariance
  out[[13]] <- FALSE

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("id",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @describeIn modelFunctions Legendre polynomials.
#'
#' @usage leg(obj,t=1,init=NA)
#'
asr_leg <- function(obj,t=1, data)
{
  ## Legendre polynomials
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to pol() must be a simple object (variate or factor)\n")

  out <- vector(mode="list",length=15)

  ## Fun
  out[[1]] <- "leg"
  ## Call
  out[[2]] <- spCall(sys.call())
  ## Obj
  obj <- as.character(substitute(obj))
  out[[3]] <- obj
  out[[14]] <- out[[2]]

  knots <- asreml.options()$knots  ## just for call to spline.f

  ibv <- getIBV(data, obj)
  jbv <- getJBV(data, obj)
  inter <- c(-13,0,0,t)
  if(sum(abs(ibv)) > 0)
    ibv[3] <- 1

  splstp <- rep(0,10)
  splstp[c(3,5,7)] <- unlist(asreml.options()$spline.step)

  nux <- length(unique(data[[obj]]))
  ncz <- min(abs(t),nux)+1
  N <- min(splstp[7],nux)+ncz+ibv[4]+asreml.options()$nsppoints

  Z <- .Call("splinek", list(x=data[[obj]], inter=inter, ibv=ibv,
                             jbv=jbv, splstp=splstp, knots=knots,
                             nsppoints=asreml.options()$nsppoints,
                             splinescale=asreml.options()$spline.scale,
                             points=attr(data,"points.env")$points,
                             N=N, silent=1), PACKAGE="asreml")


  ## Flag how to generate levels sequence if necessary:
  ## if(t < 0) generate as seq(0,Lvls-1)
  if(t <= 0)
    out[[4]] <- paste("order",seq(1,Z$ncz),sep="")
  else
    out[[4]] <- paste("order",seq(0,Z$ncz-1),sep="")

  n <- length(out[[4]])

  ## Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <-""

  # Lab
  out[[7]] <- paste("!",out[[2]],sep="")

  # Tgamma

  out[[8]] <- as.integer(2)

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(length(out[[4]]),length(out[[5]]),0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  # Inter

  out[[10]] <- as.integer(c(-13,0,match(obj,names(data))-1,t))

  #Coords
  out[[11]] <- Z$knotpoints

  # Argv
  out[[12]] <- obj

  # isVariance
  out[[13]] <- FALSE

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("id",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @param k
#'
#' The number of equally spaced knot points for a cubic smoothing
#' spline. If zero or omitted, \code{k} is set to
#' \code{asreml.options()$knots} (default 50).
#' @describeIn modelFunctions Cubic smoothing spline, random component.
#'
#' @usage spl(obj, k=0, init=NA)
#'
asr_spl <- function(obj, k=0, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to spl() must be a simple object (variate or factor)\n")

  out <- vector(mode="list",length=15)

  # Fun

  out[[1]] <- "spl"

  # Call

  out[[2]] <- spCall(sys.call())

  # Obj
  obj <- as.character(substitute(obj))
  out[[3]] <- obj
  out[[14]] <- out[[2]]

  nux <- length(unique(data[[obj]]))
  knots <- asreml.options()$knots #min(nux, asreml.options()$knots)  ## def is 50
  ## inter(4) takes priority

  kl <- 0
  kptr <- 0

  ## Argument takes precedence
  i4 <- k
  ## user supplied knot points
  ukp <- locKnots(data,obj)
  kptr <- ukp[1]
  kl <- ukp[2]
  if(kptr > 0) {
    if(k > 0)
      stop("Spline knot points already set (k > 0)") #knots <- max(k, kl)
    else
      i4 <- kl
  }
  ## predict/design points
  ibv <- getIBV(data, obj)
  jbv <- getJBV(data, obj)
  inter <- c(-3, kptr, 0, i4)
  if(sum(abs(ibv)) > 0)
    ibv[3] <- 1

  # Levels
  if(i4 > 0) {
    ncz <- i4 - 2
  }
  else {
    ncz <- min(knots, nux) - 2
  }
  if(ncz < 1)
    stop("Insufficient points for spline.")

  splstp <- rep(0,10)
  splstp[c(3,5,7)] <- unlist(asreml.options()$spline.step)

  N <- min(splstp[3],length(unique(data[[obj]]))) +
    ncz + asreml.options()$nsppoints + ibv[4]



  Z <- .Call("splinek",list(x=data[[obj]], inter=inter,ibv=ibv,
                            jbv=jbv, splstp=splstp, knots=knots,
                            nsppoints=asreml.options()$nsppoints,
                            splinescale=asreml.options()$spline.scale,
                            points=attr(data,"points.env")$points,
                            N=N, silent=1), PACKAGE="asreml")

  out[[4]] <- as.character(seq(1,Z$ncz))

  ## Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <-""

  # Lab
  out[[7]] <- ""

  # Tgamma

  out[[8]] <- NA

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(Z$ncz,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  # Inter

  out[[10]] <- as.integer(c(-3, kptr, match(obj,names(data))-1, i4))

  #Coords
  out[[11]] <- Z$knotpoints

  # Argv
  out[[12]] <- obj

  ## isVariance
  out[[13]] <- FALSE

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("id",c("LB","UB"))
  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam", "Bounds")

  oldClass(out) <- "asr.special"

  out
}
#' @describeIn modelFunctions Spline deviations; create a factor
#' from the variate \code{obj}.
#'
#' @usage dev(obj, init=NA)
#'
asr_dev <- function(obj, init=NA, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to dev() must be a simple variate\n")

  out <- vector(mode="list",length=15)

  # Fun

  out[[1]] <- "dev"

  # Call

  out[[2]] <- spCall(sys.call())

  # Obj
  obj <- as.character(substitute(obj))
  out[[3]] <- obj
  out[[14]] <- out[[2]]

  if(is.factor(data[[obj]]))
    stop(paste(obj,"is already a factor.\n"))

  knots <- asreml.options()$knots  ## def is 50

  inter <- c(-5,0,0,0)
  ## predict/design points
  ibv <- getIBV(data, obj)
  jbv <- getJBV(data, obj)
  if(sum(abs(ibv)) > 0)
    ibv[3] <- 1

  N <- length(unique(data[[obj]]))+ knots + max(asreml.options()$nsppoints,ibv[4])

  splstp <- rep(0,10)
  splstp[c(3,5,7)] <- unlist(asreml.options()$spline.step)
  params <- list(x=as.double(data[[obj]]), inter=as.integer(inter), ibv=as.integer(ibv),
                 jbv=as.integer(jbv), splstp=as.double(splstp), knots=as.integer(knots),
                 nsppoints=as.integer(asreml.options()$nsppoints),
                 splinescale=as.double(asreml.options()$spline.scale),
                 points=as.double(attr(data,"points.env")$points),
                 N=as.integer(N), silent=1)

  Z <- .Call("splinek",params, PACKAGE="asreml")

  out[[4]] <- as.character(Z$knotpoints)

  ## Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <-""

  # Lab
  out[[7]] <- ""

  # Tgamma

  out[[8]] <- as.integer(2)

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  # Inter

  out[[10]] <- as.integer(c(-5,0,match(obj,names(data))-1,0))

  #Coords
  out[[11]] <- Z$knotpoints

  # Argv
  out[[12]] <- obj

  ## isVariance
  out[[13]] <- FALSE

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("id",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @describeIn modelFunctions Construct a term with a moving-average
#' order 1 design matrix from \code{obj}.
#'
#' @usage ma(obj)
#'
asr_ma <- function(obj, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to ma() must be a factor\n")

  out <- spc("ma","mdl",0,0,NA,substitute(obj),NA,data)
  ## Inter
  out[[10]] <- as.integer(c(-6,0,match(out$Obj,names(data))-1,0))
  out
}
#' @param lvls Vector of levels of the conditioning factor
#' (\code{obj}) that define the conditioning covariates formed by
#' \code{at}. If numeric, \code{lvls} indexes the levels vector of
#' \code{obj}; that is, \code{levels(obj)[lvls]}.
#'
#' @describeIn modelFunctions Form a conditioning covariable from
#' \code{obj} for each level of \code{obj} specified in the
#' \code{lvls} argument.
#'
#' @usage at(obj,lvls)
#'
asr_at <- function(obj,lvls, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to at() must be a simple object (factor)\n")

  out <- vector(mode="list",length=15)
  # Fun
  out[[1]] <- "at"

  # Call
  out[[2]] <- spCall(sys.call())

  # Obj
  obj <- as.character(substitute(obj))
  out[[3]] <- obj


  dd <- data[[obj]]
  if(!is.factor(dd))
    stop(paste("Argument",obj,"to at() must be a factor\n"))

  # Levels
  if(missing(lvls))
    at.lev <- levels(dd)
  else {
#    if(mode(substitute(lvls)) == "name")
#      lvls <- eval(lvls)
    at.lev <- eval(lvls)
  }
#    at.lev <- eval(parse(text=lvls))
  if(is.numeric(at.lev))
    at.lev <- levels(dd)[at.lev]

  if(any(is.na(match(at.lev,levels(dd)))))
    stop(paste("Not all levels specified in at() match those in",obj,"\n"))

  out[[4]] <- at.lev #as.integer(length(at.lev))
  ##attr(out[[4]], "Levels") <- at.lev

  # Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <- ""

  # Lab
  out[[7]] <- ""

  # Tgamma

  out[[8]] <- as.integer(2)

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  ## Inter - for the 'at' factor
  out[[10]] <- as.integer(c(-15,0,match(obj,names(data))-1,0))

  #Coords
  out[[11]] <- list()

  # Argv
  out[[12]] <- obj

  # isVariance
  out[[13]] <- FALSE

  facnam <- NULL
  for(i in at.lev)
    facnam <- c(facnam, paste("at(",obj,", ", i,")",sep=""))
  out[[14]] <- facnam

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("id",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @param times Multiples (may be non-integer) of the design matrix
#' for \code{obj} are added to the preceeding design matrix.
#'
#' @describeIn modelFunctions Multiply the design matrix for
#' \code{obj} by \code{times} and add it to the preceeding design
#' matrix.
#'
#' @usage and(obj, times=1)
#'
asr_and <- function(obj, times=1, data)
{
  ## deal with 'times'
  wgt <- function(times) {
    inter34 <- vector(length=2)
    x <- -1
    rem <- 1
    while(rem != 0) {
      x <- x+1
      rem <- times * 10^x - trunc(times * 10^x)
      inter34 <- c(times*10^x,x)
    }
    inter34
  }

  ## and() may be called with: a simple term, a special function,
  ##       or an interaction between any of these.
  ##

  out <- vector(mode="list",length=14)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam")
  oldClass(out) <- "asr.special"
  ##
  sobj <- substitute(obj)
  if(mode(sobj)=="call") {
    obj <- my.dparse(sobj)
  }
  else
    obj <- as.character(substitute(obj))

  arg.vec <- formula.variables(formula(paste("~",obj)),data,prefix="asr_")
  ## Fun
  out[[1]] <- "and"

  ## Call
  ##out[[2]] <- paste("and(",paste(tt,collapse=":"),")",sep="")
  out[[2]] <- spCall(sys.call())

  ## Obj July 2014 now a list
  out[[3]] <- lapply(formula.specialCalls(formula(paste("~",obj)),data,prefix=""),function(x,data){
                       evalWithData(x, data)
                     }, data)

  out[[14]] <- out[[2]]

  ## Get component names from data
  ##drop.unused.levels <- attr(data,"Control")$drop.unused.levels
  ##data <- data[[obj]]

  ## Levels

                                        #out[[4]] <- asr.levels(data,drop.unused.levels)
  out[[4]] <- out[[2]]

  ## Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <- ""

  ## Lab
  out[[7]] <- ""

  ## Tgamma
  out[[8]] <- as.integer(2)

  ## Struc 3,6,8,13
  out[[9]] <- as.integer(c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  ## Inter

  out[[10]] <- as.integer(c(-12,0,wgt(times)))

  ## Coords
  out[[11]] <- list(faconst=NULL,nuxPoints=NULL,coords=NULL)

  ## Argv
  out[[12]] <- arg.vec

  ## isVariance
  out[[13]] <- NA
  class(out) <- "asr.special"
  out
}
#' @describeIn modelFunctions Create a model term from covariates not
#' stored in \code{data}.
#'
#' @usage mbf(obj)
#'
asr_mbf <- function(obj, data)
{
  obj <- as.character(substitute(obj))
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to mbf() must be a numeric or character vector\n")

  out <- vector(mode="list",length=15)

  # Fun

  out[[1]] <- "mbf"

  # Call

  out[[2]] <- spCall(sys.call()) #obj
  # Obj
  out[[3]] <- obj
  out[[14]] <- out[[2]]

  # Get component names from data

  what <- match(obj,names(attr(data,"mbf.env")$mbfAttr))
  which <- attr(data,"mbf.env")$mbfAttr[[obj]]$colNames
  key <- attr(data,"mbf.env")$mbfAttr[[obj]]$key[1]

  # Levels
  # data file key is first
  out[[4]] <- which[-1]

  # Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <- ""

  # Lab
  out[[7]] <- ""

  # Tgamma
  out[[8]] <- as.integer(2)

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(length(out[[4]]),length(out[[5]]),0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  # Inter

  out[[10]] <- as.integer(c(-24,what,match(key,names(data))-1,length(which)-1))

  #Coords
  out[[11]] <- list()

  # Argv
  out[[12]] <- which[1]

  # isVariance
  out[[13]] <- FALSE

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37), nrow=length(out[[5]]), ncol=2)
  dimnames(out[[15]]) <- list(out[[7]],c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @describeIn modelFunctions Create a model term from covariates held
#' in columns of \code{data}.
#'
#' @usage grp(obj)
#'
asr_grp <- function(obj,data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to grp() must be a numeric or character vector\n")

  out <- vector(mode="list",length=15)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")

  obj <- as.character(substitute(obj))
  ## Fun
  out$Fun <- "grp"
  ## Call
  out$Call <- spCall(sys.call()) ##obj
  ## Obj
  out$Obj <- obj
  out$FacNam <- out$Call

  ## Get component names from data
  what <- match(obj,names(attr(data,"GROUP")))
  if(is.na(what))
    stop(paste("Object",obj,"is not a component of the group argument"))
  which <- attr(data,"GROUP")[[obj]]

  ## Levels

  out$Lvls <- which #as.integer(length(which))

  ## Initial & Con
  out$Initial <- as.numeric(NA)
  out$Con <- ""

  ## Lab
  out$Lab <- ""

  ## Tgamma
  out$Tgamma <- as.integer(2)

  ## Struc 3,6,8,13
  out$Struc <- as.integer(c(length(out[[4]]),length(out[[5]]),0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  ## Inter

  out$Inter <- as.integer(c(length(which),0,match(which[1],names(data))-1,0))

  ## Coords
  out$Coords <- list()

  ## Argv
  out$Argv <- which

  ## isVariance
  out$isVariance <- FALSE

  ## Bounds
  out$Bounds <- matrix(nrow=1, ncol=2)
  dimnames(out[[15]]) <- list(NULL,c("LB","UB"))
  oldClass(out) <- "asr.special"
  out
}

#' Default identity variance models.
#'
#' Model functions for identlty variance models.
#'
#' The class of identity models includes the \emph{null} correlation
#' model \code{id}, and its homogeneous and heterogeneous variance
#' forms (\code{idv} and \code{idh}).
#'
#' @param obj
#'
#' A factor in \code{data}.
#'
#' @param init
#'
#' Optional vector of initial values with an optional \code{names}
#' attribute from the set \{\dQuote{P}, \dQuote{U}, \dQuote{F}\}
#' specifying the boundary constraint for each parameter as positive,
#' unconstrained or fixed, respectively.
#'
#' @aliases id idv idh
#' @name id
#' @usage id(obj)
#'
asr_id <- function(obj, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("id","cor","numeric(0)","numeric(0)",NA,obj,NA,data)
  out$Struc[6] <- 0
  out
}
#' @describeIn id Identity variance model.
#'
#' @usage idv(obj, init=NA)
#'
asr_idv <- function(obj, init=NA,  data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("idv","cor","numeric(0)",1,NA,obj,init, data)
  out
}
#' @describeIn id Heterogeneous identity (diagonal) variance
#' model.
#'
#' @usage idh(obj, init=NA)
#'
asr_idh <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("idh","cor","numeric(0)","rep(0.1,n)",NA,obj,init, data)
  out
}
#' Time series type variance models.
#'
#' Time series type correlation and variance models.
#'
#' The class of time series type models includes autoregressive models
#' of order 1, 2 and 3 (\code{ar1}, \code{ar2} and \code{ar3}),
#' symmetric autoregressive (\code{sar}), constrained autoregressive
#' order 3 (\code{sar2}), moving average models of order 1 and 2
#' (\code{ma1}, \code{ma2}) and the autoregressive-moving average
#' model (\code{arma}).
#'
#' @param obj
#'
#' A factor in \code{data}.
#'
#' @param init
#'
#' A vector of initial values (correlation parameters followed by
#' variance parameters) with an optional \code{names} attribute from
#' the set \{P, U, F\} specifying the boundary constraint as positive,
#' unconstrained or fixed, respectively.
#'
#' @aliases ar1 ar2 ar3 sar sar2 ma1 ma2 arma ar1v ar1h ar2v ar2h ar3v
#' ar3h sarv sarh sar2v sar2h ma1v ma1h ma2v ma2h armav armah
#'
#' @name timeSeries
#' @usage ar1(obj, init=NA)
#'
asr_ar1 <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ar1","cor",0.1,numeric(0),NA,obj,init, data)
  out
}
#' @describeIn timeSeries Autoregressive model of order 1;
#' homogeneous variance form.
#'
#' @usage ar1v(obj, init=NA)
#'
asr_ar1v <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ar1v","cor",0.1,0.1,NA,obj,init, data)
  out
}
#' @describeIn timeSeries Autoregressive model of order 1;
#' heterogeneous variance form.
#'
#' @usage ar1h(obj, init=NA)
#'
asr_ar1h <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ar1h","cor",0.1,"rep(0.1,n)",NA,obj,init, data)
  out
}
#' @describeIn timeSeries Autoregressive model of order 2.
#'
#' @usage ar2(obj, init=NA)
#'
asr_ar2 <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ar2","cor","rep(0.1,2)",numeric(0),NA,obj,init, data)
  out[[9]] <- as.integer(c(0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0))
  out
}
#' @describeIn timeSeries Autoregressive model of order 2;
#' homogeneous variance form.
#'
#' @usage ar2v(obj, init=NA)
#'
asr_ar2v <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ar2v","cor","rep(0.1,2)",0.1,NA,obj,init, data)
  out[[9]][13] <- 2
  out
}
#' @describeIn timeSeries Autoregressive model of order 2;
#' heterogeneous variance form.
#'
#' @usage ar2h(obj, init=NA)
#'
asr_ar2h <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ar2h","cor","rep(0.1,2)","rep(0.1,n)",NA,obj,init, data)
  out
}
#' @describeIn timeSeries Autoregressive model of order 3.
#'
#' @usage ar3(obj, init=NA)
#'
asr_ar3 <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ar3","cor","rep(0.1,3)",numeric(0),NA,obj,init, data)
  out
}
#' @describeIn timeSeries Autoregressive model of order 3;
#' homogeneous variance form.
#'
#' @usage ar3v(obj, init=NA)
#'
asr_ar3v <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ar3v","cor","rep(0.1,3)",0.1,NA,obj,init, data)
  out[[9]][13] <- 3
  out
}
#' @describeIn timeSeries Autoregressive model of order 3;
#' heterogeneous variance form.
#'
#' @usage ar3h(obj, init=NA)
#'
asr_ar3h <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ar3h","cor","rep(0.1,3)","rep(0.1,n)",NA,obj,init, data)
  out
}
#' @describeIn timeSeries Symmetric autoregressive model.
#'
#' @usage sar(obj, init=NA)
#'
asr_sar <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("sar","cor",0.1,numeric(0),NA,obj,init, data)
  out
}
#' @describeIn timeSeries Symmetric autoregressive model;
#' homogeneous variance form.
#'
#' @usage sarv(obj, init=NA)
#'
asr_sarv <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("sarv","cor",0.1,0.1,NA,obj,init, data)
  out[[9]][13] <- 1
  out
}
#' @describeIn timeSeries Symmetric autoregressive model;
#' heterogeneous variance form.
#'
#' @usage sarh(obj, init=NA)
#'
asr_sarh <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("sarh","cor",0.1,"rep(0.1,n)",NA,obj,init, data)
  out
}
#' @describeIn timeSeries Constrained autoregressive model of order 3.
#'
#' @usage sar2(obj, init=NA)
#'
asr_sar2 <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("sar2","cor","rep(0.1,2)",numeric(0),NA,obj,init, data)
  out
}
#' @describeIn timeSeries Constrained autoregressive model of order 3;
#' homogeneous variance form.
#'
#' @usage sar2v(obj, init=NA)
#'
asr_sar2v <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("sar2v","cor","rep(0.1,2)",0.1,NA,obj,init, data)
  out[[9]][13] <- 2
  out
}
#' @describeIn timeSeries Constrained autoregressive model of order 3;
#' heterogeneous variance form.
#'
#' @usage sar2h(obj, init=NA)
#'
asr_sar2h <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("sar2h","cor","rep(0.1,2)","rep(0.1,n)",NA,obj,init, data)
  out
}
#' @describeIn timeSeries Moving average model of order 1.
#'
#' @usage ma1(obj, init=NA)
#'
asr_ma1 <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ma1","cor",0.1,numeric(0),NA,obj,init, data)
  out
}
#' @describeIn timeSeries Moving average model of order 1;
#' homogeneous variance form.
#'
#' @usage ma1v(obj, init=NA)
#'
asr_ma1v <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ma1v","cor",0.1,0.1,NA,obj,init, data)
  out[[9]][13] <- 1
  out
}
#' @describeIn timeSeries Moving average model of order 1;
#' heterogeneous variance form.
#'
#' @usage ma1h(obj, init=NA)
#'
asr_ma1h <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ma1h","cor",0.1,"rep(0.1,n)",NA,obj,init, data)
  out
}
#' @describeIn timeSeries Moving average model of order 2.
#'
#' @usage ma2(obj, init=NA)
#'
asr_ma2 <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ma2","cor","rep(0.1,2)",numeric(0),NA,obj,init, data)
  out
}
#' @describeIn timeSeries Moving average model of order 2;
#' homogeneous variance form.
#'
#' @usage ma2v(obj, init=NA)
#'
asr_ma2v <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ma2v","cor","rep(0.1,2)",0.1,NA,obj,init, data)
  out[[9]][13] <- 2
  out
}
#' @describeIn timeSeries Moving average model of order 2;
#' heterogeneous variance form.
#'
#' @usage ma2h(obj, init=NA)
#'
asr_ma2h <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ma2h","cor","rep(0.1,2)","rep(0.1,n)",NA,obj,init, data)
  out
}
#' @describeIn timeSeries Autoregressive-moving average model.
#'
#' @usage arma(obj, init=NA)
#'
asr_arma <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("arma","cor","rep(0.1,2)",numeric(0),NA,obj,init, data)
  out
}
#' @describeIn timeSeries Autoregressive-moving average model;
#' homogeneous variance form.
#'
#' @usage armav(obj, init=NA)
#'
asr_armav <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("armav","cor","rep(0.1,2)",0.1,NA,obj,init, data)
  out[[9]][13] <- 2
  out
}
#' @describeIn timeSeries Autoregressive-moving average model;
#' heterogeneous variance form.
#'
#' @usage armah(obj, init=NA)
#'
asr_armah <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("armah","cor","rep(0.1,2)","rep(0.1,n)",NA,obj,init, data)
  out
}
#' General structure variance models.
#'
#' General correlation and covariance models.
#'
#' The class of general variance models includes the simple, banded
#' and general correlation models (\code{cor}, \code{corb},
#' \code{corg}), the diagonal, unstructured, Cholesky and
#' antedependence variance models (\code{diag}, \code{us},
#' \code{chol}, \code{cholc}, \code{ante}) and the factor analytic
#' structures (\code{sfa}, \code{facv}, \code{fa}).
#'
#' @param obj
#'
#' A factor in \code{data}.
#'
#' @param k
#'
#' Order of the model (\code{chol, ante}) or number of factors
#' (\code{sfa, facv, fa, rr}).
#'
#' @param init
#'
#' A vector of initial values (correlation parameters followed by
#' variance parameters) with an optional \code{names} attribute from
#' the set \{P, U, F\} specifying the boundary constraint as positive,
#' unconstrained or fixed, respectively.
#'
#' @aliases cor corv corh corb corbv corbh corg corgv corgh diag us
#' chol ante sfa facv fa rr
#'
#' @name unstructured
#'
#' @usage cor(obj, init=NA)
#'
asr_cor <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("cor","cor",0.1,numeric(0),NA,obj,init, data)
  out
}
#' @describeIn unstructured Simple correlation model,
#' homogeneous variance form.
#'
#' @usage corv(obj, init=NA)
#'
asr_corv <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("corv","cor",0.1,0.1,NA,obj,init, data)
  out[[9]][13] <- 1
  out
}
#' @describeIn unstructured Simple correlation model,
#' heterogeneous variance form.
#'
#' @usage corh(obj, init=NA)
#'
asr_corh <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("corh","cor",0.1,"rep(0.1,n)",NA,obj,init, data)
  out
}
#' @param b Number of (sub-diagonal) bands in banded correlation models.
#' @describeIn unstructured Banded correlation model with \code{b} bands.
#'
#' @usage corb(obj, b=1, init=NA)
#'
asr_corb <- function(obj, b=1, init=NA, data)
{
  ## corb has w=n-1 parameters where size=n x n
  ## Estimate b and fix the rest to zero
  out <- vector(mode="list",length=15)

  ## nest == true
  ## COMMON
  out[[13]] <- FALSE

  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special")) {
    out[[1]] <- obj[[1]]
    out[[2]] <- obj[[2]]
    out[[3]] <- obj[[3]]
    out[[14]] <- obj[[14]]
    out[[4]] <- obj[[4]]
    out[[10]] <- as.integer(obj[[10]])
    out[[11]] <- obj[[11]]
    out[[12]] <- obj[[12]]
  }
  else {
    out[[1]] <- "corb"
    out[[2]] <- spCall(sys.call())
    obj <- as.character(substitute(obj))
    out[[3]] <- obj
    out[[14]] <- out[[3]]
                                        # Levels
    if(is.factor(data[[obj]]))
      out[[4]] <- levels(data[[obj]])
    else
      stop(paste(obj,"must be a factor.\n"))
    ## Inter
    out[[10]] <- as.integer(c(length(out[[4]]), 0, match(obj, names(data))-1, 0))
    ##Coords
    out[[11]] <- list()
    ## Argv
    out[[12]] <- obj
  }
  ## COMMON
  n <- length(out[[4]])
  w <- n-1
  IniFlag <- TRUE
  if(missing(init)) {
    IniFlag <- FALSE
    init <- c(rep(0.1, b),rep(0.0,w-b))
  }
  else {
    if(is.character(init)) init <- eval(parse(text=init))
    if(length(init) != b)
      stop("corb(): Wrong number of initial values\n")
    init <- c(init, rep(0.0,w-b))
  }

  out[[5]] <- as.numeric(init)
  con <- matchCon(init)
  if(length(con)==0)
    out[[6]] <- c(rep("P", b),rep("F",(w-b)))
  else
    out[[6]] <- con

  attr(out[[5]], "set") <- IniFlag

  out[[7]] <- c(paste0("!",obj,"!cor",seq(1,b)),
                ie(b < w, paste0("!",obj,"!",rep("<NotEstimated>",(w-b))),NULL))

  out[[8]] <- as.integer(rep(3,w))

  out[[9]] <- as.integer(c(n,length(out[[5]]),5,0,0,w,0,0,0,0,0,0,0,0,0,0))

  ## DUMMY Bounds
  out[[15]] <- matrix(nrow=1, ncol=2)
  dimnames(out[[15]]) <- list(NULL,c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @describeIn unstructured Banded correlation model with \code{b} bands,
#' homogeneous variance form.
#'
#' @usage corbv(obj, init=NA)
#'
asr_corbv <- function(obj, b=1, init=NA, data)
{
    ## corbv has n-1+1 parameters where size=n x n
    out <- vector(mode="list",length=15)

    ## nest == true
    ## COMMON
    out[[13]] <- TRUE
    if(mode(substitute(obj))=="call" && inherits(obj,"asr.special")) {
      out[[1]] <- obj[[1]]
      out[[2]] <- obj[[2]]
      out[[3]] <- obj[[3]]
      out[[14]] <- obj[[14]]
      out[[4]] <- obj[[4]]
      out[[10]] <- as.integer(obj[[10]])
      out[[11]] <- obj[[11]]
      out[[12]] <- obj[[12]]
    }
    else {
      obj <- as.character(substitute(obj))
      out[[1]] <- "corbv"
      out[[2]] <- spCall(sys.call())
      out[[3]] <- obj
      out[[14]] <- out[[3]]
      if(is.factor(data[[obj]]))
        out[[4]] <- levels(data[[obj]])
      else
        stop(paste(obj,"must be a factor\n"))

      ## Inter
      out[[10]] <- as.integer(c(length(out[[4]]),0,match(obj,names(data))-1,0))
      ##Coords
      out[[11]] <- list()
      ## Argv
      out[[12]] <- obj
    }
    ## COMMON
    n <- length(out[[4]])
    w <- n-1
    ## Initial & Con
    IniFlag <- TRUE
    if(missing(init)) {
        IniFlag <- FALSE
        init <- c(rep(0.1,b),rep(0.0,w-b),0.1)
    }
    else {
        if(is.character(init)) init <- eval(parse(text=init))
        if(length(init) != b+1)
            stop("corbv(): Wrong number of initial values\n")
        tmp <- names(init)
        init <- c(init[1:b],rep(0.0,w-b),init[b+1])
        if(length(tmp) > 0)
            names(init) <- c(tmp[1:b],rep("",w-b),tmp[b+1])
    }

    out[[5]] <- as.numeric(init)
    con <- matchCon(init)
    if(length(con)==0)
        out[[6]] <- c(rep("P",b),rep("F",(w-b)),"P")
    else
      out[[6]] <- con

    attr(out[[5]], "set") <- IniFlag

    ## Lab
    out[[7]] <- c(paste0("!",obj,"!cor",seq(1,b)),
                  ie(b < w, paste0("!",obj,"!",rep("<NotEstimated>",(w-b))),NULL),
                  paste0("!",obj,"!var"))
    ## Tgamma
    out[[8]] <- as.integer(c(rep(3,w),2))

    ##Struc 3,6,8,13
    out[[9]] <- as.integer(c(n,length(out[[5]]),5,0,0,w,0,0,0,0,0,0,0,0,0,0))

    ## DUMMY Bounds
    out[[15]] <- matrix(nrow=1, ncol=2)
    dimnames(out[[15]]) <- list(NULL,c("LB","UB"))

    names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc",
                    "Inter","Coords","Argv","isVariance","FacNam","Bounds")
    oldClass(out) <- "asr.special"
    out
  }
#' @describeIn unstructured Banded correlation model with \code{b} bands,
#' heterogeneous variance form.
#'
#' @usage corbh(obj, init=NA)
#'
asr_corbh <- function(obj, b=1, init=NA,data)
{
  ## corbh has 2n-1 parameters where size=n x n
  out <- vector(mode="list",length=15)

  ## nest == true
  ## COMMON
  out[[13]] <- TRUE
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special")) {
    out[[1]] <- obj[[1]]
    out[[2]] <- obj[[2]]
    out[[3]] <- obj[[3]]
    out[[14]] <- obj[[14]] #Obj
    out[[4]] <- obj[[4]]
    out[[10]] <- as.integer(obj[[10]])
    out[[11]] <- obj[[11]]
    out[[12]] <- obj[[12]]
  }
  else {
    out[[1]] <- "corbh"
    out[[2]] <- spCall(sys.call())
    obj <- as.character(substitute(obj))
    out[[3]] <- obj
    out[[14]] <- out[[3]]
    if(is.factor(data[[obj]])) {
      out[[4]] <- levels(data[[obj]])
    }
    else
      stop(paste(obj,"must be a factor\n"))
    ## Inter
    out[[10]] <- as.integer(c(length(out[[4]]),0,match(obj,names(data))-1,0))
    ##Coords
    out[[11]] <- list()
    ## Argv
    out[[12]] <- obj
  }
  n <- length(out[[4]])
  w <- n-1
  IniFlag <- TRUE
  if(missing(init)) {
    IniFlag <- FALSE
    init <- c(rep(0.1,b),rep(0.0,w-b),rep(0.1,n))
  }
  else {
    if(is.character(init)) init <- eval(parse(text=init))
    if(length(init) != b+n)
      stop("corbh(): Wrong number of initial values\n")
    tmp <- names(init)
    init <- c(init[1:b],rep(0.0,w-b),init[(b+1):(b+n)])
    if(length(tmp) > 0)
      names(init) <- c(tmp[1:b],rep("",w-b),tmp[(b+1):(b+n)])
  }
  out[[5]] <- as.numeric(init)
  con <- matchCon(init)
  if(length(con)==0)
    out[[6]] <- c(rep("P",b),rep("F",(w-b)),rep("P",n))
  else
    out[[6]] <- con

  attr(out[[5]], "set") <- IniFlag

  out[[7]] <- c(paste0("!",obj,"!cor",seq(1,b)),
                ie(b < w,paste0("!",obj,"!", rep("<NotEstimated>",(w-b)),sep=""),NULL),
                paste0("!",obj,"_",out[[4]],"!var"))

  out[[8]] <- as.integer(c(rep(3,w),rep(2,n)))

  out[[9]] <- as.integer(c(n,length(out[[5]]),5,0,0,w,0,0,0,0,0,0,0,0,0,0))

  ## DUMMY Bounds
  out[[15]] <- matrix(nrow=1, ncol=2)
  dimnames(out[[15]]) <- list(NULL,c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc",
                  "Inter","Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @describeIn unstructured General correlation model.
#'
#' @usage corg(obj, init=NA)
#'
asr_corg <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("corg","cor","matrix(0.1,nrow=n,ncol=n)",numeric(0),NA,obj,init,data)
  out
}
#' @describeIn unstructured General correlation model,
#' homogeneous variance form.
#'
#' @usage corgv(obj, init=NA)
#'
asr_corgv <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("corgv","cor","matrix(0.1,nrow=n,ncol=n)",0.1,NA,obj,init, data)
  N <- length(out[[4]])*(length(out[[4]])-1)/2
  out[[9]][13] <- N
  out
}
#' @describeIn unstructured General correlation model,
#' heterogeneous variance form.
#'
#' @usage corgh(obj, init=NA)
#'
asr_corgh <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("corgh","cor","matrix(0.1,nrow=n,ncol=n)","rep(0.1,n)",
                    NA,obj,init, data)
  out
}
#' @describeIn unstructured Diagonal variance model.
#'
#' @usage diag(obj, init=NA)
#'
asr_diag <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("diag","var",numeric(0),"rep(0.1,n)",NA,obj,init, data)
  out
}
#' @describeIn unstructured Unstructured variance model.
#'
#' @usage us(obj, init=NA)
#'
asr_us <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("us","var",numeric(0),"matrix(0.1,nrow=n,ncol=n)+diag(0.05,nrow=n)",
             NA,obj,init, data)
  out
}
#' @describeIn unstructured Cholesky variance model of order \code{k}.
#'
#' @usage chol(obj, k=1, init=NA)
#'
asr_chol <- function(obj, k=1, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("chol","var",numeric(0),"matrix(0.1,nrow=n,ncol=n)+diag(0.05,nrow=n)",
                    k,obj,init, data)
  out[[9]][6] <- k+1
  out
}
asr_cholc <- function(obj, k=1, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("cholc","var",numeric(0),"matrix(0.1,nrow=n,ncol=n)+diag(0.05,nrow=n)",
                    k,obj,init, data)
  out[[9]] <- as.integer(c(0,0,11,0,0,-(k+1),0,0,0,0,0,0,0,0,0,0))
  out
}
#' @describeIn unstructured Antedependence variance model of order \code{k}.
#'
#' @usage ante(obj, k=1, init=NA)
#'
asr_ante <- function(obj, k=1, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"asr.special")))
    obj <- substitute(obj)
  out <- spc("ante","var",numeric(0),"matrix(0.1,nrow=n,ncol=n)+diag(0.05,nrow=n)",
                    k,obj,init, data)
  out[[9]][6] <- k+1
  out
}
#' @describeIn unstructured Factor analytic model with \code{k} factors;
#' the variance-covariance matrix is modelled on the correlation
#' scale.
#'
#' @usage sfa(obj, k=1, init=NA)
#'
asr_sfa <- function(obj, k=1, init=NA, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to sfa() must be a factor\n")

  out <- vector(mode="list",length=15)

  # Fun

  out[[1]] <- "sfa"

  # Call
  obj <- as.character(substitute(obj))
  out[[2]] <- spCall(sys.call())

  # Obj

  out[[3]] <- obj
  out[[14]] <- out[[2]]

  drop.unused.levels <- attr(data,"Control")$drop.unused.levels
  data <- data[[obj]]

  # Levels

  if(is.factor(data)) {
    lvls <- levels(data)
    out[[4]] <- lvls
  }
  else
    stop(paste(obj,"must be a factor\n")) #out[[4]] <- obj
  n <- length(out[[4]])
  N <- k*n+n

  # Initial & Con
  IniFlag <- TRUE
  if(missing(init)) {
    IniFlag <- FALSE
    init <- c(rep(0.7,n*k),rep(0.1,n))
  }
  else {
    if(is.character(init)) init <- eval(parse(text=init))
    if(length(init) != N)
      stop("sfa(): Wrong number of initial values\n")
  }

  if(k > 1)
    init[c(!lower.tri(matrix(nrow=n,ncol=k),diag=TRUE),rep(FALSE,n))] <- 0.0

  out[[5]] <- as.numeric(init)
  con <- matchCon(init)
  if(length(con)==0) {
    temp <- rep("P",N)
    if(k > 1)
      temp[c(!lower.tri(matrix(nrow=n,ncol=k),diag=TRUE),rep(FALSE,n))]  <- "F"
    out[[6]] <- temp
  }
  else
    out[[6]] <- con

  attr(out[[5]], "set") <- IniFlag

  # Lab
  out[[7]] <- c(paste(paste(rep(paste("!",obj,"_",lvls,sep=""),k),"sfa",sep="!"),
                      rep(seq(1,k),rep(n,k)),sep=""),
                paste("!",obj,"_",lvls,"!var",sep=""))

  # Tgamma
  out[[8]] <- as.integer(c(rep(3,n*k),rep(2,n)))

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(n,length(out[[5]]),10,0,0,k,0,1,0,0,0,0,0,0,0,0))

  # Inter
  out[[10]] <- as.integer(c(-40, 0, NA, 0)) #n

  #Coords
  out[[11]] <- list()

  # Argv
  out[[12]] <- obj
                                      # isVariance
  out[[13]] <- TRUE
  ## Bounds
  ## n variances, n*k loadings
  out[[15]] <- matrix(rep(c(-1e37,1e37),n+n*k), nrow=length(out[[5]]), byrow=TRUE)
  dimnames(out[[15]]) <- list(out[[7]],c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @describeIn unstructured Factor analytic model with \code{k} factors;
#' the variance-covariance matrix is modelled on the covariance
#' scale.
#'
#' @usage facv(obj, k=1, init=NA)
#'
asr_facv <- function(obj, k=1, init=NA, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to facv() must be a factor\n")

  out <- vector(mode="list",length=15)
                                        # Fun
  out[[1]] <- "facv"
                                        # Call
  obj <- as.character(substitute(obj))
  out[[2]] <- spCall(sys.call()) #obj
                                        # Obj
  out[[3]] <- obj
  out[[14]] <- out[[2]]

  drop.unused.levels <- attr(data,"Control")$drop.unused.levels
  data <- data[[obj]]
                                        # Levels
  if(is.factor(data)) {
    lvls <- levels(data)
    out[[4]] <- lvls
  }
  else
    stop(paste(obj,"must be a factor\n")) #out[[4]] <- obj
  n <- length(out[[4]])
  N <- k*n+n
                                        # Initial & Con
  IniFlag <- TRUE
  if(missing(init)) {
    IniFlag <- FALSE
    init <- c(rep(0.1,n*k),rep(0.1,n))
  }
  else {
    if(is.character(init)) init <- eval(parse(text=init))
    if(length(init) != N)
      stop("facv(): Wrong number of initial values\n")
  }

  if(k > 1)
    init[c(!lower.tri(matrix(nrow=n,ncol=k),diag=TRUE),rep(FALSE,n))] <- 0.0

  out[[5]] <- as.numeric(init)
  con <- matchCon(init)
  if(length(con)==0) {
    temp <- rep("P",N)
    if(k > 1)
      temp[c(!lower.tri(matrix(nrow=n,ncol=k),diag=TRUE),rep(FALSE,n))]  <- "F"
    out[[6]] <- temp
  }
  else
    out[[6]] <- con

  attr(out[[5]], "set") <- IniFlag
                                          # Lab
  out[[7]] <- c(paste(paste(rep(paste("!",obj,"_",lvls,sep=""),k),"fa",sep="!"),
                      rep(seq(1,k),rep(n,k)),sep=""),
                paste("!",obj,"_",lvls,"!var",sep=""))
                                        # Tgamma
  out[[8]] <- as.integer(c(rep(2,n*k),rep(2,n)))

                                        #Struc 3,6,8,13
  out[[9]] <- as.integer(c(n,length(out[[5]]),13,0,0,k,0,1,0,0,0,0,0,0,0,0))
                                        # Inter
  out[[10]] <- as.integer(c(-40, 0, NA, 0)) #n
                                        #Coords
  out[[11]] <- list()
                                        # Argv
  out[[12]] <- obj
                                        # isVariance
  out[[13]] <- TRUE
  ## Bounds
  ## n variances, n*k loadings
  out[[15]] <- matrix(rep(c(-1e37,1e37),n+n*k), nrow=length(out[[5]]), byrow=TRUE)
  dimnames(out[[15]]) <- list(out[[7]],c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @describeIn unstructured Factor analytic model with \code{k} factors;
#' sparse formulation where \code{k} \dQuote{extra} levels are
#' inserted in the mixed model equations.
#'
#' @usage fa(obj, k=1, init=NA)
#'
asr_fa <- function(obj, k=1, init=NA, data)
{
  out <- vector(mode="list",length=15)

  ## nest == true
  ## COMMON
  out[[1]] <- "fa"
  out[[13]] <- TRUE
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special")) {
    ## Trap grp and mbf
    if(obj[[1]] == "mbf")
      stop("Use 'str()' for 'fa(mbf())' models")
    if(obj[[1]] == "grp")
      stop("Use 'str()' for 'fa(grp())' models")

    out[[2]] <- obj[[2]]
    out[[3]] <- obj[[3]]
    out[[4]] <- c(obj[[4]], paste("Comp",seq(1,k),sep=""))
    n <- length(out[[4]])-k
    out[[10]] <- as.integer(c(-40,0,obj$inter[3],0)) #n+k
    out[[11]] <- obj[[11]]
    out[[12]] <- obj[[12]]
  }
  else if(is.numeric(substitute(obj))) {
    out[[2]] <- spCall(sys.call())
    out[[3]] <- as.character(obj)
    out[[4]] <- as.character(seq(1,obj+k))
    n <- obj
    out[[10]] <- as.integer(c(obj,0,NA,0))
    out[[11]] <- list()
    out[[12]] <- obj
  }
  else {
    ##k gives no of "extra" levels
    out[[2]] <- spCall(sys.call())
    obj <- as.character(substitute(obj))
    out[[3]] <- obj
    ## Levels
    if(is.factor(data[[obj]])) {
      out[[4]] <- c(levels(data[[obj]]), paste("Comp",seq(1,k),sep=""))
    }
    else
      stop(paste(obj,"must be a factor\n")) #out[[4]] <- obj

    n <- length(out[[4]])-k
    ## Inter
    ## inter(3) points to target in inter (facnam)
    out[[10]] <- as.integer(c(-40,0, NA, 0)) #n+k #match(obj,names(data))-1
    ## Coords
    out[[11]] <- list()
    ## Argv
    out[[12]] <- obj
  }
  ## COMMON
  N <- k*n+n
  ## Initial & Con
  ## Note: Inits are variances followed by loadings on cv scale (opposite to fa)
  IniFlag <- TRUE
  if(missing(init)) {
    IniFlag <- FALSE
    init <- c(rep(0.1,n),rep(0.1,n*k))
  }
  if(!missing(init)) {
    if(is.character(init)) init <- eval(parse(text=init))
    if(length(init) != N)
      stop("fa(): Wrong number of initial values\n")
  }
  if(k > 1 && !IniFlag && !asreml.options()$rotate.fa)
    init[c(rep(FALSE,n),!lower.tri(matrix(nrow=n,ncol=k),diag=TRUE))] <- 0.0

  out[[5]] <- as.numeric(init)
  con <- matchCon(init)
  con0 <- (length(con) == 0)
  if(con0)
    con <- c(rep("P",n),rep("P",k*n))
  if(k > 1 && con0 && !asreml.options()$rotate.fa)
    con[c(rep(FALSE,n),!lower.tri(matrix(nrow=n,ncol=k),diag=TRUE))]  <- "F"

  out[[6]] <- con
  attr(out[[5]], "set") <- IniFlag

  temp <- out[[4]][ 1:n ]
  out[[7]] <- c(paste("!",temp,"!var",sep=""),
                paste(paste(rep(paste("!",temp,sep=""),k),"fa",sep="!"),
                      rep(seq(1,k),rep(n,k)),sep=""))

  temp <- c(rep(1,n),rep(6,k*n))
  temp[seq(1,length(con))[con == "P"]] <- 1
  out[[8]] <- as.integer(temp)
  out[[9]] <- as.integer(c(length(out[[4]]),length(out[[5]]),15,0,0,k,0,1,0,0,0,0,0,0,0,0))
  ## facnam
  out[[14]] <- out[[2]]
  ## Bounds
  ## n variances, n*k loadings
  out[[15]] <- matrix(rep(c(-1e37,1e37),n+n*k), nrow=length(out[[5]]), byrow=TRUE)
  dimnames(out[[15]]) <- list(out[[7]],c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @describeIn unstructured Factor analytic model with \code{k} factors;
#' reduced rank formulation of \code{fa()} where the default boundary
#' constraints for the specific variances are set to \strong{F}ixed.
#'
#' @usage rr(obj, k=1, init=NA)
#'
asr_rr <- function(obj, k=1, init=NA, data)
{
  out <- vector(mode="list",length=15)

  ## nest == true
  ## COMMON
  out[[1]] <- "rr"

  out[[13]] <- TRUE
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special")) {
    ## Trap grp and mbf
    if(obj[[1]] == "mbf")
      stop("Use 'str()' for 'rr(mbf())' models")
    if(obj[[1]] == "grp")
      stop("Use 'str()' for 'rr(grp())' models")

    out[[2]] <- obj[[2]]
    out[[3]] <- obj[[3]]
    out[[4]] <- c(obj[[4]], paste("Comp",seq(1,k),sep=""))
    n <- length(out[[4]])-k
    out[[10]] <- as.integer(c(-40,0,obj$inter[3],0)) #n+k
    out[[11]] <- obj[[11]]
    out[[12]] <- obj[[12]]
  }
  else if(is.numeric(substitute(obj))) {
    out[[2]] <- spCall(sys.call())
    out[[3]] <- as.character(obj)
    out[[4]] <- as.character(seq(1,obj+k))
    n <- obj
    out[[10]] <- as.integer(c(obj,0,NA,0))
    out[[11]] <- list()
    out[[12]] <- obj
  }
  else {
    ##k gives no of "extra" levels
    out[[2]] <- spCall(sys.call())
    obj <- as.character(substitute(obj))
    out[[3]] <- obj
    ## Levels
    if(is.factor(data[[obj]])){
      out[[4]] <- c(levels(data[[obj]]), paste("Comp",seq(1,k),sep=""))
    }
    else
      stop(paste(obj,"must be a factor\n")) #out[[4]] <- obj

    n <- length(out[[4]])-k
    ## Inter
    out[[10]] <- as.integer(c(-40,0,NA,0)) #n+k
    ##Coords
    out[[11]] <- list()
    ## Argv
    out[[12]] <- obj
  }
  ## COMMON
  N <- k*n+n
  ## Initial & Con
  ## Note: Inits are variances followed by loadings on cv scale (opposite to fa)
  IniFlag <- TRUE
  if(missing(init)) {
    IniFlag <- FALSE
    init <- c(rep(0.0,n),rep(0.1,n*k))
  }
  if(!missing(init)) {
    if(is.character(init)) init <- eval(parse(text=init))
    if(length(init) != N)
      stop("rr(): Wrong number of initial values\n")
  }
  if(k > 1 && !IniFlag)
    init[c(rep(FALSE,n),!lower.tri(matrix(nrow=n,ncol=k),diag=TRUE))] <- 0.0

  out[[5]] <- as.numeric(init)
  con <- matchCon(init)
  if(length(con)==0)
      con <- c(rep("F",n),rep("U",k*n))
  if(k > 1)
      con[c(rep(FALSE,n),!lower.tri(matrix(nrow=n,ncol=k),diag=TRUE))]  <- "F"

  out[[6]] <- con
  attr(out[[5]], "set") <- IniFlag

  temp <- out[[4]][ 1:n ]
  out[[7]] <- c(paste("!",temp,"!var",sep=""),
                paste(paste(rep(paste("!",temp,sep=""),k),"fa",sep="!"),
                      rep(seq(1,k),rep(n,k)),sep=""))

  temp <- c(rep(2,n),rep(6,k*n))
  temp[seq(1,length(con))[con == "P"]] <- 2
  out[[8]] <- as.integer(temp)

  out[[9]] <- as.integer(c(length(out[[4]]),length(out[[5]]),15,0,0,k,0,1,0,0,0,0,0,0,0,0))
  ## facnam
  out[[14]] <- out[[2]]
  ## Bounds
  ## n variances, n*k loadings
  out[[15]] <- matrix(rep(c(-1e37,1e37),n+n*k), nrow=length(out[[5]]), byrow=TRUE)
  dimnames(out[[15]]) <- list(out[[7]],c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}

#' Metric based models in one dimension.
#'
#' Metric based variance model functions in one dimension.
#'
#' Includes one dimensional exponential, gaussian and linear variance
#' power models (\code{exp}, \code{gau}, \code{lvr}).
#'
#' @param x
#'
#' An object in \code{data}.
#'
#' @param dist
#'
#' Optional numeric vector of coordinates (distances). If missing then
#' the distances are obtained as \code{unique(obj)}.
#'
#' @param init
#'
#' An optional vector of initial values (power parameters followed by
#' variance parameters) with an optional \code{names} attribute from
#' the set \{P, U, F\} specifying the boundary constraint as positive,
#' unconstrained or fixed, respectively.
#'
#' @name metric-1d
#' @aliases exp expv exph gau gauv gauh lvr lvrv lvrh
#' @usage exp(x, init=NA, dist=NA)
#'
asr_exp <- function(x, init=NA, dist=NA, data)
{
  if(!(mode(substitute(x))=="call" && inherits(x,"asr.special")))
    x <- substitute(x)

  # Fun

  fun <- "exp"

  ## Call
  ##obj <- as.character(substitute(x))

  type <- "i"
  struc <- c(0,0,6,0,0,1,0,0,0,0,0,0,0,0,0,0)
  out <- specialsOned(fun,x,type,data,struc,dist,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-1d Homogeneous variance form.
#'
#' @usage expv(x, init=NA, dist=NA)
#'
asr_expv <- function(x, init=NA, dist=NA,data)
{
  if(!(mode(substitute(x))=="call" && inherits(x,"asr.special")))
    x <- substitute(x)

  # Fun

  fun <- "expv"

  ## Call
  ##obj <- as.character(substitute(x))

  type <- "v"
  struc <- c(0,0,6,0,0,1,0,0,0,0,0,0,1,0,0,0)
  out <- specialsOned(fun,x,type,data,struc,dist,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-1d Heterogeneous variance form.
#'
#' @usage exph(x, init=NA, dist=NA)
#'
asr_exph <- function(x, init=NA, dist=NA,data)
{
  if(!(mode(substitute(x))=="call" && inherits(x,"asr.special")))
    x <- substitute(x)

  # Fun
  fun <- "exph"

  ## Call
  ##obj <- as.character(substitute(x))

  type <- "h"
  struc <- c(0,0,6,0,0,1,0,0,0,0,0,0,0,0,0,0)
  out <- specialsOned(fun,x,type,data,struc,dist,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-1d Gaussian power model.
#'
#' @usage gau(x, init=NA, dist=NA)
#'
asr_gau <- function(x, init=NA, dist=NA, data)
{
  if(!(mode(substitute(x))=="call" && inherits(x,"asr.special")))
    x <- substitute(x)

  ## Fun
  fun <- "gau"
  ## Call
  ##obj <- as.character(substitute(x))

  type <- "i"
  struc <- c(0,0,6,0,0,2,0,0,0,0,0,0,0,0,0,0)
  out <- specialsOned(fun,x,type,data,struc,dist,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-1d Gaussian power model, homogeneous variance form.
#'
#' @usage gauv(x, init=NA, dist=NA)
#'
asr_gauv <- function(x, init=NA, dist=NA, data)
{
  if(!(mode(substitute(x))=="call" && inherits(x,"asr.special")))
    x <- substitute(x)
  ## Fun
  fun <- "gauv"
  ## Call
  ##obj <- as.character(substitute(x))

  type <- "v"
  struc <- c(0,0,6,0,0,2,0,0,0,0,0,0,1,0,0,0)
  out <- specialsOned(fun,x,type,data,struc,dist,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-1d Gaussian power model, heterogeneous variance form.
#'
#' @usage gauh(x, init=NA, dist=NA)
#'
asr_gauh <- function(x, init=NA, dist=NA,data)
{
  if(!(mode(substitute(x))=="call" && inherits(x,"asr.special")))
    x <- substitute(x)

  ## Fun
  fun <- "gauh"
  ## Call
  ##obj <- as.character(substitute(x))

  type <- "h"
  struc <- c(0,0,6,0,0,2,0,0,0,0,0,0,0,0,0,0)
  out <- specialsOned(fun,x,type,data,struc,dist,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-1d Linear variance model.
#'
#' @usage lvr(x, init=NA, dist=NA)
#'
asr_lvr <- function(x, init=NA, dist=NA, data)
{
  if(!(mode(substitute(x))=="call" && inherits(x,"asr.special")))
    x <- substitute(x)

  ## Fun
  fun <- "lvr"
  ## Call
  ##obj <- as.character(substitute(x))

  type <- "i"
  struc <- c(0,0,6,0,0,7,0,0,0,0,0,0,0,0,0,0)
  out <- specialsOned(fun,x,type,data,struc,dist,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-1d Linear variance model, homogeneous variance form.
#'
#' @usage lvrv(x, init=NA, dist=NA)
#'
asr_lvrv <- function(x, init=NA, dist=NA, data)
{
  if(!(mode(substitute(x))=="call" && inherits(x,"asr.special")))
    x <- substitute(x)
  ## Fun
  fun <- "lvrv"
  ## Call
  ##obj <- as.character(substitute(x))

  type <- "v"
  struc <- c(0,0,6,0,0,7,0,0,0,0,0,0,1,0,0,0)
  out <- specialsOned(fun,x,type,data,struc,dist,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-1d Linear variance model, heterogeneous variance form.
#'
#' @usage lvrh(x, init=NA, dist=NA)
#'
asr_lvrh <- function(x, init=NA, dist=NA,data)
{
  if(!(mode(substitute(x))=="call" && inherits(x,"asr.special")))
    x <- substitute(x)

  ## Fun
  fun <- "lvrh"
  ## Call
  ##obj <- as.character(substitute(x))

  type <- "h"
  struc <- c(0,0,6,0,0,7,0,0,0,0,0,0,0,0,0,0)
  out <- specialsOned(fun,x,type,data,struc,dist,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' Metric based models in two dimensions.
#'
#' Metric based variance model functions in two dimensions.
#'
#' Includes two two dimensional isotropic exponential, gaussian,
#' euclidean, linear variance, spherical and circular power models
#' (\code{iexp}, \code{igau}, \code{ieuc}, \code{ilv}, \code{sph},
#' \code{cir}), anisotropic exponential and gaussian models
#' (\code{aexp}, \code{agau}) and the Matern class
#' (\code{\link[=matern]{mtrn}}).
#'
#' @param x
#'
#' An object in \code{data} containing the \emph{x} coordinates.
#'
#' @param y
#'
#' An object in \code{data} containing the \emph{y} coordinates.
#'
#' @param init
#'
#' An optional vector of initial values (power parameters followed by
#' variance parameters) with an optional \code{names} attribute from
#' the set \{P, U, F\} specifying the boundary constraint as positive,
#' unconstrained or fixed, respectively.
#'
#' @name metric-2d
#'
#' @aliases iexp iexpv iexph aexp aexpv aexph igau igauv igauh agau
#'   agauv agauh ieuc ieucv ieuch ilv ilvv ilvh sph sphv sphh cir cirv
#'   cirh
#'
#' @usage iexp(x, y, init=NA)
#'
asr_iexp <- function(x, y, init=NA, data)
{
                                        # Fun
  fun <- "iexp"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "ii"
  struc <- c(0,0,6,0,0,1,0,0,0,0,0,0,0,0,0,0)
  out <- do.call("specialsTwod",
                 list(fun=fun,type=type,xx=xx,yy=yy,data=data,struc=struc,init=init))
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Homogeneous variance form.
#'
#' @usage iexpv(x, y, init=NA)
#'
asr_iexpv <- function(x, y, init=NA,data)
{
                                        # Fun
  fun <- "iexpv"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "iv"
  struc <- c(0,0,6,0,0,1,0,0,0,0,0,0,1,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Heterogeneous variance form.
#'
#' @usage iexph(x, y, init=NA)
#'
asr_iexph <- function(x, y, init=NA,data)
{
                                        # Fun
  fun <- "iexph"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "ih"
  struc <- c(0,0,6,0,0,1,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out
}
#' @describeIn metric-2d Anisotropic exponential variance model.
#'
#' @usage aexp(x, y, init=NA)
#'
asr_aexp <- function(x, y, init=NA, data)
{
  fun <- "aexp"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "ai"
  struc <- c(0,0,6,0,0,1,0,0,0,0,0,0,0,0,0,0)
  out <- do.call("specialsTwod",
                 list(fun=fun,type=type,xx=xx,yy=yy,data=data,struc=struc,init=init))
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Anisotropic exponential variance model,
#' homogeneous variance form.
#'
#' @usage aexpv(x, y, init=NA)
#'
asr_aexpv <- function(x, y, init=NA,data)
{
                                        # Fun
  fun <- "aexpv"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "av"
  struc <- c(0,0,6,0,0,1,0,0,0,0,0,0,2,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Anisotropic exponential variance model,
#' heterogeneous variance form.
#'
#' @usage aexph(x, y, init=NA)
#'
asr_aexph <- function(x, y, init=NA,data)
{
                                        # Fun
  fun <- "aexph"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "ah"
  struc <- c(0,0,6,0,0,1,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out

}
#' @describeIn metric-2d Isotropic Gaussian variance model.
#'
#' @usage igau(x, y, init=NA)
#'
asr_igau <- function(x, y, init=NA, data)
{
                                        # Fun
  fun <- "igau"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "ii"
  struc <- c(0,0,6,0,0,2,0,0,0,0,0,0,0,0,0,0)
  out <- do.call("specialsTwod",
                 list(fun=fun,type=type,xx=xx,yy=yy,data=data,struc=struc,init=init))
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Isotropic Gaussian variance model,
#' homogeneous variance form.
#'
#' @usage igauv(x, y, init=NA)
#'
asr_igauv <- function(x, y, init=NA,data)
{
                                        # Fun
  fun <- "igauv"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "iv"
  struc <- c(0,0,6,0,0,2,0,0,0,0,0,0,1,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Isotropic Gaussian variance model,
#' heterogeneous variance form.
#'
#' @usage igauh(x, y, init=NA)
#'
asr_igauh <- function(x, y, init=NA,data)
{
                                        # Fun
  fun <- "igauh"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "ih"
  struc <- c(0,0,6,0,0,2,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Anisotropic Gaussian variance model.
#'
#' @usage agau(x, y, init=NA)
#'
asr_agau <- function(x, y, init=NA, data)
{
                                        # Fun
  fun <- "agau"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "ai"
  struc <- c(0,0,6,0,0,2,0,0,0,0,0,0,0,0,0,0)
  out <- do.call("specialsTwod",
                 list(fun=fun,type=type,xx=xx,yy=yy,data=data,struc=struc,init=init))
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Anisotropic Gaussian variance model,
#' homogeneous variance form.
#'
#' @usage agauv(x, y, init=NA)
#'
asr_agauv <- function(x, y, init=NA,data)
{
                                        # Fun
  fun <- "agauv"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "av"
  struc <- c(0,0,6,0,0,2,0,0,0,0,0,0,2,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Anisotropic Gaussian variance model,
#' heterogeneous variance form.
#'
#' @usage agauh(x, y, init=NA)
#'
asr_agauh <- function(x, y, init=NA,data)
{
                                        # Fun
  fun <- "agauh"
                                        # Call
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))

  type <- "ah"
  struc <- c(0,0,6,0,0,2,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Isotropic Euclidean variance model.
#'
#' @usage ieuc(x, y, init=NA)
#'
asr_ieuc <- function(x, y, init=NA, data)
{
  ## Fun
  fun <- "ieuc"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "ii"
  struc <- c(0,0,6,0,0,3,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Isotropic Euclidean variance model,
#' homogeneous variance form.
#'
#' @usage ieucv(x, y, init=NA)
#'
asr_ieucv <- function(x, y, init=NA, data)
{
  ## Fun
  fun <- "ieucv"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "iv"
  struc <- c(0,0,6,0,0,3,0,0,0,0,0,0,1,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())

  out
}
#' @describeIn metric-2d Isotropic Euclidean variance model,
#' heterogeneous variance form.
#'
#' @usage ieuch(x, y, init=NA)
#'
asr_ieuch <- function(x, y, init=NA, data)
{
  ## Fun
  fun <- "ieuch"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "ih"
  struc <- c(0,0,6,0,0,3,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)

  out
}
#' @describeIn metric-2d Isotropic linear variance model.
#'
#' @usage ilv(x, y, init=NA)
#'
asr_ilv <- function(x, y, init=NA, data)
{
  ## Fun
  fun <- "ilv"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "ii"
  struc <- c(0,0,6,0,0,7,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Isotropic linear variance model,
#' homogeneous variance form.
#'
#' @usage ilvv(x, y, init=NA)
#'
asr_ilvv <- function(x, y, init=NA, data)
{
  ## Fun
  fun <- "ilvv"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "iv"
  struc <- c(0,0,6,0,0,7,0,0,0,0,0,0,1,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)

  out
}
#' @describeIn metric-2d Isotropic linear variance model,
#' heterogeneous variance form.
#'
#' @usage ilvh(x, y, init=NA)
#'
asr_ilvh <- function(x, y, init=NA, data)
{
  ## Fun
  fun <- "ilvh"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "ih"
  struc <- c(0,0,6,0,0,7,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Spherical variance model.
#'
#' @usage sph(x, y, init=NA)
#'
asr_sph <- function(x,y, init=NA, data)
{
  ## Cubic spherical (=CSP)
  ## Fun
  fun <- "sph"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "ii"
  struc <- c(0,0,6,0,0,4,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out
}
#' @describeIn metric-2d Spherical variance model,
#' homogeneous variance form.
#'
#' @usage sphv(x, y, init=NA)
#'
asr_sphv <- function(x,y, init=NA, data)
{
  ## Cubic spherical (=CSP)
  ## Fun
  fun <- "sphv"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "iv"
  struc <- c(0,0,6,0,0,4,0,0,0,0,0,0,1,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Spherical variance model,
#' heterogeneous variance form.
#'
#' @usage sphh(x, y, init=NA)
#'
asr_sphh <- function(x,y, init=NA, data)
{
  ## Cubic spherical (=CSP)
  ## Fun
  fun <- "sphh"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "ih"
  struc <- c(0,0,6,0,0,4,0,0,0,0,0,0,0,0,0,0)
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out
}
#' @describeIn metric-2d Circular variance model.
#'
#' @usage cir(x, y, init=NA)
#'
asr_cir <- function(x,y, init=NA,  data)
{
  ## Circular
  ## Fun
  fun <- "cir"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "ii"
  struc <- c(0,0,6,0,0,5,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn metric-2d Circular variance model,
#' homogeneous variance form.
#'
#' @usage cirv(x, y, init=NA)
#'
asr_cirv <- function(x,y, init=NA,  data)
{
  ## Circular
  ## Fun
  fun <- "cirv"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "iv"
  struc <- c(0,0,6,0,0,5,0,0,0,0,0,0,1,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out
}
#' @describeIn metric-2d Circular variance model,
#' heterogeneous variance form.
#'
#' @usage cirh(x, y, init=NA)
#'
asr_cirh <- function(x,y, init=NA,  data)
{
  ## Circular
  ## Fun
  fun <- "cirh"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "ih"
  struc <- c(0,0,6,0,0,5,0,0,0,0,0,0,0,0,0,0)
  out <- specialsTwod(fun,type,xx,yy,data,struc,init)
  out[[2]] <- spCall(sys.call())
  out
}
#' Matern variance structure.
#'
#' Model function for an extended Matern class.
#'
#' The \code{mtrn} special function implements an extended Matern
#' class which accomodates geometric anisotropy and a choice of
#' metrics for random fields observed in two dimensions (\cite{Haskard
#' et al., 2007}). See the User Guide for details.
#'
#' If an argument to \code{mtrn} is numeric, it is treated as a
#' starting value for estimation and given the constraint code
#' \code{P} (positive). This behaviour can be altered by concatenating
#' the numeric value followed by the constraint code (\dQuote{P},
#' \dQuote{U} or \dQuote{F}) into a character string. If an argument
#' is absent from the call, the corresponding parameter is held fixed
#' at its default value.
#'
#' @param x
#'
#' An object in \code{data} containing the \emph{x} coordinates.
#'
#' @param y
#'
#' An object in \code{data} containing the \emph{y} coordinates.
#'
#' @param phi
#'
#' The range parameter; default \code{NA}.
#'
#' @param nu
#'
#' The smoothness parameter; default 0.5.
#'
#' @param delta
#'
#' Governs geometric anisotropy; default 1.0.
#'
#' @param alpha
#'
#' Governs geometric anisotropy; default 0.0.
#'
#' @param lambda
#'
#' Specifies the choice of metric: 2 is Euclidean distance (default),
#' and 1 is city block.
#'
#' @param init
#'
#' An optional vector of initial values for any variance parameters,
#' with an optional \code{names} attribute from the set \{P, U, F\}
#' specifying the boundary constraint as positive, unconstrained or
#' fixed, respectively.
#'
#' @references
#' % bibentry: Haskard:2007
#'
#' @aliases mtrn mtrnh mtrnv
#' @name matern
#' @usage mtrn(x, y, phi=NA, nu=0.5, delta=1.0, alpha=0.0, lambda=2)
#'
asr_mtrn <- function(x, y, phi=NA, nu=0.5, delta=1.0, alpha=0.0, lambda=2,
                      data)
{
  fun <- "mtrn"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "mi"
  ##Struc 3,6,8,13
  struc <- c(0,0,6,0,0,9,0,0,0,0,0,0,0,0,0,0)

  attr(phi,"missing") <- ie(missing(phi),TRUE,FALSE)
  attr(nu,"missing") <- ie(missing(nu),TRUE,FALSE)
  attr(delta,"missing") <- ie(missing(delta),TRUE,FALSE)
  attr(alpha,"missing") <- ie(missing(alpha),TRUE,FALSE)
  attr(lambda,"missing") <- ie(missing(lambda),TRUE,FALSE)

  init <- NA
  out <- specialsTwod(fun,type,xx,yy,data,struc,init,
                      phi=phi,nu=nu,delta=delta,alpha=alpha,lambda=lambda)
  out[[2]] <- spCall(sys.call())
  out
}
#' @describeIn matern Matern variance model,
#' homogeneous variance form.
#'
#' @usage
#'
#' mtrnv(x, y, phi=NA, nu=0.5, delta=1.0, alpha=0.0, lambda=2, init=0.1)
#'
asr_mtrnv <- function(x, y, phi=NA, nu=0.5, delta=1.0, alpha=0.0, lambda=2,
                         init=0.1, data)
{
  fun <- "mtrnv"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "mv"
  ##Struc 3,6,8,13
  struc <- c(0,0,6,0,0,9,0,0,0,0,0,0,5,0,0,0)

  attr(phi,"missing") <- ie(missing(phi),TRUE,FALSE)
  attr(nu,"missing") <- ie(missing(nu),TRUE,FALSE)
  attr(delta,"missing") <- ie(missing(delta),TRUE,FALSE)
  attr(alpha,"missing") <- ie(missing(alpha),TRUE,FALSE)
  attr(lambda,"missing") <- ie(missing(lambda),TRUE,FALSE)
  attr(init,"missing") <- ie(missing(init),TRUE,FALSE)

  out <- specialsTwod(fun,type,xx,yy,data,struc,init,
                      phi=phi,nu=nu,delta=delta,alpha=alpha,lambda=lambda)
  out[[2]] <- spCall(sys.call())
  out

}
#' @describeIn matern Matern variance model,
#' heterogeneous variance form.
#'
#' @usage
#'
#' mtrnh(x, y, phi=NA, nu=0.5, delta=1.0, alpha=0.0, lambda=2, init=0.1)
#'
asr_mtrnh <- function(x, y, phi=NA, nu=0.5, delta=1.0, alpha=0.0, lambda=2,
                         init=0.1, data)
{
  fun <- "mtrnh"
  xx <- as.character(substitute(x))
  yy <- as.character(substitute(y))
  type <- "mh"
  ##Struc 3,6,8,13
  struc <- c(0,0,6,0,0,9,0,0,0,0,0,0,5,0,0,0)

  attr(phi,"missing") <- ie(missing(phi),TRUE,FALSE)
  attr(nu,"missing") <- ie(missing(nu),TRUE,FALSE)
  attr(delta,"missing") <- ie(missing(delta),TRUE,FALSE)
  attr(alpha,"missing") <- ie(missing(alpha),TRUE,FALSE)
  attr(lambda,"missing") <- ie(missing(lambda),TRUE,FALSE)
  attr(init,"missing") <- ie(missing(init),TRUE,FALSE)

  out <- specialsTwod(fun,type,xx,yy,data,struc,init,
                        phi=phi,nu=nu,delta=delta,alpha=alpha,lambda=lambda)
  out[[2]] <- spCall(sys.call())
  out
}

## end of function list

matchCon <- function(init)
{
  what <- names(init)
  if(is.null(what))
    return(NULL)
  codes <- c('P','U','F')
  what <- casefold(what,upper=TRUE)
  which <- charmatch(what,codes)
  where <- is.na(which)
  if(all(where))
    return(NULL)
  else if(sum(as.numeric(where)) > 0)
    what[where] <- 'F'
  return(what)

}
iniCon <- function(x)
{
  n <- nchar(x)
  vec <- casefold(substring(x,1:n,1:n),upper=TRUE)
  where <- match(c("P","U","F"),vec)
  if(sum(!is.na(where)) == 0) {
    ## default to Fixed
    x <- paste(x,"F",sep="")
    where <- c(NA,NA,n+1)
  }
  if(sum(!is.na(where)) > 1)
    stop("Only one of 'P','U','F' may be specified in 'mtrn'")
  which <- where[!is.na(where)]
  value <- as.numeric(substring(x,1,which-1))
  constraint <- casefold(substring(x,which,which),upper=TRUE)
  list(value=value,constraint=constraint)
}
specialsTwod <- function(fun, type, xx, yy, data, struc, init=NA, ...)
{
  ## type
  ## ii, iv, ih : isotropic
  ## ai, av, ah : anisotropic
  ## si, sv, sh : spherical
  ## mi, mv, mh : matern (ident, var, het)

  Rcov <- attr(data,"Rcov")

  call <- list(...)

  if(is.null(call$p))
    p <- 1
  else
    p <- call$p

  ## for matern
  if(is.element(type,c("mi", "mv", "mh"))) {
    phi <- call$phi
    nu <- call$nu
    delta <- call$delta
    alpha <- call$alpha
    lambda <- call$lambda
  }

  out <- vector(mode="list",length=15)

  ## Fun
  out[[1]] <- fun
  ## Call
  obj <- paste(fun,"(",xx,",",yy,")",sep="")
  out[[2]] <- obj
  ## Obj
  out[[3]] <- obj
  out[[14]] <- out[[3]]

  ## Get data vector
  ## else make obj now
  if(is.na(match(obj, names(data)))) {

    u <- is.na(as.vector(matrix(1,nrow=1,ncol=2) %*% rbind(data[[xx]],data[[yy]])))
    nuFac <- paste(as.character(data[[xx]]),as.character(data[[yy]]), sep=",")
    nuFac[u] <- NA
    data[, (obj) := factor(nuFac, levels=unique(nuFac[!u]))]
  }
  ## Levels

  PP <- t(getPpoints(data,obj,1))
  if(prod(dim(PP)) > 0) {
    pmat <- rbind(cbind(as.numeric(data[[xx]]),as.numeric(data[[yy]])), PP)
  }
  else {
    pmat <- cbind(as.numeric(data[[xx]]),as.numeric(data[[yy]]))
  }
  pmat <- pmat[!duplicated(pmat),,drop=FALSE]
  if(!Rcov)
    idx <- base::order(as.vector(pmat[,2]), as.vector(pmat[,1]))
  else
    idx <- seq(1,nrow(pmat))
  lvls <- unique(paste(pmat[idx,1],pmat[idx,2],sep=","))
  out[[4]] <- lvls
  n <- length(out[[4]])

  ## For Matern
  if(is.element(type,c("mi", "mv", "mh"))) {
    ## Initial & Con
    IniFlag <- switch(type,
                      mi=rep(FALSE,5),
                      mv={x <- rep(FALSE,6)
                          x[6] <- !attr(init,"missing")
                          x},
                      mh={x <- rep(FALSE,(5+n))
                          x[6:(5+n)] <- rep(!attr(init,"missing"),n)
                          x})
    initv <- switch(type,
                    mi=vector(mode="numeric",length=5),
                    mv=vector(mode="numeric",length=6),
                    mh=vector(mode="numeric",length=5+n))
    cons <- switch(type,
                   mi=vector(mode="character",length=5),
                   mv=vector(mode="character",length=6),
                   mh=vector(mode="character",length=5+n))

    if(!attr(phi,"missing")) {
      IniFlag[1] <- TRUE
      if(is.numeric(phi)) {
        initv[1] <- phi
        cons[1] <- "P"
      }
      else {
        initv[1] <- iniCon(phi)$value
        cons[1] <- iniCon(phi)$constraint
      }
    }
    else {
      initv[1] <- 0.1
      cons[1] <- "P"
    }
    if(!attr(nu,"missing")) {
      IniFlag[2] <- TRUE
      if(is.numeric(nu)) {
        initv[2] <- nu
        cons[2] <- "P"
      }
      else {
        initv[2] <- iniCon(nu)$value
        cons[2] <- iniCon(nu)$constraint
      }
    }
    else {
      initv[2] <- nu
      cons[2] <- "F"
    }
    if(!attr(delta,"missing")) {
      IniFlag[3] <- TRUE
      if(is.numeric(delta)) {
        initv[3] <- delta
        cons[3] <- "P"
      }
      else {
        initv[3] <- iniCon(delta)$value
        cons[3] <- iniCon(delta)$constraint
      }
    }
    else {
      initv[3] <- delta
      cons[3] <- "F"
    }
    if(!attr(alpha,"missing")) {
      IniFlag[4] <- TRUE
      if(is.numeric(alpha)) {
        initv[4] <- alpha
        cons[4] <- "P"
      }
      else {
        initv[4] <- iniCon(alpha)$value
        cons[4] <- iniCon(alpha)$constraint
      }
    }
    else {
      initv[4] <- alpha
      cons[4] <- "F"
    }
    if(!attr(lambda,"missing")) {
      IniFlag[5] <- TRUE
      if(is.numeric(lambda)) {
        initv[5] <- lambda
        cons[5] <- "F"
      }
      else {
        initv[5] <- iniCon(lambda)$value
        cons[5] <- "F"
      }
    }
    else {
      initv[5] <- lambda
      cons[5] <- "F"
    }

    out[[5]] <- initv
    out[[6]] <- cons

    out[[5]] <- switch(type,
                       mi=initv,
                       mv={
                         if(IniFlag[6] == FALSE)
                           initv[6] <- 0.1
                         else
                           {
                             if(is.character(init)) init <- eval(parse(text=init))
                             if(length(init) != 1)
                               stop("mtrnv(): Wrong number of initial values\n")
                             initv[6] <- init
                           }
                         initv
                       },
                       mh={
                         if(IniFlag[6] == FALSE)
                           initv[6:(n+5)] <- rep(0.1,n)
                         else
                           {
                             if(is.character(init)) init <- eval(parse(text=init))
                             if(length(init) != n)
                               stop("mtrnh(): Wrong number of initial values\n")
                             initv[6:(n+5)] <- init
                           }
                         initv
                       })
    out[[6]] <- switch(type,
                       mi=cons,
                       mv={
                         tmp <- matchCon(initv[6])
                         if(length(tmp)==0)
                           cons[6] <- "P"
                         else
                           cons[6] <- tmp
                         cons},
                       mh={
                         tmp <- matchCon(init[6:(n+5)])
                         if(length(tmp)==0)
                           cons[6:(n+5)] <- rep("P",n)
                         else
                           cons[6:(n+5)] <- tmp
                         cons})
    attr(out[[5]], "set") <- IniFlag
  }
  else {
    ## Initial & Con
    ni <- switch(type,ii=1,iv=2,ih=n,ai=2,av=3,ah=n+2,si=p,sv=p+1,sh=n+p)
    IniFlag <- TRUE
    if(all(is.na(init))) {
      IniFlag <- FALSE
      init <- rep(0.1,ni)
    }
    else {
      if(is.character(init)) init <- eval(parse(text=init))
      if(length(init) != ni)
        stop(paste(fun,"Wrong number of initial values\n"))
      if(type=="sh") p <- length(init)-n
      if(type=="sv") p <- length(init)-1
      if(type=="si") p <- length(init)
    }

    out[[5]] <- as.numeric(init)
    con <- matchCon(init)
    if(length(con)==0)
      out[[6]] <- switch(type,
                         ii="P",iv=c("P","P"),ih=c("P",rep("P",n)),
                         ai=c("P","P"),av=c("P","P","P"),ah=c("P","P",rep("P",n)),
                         si=rep("P",p),sv=c(rep("P",p),"P"),sh=c(rep("P",p),rep("P",n)))
    else
      out[[6]] <- con

    attr(out[[5]], "set") <- IniFlag
  }
  ## Lab
  out[[7]] <- switch(type,
                     ii=paste("!","pow",sep=""),
                     iv=paste("!",c("pow","var"),sep=""),
                     ih=c(paste("!","pow",sep=""),paste("_",lvls,sep="")),
                     ai=paste("!",c(xx,yy),c("!pow","!pow"),sep=""),
                     av=paste("!",c(xx,yy,""),c("!pow","!pow","var"),sep=""),
                     ah=c(paste("!",c(xx,yy),c("!pow","!pow"),sep=""),paste("_",lvls,sep="")),
                     si=paste("!",xx,"!",yy,paste("!phi",seq(1,p),sep=""),sep=""),
                     sh=c(paste("!",paste("phi",seq(1,p),sep=""),sep=""),paste("_",lvls,sep="")),
                     mi=paste("!",c("phi","nu","delta","alpha","lambda"),sep=""),
                     mv=paste("!",c("phi","nu","delta","alpha","lambda","var"),sep=""),
                     mh=c(paste("!",obj,c("!phi","!nu","!delta","!alpha","!lambda"),sep=""),
                paste("_",lvls,sep="")))


  ## Tgamma
  out[[8]] <- switch(type,
                     ii=3 * as.numeric(ie(IniFlag,-1,1)),
                     iv=c(3,2) * as.numeric(ie(IniFlag,-1,1)),
                     ih=c(3,rep(2,n)) * as.numeric(ie(IniFlag,-1,1)),
                     ai=c(3,3) * as.numeric(ie(IniFlag,-1,1)),
                     av=c(3,3,2) * as.numeric(ie(IniFlag,1,1)),
                     ah=c(3,3,rep(2,n)) * as.numeric(ie(IniFlag,-1,1)),
                     si=rep(3,p) * as.numeric(ie(IniFlag,-1,1)),
                     sv=c(rep(3,p),2) * as.numeric(ie(IniFlag,-1,1)),
                     sh=c(rep(3,p),rep(2,n)) * as.numeric(ie(IniFlag,-1,1)),
                     mi={x <- c(3,3,3,3,3)
                         what <- as.numeric(IniFlag)
                         what[what==1] <- 1 #-1
                         what[what==0] <- 1
                         x <- what*x
                         as.numeric(x)},
                     mv={x <- c(3,3,3,3,3,2)
                         what <- as.numeric(IniFlag)
                         what[what==1] <- -1
                         what[what==0] <- 1
                         x <- what*x
                         as.numeric(x)},
                     mh={x <- c(3,3,3,3,3,rep(2,n))
                         what <- as.numeric(IniFlag)
                         what[what==1] <- -1
                         what[what==0] <- 1
                         x <- what*x
                         as.numeric(x)})
  out[[8]] <- as.integer(out[[8]])

  ##Struc 3,6,8,13
  out[[9]] <- as.integer(struc)
  out[[9]][c(1,2,3)] <- c(n,length(out[[5]]),struc3(out[[1]]))
  ## Inter
  ## equiv to fac() in SA --> use -5
  ## Seems dim 1 is base addr, dim 2 is index addr???
  if(!inherits(xx,"asr.special"))
    out[[10]] <- as.integer(c(-5, 0, match(xx,names(data))-1, match(yy,names(data))))
  ## Coords
  out[[11]] <- t(pmat[idx,])

  ## Argv
  if(!inherits(xx,"asr.special"))
    out[[12]] <- c(xx,yy) #obj
  ## isVariance
  out[[13]] <- switch(type,
                      ii=FALSE,iv=TRUE,ih=TRUE,
                      ai=FALSE,av=TRUE,ah=TRUE,
                      si=FALSE,sv=TRUE,sh=TRUE,
                      mi=FALSE,mv=TRUE,mh=TRUE)

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37), nrow=length(out[[5]]), ncol=2)
  dimnames(out[[15]]) <- list(out[[7]],c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
specialsOned <- function(fun,obj,type,data,struc,dist,init=NA)
{
  ## type
  ## i, v, h :    ident, variance, heterogeneous
  ## si, sv, sh : spherical

  p <- 1
  Rcov = attr(data,"Rcov")

  out <- vector(mode="list",length=15)

  if(inherits(obj,"asr.special")) {
    out[[1]] <- fun
    out[[2]] <- obj[[2]]
    out[[3]] <- obj
    object <- obj[[3]]
    out[[14]] <- out[[3]]
    out[[10]] <- as.integer(obj[[10]])
    out[[12]] <- obj[[12]]
  }
  else {
    object <- as.character(obj)
    ## Fun
    out[[1]] <- fun
    ## Call
    out[[2]] <- object
    ## Obj
    out[[3]] <- object
    out[[14]] <- out[[3]]
    ## Argv
    out[[12]] <- object
  }

  pwrpoints <- getPpoints(data, object, 3) # 3 is for pwrpoints in addr
  if(length(pwrpoints) > 0)
    dist <- pwrpoints
  else if(length(dist)==1 && is.na(dist))
    dist <- data[[object]]
  else
    if(is.character(dist)) dist <- eval(parse(text=dist))
  if(is.factor(dist))
    dist <- unique(as.numeric(as.character(dist)))
  else
    dist <- unique(dist)

  PP <- getPpoints(data, object, 1) # 1 is for design.points in addr
  if(sum(dim(PP)) > 0) {
    pmat <- c(dist,PP)
    pmat <- pmat[!duplicated(pmat)]
  }
  else {
    pmat <- dist
  }

  lvls <- unique(pmat)
  out[[4]] <- as.character(lvls)
  n <- length(out[[4]])
  ni <- switch(type,i=1,v=2,h=n+1,si=p,sv=p+1,sh=n+p)
  IniFlag <- TRUE
  if(all(is.na(init))) {
    IniFlag <- FALSE
    init <- rep(0.1,ni)
  }
  else {
    if(is.character(init)) init <- eval(parse(text=init))
    if(length(init) != ni)
      stop(paste(fun, "Wrong number of initial values\n"))
    if(type=="sh") p <- length(init)-n
    if(type=="sv") p <- length(init)-1
    if(type=="si") p <- length(init)
  }

  out[[5]] <- as.numeric(init)
  con <- matchCon(init)
  if(length(con)==0)
    out[[6]] <- switch(type,i="U",v=c("U","P"),h=c("U",rep("P",n)),
                       si=rep("U",p),sv=c(rep("U",p),p),sh=c(rep("U",p),rep("P",n)))
  else
    out[[6]] <- con
  attr(out[[5]], "set") <- IniFlag
  ## Lab
  out[[7]] <- switch(type,
                     i=paste("!",object,"!pow",sep=""),
                     v=paste("!",object,c("!pow","!var"),sep=""),
                     h=c(paste("!",object,"!pow",sep=""),paste("!",object,"_",lvls,sep="")),
                     si=paste("!",object,paste("!phi",seq(1,p),sep=""),sep=""),
                     sv=paste("!",object,c(paste("!phi",seq(1,p),sep=""),"!var"),sep=""),
                     sh=c(paste("!",object,paste("!phi",seq(1,p),sep=""),sep=""),
                       paste("!",object,"_",lvls,sep="")))

  ## Tgamma
  out[[8]] <- switch(type,
                     i=as.numeric(3),
                     v=as.numeric(c(3,2)),
                     h=as.numeric(c(3,rep(2,n))),
                     si=as.numeric(rep(3,p)),
                     sv=as.numeric(c(rep(3,p),2)),
                     sh=as.numeric(c(rep(3,p),rep(2,n))))
  out[[8]] <- as.integer(out[[8]])
  ##Struc 3,6,8,13
  out[[9]] <- as.integer(struc)
  out[[9]][c(1,2,3)] <- c(n,length(out[[5]]),struc3(out[[1]]))
  ## Inter
  if(!inherits(obj,"asr.special"))
    out[[10]] <- as.integer(c(n,0,match(object,names(data))-1,0))
  ##Coords
  if(Rcov) {
    if(length(dist) != length(unique(data[[object]])) || !all(dist == unique(data[[object]])))
      stop(paste("\nData not in ",object,"order\n"))
  }
  out[[11]] <- matrix(unique(pmat),nrow=1)
  out[[13]] <- switch(type,i=FALSE,v=TRUE,h=TRUE)

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37), nrow=length(out[[5]]), ncol=2)
  dimnames(out[[15]]) <- list(out[[7]],c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}

spCall <- function(sc)
{
  return(paste(my.dparse(recurse.del(sc)),collapse=""))
}
asr.levels <- function(x, Rcov = TRUE) {
  ## If levels of a factor are nested within at() sections
  ## Rstruc requires just the levels present in the given section
  ## rdflt and rlist call these special functions using data
  ## subsetted by at()
  ## Not called from gdflt or glist this way
  ##
  ## sort(unique()) may not be good enough
  ## TODO: check NA's
  if(length(Rcov)==0) Rcov <- FALSE
  if(Rcov) {
    full <- levels(x)
    present <- unique(x)
    ##return(full[sort(match(present,full))])
    return(full[match(present,full)])
  }
  else
    return(levels(x))
}
## getPdim <- function(dataFrame,obj)
## {
##   dims <- attr(dataFrame,"Control")$splXtras$dimTbl
##   which <- match(obj,dims$axis)
##   if(is.na(which))
##     return(0)
##   term <- dims$term[which]
##   ndim <- sum(as.numeric(as.character(dims$term) == term))
##   return(ndim)
## }
#' General variance structures.
#'
#' General variance structure spanning consecutive model terms.
#'
#' Typically, a variance structure applies to an individual term (main
#' effect or interaction) in the linear model, and there is no
#' covariance between model terms. Sometimes it is appropriate to
#' include a covariance, such as random coefficients regression, for
#' example. In such cases it is essential that the model terms be
#' contiguous and that the variance structure defined is the structure
#' required across all terms in the set. The model terms in
#' \code{form} are consequently not reordered. While \code{asreml}
#' will check the overall size of the included terms, it cannot check
#' that the order of effects matches the structure definition in
#' \code{vmodel}; care must be taken to ensure this is correct. Check
#' that the terms are conformable by considering the order of the
#' fitted effects and ensuring the first term of the direct product in
#' \code{vmodel} corresponds to the outer factor in the nesting of the
#' effects in \code{form}.
#'
#' @param form
#'
#' A model formula included verbatim in the \code{asreml()}
#' \code{random} argument.
#'
#' @param vmodel
#'
#' A direct product variance model for the set of terms given in
#' \code{form}.
#'
#' @aliases str
#' @name str
#' @usage str(form, vmodel)
#'
asr_str <- function(form, vmodel, data)
{
#  if(mode(substitute(obj))=="call" && inherits(obj,"asreml.special"))
#    stop("Argument to str() must be a formula\n")
  out <- vector(mode="list",length=14)

  ttf <- trimSpc(Terms(as.formula(form),keep.order=TRUE))
  ttm <- Terms(as.formula(vmodel),keep.order=TRUE)

  form.lab <- attr(ttf,"term.labels")

  form.var <- lapply(form.lab, function(x){
    dimnames(attr(Terms(formula(paste("~",x))),"factors"))[[1]]})

  vmodel.lab <- dimnames(attr(ttm,"factors"))[[2]]
  if(length(vmodel.lab) > 1)
    stop("Invalid vmodel formula in str()")
  vmodel.var <- dimnames(attr(ttm,"factors"))[[1]]
  ndim <- length(vmodel.var)

  Y <- lapply(vmodel.var, function(x,data) {
    evalWithData(x,data)
  },data)

  vn <- dimnames(attr(ttf,"factors"))[[1]]
  FVars <- lapply(vn,function(x,data) {
    evalWithData(x,data)
  },data)
  names(FVars) <- vn

  ## Check conformity
  ## (NOTE that xfa/rr must be fully specified in both form and vmodel)
  lcheck <- lapply(Y,function(x){
    getLevels(x$Lvls)
  })
  ## fsize = sum(levels( "Anim","Anim:time", ...))
  ##         inner sapply does prod(levels(strsplit("Anim:time")))
  vsize <- prod(sapply(lcheck,function(x)length(x)))
  fsize <- sum(unlist(lapply(form.var, function(x,FV,data){
    w <- sapply(x,function(z,FV,data){
      if(inherits(FV[[z]],"asr.special")) {
        if(FV[[z]]$Fun == "and")
          NA
        else
          length(getLevels(FV[[z]]$Lvls))
      }
      else {
        ifelse(is.factor(data[[z]]),length(levels(data[[z]])),1)
      }
    },FVars,data)
    prod(w)
  },FVars,data)),na.rm=TRUE)

  if(vsize != fsize)
    stop(paste("Size of direct product (",vsize,
               ") does not conform with total size of included terms (",fsize,")",sep=""))

  ## Fun
  out[[1]] <- "str"

  ## Call
  out[[2]] <- Y
  names(out[[2]]) <- sapply(Y,function(x)x$Call)

  ## Obj
  out[[3]] <- ttf
  ## Levels
  out[[4]] <- lapply(Y,function(x)x$Lvls)
  names(out[[4]]) <- sapply(Y,function(x)x$Fun)

  ## Initial & Con
  out[[5]] <- lapply(Y,function(x)x$Initial)
  out[[6]] <- lapply(Y,function(x)x$Con)
  names(out[[5]]) <- sapply(Y,function(x)x$Fun)
  names(out[[6]]) <- sapply(Y,function(x)x$Fun)
  ## Lab
  out[[7]] <- lapply(Y,function(x)x$Lab)
  names(out[[7]]) <- sapply(Y,function(x)x$Fun)

  ## Tgamma
  out[[8]] <- lapply(Y,function(x)x$Tgamma)
  names(out[[8]]) <- sapply(Y,function(x)x$Fun)

  ##Struc 3,6,8,13
  out[[9]] <- lapply(Y,function(x)x$Struc)
  names(out[[9]]) <- sapply(Y,function(x)x$Fun)

  ## Inter
  yy <- sapply(Y,function(x)x$Fun)
  out[[10]] <- vector(mode="list",length=length(yy))
  names(out[[10]]) <- yy
  for(i in 1:length(yy))
    out[[10]][[i]] <- c(-101,0,NA,0)


  ##Coords
  out[[11]] <- list(faconst=NULL,nuxPoints=NULL,coords=NULL)

  ## Argv
  out[[12]]  <- paste(unlist(lapply(form.var, function(x,FV,data){
    #y <- strsplit(x,":",fixed=TRUE)[[1]]
    w <- sapply(x,function(z,FV,data){
      if(inherits(FV[[z]],"asr.special") && FV[[z]]$Fun == "grp")
        FV[[z]]$Obj
      else if(inherits(FV[[z]],"asr.special"))
        FV[[z]]$Call
      else
        z
    },FVars,data)
    paste(w,collapse=":")
  },FVars,data)), collapse="+")
  ##out[[12]] <- out[[3]]

  ## isVariance
  out[[13]] <- {x <- unlist(lapply(Y,function(x)x$isVariance))
                if(any(is.na(x)))
                  NA
                else if(any(x))
                  TRUE
                else
                  FALSE
              }
  out[[14]] <- paste(form.lab, collapse="+") #spCall(sys.call())
  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam")
  oldClass(out) <- "asr.special"

  out[c(1:3,14)]
}
#' Known variance structures.
#'
#' Model function associating a known variance structure with a factor
#' in the data.
#'
#' If \code{source} inherits from class \code{Matrix}, \code{asreml}
#' will convert \code{source} internally to either sparse triplet form
#' (class \code{dsparseMatrix}), or dense vector form (class
#' \code{ddenseMatrix}) for processing.
#'
#' @param obj
#'
#' A factor in \code{data}.
#'
#' @param source
#'
#' The known inverse or relationship matrix:
#'
#' \itemize{
#'
#' \item a sparse inverse variance
#' matrix held in three column co-ordinate form in row major
#' order. This triplet matrix must have class \code{ginv}
#' from a call to \code{ainverse()}, or have attribute \code{INVERSE}
#' set to \code{TRUE}. For backwards compatability, a three column
#' data frame is also accepted. In either case, the \code{source} must
#' have a \code{rowNames} attribute.
#'
#' \item a sparse relationship
#' matrix held in three column co-ordinate form (as a matrix) in row major
#' order. If the attribute \code{INVERSE} is not set then
#' \code{FALSE} is assumed; a \code{rowNames}
#' attribute must be set.
#'
#' \item a \code{matrix} (or \code{Matrix} object) with a
#' \code{dimnames} attribute giving the levels of the model term
#' being defined. This may be a relationship matrix or its inverse; if
#' an inverse, it must have an attribute \code{INVERSE} set to
#' \code{TRUE}.
#'
#' \item a numeric vector of the lower triangular elements in row
#' major order. The vector must have a \code{rowNames} attribute, and
#' if an inverse structure, it must also have an \code{INVERSE}
#' attribute set to \code{TRUE}.  }
#'
#' @param singG
#'
#' Ignored if \code{source} has class \code{ginv} or attribute
#' \code{INVERSE}=\code{TRUE}; in such cases \code{source} must be one
#' of:
#'
#' \itemize{
#'
#' \item a sparse matrix in coordinate form with class \code{ginv}, or
#' attribute \code{INVERSE}=\code{TRUE}, or
#'
#' \item an object of class \code{matrix} or \code{Matrix}
#' with \code{INVERSE}=\code{TRUE}), or
#'
#' \item a vector assumed to be the lower triangle in row
#' major order with attribute \code{INVERSE}=\code{TRUE}.
#' }
#'
#' If \code{source} does not have class \code{ginv}, or the attribute
#' \code{INVERSE} is \code{FALSE} or is not set, and \code{singG} is
#' \code{NULL} (the default), then \code{source} is assumed a positive
#' definite relationship matrix and \code{singG} is reset to
#' \code{"PD"}. Otherwise, a character string giving the state of the
#' (to be inverted) \code{source} object:
#'
#' \describe{
#'
#' \item{\code{"PD"}}{positive definite (default)}
#'
#' \item{\code{"ND"}}{\code{source} is non-singular indefinite (positive
#' and negative roots). In this case
#' \code{asreml} ignores the indefinite condition and
#' proceeds}
#'
#' \item{\code{"PSD"}}{\code{source} is positive semi-definite. In this case,
#' \code{asreml} proceeds using lagrangian multipliers to process the
#' matrix. Two cases arise: whether the singularity arises because of
#' an effect has zero variance or whether it arises as a linear
#' dependence. An example of the first is when the GRM represents a
#' dominance matrix, and the list of genotypes includes fully inbred
#' individuals which by definition have no dominance. An example of
#' the second is when the list of genotypes includes clones}
#'
#' \item{\code{"NSD"}}{\code{source} is singular indefinite (positive, zero and
#' negative roots). The indefinite condition is ignored
#' and \code{asreml} proceeds using lagrangian multipliers as for
#' \code{"PSD"} matrices}.
#' }
#'
#' @aliases vm ide
#' @name knownStruc
NULL
#' @describeIn knownStruc Create a model term associating a known
#' relationship structure in \code{source} with a factor in
#' \code{data}.
#'
#' @usage vm(obj, source, singG=NULL)
#'
asr_vm <- function(obj, source, singG=NULL, data)
{
  out <- vector(mode="list",length=15)

  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special")) {
    ## extend to handle vm(grp()) etc
    out[[1]] <- "vm"
    out[[2]] <- spCall(sys.call())
    out[[3]] <- obj[[3]]
    out[[4]] <- obj[[4]]
    out[[10]] <- obj[[10]]
    ## if obj[[1]] is grp then do stuff to inter??????
    out[[11]] <- obj[[11]]
    out[[12]] <- obj[[12]]
    out[[14]] <- out[[2]] #obj[[14]]  ## FacNam
  }
  else {
    out[[1]] <- "vm"
    ## Call
    obj <- as.character(substitute(obj))
    out[[2]] <- spCall(sys.call())
    ## Obj
    out[[3]] <- obj
    out[[4]] <- NA # set below
    out[[14]] <- out[[2]]  ## FacNam
    out[[10]] <- c(-2,0,0,0) ## Inter
    ##Coords
    out[[11]] <- list()
    ## Argv
    out[[12]] <- obj
  }

  ## figure out what we have:
  ## if source inherits class 'ginv'
  ##    just read the object (df or 3 column matrix)
  ## if a matrix then check for rowNames, then dimnames
  ##    if singG=PD/PSD/ND/NSD then a relationship matrix to be inverted
  ##    if is.null(singG) assume PD unless class=ginv
  ## else
  ##    check if vector....

  if(is.character(source)) {
    expr <- as.name(source)
    source <- get(source)
  } else {
    expr <- substitute(source)
  }
  inv <- attr(source, "INVERSE")
  if(is.null(inv))
    inv <- FALSE
  inv <- (inv || inherits(source, "ginv"))

  if(!is.null(singG)) {
    if(inv)
      stop("'singG' set for an inverse object.", call.=FALSE)
    if(!is.element(casefold(singG), c("pd","psd","nd","nsd")))
      stop("'singG' must be NULL, or one of 'pd','psd','nd','nsd'.", call.=FALSE)
  }

  ## Assume a 3 col data frame is A^{-1}
  ## Assume a 3 col matrix is A^{-1} unless attr inverse=FALSE
  if(is.data.frame(source)) {
    if(ncol(source) == 3) { # Assume an inverse or ginv
      if(!inv) {
        stop("Source object ", deparse(expr),
             " must be a sparse inverse; coerce to a matrix.", call.=FALSE)
      }
      singG <- "ginv"
      inverse <- TRUE
      if(is.null(glvls <- attr(source,"rowNames")))
        stop("Missing 'rowNames' attribute.", call.=FALSE)

      if(is.unsorted(do.call("order",list(source[,1], source[,2]))))
        stop(deparse(expr)," does not appear to be in row-major order.",
             call.=FALSE)
      lev <- as.call(list(as.name("attr"),expr,"rowNames"))
    }
    else
      stop("Data frame must have 3 columns.", call.=FALSE)
  }
  else if(inherits(source, c("matrix", "Matrix"))) {
    if(inv) {
      singG <- "ginv"
      inverse <- TRUE
    }
    else {
      inverse <- FALSE
      singG <- if(is.null(singG)) "pd" else singG
    }
    nc <- if(inherits(source,"TsparseMatrix"))
            ncol(summary(source))
          else
            ncol(source)
    if(nc == 3) {
      if(inherits(source,"TsparseMatrix")) { ## gets sorted in '
        if(is.null(glvls <- dimnames(source)[[1]])) {
          stop("'source' is missing a 'dimnames' attribute 1.", call.=FALSE)
        }
        else {
          lev <- as.call(list(as.name("rownames"),expr))
        }
      }
      else {
        if(is.unsorted(do.call("order",list(source[,1], source[,2]))))
          stop(deparse(expr)," does not appear to be in row-major order.",
               call.=FALSE)
        if(is.null(glvls <- attr(source,"rowNames")))
          stop("'source' is missing a 'rowNames' attribute.", call.=FALSE)
        lev <- as.call(list(as.name("attr"),expr,"rowNames"))
      }
    }
    else {
      # Must have a dimnames attribute (15/1/20)
      if(is.null(glvls <- rownames(source))) {
        stop(expr, " is missing a 'dimnames' attribute.")
      } 
      # other forms must also use rowNames for extra levels
      if(casefold(singG) == "pd") {
        lev <- as.call(list(as.name("rownames"),expr))
      } else {
        lev <- as.call(list(as.name("attr"),expr,"rowNames"))
      }
    }
  }
  else { # vector
    if(inv) {
      singG <- "ginv"
      inverse <- TRUE
    }
    else {
      inverse <- FALSE
      singG <- if(is.null(singG)) "pd" else singG
      message("Note: ",deparse(expr), " assumed a relationship (not inverse) structure.")
    }
    if(is.null(glvls <- attr(source,"rowNames"))) {
      stop("'source' is missing a 'rowNames' attribute.")
    }
    else {
      lev <- as.call(list(as.name("attr"),expr,"rowNames"))
    }
  }

  if(!is.character(glvls))
    stop("'rowNames' must be of mode 'character'.", call.=FALSE)

  attr(out[[2]],"Expr") <- expr
  attr(out[[2]],"Source") <- deparse(expr)
  attr(out[[2]],"singG") <- singG
  attr(out[[2]],"inverse") <- inverse
  if(is.null(attr(source, "logdet")))
    attr(out[[2]],"logdet") <- -1e-37
  else
    attr(out[[2]],"logdet") <- attr(source, "logdet")
  if(is.null(attr(source, "geneticGroups")))
    attr(out[[2]],"geneticGroups") <- c(0.0,0.0)
  else
    attr(out[[2]],"geneticGroups") <- attr(source, "geneticGroups")

  if(out[[10]][1] == -2) { # from above
    v <- match(obj,names(data))
    if(!is.factor(data[[obj]]))
      stop("Argument to vm() must be a factor)\n", call.=FALSE)

    if(length(flvls <- levels(data[[obj]])) == 0)
      flvls <- unique(data[[obj]])
    not_genotyped <- symdiff(intersect(flvls,glvls), flvls)
    if(length(not_genotyped) > 0) {
      ##cat(not_genotyped,"\n")
      warning(obj," has levels in the data that are missing in ",expr,
              call. = FALSE, immediate. = FALSE)
    }
    out[[4]] <- lev
    ## Inter inter[4] holds the loc of giv in ainv (later)
    out[[10]] <- c(-2,0,v-1,0)
    ## Use this for ide!
    setattr(data[[obj]],"rowNames",c(glvls, not_genotyped))
  }

  ## Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <- ""

  ## Lab
  out[[7]] <- "" #"!var"
  ## Tgamma
  out[[8]] <- as.numeric(2)

  ##Struc 3,6,8,13
  ##Use -7 to flag Ainv for struc

  out[[9]] <- c(0,0,-7,0,0,1,0,0,0,0,0,0,0,0,0,0)
  names(out[[9]]) <- c("","",deparse(expr),rep("",13))

  ## isVariance
  out[[13]] <- FALSE
  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("vm",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc",
                  "Inter","Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
asr_oldide <- function(obj, source=NULL, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special"))
    stop("Argument to vm() must be a factor)\n")
  ####### if source=NULL then
  ####### relies on vm() coming first to set "rowNames"
  ####### levels of obj (re)set at end in asreml.q

  out <- vector(mode="list",length=14)
  out[[1]] <- "ide"
  ## Call
  obj <- as.character(substitute(obj))
  out[[2]] <- spCall(sys.call())
  ## Obj
  out[[3]] <- obj
  out[[14]] <- out[[2]]  ## FacNam

  v <- match(obj,names(data))
  if(!is.factor(data[[obj]]))
    stop("Argument to ide() must be a factor)\n")

  if(is.null(glvls <- attr(data[[obj]],"rowNames")))
    stop("'rowNames' attribute not set for ",obj,". ide() precedes vm()?",
         call. = FALSE)

  if(length(flvls <- levels(data[[obj]])) == 0)
    flvls <- unique(data[[obj]])
  if(any(is.na(match(flvls,glvls)))) {
    print(flvls[is.na(match(flvls,glvls))])
    stop(obj,"has levels in the data that are missing in ",substitute(source))
  }
  ## Probably don't need both of these
  setattr(data[[obj]],"rowNames",glvls)
  out[[4]] <- glvls
  ## Initial & Con
  IniFlag <- FALSE
  init <- 0.1
  out[[5]] <- as.numeric(init)
  attr(out[[5]], "set") <- IniFlag
  out[[6]] <- "P"

  ## Lab
  out[[7]] <- "!var"
  ## Tgamma
  out[[8]] <- as.numeric(2)

  ##Struc 3,6,8,13

  out[[9]] <- c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
  ## Inter inter[4] holds the loc of giv in ainv

  out[[10]] <- c(-2,0,v-1,0)

  ##Coords
  out[[11]] <- list()
  ## Argv
  out[[12]] <- obj
  ## isVariance
  ## Reset to TRUE in gdflt if single term
  out[[13]] <- FALSE
  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("ide",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc",
                  "Inter","Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @describeIn knownStruc Create a term with the levels of \code{vm},
#' and modelled by the homogeneous form of the identity variance
#' structure. The \code{vm} term must precede \code{ide} in the model
#' for the factor levels to be found.
#'
#' @usage ide(obj)
#'
asr_ide <- function(obj, source=NULL, data)
{
  out <- vector(mode="list",length=15)

  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special")) {
    ## extend to handle vm(grp()) etc
    out[[1]] <- "ide"
    out[[2]] <- spCall(sys.call())
    out[[3]] <- obj[[3]]
    out[[4]] <- obj[[4]]
    out[[10]] <- obj[[10]]
    ## if obj[[1]] is grp then do stuff to inter??????
    out[[11]] <- obj[[11]]
    out[[12]] <- obj[[12]]
    out[[14]] <- out[[2]] #obj[[14]]  ## FacNam
  }
  else {
    out[[1]] <- "ide"
    ## Call
    obj <- as.character(substitute(obj))
    out[[2]] <- spCall(sys.call())
    ## Obj
    out[[3]] <- obj
    out[[4]] <- NA # set below
    out[[14]] <- out[[2]]  ## FacNam
    ##Coords
    out[[11]] <- list()
    ## Argv
    out[[12]] <- obj
  }

  ## figure out what we have:
  ## if source inherits class 'ginv'
  ##    just read the object (df or 3 column matrix)
  ## if a matrix then check for rowNames, then dimnames
  ##    if singG=PD/PSD/ND/NSD then a relationship matrix to be inverted
  ##    if is.null(singG) assume PD unless class=ginv
  ## else
  ##    check if vector....

  if(!is.null(source)) {
    if(is.character(source)) {
      expr <- as.name(source)
      source <- get(source)
    }
    else
      expr <- as.name(substitute(source))
    ## Assume a 3 col data frame is A^{-1}
    ## Assume a 3 col matrix is A^{-1} unless attr inverse=FALSE
    if(is.data.frame(source)) {
      if(ncol(source) == 3) {
        if(is.null(glvls <- attr(source,"rowNames")))
          stop("Missing 'rowNames' attribute.", call.=FALSE)
        lev <- as.call(list(as.name("attr"),expr,"rowNames"))
      }
      else
        stop("ide() source Data frame must have 3 columns.", call.=FALSE)
    }
    else if(inherits(source, c("matrix", "Matrix"))) {
      nc <- if(inherits(source,"TsparseMatrix"))
              ncol(summary(source))
            else
              ncol(source)
      if(nc == 3) {
        if(inherits(source,"TsparseMatrix")) { ## gets sorted in '
          if(is.null(glvls <- dimnames(source)[[1]])) {
            stop("ide() 'source' is missing a 'dimnames' attribute.", call.=FALSE)
          }
          else {
            lev <- as.call(list(as.name("rownames"),expr))
          }
        }
        else {
          if(is.null(glvls <- attr(source,"rowNames")))
            stop("ide() 'source' is missing a 'rowNames' attribute.", call.=FALSE)
          lev <- as.call(list(as.name("attr"),expr,"rowNames"))
        }
      }
      else {
        if(is.null(glvls <- attr(source, "rowNames"))) { # rowNames gets priority - may be set from checkPSD
          if(is.null(glvls <- dimnames(source)[[1]])) {
            stop("'source' is missing a 'dimnames' attribute.")
          }
          else {
            lev <- as.call(list(as.name("rownames"),expr))
          }
        }
        else {
          lev <- as.call(list(as.name("attr"),expr,"rowNames"))
        }
      }
    }
    else { # vector
      if(is.null(glvls <- attr(source,"rowNames"))) {
        stop("ide() 'source' is missing a 'rowNames' attribute.")
      }
      else {
        lev <- as.call(list(as.name("attr"),expr,"rowNames"))
      }
    }

    if(!is.character(glvls))
      stop("'rowNames' must be of mode 'character'.", call.=FALSE)

    if(length(flvls <- levels(data[[obj]])) == 0)
      flvls <- unique(data[[obj]])
    not_genotyped <- symdiff(intersect(flvls,glvls), flvls)
    if(length(not_genotyped) > 0) {
      ##cat(not_genotyped,"\n")
      warning(obj," has levels in the data that are missing in ",expr,
              call. = FALSE, immediate. = FALSE)
    }
    setattr(data[[obj]],"rowNames",c(glvls, not_genotyped))
  }
  else {
    if(is.null(lev <- attr(data[[obj]],"rowNames")))
      stop("ide: 'rowNames' attribute not set for ",obj,". ide() precedes vm()?",
           call. = FALSE)
  }
  out[[4]] <- lev

  ## Initial & Con
  IniFlag <- FALSE
  out[[5]] <- as.numeric(NA)
  out[[6]] <- ""

  ## Lab
  out[[7]] <- "!var"
  ## Tgamma
  out[[8]] <- as.numeric(2)

  ##Struc 3,6,8,13

  out[[9]] <- c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)

  ## Inter inter[4] holds the loc of giv in ainv
  v <- match(obj,names(data))
  out[[10]] <- c(-2,0,v-1,0)

  ## isVariance
  out[[13]] <- FALSE
  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("vm",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc",
                  "Inter","Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' @describeIn modelFunctions Direct sum structures for residual
#' models.
#'
#' @param model
#'
#' A formula of the form \code{~A+B+...|Z}, where \code{A} and
#' \code{B} define variance matrices for simple or compound model
#' terms, and \code{Z} is a simple conditioning factor whose levels
#' identify and determine the number of sub-matrices in the direct
#' sum. The \code{"|"} operator is applied associatively and operates
#' with all terms on its left; that is, \code{A+B|C} implies
#' \code{(A+B)|C} and is equivalent to \code{A|C+B|C}.
#'
#' @param levels
#'
#' A list of length the number of terms in the left hand side of
#' \code{model} that are separated by \code{"+"}. The components of
#' \code{levels} are vectors of unique values of \code{Z}. If there is
#' only one term in the left hand side of \code{model} (or if the
#' context allows, see examples) then \code{levels} may be a
#' vector. If \code{levels} is numeric, then these are ordinal numbers 
#' that refer to the sections defined by Z in \code{unique(Z)} order. 
#' If \code{NULL}, the default is to use \code{unique(Z)}.
#'
#' @param outer
#'
#' if \code{TRUE}, independent blocks of correlated observations are
#' modelled with common variance and correlation parameters; the
#' blocks can be of different sizes.
#'
#' @examples \dontrun{
#'
#' ## separable autoregressive residual model at each level of Site
#' residual = ~ dsum(~ ar1(Column):ar1(Row) | Site)
#'
#' ## different residual models at different levels of site
#' ## the ordinals in the levels list refer to the unique values of
#' ## Site in unique(Site) order.
#' residual = ~ dsum(~ ar1(Column):ar1(Row) + id(Column):ar1(Row) | Site,
#'                 levels = list(c(1,3), c(2,4)))
#'
#' ## equivalent
#' residual = ~ dsum(~ ar1(Column):ar1(Row) | Site, levels=c(1,3))
#'           + dsum(~ id(Column):ar1(Row)  | Site, levels=c(2,4))
#'
#' ## "biological" Date within Plot
#' residual = ~ dsum(~ ar1(Date) | Plot, outer=TRUE)
#'
#' ## "explicit" times
#' residual = ~ dsum(~ exp(Date) | Plot, outer=TRUE)
#' }
#'
#' @usage dsum(model, levels=NULL, outer=FALSE)
#'
asr_dsum <- function(model, levels=NULL, outer=FALSE, data) {

  ## model is a formula: ~ A + B + C | D
  ## where A,B,C are model terms involving variance structures
  ## Eg for R (scale=1):
  ##
  ## ~ar1v(Col):ar1(Row) + idv(Col):id(Row) | Site
  ##
  ## levels is a list of length the number of terms separated by "+",
  ##   the elements of which are vectors of levels of D.
  ## Eg
  ## levels=list(c('Warwick','Dalby'),'Gatton')
  ## So,
  ## dsum(~ar1v(Col):ar1(Row) + idv(Col):id(Row) | Site,
  ##      levels=list(c('Warwick','Dalby'),'Gatton'))
  ##
  ## means fit an arXar at sites W & D, and an id at G
  ##
  ## Arthur's !SUBSECTION examples on P147 of the SA V3 guide
  ## dsum(~ar1v(bid) | auction, outer=TRUE)
  ## dsum(expv(date) | plot, outer=TRUE)

  call <- spCall(sys.call())

  ## split model on "|"
  m1 <- formulaTerms(model, sep="|")
  if(length(m1) != 2)
    stop("Invalid dsum model - missing '|'?")
  ## split m1 on "+"
  lhs <- formulaTerms(m1[[1]], sep="+")
  cf <- attr(terms(m1[[2]]),"term.labels")
  if(length(lhs) > 1) {
    if(is.list(levels)) {
      if(length(levels) != length(lhs))
        stop("levels' must be a list of length ",length(lhs), call.=FALSE)
    }
    else if(is.null(levels)) {
      if(length(lhs) != length(unique(data[[cf]])))
         stop("Insufficient variance structures for ",
              length(unique(data[[cf]])), " sections", call.=FALSE)
      levels <- as.list(seq(1, length(unique(data[[cf]]))))
    }
    else
      stop("levels' must be a list of length ",length(lhs), call.=FALSE)
  }

  if(outer && length(lhs) > 1)
    stop("dsum: Only a single term allowed if 'outer=TRUE'", call.=FALSE)
  ##
  ## return a list (one for each level of cf) of special
  ##        function evaluations

  if(is.null(levels))
    ds.lev <- V.lev <- unique(data[[cf]])
  else if(is.list(levels)) {
    V.lev <- levels
    for(ll in seq(1,length(V.lev))) {
      if(is.numeric(V.lev[[ll]])) V.lev[[ll]] <- unique(data[[cf]])[V.lev[[ll]]]
    }
    ds.lev <- unlist(V.lev)
  }
  else if(is.numeric(levels))
    ds.lev <- V.lev <- unique(data[[cf]])[levels]
  else
    ds.lev <- V.lev <- levels
  if(!all(is.element(ds.lev, unique(data[[cf]]))))
     stop("Elements in 'levels' argument not in data")

##   if(is.list(V.lev)) {
##     V.len <- sum(sapply(V.lev,function(x)length(x)))
##     V.nam <- unlist(sapply(V.lev,function(x)x))
##   }
##   else {
##     V.len <- length(V.lev)
##     V.nam <- V.lev
##   }

  ## model terms fixed, mixed, random, residual, Csparse, dense, data
  model.terms <- modelTerms(residual=m1[[1]],data=data)$residual
  if(outer && length(model.terms$Vars) > 1)
    stop("Only one dimension allowed if 'outer=TRUE'")

  ## look-up table "section, term, fun" (section is levels of cf)
  if(is.list(V.lev)) {
    section.term <- data.table(
      term=rep(sapply(lhs,function(x)as.character(x)[2]),
        times=sapply(V.lev,function(x)length(x))),
      section=unlist(lapply(V.lev,function(x)x)))
  }
  else {
    section.term <- data.table(
      term=rep(as.character(m1[[1]])[2],times=length(V.lev)),
      section=V.lev)
  }
  section.term$fun <- rep(call, nrow(section.term))

  ## expanded formula
  ## dQuote misbehaved on Linux - utf chars??
  at.form <- formula(paste("~", paste( paste("at(",cf,", ",paste0('"',section.term$section,'"'),"):",
                                             section.term$term),collapse="+")))
##  V <- vector(mode="list", length=V.len)
##  names(V) <- V.nam
##  if(is.list(V.lev)) {
##    for(ll in seq(1,length(V.lev))) {
##      V[[ll]] <- evalSpecials(lhs[[ll]],data,id2idv=FALSE)
##    }
##  }
##  else if(is.vector(V.lev)) { # only one formula allowed
##    for(ll in seq(1,length(V.lev))) {
##      V[[ll]] <- evalSpecials(lhs[[1]],data,id2idv=FALSE)
##    }
##      }

  ## some checks
  #dims <- sapply(V,function(x)length(x))
  #dnz <- dims[which(dims > 0)]
  ## base funs identical and/or all.equal seem spooked by data.table
  #if(sum(dnz-rep(dnz[1],length(dnz))) > 1e-5)
  #  stop("Unequal dimensions")
  ## set missing to id
  ##dz <- which(dims == 0)
  ##if(length(dz)) {
  ##  dn <- names(V[[which(dims > 0)[1]]])
  ##  model <- formula(paste("~",paste(paste("id(",dn,")",sep=""),collapse=":")))
  ##  for(i in names(V)[dz])
  ##    V[[i]] <- evalSpecials(model,data,id2idv=FALSE)
  ##}

  ##V

  out <- vector(mode="list",length=14)
  # Fun
  out[[1]] <- "dsum"

  # Call
  out[[2]] <- call

  # Obj
  out[[3]] <- cf

  # Levels

  if(any(is.na(match(ds.lev,levels(data[[cf]])))))
    stop(paste("Not all levels specified in dsum() match those in",cf,"\n"))

  out[[4]] <- ds.lev

  # Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <- ""

  # Lab
  out[[7]] <- ""

  # Tgamma

  out[[8]] <- as.integer(2)

  #Struc 3,6,8,13
  v <- match(cf,names(data))
  ## struc[9] = column in data of conditioning factor
  ##            flag 'outer=TRUE' with struc 7 & 9 (used in knownStruc.cpp)
  out[[9]] <- as.integer(c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))
  if(outer) {
    out[[9]][9] <- -v
    out[[9]][7] <- -match(model.terms$Vars[[1]]$Argv[1],names(data))
    model.terms$Vars[[1]]$Struc[9] <- -v
    model.terms$Vars[[1]]$Struc[7] <- -match(model.terms$Vars[[1]]$Argv[1],names(data))
  }

  ## Inter - for the 'at' factor
  out[[10]] <- as.integer(c(-98,0,v-1,0))

  #Coords
  out[[11]] <- list()

  # Argv
  out[[12]] <- c(unique(unlist(lapply(model.terms$Vars,function(x)x$Argv)))) #cf

  # isVariance
  out[[13]] <- FALSE

  out[[14]] <- out[[2]]

  ## attributes of "Call"
  attr(out[[2]],"model.terms") <- model.terms
  attr(out[[2]],"section.term") <- section.term
  attr(out[[2]],"at.form") <- at.form
  attr(out[[2]],"conditioning.factor") <- cf
  attr(out[[2]],"outer") <- outer

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam")
  oldClass(out) <- "asr.special"

  out
}
asr_mthr <- function(obj, init=1.0, data, ...)
{
  ## multinomial threshold residual model
  ## k categories, t = k-1 thresholds
  ## obj should be 'trait' (which is not in data)

  out <- vector(mode="list",length=15)

  out[[1]] <- "mthr"
  out[[2]] <- spCall(sys.call())
  out[[13]] <- NA

  obj <- as.character(substitute(obj))
  if(obj != "trait")
    stop("Argument to mthr() must be 'trait'")
  out[[3]] <- obj
  out[[14]] <- out[[3]]
  lhs <- attr(data, "traits")$lhs
  if(length(lhs) > 1)
    lvls <- lhs
  else
    lvls <- levels(data[[lhs]])

  t <- length(lvls) - 1
  out[[4]] <- as.character(seq(1,t))

  ## Inter
  out[[10]] <- as.integer(c(t, 0, match(obj,names(data))-1, 0))
  ##Coords
  out[[11]] <- list()
  ## Argv
  out[[12]] <- obj

  init <- matrix(0,nrow=t,ncol=t) + diag(rep(1.0,t))
  x <- t(lower.tri(init, diag=TRUE))
  out[[5]] <- init[x]
  out[[6]] <- rep("F",sum(x))


  out[[7]] <- paste("!","trait","_",
                    paste(lvls[col(x)[x]],lvls[row(x)[x]],sep=":"),sep="")
  out[[8]] <- as.integer(rep(2,sum(x)))
  out[[9]] <- as.integer(c(t,sum(x),9,0,0,0,0,0,0,0,0,0,0,0,0,0))

  out[[15]] <- numeric(0)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc",
                  "Inter","Coords","Argv","isVariance","FacNam","Bounds")
  class(out) <- "asr.special"
  out
}

Subset_spc <- function(obj, subset, data, ...)
{
  #print(obj)
  out <- vector(mode="list",length=15)
  ## Fun
  out[[1]] <- "Subset"

  # Call
  out[[2]] <- spCall(sys.call())

  # Obj
  obj <- as.character(obj)
  out[[3]] <- obj

  dd <- data[[obj]]
  if(!is.factor(dd))
    stop(paste("Argument",obj,"to Subset() must be a factor\n"))

  # Levels
  if(missing(subset))
    sub.lev <- levels(dd)
  else {
    sub.lev <- eval(subset)
  }

  if(is.numeric(sub.lev)) {
    sub.ilev <- sub.lev
    sub.lev <- levels(dd)[sub.lev]
  }
  else {
    sub.ilev <- match(sub.lev, levels(dd))
    if(any(is.na(sub.ilev)))
      stop("Subset levels not matched in ",obj)
  }

  out[[4]] <- sub.lev
  storage.mode(sub.ilev) <- "integer"
  attr(out[[4]], "ilevels") <- sub.ilev

  # Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <- ""

  # Lab
  out[[7]] <- ""

  # Tgamma

  out[[8]] <- as.integer(2)

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  ## Inter - for the 'sbs' factor
  ## 1 -27
  ## 2 base addr in X of ilev (set in AIdata)
  ## 3 base in data of defining fac
  ## 4 length of ilev
  out[[10]] <- as.integer(c(-27,0,match(obj,names(data))-1,length(sub.ilev)))

  #Coords
  out[[11]] <- list()

  # Argv
  out[[12]] <- obj

  # isVariance
  out[[13]] <- FALSE

  out[[14]] <- paste("Subset(",obj,")", sep="")

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("id",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
asr_sbs <- function(obj, data, ...) {
  obj <- as.character(substitute(obj))
  sublist <- attr(data, "Subset")
  if(!is.element(obj, names(sublist)))
    stop(obj, " not matched in subset list")
  if(!inherits(sublist[[obj]], "asr.special"))
    stop("Internal error; class(sublist)")

  base <- sublist[[obj]]$Obj
  sublist[[obj]]$Fun <- "sbs"
  sublist[[obj]]$Call <- spCall(sys.call())
  sublist[[obj]]$Obj <- obj
  ## set inter(2) to the element of attr(data,"Subset")
  ## later setup and change to addr in X in AIdata.cpp
  sublist[[obj]]$Inter[2] <- match(obj, names(attr(data,"Subset")))
  sublist[[obj]]$Inter[3] <- match(base, names(data)) - 1
  sublist[[obj]]$FacNam <- spCall(sys.call())

  return(sublist[[obj]])
}
Units_spc <- function(obj, n, data, ...)
{
  out <- vector(mode="list",length=15)
  ## Fun
  out[[1]] <- "Units"

  # Call
  out[[2]] <- spCall(sys.call())

  # Obj
  obj <- as.character(obj)
  out[[3]] <- obj

  dd <- data[[obj]]

  if(!is.factor(dd))
    stop("Argument ",obj," to Units() must be a factor.")

  ## Levels
  x <- type.convert(as.character(dd), as.is=TRUE)
  if(!is.na(n)) {
    if(n == 0) {
      x[ x == 0 ] <- NA
    }
    else {
      fl <- if(is.numeric(n)) levels(dd)[n] else n
      x[ x != fl ] <- NA
    }
  }
  new.lev <- row.names(data)[!is.na(x)]

  if(length(new.lev) == nrow(data))
    message("Units: all records selected", call.=FALSE)

  out[[4]] <- new.lev
  new.ilev <- match(new.lev, row.names(data))
  storage.mode(new.ilev) <- "integer"
  attr(out[[4]], "ilevels") <- new.ilev

  # Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <- ""

  # Lab
  out[[7]] <- ""

  # Tgamma

  out[[8]] <- as.integer(2)

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  ## Inter - for the 'uni' factor
  ## 1 -9
  ## 2 0
  ## 3 base in data of defining fac
  ## 4 n
  out[[10]] <- as.integer(c(-9, 0, match(obj,names(data))-1,
                            if(is.na(n) || n==0) 0 else match(fl,levels(dd))))

  #Coords
  out[[11]] <- list()

  # Argv
  out[[12]] <- obj

  # isVariance
  out[[13]] <- FALSE

  out[[14]] <- paste("Subset(",obj,")", sep="")

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("id",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
asr_uni <- function(obj, data, ...) {
  obj <- as.character(substitute(obj))
  sublist <- attr(data, "Units")
  if(!is.element(obj, names(sublist)))
    stop(obj, " not matched in Units list")
  if(!inherits(sublist[[obj]], "asr.special"))
    stop("Internal error; class(sublist)")

  base <- sublist[[obj]]$Obj
  sublist[[obj]]$Fun <- "uni"
  sublist[[obj]]$Call <- spCall(sys.call())
  sublist[[obj]]$Obj <- obj
  sublist[[obj]]$Inter[3] <- match(base, names(data)) - 1
  sublist[[obj]]$FacNam <- spCall(sys.call())

  return(sublist[[obj]])
}
Levels_spc <- function(obj, Levels, data, ...)
{
  out <- vector(mode="list",length=15)
  ## Fun
  out[[1]] <- "Levels"

  # Call
  out[[2]] <- spCall(sys.call())

  # Obj
  obj <- as.character(obj)
  out[[3]] <- obj

  dd <- data[[obj]]
  if(!is.factor(dd))
    stop(paste("Argument",obj,"to Levels() must be a factor.\n"))

  # Levels
  if(missing(Levels))
    new.lev <- levels(dd)
  else {
    new.lev <- eval(Levels)
  }
  if(length(new.lev) != length(levels(dd)))
    stop("Length of new levels in 'combine' must be ",length(levels(dd)))
  if(!is.character(new.lev))
    stop("Arg to 'Levels' must be a character vector.")

  levels(dd) <- new.lev

  out[[4]] <- levels(dd)
  new.ilev <- match(new.lev, levels(dd))
  storage.mode(new.ilev) <- "integer"
  attr(out[[4]], "ilevels") <- new.ilev

  # Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <- ""

  # Lab
  out[[7]] <- ""

  # Tgamma

  out[[8]] <- as.integer(2)

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  ## Inter - for the 'gpf' factor
  ## 1 -37
  ## 2 base addr in X of ilev (set in AIwork)
  ## 3 base in data of defining fac
  ## 4 length of 'Levels' vector
  out[[10]] <- as.integer(c(-37,0,match(obj,names(data))-1,length(Levels)))

  #Coords
  out[[11]] <- list()

  # Argv
  out[[12]] <- obj

  # isVariance
  out[[13]] <- FALSE

  out[[14]] <- paste("Levels(",obj,")", sep="")

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("id",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
asr_gpf <- function(obj, data, ...) {
  obj <- as.character(substitute(obj))
  sublist <- attr(data, "Combine")
  if(!is.element(obj, names(sublist)))
    stop(obj, " not matched in 'combine' list")
  if(!inherits(sublist[[obj]], "asr.special"))
    stop("Internal error; class(sublist)")

  base <- sublist[[obj]]$Obj
  sublist[[obj]]$Fun <- "gpf"
  sublist[[obj]]$Call <- spCall(sys.call())
  sublist[[obj]]$Obj <- obj
  ## set inter(2) to the element of attr(data,"Combine")
  ## later setup and change to addr in X in AIdata.cpp
  sublist[[obj]]$Inter[2] <- match(obj, names(attr(data,"Combine")))
  sublist[[obj]]$Inter[3] <- match(base, names(data)) - 1
  sublist[[obj]]$FacNam <- spCall(sys.call())

  return(sublist[[obj]])
}
#' @describeIn modelFunctions Treatment contrasts
#'
#' @param contr
#'
#' An integer vector of contrast coefficients parallel to \code{levels(obj)}.
#'
#' @usage C(obj, contr)
#'
asr_C <- function(obj, contr, data) {
  ## contr is a n-vector of contrast coefficients

  out <- vector(mode="list",length=15)
  ## Fun
  out[[1]] <- "C"

  # Call
  out[[2]] <- spCall(sys.call())

  # Obj
  obj <- as.character(substitute(obj))
  out[[3]] <- obj

  dd <- data[[obj]]
  if(!is.factor(dd))
    stop(paste("Argument",obj,"to C() must be a factor\n"))

  # Levels
  if(missing(contr))
    stop("Missing contrast vector")
  else {
    storage.mode(contr) <- "integer"
    L <- eval(contr)
  }
  if(length(L) != length(levels(dd)))
    stop("contr vector shoud have ",length(levels(dd))," coefficients")

  out[[4]] <- "1"
  attr(out[[4]], "contr") <- L

  # Initial & Con
  out[[5]] <- as.numeric(NA)
  out[[6]] <- ""

  # Lab
  out[[7]] <- ""

  # Tgamma

  out[[8]] <- as.integer(2)

  #Struc 3,6,8,13
  out[[9]] <- as.integer(c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))

  ## Inter
  ## 1 -25
  ## 2 base addr in X of contr (to be set in AIwork (wrkSpace))
  ## 3 base in data of defining fac
  ## 4 length of contr
  contr.lst <- attr(data, "Contr")
  if(is.null(contr.lst))
    contr.lst <- list(contr)
  else
    contr.lst[[length(contr.lst)+1]] <- contr
  setattr(data, "Contr", contr.lst)
  out[[10]] <- as.integer(c(-25,length(contr.lst),match(obj,names(data))-1,length(L)))

  #Coords
  out[[11]] <- list()

  # Argv
  out[[12]] <- obj

  # isVariance
  out[[13]] <- FALSE

  out[[14]] <- out[[2]]

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("id",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
#' User-defined variance models.
#'
#' Specify an external function that provides a variance matrix, or
#' its inverse, and the respective derivative matrices with respect to
#' the parameters.
#'
#' The \code{own} variance model allows users to specify external
#' variance structure(s). This requires the user to provide an
#' \code{R} function that accepts the current set of parameters, forms
#' the variance matrix and a full set of derivative matrices, and
#' return these in a list object. The \code{R} function may invoke
#' compiled code if necessary. Before each iteration, \code{asreml}
#' calls the nominated function with the current parameter estimates
#' to update the variance matrix and derivatives.
#'
#' @param obj A factor in \code{data}, or a constructed model term
#' such as mbf().
#'
#' @param fun
#'
#' The name (as a character string) of an \code{R} function to compute
#' the variance matrix and its derivatives. This function must accept
#' two input arguments:
#'
#' \describe{
#'
#' \item{order}{A scalar giving the dimension of the structure being
#' defined;}
#'
#' \item{kappa}{A numeric vector of \eqn{1, \ldots, k}
#' parameter values;}
#'
#' }
#'
#' and return a list of \code{k+1} matrices: the variance matrix, or
#' its inverse, followed by the \code{k} derivative matrices. This
#' list may have an attribute \code{INVERSE}, a logical scalar
#' identifying the structures as variance matrices or their inverses;
#' if \code{INVERSE} is absent the default is \code{FALSE}.
#'
#' @param init
#'
#' The \eqn{k}-vector of parameter values.
#'
#' @param type
#'
#' A character vector defining the type of each parameter from the set
#' \code{"V"}, \code{"G"}, \code{"R"}, \code{"C"}, \code{"P"} and
#' \code{"L"}, identifying each parameter as type \emph{variance},
#' \emph{variance-ratio}, \emph{correlation}, \emph{covariance},
#' \emph{positive correlation} or \emph{loading}, respectively.
#'
#' @param con
#'
#' A character vector from the set \code{"F"}, \code{"P"} or
#' \code{"U"} setting the boundary constraint for each parameter to
#' Fixed, Positive or Unconstrained, respectively. The default is "U"
#' for all types except "P" for type \emph{positive correlation}.
#'
#' @aliases own
#' @name own
#' @usage own(obj, fun, init=NULL, type=NULL, con=NULL)
#'
#' @examples \dontrun{
#' ## An own ar1 function
#' data(shf)
#' ar1.asr <- asreml(yield ~ Variety,
#'                   residual = ~ar1(Row):own(Column,"ar1",0.1,"R"),
#'                   data=shf)
#'
#' ## where the function 'ar1' is defined as:
#'
#' ## ar1 <- function(order, kappa) {
#' ##   t <- 1:order
#' ##   H <- abs(outer(t,t,"-"))
#' ##   V <- kappa^H
#' ##   ## derivative
#' ##   dV <- H*(kappa^(H-1))
#' ##   return(list(V, dV))
#' ## }
#' }
#'
asr_own <- function(obj, fun, init=NULL, type = NULL, con=NULL, data) {
  ##
  ## R function myowngdg provides G and its derivatives
  ## args are:
  ## 1. order of the structure (length(levels(obj)))
  ## 2. numeric vector of parameters, length k
  ## return:
  ## 1. a list of (k+1) matrices:
  ##    a) G
  ##    b) derivative matrices wrt the k parameters
  ##

  ## Check missing args
  if(is.null(init)) stop("own: 'init' is missing with no default")
  if(is.null(type)) stop("own: 'type' is missing with no default")
  if(length(init) != length(type)) {
    stop("own: lengths of 'init' and 'type' do not match")
  }
  if(!is.null(con)) {
    if(length(con) != length(type))
      stop("own: lengths of 'con' and 'type' do not match")
    con <- casefold(con, upper=TRUE)
  }

  typeCode <- c("V","G","R","C","P","L")

  out <- vector(mode="list",length=15)
  ## Fun
  out[[1]] <- "own"

  # Call
  out[[2]] <- spCall(sys.call())
  attr(out[[2]], "OWN") <- fun

  # Obj
  if(mode(substitute(obj))=="call" && inherits(obj,"asr.special")) {

    out[[3]] <- obj$Call
    out[[4]] <- obj$Lvls
    out[[10]] <- obj$Inter
    out[[14]] <- obj$FacNam
    n <- length(obj$Lvls)
    obj <- obj$Call
  } else {
    obj <- as.character(substitute(obj))
    out[[3]] <- obj
    out[[14]] <- out[[3]] ## facnam
    dd <- data[[obj]]
    if(!is.factor(dd))
      stop(paste("Argument",obj,"to own() must be a factor\n"))
    ## Levels
    out[[4]] <- levels(dd)
    ## Inter
    n <- length(levels(dd))
    out[[10]] <- as.integer(c(n, 0, match(obj,names(data))-1, 0))
  }
  # Initial & Con
  out[[5]] <- init
  attr(out[[5]], "set") <- TRUE
  if(is.null(con)) {
  ## Default boundary constraints
  B <- c("U","U","U","U","P","U")
  names(B) <- typeCode
  out[[6]] <- B[casefold(type, upper=TRUE)]  ## (Variance,Gamma,coR,Cov,Pos cor,Loading)
  }
  else {
    out[[6]] <- con
  }

  ## Lab
  out[[7]] <- paste("!", obj, ".", seq(along=type), sep="")

  ## Tgamma
  ty <- c(1,2,3,4,3,6)
  names(ty) <- typeCode
  out[[8]] <- ty[casefold(type, upper=TRUE)]

  ## Struc 3,6,8,13 (struc(3)==7 triggers own models)
  out[[9]] <- as.integer(c(n,length(init),7,0,0,0,0,0,0,0,0,0,0,0,0,0))
  names(out[[9]]) <- c("", "", fun, rep("",13))

  #Coords
  out[[11]] <- list()

  # Argv
  out[[12]] <- obj

  ## isVariance
  out[[13]] <- sum(as.numeric(is.element(c("v","g"), casefold(type)))) > 0

  ## Bounds
  out[[15]] <- matrix(c(-1e37,1e37),nrow=1,ncol=2)
  dimnames(out[[15]]) <- list("id",c("LB","UB"))

  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Con","Lab","Tgamma","Struc","Inter",
                  "Coords","Argv","isVariance","FacNam","Bounds")
  oldClass(out) <- "asr.special"
  out
}
getLevels <- function(spc__object) {
  ## function to return the levels of a model term from
  ##   an object of class "asr.special".
  ##   The Lvls component may be a function, vector, or expression.

  if(is.expression(spc__object) || is.call(spc__object))
    return(eval(spc__object))

  if(is.element(mode(spc__object), c("numeric","character","list")))
     return(spc__object)

  if(mode(spc__object)=="function")
    return(spc__object())
}
evalWithData <- function(expr,data=NULL,evaluate=TRUE)
{
  ## add 'data' arg to a special function call
  makeExpr <- function(ee,data) {

    if(is.character(ee))
      ee <- parse(text=ee)
    switch(mode(ee[[1]]),
           "call" = {
             ee11 <- as.character(ee[[1]][[1]])
              if(!is.na(match(ee11, c(Spcls$Fun,"sections")))) {
               if(!is.null(data) && !is.element("data",names(ee[[1]]))) {
                 ll <- length(ee[[1]])+1
                 nn <- names(ee[[1]])
                 if(is.null(nn)) nn <- rep("",(ll-1))
                 ee[[1]][[ll]] <- as.name(data)
                 names(ee[[1]]) <- c(nn,"data")
               }
               ee[[1]][[1]] <- as.name(paste("asr_", ee[[1]][[1]],sep = ""))
             }
             else
               ee[1] <- ee[1]
             ## trap formulae args to struc here
             if((ee11 != "~") && (length(ee[[1]]) > 1)) {
               for(i in 2:length(ee[[1]])) {
                 ee[[1]][i] <-makeExpr(ee[[1]][i],data)
               }
             }
           },
           "numeric" = {
             ee[1] <- ee[1]
           },
           "name" = {
             ee[1] <- ee[1]
           },
           "character" = {
             ee[1] <- ee[1]
           },
           "logical" = {
             ee[1] <- ee[1]
           },
           ee[1] <- ee[1])
    ee
  }

  z <- as.character(substitute(data))
  expr <- makeExpr(expr,z)
  if(length(expr[[1]]) == 1 & mode(expr[[1]]) == "name")
    expr <- as.character(expr[1])
 if(evaluate)
   return(eval(expr))
  else
    return(expr)
}
evalSpecials <- function(tt,data,id2idv=FALSE)
{
  ## Specials
  if(inherits(tt,"formula") && !inherits(tt,"terms"))
    tt <- terms(tt, specials=Spcls$Fun)
  else
    stop("Internal error: tt must be a formula or terms object")

  dimensions <- dimnames(attr(tt,"factors"))[[1]]
  ##if(length(dimensions) > 1) stop("Internal error: evalSpecials")
  X <- vector(mode="list", length=length(dimensions))
  names(X) <- dimensions

  howMany <- unlist(lapply(attr(tt,"specials"),function(x)length(x)))
  fun <- list(trm=unlist(attr(tt,'specials')),
              fun=rep(names(attr(tt,"specials")),times=howMany))
  model <- vector(mode="character",length=length(dimensions))
  names(model) <- dimensions
  is.set <- vector(mode="logical",length=length(dimensions))
  names(is.set) <- dimensions
  if(sum(howMany)) {
    which <- match(seq(1,length(dimensions)),fun$trm)
    model[is.na(which)] <- "id"
    model[!is.na(which)] <- fun$fun[which[!is.na(which)]]
    is.set[is.na(which)] <- FALSE
    is.set[!is.na(which)] <- TRUE
  }
  else {
    model <- rep("id",length(dimensions))
    is.set <- rep(FALSE,length(dimensions))
  }
  names(is.set) <- dimensions
  names(model) <- dimensions
  if(id2idv) {
      if(all(model=="id")) model[1] <- "idv"
  }
  for(v in dimensions) {
    if(is.set[v])
      X[[v]] <- evalWithData(v,data)
    else
      X[[v]] <- do.call(paste("asr_",model[v],sep=""),list(obj=v, data=data))
  }
  if(length(dimensions) == 1)
    return(X[[1]])
  else
    return(X)
}
modelList <- function(tt, data)
{
  ## tt is a terms object
  rsp <- attr(tt,"response")
  ## R breaks long dimnames() strings with \n; Var names won't match later!!!!
  tt.vars <- gsub("[\r\n]", "", dimnames(attr(tt,"factors"))[[1]])
  tt.terms <- dimnames(attr(tt,"factors"))[[2]]
  idx <- seq(along=tt.vars)
  if(any(rsp > 0))
    idx <- idx[-rsp]
  ## out is an evaluated list of length no. of variables

  ## May have a fixed form like y~1 (length(tt.terms)==0 in that case)
  if(rsp && length(tt.terms) == 0) {
      out <- vector(mode="list", length=1)
      out[[1]] <- NULL #"(Intercept)"
  }
  else {
    nvars <- length(tt.vars)
    out <- vector(mode="list", length=length(idx))

    howMany <- unlist(lapply(attr(tt,"specials"),function(x)length(x)))
    fun <- list(trm=unlist(attr(tt,'specials')),
                fun=rep(names(attr(tt,"specials")),times=howMany))
    model <- rep("id",nvars)
    is.set <- rep(FALSE,nvars)
    model[fun$trm] <- fun$fun
    is.set[fun$trm] <- TRUE
    for(v in seq(along=idx)) {
      idxv <- idx[v]
      if(is.set[idxv])
        out[[v]] <- evalWithData(tt.vars[idxv],data)
      else
        out[[v]] <- do.call(paste("asr_",model[idxv],sep=""),
                            list(obj=tt.vars[idxv], data=data))
    }
    names(out) <- tt.vars[idx]
  }
  out
}

fak <- function(lev,lab)
{
  ## calc k in an fa model given no of parameters and size
  ## 'lev is a vector of levels
  ## 'lab' is a vector of labels
  ##  lev is length n+k
  ## lab is length n*k+k
  A <- length(lev)
  B <- length(lab)
  return(((A-1)-sqrt((1-A)^2 - 4*(B-A)))/2)
}
sfak <- function(lev,lab)
{
  ## calc k in an fa model given no of parameters and size
  ## 'lev is a vector of levels
  ## 'lab' is a vector of labels
  ##  lev is length n+k
  ## lab is length n*k+k
  A <- length(lev)
  B <- length(lab)
  return((B-A)/A)
}
offset.col <- function(amf) {
  if(!inherits(amf,"asr.model.frame"))
    stop("Argument to 'offset.col' must inherit 'asr.model.frame'")

  what <- unlist(lapply(attr(amf,"model.terms"),function(x)
                        {
                          if(length(w <- attr(x$Terms.obj,"offset")))
                            my.dparse(attr(x$Terms.obj,"variables")[[w+1]])
                          else
                            w
                        }))
  if(!is.null(what)) {
    which <- match(what,names(amf))
    names(which) <- what
  }
  else
    which <- NA
  which
}
weights.col <- function(amf) {
  ## "weights" attr of amf is from weights argument
  ## else from "total" in family
  if(!inherits(amf,"asr.model.frame"))
    stop("Argument to 'weights.col' must inherit 'asr.model.frame'")
  if(!is.null(what <- attr(amf,"weights"))) {
    wt <- match(what,names(amf))
    names(wt) <- what
  }
  else if(sum(who <- nchar(tot <- unlist(lapply(attr(amf,"family"), function(x){if(is.null(x$total)) "" else x$total}))))) {
    who <- as.logical(who)
    wt <- rep(NA, length(attr(amf,"family")))
    wt[which(who)] <- match(tot, names(amf))
    names(wt)[which(who)] <- tot
  }
  else
    wt <- rep(NA, length(attr(amf,"family")))
  wt
}
response.col <- function(amf) {
  if(!inherits(amf,"asr.model.frame"))
    stop("Argument to 'response.col' must inherit 'asr.model.frame'")

  return(attr(amf, "traits")$lhs)

##  if (rsp <- attr(attr(amf,"model.terms")$fixed$Terms.obj,"response")) {
##    response <- attr(attr(amf,"model.terms")$fixed$Terms.obj,"variables")[[rsp+1]]
##    if(mode(response) == "name")
##      return(my.dparse(response))
##    else if(mode(response) == "call") {
##      if(is.matrix(eval(response)))
##        return(dimnames(eval(response))[[2]])
##      else
##        return(my.dparse(response))
##    }
##    else if(mode(response) == "character") {## assume a matrix ??????????
##      return(dimnames(eval(parse(text=response)))[[2]])
##    }
##    else
##      return(NULL)
##  }
}
is.mu <- function(amf) {
  if(!inherits(amf,"asr.model.frame"))
    stop("Argument to 'is.mu' must inherit 'asr.model.frame'")

  if(attr(amf,"traits")$mvar.method != "ISUV")
    return(NA)
  return(as.logical(attr(attr(amf,"model.terms")$fixed$Terms.obj,"intercept")))
}
is.multivariate <- function(amf) {
  if(!inherits(amf,"asr.model.frame"))
    stop("Argument to 'is.multivariate' must inherit 'asr.model.frame'")

  traits <- attr(amf,"traits")
  if(length(traits$lhs) > 1) {
    if(traits$family[1] == "multinomial")
      return(FALSE)
    else
      return(TRUE)
  }
  else
    return(FALSE)
}
is.multinomial <- function(amf) {
  if(!inherits(amf,"asr.model.frame"))
    stop("Argument to 'is.multinomial' must inherit 'asr.model.frame'")

  rsp <- attr(amf,"traits")
  if(rsp$family[1] == "multinomial")
    return(TRUE)
  else
    return(FALSE)
}
is.bglm <- function(amf) {
  ## Bivariate GLM
  if(!inherits(amf,"asr.model.frame"))
    stop("Argument to 'is.bglm' must inherit 'asr.model.frame'")

  if(length(rsp <- attr(amf,"response")$lhs) == 2) {
    if(length(rsp$family) == 1) {
      if(rsp$family == "multinomial")
        stop("Cannot specify bivariate glm with multinomial")
      else if(rsp$family == "gaussian")
        return(FALSE)
      else
        return(TRUE)
    }
    else
      stop("Multiple error families not implemented")
  }
  return(FALSE)
}
traits <- function(amf) {
  if(!inherits(amf,"asr.model.frame"))
    stop("Argument to 'traits' must inherit 'asr.model.frame'")

  return(attr(amf,"traits")$lhs)
}

formula.variables <- function(form,data,prefix=NULL) {
  ## intended to be called with a (constructed) formula
  ## that may be a special function, or an interaction with one,
  ## used as a nested argument in an outer special function call.
  ##
  ## form is the formula object
  ## prefix may be set to "asr_" if form is from an "fa(x):y" construct
  ##        inside a special like 'and'
  tt <- terms(form,specials=paste(prefix,Spcls$Fun,sep=""))
  vars <- sapply(attr(tt,"variables"),function(x)my.dparse(x))[-1]
  ## eval any specials
  which <- numeric(0)
  vv <- NULL
  if(!is.null(ss <- attr(tt,"specials"))) {
    which <- unique(unlist(ss))
    vv <- sapply(vars[which],function(x, data)
                 {
                   evalWithData(x,data)$Argv
                 },data)
  }
  if(length(which) == 0)
    vv <- vars
  else if(length(which) < length(vars))
    vv <- c(vv,vars[-which])

  unlist(vv)
}
formula.specialCalls <- function(form,data,prefix=NULL) {
  ## intended to be called with a (constructed) formula
  ## that may be a special function, or an interaction with one,
  ## used as a nested argument in an outer special function call.
  ##
  ## form is the formula object
  ## prefix may be set to "asr_" if form is from an "fa(x):y" construct
  ##        inside a special like 'and'
  tt <- terms(form,specials=paste(prefix,Spcls$Fun,sep=""))
  vars <- sapply(attr(tt,"variables"),function(x)my.dparse(x))[-1]
  ## eval any specials
  which <- numeric(0)
  if(!is.null(ss <- attr(tt,"specials")))
    which <- unique(unlist(ss))
  vv <- vector(mode="list", length=length(vars))
  for(i in seq(along=vv)) {
    if(is.element(i, which))
      vv[[i]] <- evalWithData(vars[i], data)
    else
      vv[[i]] <- vars[i]
  }
  names(vv) <- sapply(vars,function(x)as.character(recurse.del(x)))
  if(length(vv)==1 && length(which)==0) vv <- unlist(vv)
  return(vv)
}

terms.variables <- function(tt) {
  ## tt is
  ## 1. a terms object (or component of one)
  ## 2. a formula
  ## 3. a character string
  if(!inherits(tt,"terms") && inherits(tt,"formula"))
    tt <- Terms(tt)
  else if(is.character(tt))
    tt <- Terms(formula(paste("~",tt)))

  vars <- sapply(attr(tt,"variables"),function(x)my.dparse(x))[-1]
  if(y <- attr(tt,"response"))
    return(vars[-y])
  else
    return(vars)
}

Terms.argv <- function(obj) {
  ## obj is a list component (eg $fixed) from a call to modelTerms()
  ## t is the model term
  ## returns $Agrv[1] from $Vars for terms in obj

  ff <- attr(obj$Terms.obj,"factors")
  out <- vector(mode="list",length=ncol(ff))
  for(i in 1:length(out)) {
    vv <- dimnames(ff)[[1]][ff[,i] > 0]
    out[[i]] <- unlist(lapply(obj$Vars[vv], function(x)x$Argv[1]))
  }
  return(out)
}
which.variables <- function(tt, term) {
  ## tt is a Terms object
  ## term is the term name or number
  ## returns the variables in the term

  ## ****Fragile - relies on tt being properly recursive
  return(dimnames(attr(tt[match(term, attr(tt,"term.labels"))], "factors"))[[1]])

}
asr.inter <- function(mf,options) {

  Neqf <- function(equations) {
    return(sum(equations$fixed[,2],equations$hidden$fixed[,2]))
  }
  Neqr <- function(equations) {
    return(sum(equations$random[,2]))
  }
  Neqs <- function(equations) {
    return(sum(equations$sparse[,2]))
  }
  Neqd <- function(equations) {
    return(sum(Neqf(equations),1,sum(equations$dense[,2])))
  }
  Neq <- function(equations) {
    return(sum(Neqf(equations),1,Neqr(equations),Neqs(equations),
               equations$hidden$random[,2],equations$hidden$sparse[,2]))
  }

  and.seq <- function(x) {
    ## sequences of 'and' terms
    ## used when reversing fixed form to get neword
    ## x is a vector of (0,1,2) where 2 is an 'and'
    ## returns a matrix where rows are (start, length)
    s <- 0
    l <- 0
    z <- matrix(nrow=0, ncol=0)
    for(i in 1:length(x)) {
      if(x[i] == 2) {
        if(s == 0)
          s <- i
        else
          l <- l+1
      }
      else if(s > 0) {
        z <- rbind(c(s,l+2))
        s <- 0
        l <- 0
      }
    }
    z
  }

  ## START

  fmx <- asr.terms(mf,options,c("fixed","mixed"))
  ## sequence mxd using facord
  ## can't just reorder inter - messes up internal references
  inter <- fmx$inter
  flev <- inter['flev',]
  nlev <- inter['nlev',]
  inform <- inter['inform',]
  facord <- inter['facord',]
  i14 <- inter[1:4,]
  and <- i14[1,] == -12
  xfa <- i14[1,] == -40
  facnam <- fmx$facnam
  baseObj <- fmx$baseObj
  varLevels <- fmx$varLevels
  str.group <- fmx$str.group
  faconst <- inter['faconst',]
  ## Submod, Neword, ...
  ## hidden is 1 if inform < 0 and is a base term or and()
  ## inform == 0 if a generated term (inc from and())
  ## inform < 0 if
  ##  1. a "main effect" not in the model (inc at())
  ##  2.
  ## facord == 0 if an added main effect not in the formula
  #inform[xfa] <- 0 ## THIS MUCKS UP PREDICT
  hidden <- (inform < 0)
  fn <- seq(1,dim(inter)[2])
  fxd <- fn[(abs(inform)==1)]
  mxd <- fn[abs(inform) == 2 | abs(inform) == 3]
  m.ord <- base::order(facord[abs(inform) == 2 | abs(inform) == 3])
  ## be careful of 'and' (inter1 == -12) when reversing fixed

  ## 0=inform, 1=hidden, 2=and
  ah <- as.numeric(inform[fxd] == -1) + 2 * as.numeric(i14[1, fxd] == -12)
  w <- which(ah == 1)
  ## put hidden last
  if(length(w) > 0) {
    fxd <- c(rev(fxd[-w]),fxd[w])
    ah <- c(rev(ah[-w]),ah[w])
  }
  else {
    fxd <- rev(fxd)
    ah <- rev(ah)
  }
  ## swap and
  w <- which(ah == 2)
  if(length(w) > 0) {
    z <- apply(and.seq(ah),1,function(x)seq(x[1], length.out=x[2]))
    if(is.matrix(z)) {
      fxd[as.vector(z)] <- fxd[as.vector(apply(z,2,function(x)rev(x)))]
    }
    else {
      fxd[unlist(z)] <- fxd[unlist(lapply(z,function(x)rev(x)))]
    }
  }
  ## At this stage neword respects 'user' or 'R' order
  neword <- c(fxd,mxd[m.ord]) #rnd,rnd.h,sps,sps.h)
  names(neword) <- c('fixed','random','sparse')[abs(inform)[neword]]
  names(neword)[hidden[neword]==1] <- paste(names(neword)[hidden[neword]==1],'.h',sep="")
  ##not and
  neword.ne12 <- neword[i14[1,neword] != -12]

  ## Check and() for conformance
  which <- seq(1,length(neword))[(i14[1,][neword] == -12)]
  conform <- NULL
  if(length(which) > 0) {
    conform <- vector(mode="list",length=length(which))
    for(i in which) {
      k <- rank(which)[which==i]
      ## get flev for the object of and()
      ## remember the and() term has flev=0
      kk <- i14[2,][neword[i]]
      lvl0 <- flev[kk]
      conform[[k]] <- facnam[kk]
      lvl1 <- 0
      for(j in seq((i-1),1,-1)) {
        ## this adds the flev for the term, so should 'skip' over a preceeding and()
        lvl1 <- lvl1+flev[neword[j]]
        conform[[k]] <- c(conform[[k]],facnam[neword[j]])
        if(lvl0 < lvl1)
          stop("Factors '",
                     paste(conform[[k]],collapse=","),
                     "' referenced by and() have levels ", lvl0,",",lvl1, " that do not conform.")
        if(lvl0 == lvl1)
          break
      }
    }
  }
  ## if ran.order="noeff" then reorder neworder in ascending noeff order
  if(options$random.order == "noeff" && length(neword)>1) {
    is.ok <- matrix(FALSE,nrow=length(neword),ncol=4)
    dimnames(is.ok) <- list(facnam[neword],c("is.fixed", "is.and", "is.hidden", "is.str"))
    is.ok[,1] <- substring(names(neword),1,5) == "fixed"
    is.ok[,3] <- as.logical(hidden[neword]) & i14[1,neword] != -12
    ## str
    x <- str.group != ""
    is.ok[, 4] <- x[neword]
    ## and
    if(!is.null(conform)) {
      is.ok[i14[1,neword] == -12,2] <- TRUE
      aa <- unlist(sapply(conform,function(x){x[-1]}))
      is.ok[aa,2] <- TRUE
    }
    ## May 2014: this to mix hidden terms
    is.ok <- is.ok[,c(1,2,4)]
    is.nfx <- !is.ok[,'is.fixed']
    if(!any(is.ok[is.nfx, 'is.and'] | is.ok[is.nfx, 'is.str'])) {
      do.it <- apply(is.ok,1,function(x){all(!x)})
      which <- seq(1,length(neword))[do.it]
      idx <- base::order(flev[neword[which]])
      nam <- names(neword)
      neword[which] <- neword[which[idx]]
      nam[which] <- nam[which[idx]]
      names(neword) <- nam
      ##not and
      neword.ne12 <- neword[i14[1,neword] != -12]
    }
  }
  ## !GDENSE
  if(length(attr(mf,"model.terms")$dense$Vars) > 0) {
    den <- asr.terms(mf,options,"dense")
    dTerms <- den$facnam[den$inter['inform',] > 0]
    dFacNum <- match(dTerms,facnam)
    if(any(is.na(dFacNum)))
      stop("No match for 'dense' terms in model")
    dNum <- match(dFacNum, neword)
    names(neword)[dNum] <- "random.d"
    #lastF <- max(grep("fixed",names(neword)))
    lastF <- max(which(is.element(names(neword), "fixed")))
    idx <- c(1:lastF, dNum, seq(lastF+1, length(neword))[-(dNum-lastF)])
    neword <- neword[idx]
    ##not and
    neword.ne12 <- neword[i14[1,neword] != -12]
  }
  eqn.lst <- vector(mode='list',length=5)
  names(eqn.lst) <- c("fixed","dense","random","sparse","hidden")
  eqn.lst$fixed <- NULL
  eqn.lst$dense <- NULL
  eqn.lst$random <- NULL
  eqn.lst$sparse <- NULL
  eqn.lst$hidden <- vector(mode='list',length=3)
  names(eqn.lst$hidden) <- c("fixed","random","sparse")
  eqn.lst$hidden$fixed <- eqn.lst$hidden$random <- eqn.lst$hidden$sparse <- NULL
  eqptr <- 2
  for(i in 1:length(neword.ne12)) {
    k <- neword.ne12[i]
    if(names(neword.ne12)[i] == "fixed") {
      dd <- dimnames(eqn.lst$fixed)[[1]]
      eqn.lst$fixed <- rbind(eqn.lst$fixed, as.integer(c(eqptr,flev[k])))
      dimnames(eqn.lst$fixed) <- list(c(dd,facnam[k]),c('eqf','neq'))
    }
    else if(names(neword.ne12)[i] == "random" || names(neword.ne12)[i] == "random.d") {
      dd <- dimnames(eqn.lst$random)[[1]]
      eqn.lst$random <- rbind(eqn.lst$random, as.integer(c(eqptr,flev[k])))
      dimnames(eqn.lst$random) <- list(c(dd,facnam[k]),c('eqr','neq'))
      if(names(neword.ne12)[i] == "random.d") { #just for neqd
        dd <- dimnames(eqn.lst$dense)[[1]]
        eqn.lst$dense <- rbind(eqn.lst$dense, as.integer(c(eqptr,flev[k])))
        dimnames(eqn.lst$dense) <- list(c(dd,facnam[k]),c('eqd','neq'))
      }
    }
    else if((r <- regexpr("\\.h$",names(neword.ne12)[i])) > 0) {
      pfix <- substring(names(neword.ne12)[i],1,r-1)
      dd <- dimnames(eqn.lst$hidden[[pfix]])[[1]]
      eqn.lst$hidden[[pfix]] <- rbind(eqn.lst$hidden[[pfix]], as.integer(c(eqptr,flev[k])))
      dimnames(eqn.lst$hidden[[pfix]]) <- list(c(dd,facnam[k]),c('eqh','neq'))
    }
    else if(names(neword.ne12)[i] == "sparse") {
      dd <- dimnames(eqn.lst$sparse)[[1]]
      eqn.lst$sparse <- rbind(eqn.lst$sparse, as.integer(c(eqptr,flev[k])))
      dimnames(eqn.lst$sparse) <- list(c(dd,facnam[k]),c('eqs','neq'))
    }
    eqptr <- eqptr+flev[k]
  }

  if(length(attr(mf,"model.terms")$Csparse$Vars) > 0) {
    Csp <- asr.terms(mf,options,"Csparse")
    Cterms <- Csp$facnam[Csp$inter['inform',] > 0]
    CfacNum <- match(Cterms,facnam)
    if(any(is.na(CfacNum)))
      warning("No match for Csparse terms in model.", call.=FALSE)
  }
  else
    CfacNum <- 0

  ## some aov flags/lengths
  submod <- 0
  submds <- as.numeric(hidden[neword])
  fixedFlag <- substring(names(neword),1,5)=="fixed"
  minus12 <- (inter[1,neword] != -12)
  whichTrm <- ((submds <= submod) & minus12)
  factdsub <- fixedFlag & whichTrm
  nfactdsub <- sum(factdsub)
  nfactd <- sum(substring(names(neword),1,5)=="fixed")
  if(nfactd == 0)
    stop("Model must have at least one fixed term.", call.=FALSE)

  storage.mode(i14) <- "integer"
  storage.mode(flev) <- "integer"
  storage.mode(nlev) <- "integer"
  storage.mode(neword) <- "integer"
  storage.mode(neword.ne12) <- "integer"
  storage.mode(submds) <- "integer"
  storage.mode(faconst) <- "double"
  storage.mode(whichTrm) <- "integer"
  storage.mode(factdsub) <- "integer"
  storage.mode(fixedFlag) <- "integer"

  ## Remove "mv" - not needed fpr predict
  wmv <- (facnam != "mv") & !is.na(baseObj)
  return(list(intercept=!is.na(is.mu(mf)),
              inter=i14,
              facnam=facnam,
              str.group=str.group,
              nlev=nlev,
              flev=flev,
              inform=inform,
              type=as.numeric(abs(inform)==2),
              submod=submod,
              submds=submds,
              baseFac=data.frame(facNum=seq(along=facnam),
                baseFun=facnam,
                baseObj=baseObj, stringsAsFactors=FALSE)[wmv,],
              varLevels=varLevels,
              neword=neword,neq=Neq(eqn.lst),neqd=Neqd(eqn.lst),
              neword.ne12=neword.ne12,
              faconst=faconst,
              equations=eqn.lst,
              CfacNum = CfacNum,
              aov=list(factd=fixedFlag, whichTrm=whichTrm,
                nfactdsub=nfactdsub, nfactd=nfactd, factdsub=factdsub)))
} ## end asr.inter

## ASReml-R V3
##  list(intercept=terms.mu,
##       facnam=facnam,
##       nlev=nlev,
##       flev=flev,
##       inter=inter,
##       inform=inform,
##       submod=0,
##       xsub=as.numeric(xsub),
##       submds=as.numeric(xsub[neword]),
##       baseFac=baseFac,
##       varLevels=varLevels,
##       IBV=IBV,JBV=JBV,points=attr(data,"Control")$splXtras$points,
##       coords=coords,
##       neword=neword,
##       neq=Neq(eqn.lst), neqd=Neqd(eqn.lst),
##       ##neqf=neqf, neqr=neqr, neqs=neqs,eqf=eqf,eqr=eqr,eqs=eqs,
##       neword.ne12=neword.ne12,
##       faconst=faconst, Coptions=list(Cfacnam=Cfacnam,Cflev=Cflev),equations=eqn.lst)

## TODO - unify this mess!!
eqf <- function(equations) {
  if(is.null(equations$fixed))
    return(0)
  else if(nrow(equations$fixed) == 1) {
    x <- seq(equations$fixed[1,1],length=equations$fixed[1,2])
    names(x) <- paste(dimnames(equations$fixed)[[1]], x, sep="")
    return(x)
  }
  else
    return(unlist(apply(equations$fixed,1,function(x){seq(x[1],length=x[2])})))
}
eqr <- function(equations) {
  if(is.null(equations$random))
    return(0)
  else if(nrow(equations$random) == 1) {
    x <- seq(equations$random[1,1],length=equations$random[1,2])
    names(x) <- paste(dimnames(equations$random)[[1]], x, sep="")
    return(x)
  }
  else
    return(unlist(apply(equations$random,1,function(x){seq(x[1],length=x[2])})))
}
eqs <- function(equations) {
  if(is.null(equations$sparse))
    return(0)
  else if(nrow(equations$sparse) == 1) {
    x <- seq(equations$sparse[1,1],length=equations$sparse[1,2])
    names(x) <- paste(dimnames(equations$sparse)[[1]], x, sep="")
    return(x)
  }
  else
    return(unlist(apply(equations$sparse,1,function(x){seq(x[1],length=x[2])})))
}
## This one for reporting the design matrix
eqns <- function(equations) {
  x <- c(eqf(equations), eqr(equations), eqs(equations),
          eqf(equations$hidden), eqr(equations$hidden), eqs(equations$hidden))
  x <- x[x > 0] -1
  return(sort(x))
}
asr.terms <- function(mf,options,formulae)
{
  ## October 2015
  ## Loop over terms, adding vars on the go
  ## mf is the model.frame
  ## Extractor functions needed:
  ## 1. response.col()
  ## 2. is.mu()
  ## 3. is.multivariate()

  ## Sets up "Nlev", "Flevel" and "Inter" as in "aidata"

  frs <- function(src, trm, form) {
    if(src=='mixed') {
      vec <- c(attr(form,"vType"),attr(form,"tType"))
      vec <- vec[unique(names(vec))]
      rndm <- switch(vec[trm],
                     random = 2,
                     sparse = 3,
                     stop("internal error - cannot match tType"))
    }
    else if(src == "Csparse")
      rndm <- 4
    else if(src == "dense")
      rndm <- 5
    else
      rndm <- 1
    return(rndm)
  }
  ## propogate str.group
  stgp <- function(src, trm, form){
    if(is.element(src, c('fixed','Csparse','dense')))
      grp <- ""
    else if(src=='mixed') {
      vec <- attr(form,"str.group")
      tt <- attr(form,"term.labels")
      i <- match(trm,tt)
      if(is.na(i))
        grp <- ""
      else
        grp <- vec[i]
    }
    return(grp)
  }
  match.term <- function(str, vec) {
    ## str is a char term, possibly an interaction
    ## vec may be a vector of such terms
    match(paste(str,collapse=":"),vec,nomatch=NA)
  }
  genFac <- function(trm,lvl,rndm,stru,f.ord) {
    ##
    ## Generate all necessary lower order interactions for terms like A:B:C
    ##
    ## Uses "<<-" assignment
    ##
    ## **** Assumes main effects are already added ****
    ## on entry trm = vec(a,b,c,d,...)
    ##          lvl is parallel to trm with a names attribute
    xL <- trm[1]
    xRlab <- paste(trm[-1],collapse=":")
    xR <- trm[-1]
    ipA <- match.term(xL,facnam)
    if(is.na(ipB <- match.term(xRlab,facnam))) {
      ## set rndm=0 here so non-existent terms are 'hidden'
      ## also set stru=""
      genFac(xR,lvl,0,stru,f.ord)
      facnam <<- c(facnam,paste(xL,xRlab,sep=":"))
      baseObj <<- c(baseObj,NA)
      ipB <- match.term(xRlab,facnam)
        inter <<- cbind(inter,c(ipA,ipB,inter['flev',ipA],inter['flev',ipB],
                                prod(lvl[xL],lvl[xR]),0,rndm,f.ord,0))
      str.group <<- c(str.group,stru)
    }
    else {
      facnam <<- c(facnam,paste(xL,xRlab,sep=":"))
      baseObj <<- c(baseObj,NA)
      inter <<- cbind(inter,c(ipA,ipB,inter['flev',ipA],inter['flev',ipB],
                              prod(lvl[xL],lvl[xR]),0,rndm,f.ord,0))
      str.group <<- c(str.group,stru)
    }
    return()
  } ## end genFac

## START----------------------------->
  inter <- matrix(0,nrow=9,ncol=0) # makes a null column in case no y
  dimnames(inter) <- list(c("inter1","inter2","inter3","inter4",
                            "flev","nlev","inform","facord","faconst"),NULL)
  facnam <- vector(mode="character")
  baseObj <- vector(mode="character")
  str.group <- vector(mode="character")
  varLevels <- vector(mode="list")
  coords <- list()

   ## Loop through 'fixed' and 'mixed'
  for (form in formulae) {
    has.and <- !is.null(attr(attr(mf,"model.terms")[[form]][['Terms.obj']],
                             "specials")$and)
    if(form == "fixed") {
      nycol <- length(response.col(mf))
      inter <- matrix(0,nrow=9,ncol=nycol)
      dimnames(inter) <- list(c("inter1","inter2","inter3","inter4",
                                "flev","nlev","inform","facord","faconst"),NULL)
      str.group <- vector(mode="character",length=nycol)
      tyfact <- 0
      ## Response
      ## traits are NOT always colums 1:nycol in the data table
      ##nycol <- length(response.col(mf))
      ycol <- match(response.col(mf),names(mf))
      ylev <- unlist(lapply(mf[,ycol,with=FALSE],function(x) {
        ifelse(is.factor(x), length(levels(x)), 1) }))
      inter['nlev',1:nycol] <- rep(1,nycol)
      inter['flev',1:nycol] <- ylev
      inter['inter1',1:nycol] <- ylev
      inter['inter2',1:nycol] <- rep(0,nycol)
      inter['inter3',1:nycol] <- ycol-1
      inter['inter4',1:nycol] <- rep(0,nycol)
      inter['inform',1:nycol] <- rep(0,nycol) ## 1
      inter['facord',1:nycol] <- rep(0,nycol) ## 1
      inter['faconst',1:nycol] <- rep(0,nycol)
      str.group <- rep("",nycol)
      facnam <- response.col(mf)
      baseObj <- rep(NA,nycol) #facnam #NA filters out the response for predict
      ## Intercept/trait
      mm <- attr(mf,"traits")$mvar.method
      if(!(mm == "ISUV" || mm == "ASMV")) {
        if(is.multinomial(mf)) {
          if(mm == "ASMN")
            flev <- length(levels(mf[[ycol]]))-1
          else
            flev <- nycol-1
        }
        else
          flev <- nycol

        inter <- cbind(inter,c(-8,0,-1,0,
                               flev,
                               0,-1,inter['facord',ncol(inter)]+1,0))
        facnam <- c(facnam,"trait")
        baseObj <- c(baseObj,"trait")

        if(is.multinomial(mf)) {
          if(mm == "ASMN")
            varLevels$"trait" <- as.character(seq(1, length(levels(mf[[ycol]]))-1))
          else
            varLevels$"trait" <- as.character(seq(1, length(ycol)-1))
        }
        else
          varLevels$"trait" <- names(mf)[ycol]
        str.group <- c(str.group,"")
      }
      else if(!is.na(is.mu(mf)) && is.mu(mf)) {
        inter <- cbind(inter,c(-8,0,0,0, 1,0,1,inter['facord',ncol(inter)]+1,0))
        facnam <- c(facnam,"(Intercept)")
        baseObj <- c(baseObj,"(Intercept)")
        varLevels$"(Intercept)" <- "(Intercept)"
        str.group <- c(str.group,"")
      }
    }
    X <- attr(mf, "model.terms")[[form]][['Vars']]
    if(is.null(X))
      next

    ## model terms
    Y <- attr(mf,"model.terms")[[form]][['Terms.obj']]
    ## Can't just skip thru Y[i] - bug in R???
    ##
    ## factor order is 0 if not involved in a term.
    ## Special cases:
    ## at, and, giv, ped, mbf, grp, ....

    for(z in seq(along=attr(Y, "term.labels"))) {
      trm <- attr(Y,"term.labels")[z]
      rndm <- frs(form, trm, attr(mf,"model.terms")[[form]][['Terms.obj']])
      stru <- stgp(form, trm, attr(mf,"model.terms")[[form]][['Terms.obj']])
      ## loop over constituents of trm
      ## each component is in X (ie "Vars")
      vars <- terms.variables(trm)
      for(v in vars) {
        base <- X[[v]]$Obj #Argv[1] in mbf, grp
        f.nam <- X[[v]]$FacNam
        col <- match(base,names(mf))-1
        lev <- getLevels(X[[v]]$Lvls)
        iinter <- X[[v]]$Inter
        if(is.null(fc <- attr(iinter,"faconst"))) fc <- 0
        object <- X[[v]]$Obj
        fun <- X[[v]]$Fun

        ## special cases first - constructors
        is.and <- FALSE
        ## AND
        if(fun == "and") {
          is.and <- TRUE
          ## Sept 2015 - and ALWAYS returns a list as Obj
          ## Jan 2017 - paste back factor names for compound terms in case
          ##            some are wrapped in variance models, eg: us(site):vm(geno)
          ##            where presumably the "object" of the and() is site:vm(geno).
          lev <- NULL
          and.name <- NULL
          for(i in seq(along=object)) {
            if(inherits(object[[i]],"asr.special")) {
              and.name <- c(and.name, object[[i]]$FacNam)
              if(is.na(match(object[[i]]$FacNam, facnam))) {
                facnam <- c(facnam,object[[i]]$FacNam)
                inter <- cbind(inter,c(object[[i]]$Inter,
                                       length(getLevels(object[[i]]$Lvls)),
                                       1,
                                       -rndm,
                                       0,
                                       fc)) #-rndm
                str.group <- c(str.group,stru)
                baseObj <- c(baseObj, object[[i]]$Argv)
                varLevels[[object[[i]]$FacNam]] <- getLevels(object[[i]]$Lvls)
              }
            }
            else {
              and.name <- c(and.name, names(object)[i])
              if(is.na(match(names(object)[i],facnam))) {
                facnam <- c(facnam,names(object)[i])
                inter <- cbind(inter,c(max(1, length(levels(mf[[names(object)[i]]]))),
                                       0,
                                       match(names(object)[i],names(mf))-1,
                                       0,
                                       max(1, length(levels(mf[[names(object)[i]]]))),
                                       1,
                                       -rndm,
                                       0,
                                       fc)) #-rndm
                str.group <- c(str.group,stru)
                baseObj <- c(baseObj, names(object)[i])
                varLevels[[ names(object)[i]] ] <- levels(mf[[names(object)[i]]])
              }
            } ## end asr.special
            lev <- c(lev, inter['flev', match(and.name[i], facnam)])
          } ## end for i
          ## Add the term then and() in sequence
          if(!is.element(paste(and.name, collapse=":"),facnam)) {
            names(lev) <- and.name
            genFac(and.name,lev,0,stru,z)
          }
          if(is.na(match(trm,facnam))) {
            facnam <- c(facnam,trm)
            inter <- cbind(inter,c(X[[trm]]$Inter,rep(0,5)))
            inter['inform',dim(inter)[2]] <- rndm #-rndm
            str.group[dim(inter)[2]] <- stru
            inter['facord',dim(inter)[2]] <- z
            inter['inter2',dim(inter)[2]] <- match(paste(and.name, collapse=":"),facnam) #names(object)
            baseObj <- c(baseObj, NA)
          }
        } ## end and

        ## AT
        if(fun == 'at') {
          ## add the defining factor
          if(!is.element(base,facnam)) {
            atf <- levels(mf[[base]])
            inter <- cbind(inter,
                           c(length(atf),0,col,0, length(atf),1,-rndm,0,fc))
            str.group <- c(str.group,stru)
            facnam <- c(facnam,base)
            baseObj <- c(baseObj,base)
            varLevels[[base]] <- atf
          }
          ## f.nam is a vec of expanded at terms
          for(atnam in seq(along=f.nam)) {
            where <- match(f.nam[atnam],facnam)
            if(is.na(where)) {
              ## At this stage:
              ## inter[2] is the number of levels in the at factor
              ## inter[3] points to the BASE position in facnam of the at factor
              ## inter[4] holds the level number of the at factor
              inter <- cbind(inter,c(as.numeric(iinter[1]),
                                     length(varLevels[[base]]),
                                     (if(base == "trait") -1 else col),
                                     match(lev[atnam],varLevels[[base]]),
                                     1,1,-rndm,0,fc))
              str.group <- c(str.group,stru)
              facnam <- c(facnam,f.nam[atnam])
              baseObj <- c(baseObj, base)
            }
            varLevels[[f.nam[atnam]]] <- paste(base,"_",lev[atnam],sep="")
          }
        } ## end at
        else if(fun == 'vm') {
          if(!is.na(match(f.nam, facnam))) {
            next
          }
          inter <- cbind(inter,c(iinter,
                                 length(lev),
                                 1,-rndm,0,fc))
          str.group <- c(str.group,stru)
          ## need loc of giv in ainv
          b <- dim(inter)[2]
          inter[4,b] <- 0
          facnam <- c(facnam,f.nam)
          baseObj <- c(baseObj, base)
          if(is.na(match(f.nam,names(varLevels))))
            varLevels[[f.nam]] <- lev
          ## might have a nested grp; set nlev
          if(length(grep('grp\\(', f.nam)) > 0)
            inter['nlev', b] <- inter[1, b]
        } ## end vm
        else if(fun == 'mbf') {
          if(!is.na(match(f.nam, facnam))) {
            next
          }
          inter <- cbind(inter,c(iinter,iinter[4],1,-rndm,0,fc))
          str.group <- c(str.group,stru)
          facnam <- c(facnam,f.nam)
          baseObj<- c(baseObj, f.nam)
          if(is.na(match(f.nam,names(varLevels))))
            varLevels[[f.nam]] <- lev
          ## Add the 'key' field in the data (maybe needed in predict)
          w <- iinter[3]+1
          if(!is.element(names(mf)[w], facnam)) {
            a <- length(levels(as.factor(mf[[w]])))
            inter <- cbind(inter,c(a,0,w-1,0, a,1,-rndm,0,fc))
            str.group <- c(str.group,stru)
            facnam <- c(facnam, names(mf)[w])
            baseObj <- c(baseObj, names(mf)[w])
            varLevels[[names(mf)[w]]] <- levels(as.factor(mf[[w]]))
          }
        } ## end mbf
        else if(fun == 'grp' || length(grep('grp\\(', f.nam)) > 0) {
          if(!is.na(match(f.nam, facnam))) {
            next
          }
          w <- match(X[[z]]$Argv[1], names(mf))
          inter <- cbind(inter,c(rep(0,4),length(lev),0,-rndm,0,fc))
          str.group <- c(str.group,stru)
          b <- dim(inter)[2]
          inter[1:4,b] <- as.numeric(iinter)
          if(is.na(inter[3,b])) inter[3,b] <- w-1
          inter['nlev',b] <- length(lev)
          facnam <- c(facnam,f.nam)
          baseObj <- c(baseObj, X[[v]]$Argv[1])
          if(is.na(match(f.nam,names(varLevels))))
            varLevels[[f.nam]] <- lev
          ## may be wrapped in a power function: expv(grp(xxxx))
          if(length(X[[v]]$Coords$coords) > 0)
            coords[[X$Obj]] <- X[[v]]$Coords$coords
        } ## end group
        else if(fun == 'con') {
          ## need to add base factor for predict
          if(is.na(match(base, facnam))){
            facnam <- c(facnam, base)
            a <- if(is.factor(mf[[col+1]])) length(levels(mf[[col+1]])) else 1
            inter <- cbind(inter, c(a, 0, col, 0, a, 1, -rndm, 0, fc))
            str.group <- c(str.group, "")
            baseObj <- c(baseObj, base)
            varLevels[[base]] <- if(is.factor(mf[[col+1]])) levels(mf[[col+1]]) else base
          }
          if(is.na(match(f.nam,facnam))) {
            facnam <- c(facnam,f.nam)
            inter <- cbind(inter,c(rep(0,4),length(lev),1,-rndm,0,fc))
            str.group <- c(str.group,stru)
            b <- dim(inter)[2]
            if(object == "mv")
              inter[c(1:4,6),b] <- c(-4,0,0,0,0) #nlev=0
            else {
              inter[1:4,b] <- as.numeric(X[[v]]$Inter)
              if(is.na(inter[3,b])) inter[3,b] <- col
            }
            baseObj <- c(baseObj, base)
            varLevels[[f.nam]] <- lev
          }
        }## end con
        else if(fun == 'C') {
          ## need to add base factor for predict
          if(is.na(match(base, facnam))){
            facnam <- c(facnam, base)
            a <- if(is.factor(mf[[col+1]])) length(levels(mf[[col+1]])) else 1
            inter <- cbind(inter, c(a, 0, col, 0, a, 1, -rndm, 0, fc))
            str.group <- c(str.group, "")
            baseObj <- c(baseObj, base)
            varLevels[[base]] <- if(is.factor(mf[[col+1]])) levels(mf[[col+1]]) else base
          }
          if(is.na(match(f.nam,facnam))) {
            facnam <- c(facnam,f.nam)
            inter <- cbind(inter,c(rep(0,4),length(lev),1,-rndm,0,fc))
            str.group <- c(str.group,stru)
            b <- dim(inter)[2]
            if(object == "mv")
              inter[c(1:4,6),b] <- c(-4,0,0,0,0) #nlev=0
            else {
              inter[1:4,b] <- as.numeric(X[[v]]$Inter)
              if(is.na(inter[3,b])) inter[3,b] <- col
            }
            baseObj <- c(baseObj, base)
            varLevels[[f.nam]] <- lev
          }
        } # end C
        else if(is.element(fun, c('fa','facv','sfa', 'rr'))) { #FA
          if(is.na(match(f.nam, facnam))) {
            if(is.na(match(base, facnam))) {
              facnam <- c(facnam, base)
              a <- if(is.factor(mf[[col+1]])) length(levels(mf[[col+1]])) else 1
              inter <- cbind(inter, c(a, 0, col, 0, a, 1, -rndm, 0, fc))
              str.group <- c(str.group, "")
              baseObj <- c(baseObj, base)
              varLevels[[base]] <- if(is.factor(mf[[col+1]])) levels(mf[[col+1]]) else base
            }
            facnam <- c(facnam,f.nam)
            inter <- cbind(inter, c(as.numeric(X[[v]]$Inter),length(lev),1,-rndm,0,fc))
            str.group <- c(str.group,stru)
            b <- dim(inter)[2]
            inter[3,b] <- match(base, facnam)
            varLevels[[f.nam]] <- lev
            baseObj <- c(baseObj, base)
          }
        } ## end FA
        else { ## default
          if(is.na(match(f.nam,facnam))) {
            facnam <- c(facnam,f.nam)
            inter <- cbind(inter,c(rep(0,4),length(lev),1,-rndm,0,fc))
            str.group <- c(str.group,stru)
            b <- dim(inter)[2]
            if(object == "mv")
              inter[c(1:4,6),b] <- c(-4,0,0,0,0) #nlev=0
            else {
              inter[1:4,b] <- as.numeric(X[[v]]$Inter)
              if(is.na(inter[3,b])) inter[3,b] <- col
            }
            baseObj <- c(baseObj, base)
            varLevels[[f.nam]] <- lev
          }
        }
      } # end v
      ## Add the term ('and' already done)
      if(is.and) next
      object <- sapply(X[terms.variables(trm)],function(x)x$FacNam)
      if(is.list(object)) {
        lev <- sapply(object,function(x,ii,f)ii[5,match(x,f)],inter,facnam)
        object <- do.call("cbind",object)
        lev <- do.call("cbind",lev)
      }
      else
        lev <- inter[5,match(object,facnam)]

      ## if object is a list then FacNam is a vector (from at),
      ## and the above "do.call" makes a matrix, the rows of which
      ## are vectors of component factor names (and levels)
      if(is.matrix(object)) {
        ## do genfac row by row; have to set names of lev[i,]
        for(i in 1:nrow(object)) {
          ll <- lev[i,]
          names(ll) <- object[i,]
          genFac(object[i,],ll,rndm,stru,z)
        }
      }
      else if(length(object) > 1) {
        names(lev) <- object
        if(!is.element(paste(object,collapse=":"),facnam)) {
          genFac(object,lev,rndm,stru,z)
        } else {
          w <- match.term(paste(object,collapse=":"), facnam)
          if(is.na(w)) {
            stop("Internal error: cannot match ",paste(object,collapse=":"), " in facnam")
          }
          inter['inform',w] <- rndm
          str.group[w] <- stru
          inter['facord',w] <- z
        }
      }
      else if(!is.na(w <- match.term(object,facnam))) {
        inter['inform',w] <- rndm
        str.group[w] <- stru
        inter['facord',w] <- z
      }
    }# end z
  } # end form
  return(list(inter=inter,facnam=facnam,baseObj=baseObj,varLevels=varLevels,
              str.group=str.group))
} ## end
recurse.del <- function(expr)
{
  ## delete 'data' arg to a special function call
  stripExpr <- function(ee) {
    switch(mode(ee[[1]]),
           "call" = {
             if(is.element("data",names(ee[[1]])))
               ee[[1]]$data <- NULL
             if(is.element("init",names(ee[[1]])))
               ee[[1]]$init <- NULL
             ee[[1]][[1]] <- as.name(gsub("asr_","",ee[[1]][[1]]))
             if(length(ee[[1]]) > 1) {
               for(i in 2:length(ee[[1]])) {
                 ee[[1]][i] <-stripExpr(ee[[1]][i])
               }
             }
             ee
           },
           "numeric" = {
             ee
           },
           "name" = {
             ee
           },
           "character" = {
             ee
           },
           "logical" = {
             ee
           },
           ee
           )
    ee
  }

  stripCall <- function(cc) {
    switch(mode(cc),
           "call" = {
             if(is.element("data",names(cc)))
               cc$data <- NULL
             if(is.element("init",names(cc)))
               cc$init <- NULL
             cc[[1]] <- as.name(gsub("asr_","",cc[[1]]))
             if(length(cc) > 1) {
               for(i in 2:length(cc)) {
                 cc[[i]] <-stripCall(cc[[i]])
               }
             }
           }
           )
    cc
  }
  ## start here
  if(is.character(expr))
    expr <- parse(text=expr)
  if(is.expression(expr)) {
    expr <- stripExpr(expr)
    return(as.expression(expr[[1]]))
  }
  else if(is.call(expr)) {
    expr <- stripCall(expr)
    return(expr)
  }
  else
    stop("Argument to 'recurse.del' must be mode expression or call")

}
R.sections <- function(mf) {

  ## no checks here - done in Rparam

  X <- attr(mf,"model.terms")$residual$Terms.obj
  V <- attr(mf,"model.terms")$residual$Var

  sect <- attr(X,"specials")$dsum

  if(length(sect) > 0) {
    outer <- attr(V[[1]]$Call,"outer")
    if(outer) {
      nsect <- 1
    }
    else {
      nsect <- nrow(rbindlist(lapply(V,function(x)attr(x$Call, "section.term"))))
    }
  }
  else {
    nsect <- 1
  }
  return(nsect)
}
R.unique <- function(mf, lhs, x, distbn) {
  ## len unique(mf[[x]]) if ISUV or ASMV
  ## len unique(trait) if ISMV or ASMN
  ## mf is the response matrix or vector
  if(x == "trait") {
    n <- length(lhs)
    if(n  > 1) {
      if(distbn[1] == 9)
        return(n-1)
      else
        return(n)
    }
    else
      return(length(unique(mf[[x]]))-1)
  }
  else
    return(length(unique(mf[[x]])))
}
Rparam <- function(mf)
{
  ## List of initial values for R(esidual) structures
  r2 <- function(sname, slevel, dimensions, family, lhs, ss) {
    attr(ss, "Rcov") <- TRUE
    one.sect <- ifelse(sname == slevel, TRUE, FALSE)
    L2 <- vector(mode="list",length=length(dimensions)+1)
    names(L2) <- c("variance",unlist(lapply(dimensions,function(x)x$Obj)))
    gam.name <- paste(unique(c(sname,slevel)),collapse="_")
    isVar <- 0
    size <- 1
    distbn <- unlist(lapply(family,function(x)x$id))[1]
    if(distbn == 9)
      scale <- 1.0
    else
      scale <- var(as.vector(as.matrix(ss[,lhs,with=FALSE])),na.rm=TRUE)/2.0
    dispersion <- unlist(lapply(family,function(x)x$dispersion))[1]

    for(i in 1:length(dimensions)) {
      ## re evaluate for different section sizes
      ## scoping issue here - specials can't find ss
      ## evaluating in this environment seems to fix it
      #X <- Need the original initial values
      X <- eval(evalWithData(dimensions[[i]]$Call, data=ss, evaluate=FALSE))
      X$Initial <- dimensions[[i]]$Initial[1:length(X$Initial)]
      attr(X$Initial, "set") <- attr(dimensions[[i]]$Initial, "set")
      n <- names(L2)[i+1]
      iset <- attr(X$Initial, "set")
      convert <- ifelse((is.na(X$isVariance) || !X$isVariance || iset), 1.0, scale)
      L2[[n]]$facnam <- X$FacNam
      L2[[n]]$model <- X$Fun
      names(L2[[n]]$model) <- X$Obj
      L2[[n]]$levels <- X$Lvls
      ## Initial values
      ## Special cases
      if(convert != 1.0 && !asreml.options()$fixgammas) {
        if(length(dimensions) == 2) {
          classify <- unlist(lapply(dimensions,function(a)a$Obj))
          tc <- unlist(lapply(classify,function(x)type.convert(x, as.is=FALSE)))
          if(all(!is.numeric(tc))) {
            if(i == 1) classify <- rev(classify) # saves a t() in us_vcov()
            if(Spcls[X$Fun, "FunGroup"] == "us") {
              ivals <- us_init(ss, classify)
              X$Initial <- ivals * 0.5
              X$Con[attr(ivals, "fix")] <- "F"
            }
            else if(Spcls[X$Fun, "FunGroup"] == "diag") {
              X$Initial <- diag_init(ss, classify) * 0.5
            }
            else if(Spcls[X$Fun, "FunGroup"] == "corh") {
              X$Initial[is.element(X$Tgamma, c(2,4))] <- diag_init(ss, classify) * 0.5
            }
            else if(Spcls[X$Fun, "FunGroup"] == "corv") {
              X$Initial[is.element(X$Tgamma, c(2,4))] <- mean(diag_init(ss, classify), na.rm=TRUE) * 0.5
            }
            else if(Spcls[X$Fun, "FunGroup"] == "corgh") {
              X$Initial <- corgh_init(ss, classify, 0.5) # NOTE: scaled in corgh_init
            }
            else if(Spcls[X$Fun, "FunGroup"] == "corgv") {
              X$Initial <- corgv_init(ss, classify, 0.5) # NOTE: scaled in corgv_init
            }
            else if(Spcls[X$Fun, "FunGroup"] == "xfa") {
              ## set those fixed to init
              ivals <- fa_init(ss, classify, fak(X$Lvls, X$Lab), sf=0.5)
              if(!is.null(ivals)) {
                ff <- casefold(substr(X$Con,1,1),upper=TRUE) != "F"
                X$Initial[ff] <- ivals[ff]
              }
            }
            else if(Spcls[X$Fun, "FunGroup"] == "fa") {
              ## set those fixed to init
              ff <- casefold(substr(X$Con,1,1),upper=TRUE) != "F"
              X$Initial[ff] <- fa_init(ss, classify, sfak(X$Lvls, X$Lab), sf=0.5, reverse=TRUE)[ff]
            }
            else {
              X$Initial[is.element(X$Tgamma, c(2,4))] <- X$Initial[is.element(X$Tgamma, c(2,4))] * convert
            }
          }
        }
        else {
          X$Initial[is.element(X$Tgamma, c(2,4))] <- X$Initial[is.element(X$Tgamma, c(2,4))] * convert
        }
      }
      L2[[n]]$initial <- as.double(X$Initial)
      names(L2[[n]]$initial) <- {if(length(dimensions) > 0)
                                   paste(gam.name,X$Lab,sep="")
                                 else
                                   gam.name}
      L2[[n]]$tgamma <- X$Tgamma
      L2[[n]]$tgamma[X$Tgamma < 3] <- ifelse(convert == 1, 2, 1) #1=variance, 2=gamma
      storage.mode(L2[[n]]$tgamma) <- "integer"
      L2[[n]]$con <- X$Con
      L2[[n]]$struc <- X$Struc
      L2[[n]]$struc[1] <- R.unique(ss, lhs, X$Obj, distbn)
      storage.mode(L2[[n]]$struc) <- "integer"
      L2[[n]]$coords <- X$Coords
      storage.mode(L2[[n]]$coords) <- "double"
      size <- prod(size, L2[[n]]$struc[1])
      L2[[n]]$bounds <- X$Bounds
      isVar <- isVar + ifelse(is.na(X$isVariance),0,as.numeric(X$isVariance))
    }
    ## have to check each section
    if(isVar > 1) {
      warning("Residual model overpamaterized unless constrained - structure has ", isVar, " variance models.",
           call.=FALSE)
    }
    L2$variance$size <- size
    L2$variance$bounds <- matrix(c(NA,NA),ncol=2)
    dimnames(L2$variance$bounds) <- list("scale",c("LB","UB"))
    L2$variance$model <- "id"
    names(L2$variance$model) <- paste(sname,"!","scale",sep="")
    L2$variance$tgamma <- as.integer(1)
    L2$variance$struc <- as.integer(c(size,rep(0,15)))

    if(is.na(dispersion)) {
      if(isVar > 0) { #  all models with error model=var
        L2$variance$initial <- as.double(asreml.options()$scale)
        L2$variance$con <- "F"
        L2$variance$bounds[,c(1,2)] <- as.double(c(1,1))
      }
      else if(one.sect) { # single section, error model=cor
        L2$variance$initial <- as.double(asreml.options()$scale)
        L2$variance$con <- "P"
        L2$variance$bounds[,c(1,2)] <- as.double(c(0.0001,1e37))
      }
      else { # multi-section, error model=cor
        L2$variance$model <- "idv"
        L2$variance$initial <- as.double(scale)
        L2$variance$con <- "P"
        L2$variance$bounds[,c(1,2)] <- as.double(c(0.0001,1e37))
      }
    }
    else { # dispersion set: eg, glm
      L2$variance$initial <- as.double(dispersion)
      L2$variance$con <- "F"
      L2$variance$bounds[,c(1,2)] <- as.double(c(dispersion,dispersion))
    }
    names(L2$variance$initial) <- paste(gam.name,"!R",sep="")
    L2
  }

  ## START -------------------------------->
  ## Suppress R CMD CHECK warning
  section <- NULL

  mm <- attr(mf,"traits")$mvar.method # asmv or multinomial

  X <- attr(mf,"model.terms")$residual$Terms.obj
  V <- attr(mf,"model.terms")$residual$Vars
  fam <- attr(mf, "family")
  distbn <- unlist(lapply(fam,function(x)x$id))[1]

  sect <- NULL
  ## Check for dsum & validate
  if(any(sect <- attr(X,"specials")$at))
    stop("'at()' not allowed in residual model formula, replace with 'dsum'\n")
  sect <- attr(X,"specials")$dsum
  if(length(sect) > 0 && (length(sect) != length(attr(X, "term.labels"))))
    stop("Invalid 'residual' formula")
  if(length(sect) == 0 && (length(attr(X, "term.labels")) > 1))
    stop("Invalid 'residual' formula")

  if(length(sect) > 0) {
    outer <- attr(V[[1]]$Call,"outer")
    cf <- attr(V[[1]]$Call,"conditioning.factor")
    if(any(is.na(mf[[cf]])))
      stop("Missing values in section factor ",cf, call.=FALSE)
    ucf <- unique(mf[[cf]])
    if(is.unsorted(match(mf[[cf]], ucf))) {
      stop("Data not grouped by ", cf)
    }
    if(outer) {
      nsect <- 1
      ndim <- length(dims <- attr(V[[1]]$Call,"model.terms")$Var[[1]]$Argv[1])
      uname <- sections <- paste(cf,dims,sep=":")
    }
    else {
      sname <- sapply(V,function(x)x$Obj) #Argv[1]
      if(length(uname <- unique(sname)) != 1)
        stop("Multiple conditioning factors ",uname," in 'residual' model")
      section.term <- rbindlist(lapply(V,function(x)attr(x$Call, "section.term")))
      ## All sections specified?
      nsect <- nrow(section.term)
      if(length(unique(section.term$section)) != nsect)
        stop("Residual model not specified for all sections")
      ndim <- unlist(lapply(V,function(x){
        apply(attr(attr(x$Call,"model.terms")$Terms.obj,"factors"),2,function(y)sum(y>0))}))
      #dims <- lapply(V,function(x){x$Obj}) #Argv #[-1]
      dims <- lapply(V,function(x){attr(x$Call,"model.terms")$Vars})
      if(length(ndim <- unique(as.vector(ndim))) != 1)
        stop("Number of dimensions differ ",unique(ndim)," in 'residual' model")
    }
  }
  else {
    outer <- FALSE
    nsect <- 1
    uname <- sections <- paste(unlist(sapply(V,function(x)x$Obj)),collapse=":") #Argv
    ndim <- length(dims <- vapply(V[terms.variables(X)],function(x){x$Obj},character(1))) #Argv[1]
  }

  ## Process in data (ie unique) order
  if(length(sect) > 0 && !outer)
    sections <- unique(mf[[uname]])

  Vlist <- vector(mode="list",length=nsect)
  names(Vlist) <- sections

  ## dispersion  sections  what?                     fit scale
  ## NA             1      S2=1, Positive            ratio
  ## NA            >1      Each S2=scale, Positive   component
  ##  x             1      S2=x, Fixed
  ##  x            >1      All S2=x, all Fixed

  lhs <- attr(mf,"traits")$lhs
  if(outer) {
    for(i in unique(mf[[cf]])) {
      ss <- subset(mf, mf[[cf]]==i, select=dims) # subset on data.table ok??
      attr(ss, "Response.col") <- names(mf)[attr(mf, "Response.col")] ## Need this for initial values calcs
      if(is.unsorted(do.call(base::order,ss)))
        stop("Data not ordered ",dims," within ",cf,".")
    }
    Vlist[[sections]] <- r2(uname,uname,attr(V[[1]]$Call, "model.terms")$Vars,
                            fam,
                            lhs,
                            mf)
  }
  else if(length(sect) > 0) {
    for(i in sections) {
      ## section.term is a data.table - subset ok???
      st <- subset(section.term, section == i)
      dd <- unique(unlist(lapply(dims[st$fun], function(x){sapply(x,function(y)y$Argv)})))
      ## Power model
      struc3 <- any(Spcls[unlist(lapply(dims[st$fun], function(x){sapply(x,function(y)y$Fun)})), "Struc3"] == 6)
      ## Check section sizes, and if sorted
      ss <- subset(mf, mf[[uname]]==i) #, select=c(lhs,dd))
      ## next 2 lines drop unused levels
      upd.cols = sapply(ss, is.factor)
      ss[, names(ss)[upd.cols] := lapply(.SD, factor), .SDcols = upd.cols]
      attr(ss, "traits") <- attr(mf, "traits")
      Y <- attr(ss, "Response.col") <- names(mf)[attr(mf, "Response.col")]
      ## multinomial and power models are exceptions
      if((length(Y) == 1 && is.factor(ss[[Y]])) || struc3 ) {
        pp <- nrow(ss)
      } else {
        pp <- prod(unlist(lapply(ss[,dd,with=FALSE],function(x)length(unique(x)))))
      }
      if(pp != length(Y)*nrow(ss)) {
        stop("Section has ",nrow(ss),
             " observations but the residual model implies ",pp)
      }
      if(is.unsorted(do.call(base::order,ss[,dd,with=FALSE])))
        stop("Data order does not match that specified by the residual model formula.", call.=FALSE)
      ff <- st$fun
      tt <- st$term
      w <- which.variables(attr(V[[ff]]$Call, "model.terms")$Terms.obj,tt)
      slevel <-  {if(nsect == 1) uname else i}
      attr(ss, "points.env") <- attr(mf, "points.env")
      attr(ss, "Rcov") <- attr(mf, "Rcov")
      Vlist[[i]] <- r2(uname,slevel,attr(V[[ff]]$Call, "model.terms")$Vars[w],
                       fam,
                       lhs, #scale[i],
                       ss)
    }
  }
  else if(!(mm == "ISUV" || mm == "ASMV")) {
    Vlist[[sections]] <- r2(uname,uname,V,
                            fam,
                            lhs,
                            mf)
  }
  else {
    ## Check section size
    if((pp <- prod(sapply(mf[,dims,with=FALSE],function(x)length(unique(x))))) != nrow(mf)) {
      stop("Data has ",nrow(mf),
           " observations but the residual model implies ",pp)
    }
    if(is.unsorted(do.call(base::order,mf[,dims,with=FALSE])))
      stop("Data order does not match that specified by the residual model formula.", call.=FALSE)
    Vlist[[sections]] <- r2(uname,uname,V,
                            fam,
                            lhs,
                            mf)
  }
  new.names <- unlist(lapply(Vlist, function(x) {
    paste(sapply(x[2:length(x)], function(y){y$facnam}),collapse=":")}))
  ## names(Vlist) <- new.names
  ## (Re)set model frame attribute "scale.fit"
  ## Use in Gparam
  setattr(mf, "scale.fit", {if(nsect > 1 || (Vlist[[1]]$variance$con == "F" && distbn == 1))
                              "sigma"
                            else
                              "gamma"})
  Vlist
}
Gparam <- function(mf)
{
  ## List of initial values for G (random) structures
  ## Tgamma: 0 fixed, 1 variance, 2 ratio, 3 correlation, 4 covariance

  g2 <- function(term, dimensions, dispersion, scale, at.nam, data) {
    L2 <- vector(mode="list",length=length(dimensions)+1)
    names(L2) <- c("variance",unlist(lapply(dimensions,function(x)x$FacNam))) #Obj
    #gam.name <- paste(unlist(lapply(dimensions, function(x) {x$FacNam})),collapse=":")
    isVar <- 0

    ## Special cases: vm, (ide ?)
    ## These have is.variance==FALSE
    ## If vm is in a direct product and ALL dimensions are correlations
    ##    then tag a variance parameter to vm. This case must be treated as
    ##    a mult-dimension structure for struc.
    ## STOP doesn't look like the parameter can be tagged to vm!!!!!!!!!!!!!!
    # if(length(dimensions) > 1) {
    #   vmide <- which(is.element(unlist(lapply(dimensions, function(x)x$Fun)), 'vm'))
    #   if(length(vmide) > 0) {
    #      if(sum(unlist(lapply(dimensions[-vmide], function(x)as.numeric(x$isVariance)))) == 0) {
    #        dimensions[[vmide]]$isVariance <- TRUE
    #        dimensions[[vmide]]$Initial <- 0.1
    #        attr(dimensions[[vmide]]$Initial, "set") <- FALSE
    #        dimensions[[vmide]]$Con <- "P"
    #       }
    #    }
    #  }
    if(length(dimensions) > 1) {
      vmide <- which(is.element(unlist(lapply(dimensions, function(x)x$Fun)), 'vm'))
      if(length(vmide) > 0) {
         if(sum(unlist(lapply(dimensions[-vmide], function(x)as.numeric(x$isVariance)))) == 0) {
           stop("Direct product with vm() must be a variance structure", call.=FALSE)
          }
       }
     }

    for(i in 1:length(dimensions)) {
      X <- dimensions[[i]]
      n <- names(L2)[i+1]
      thisVar <- (!is.na(X$isVariance) && X$isVariance)
      if(thisVar && !attr(X$Initial, "set") && !asreml.options()$fixgammas) {
        include <- !any(is.element(c("grp","mbf"), unlist(lapply(dimensions,function(a)a$Fun))))
        ## special cases
        if(length(dimensions) == 2 && scale !=1.0 && include) { # only doing 2-d
          classify <- unlist(lapply(dimensions,function(a)a$Obj))
          tc <- unlist(lapply(classify,function(x)type.convert(x, as.is=FALSE)))
          if(all(!is.numeric(tc))) {
            if(i == 1) classify <- rev(classify) # saves a t() in us_vcov()
            if(Spcls[X$Fun, "FunGroup"] == "us") {
              ivals <- us_init(data, classify)
              X$Initial <- ivals * 0.1
              X$Con[attr(ivals, "fix")] <- "F"
            }
            else if(Spcls[X$Fun, "FunGroup"] == "diag") {
              X$Initial <- diag_init(data, classify) * 0.1
            }
            else if(Spcls[X$Fun, "FunGroup"] == "corh") {
              X$Initial[is.element(X$Tgamma, c(2,4))] <- diag_init(data, classify) * 0.1
            }
            else if(Spcls[X$Fun, "FunGroup"] == "corv") {
              X$Initial[is.element(X$Tgamma, c(2,4))] <- mean(diag_init(data, classify), na.rm=TRUE) * 0.1
            }
            else if(Spcls[X$Fun, "FunGroup"] == "corgh") {
              X$Initial <- corgh_init(data, classify) # NOTE: scaled in corgh_init
            }
            else if(Spcls[X$Fun, "FunGroup"] == "corgv") {
              X$Initial <- corgv_init(data, classify) # NOTE: scaled in corgv_init
            }
            else if(Spcls[X$Fun, "FunGroup"] == "xfa") {
              ## leave those fixed to init
              ivals <- fa_init(data, classify, fak(X$Lvls, X$Lab))
              if(!is.null(ivals)) {
                ff <- casefold(substr(X$Con,1,1),upper=TRUE) != "F"
                X$Initial[ff] <- ivals[ff]
              }
            }
            else if(Spcls[X$Fun, "FunGroup"] == "fa") {
              ## leave those fixed to init
              ff <- casefold(substr(X$Con,1,1),upper=TRUE) != "F"
              X$Initial[ff] <- fa_init(data, classify, sfak(X$Lvls, X$Lab), reverse=TRUE)[ff]
            }
            else {
              X$Initial[is.element(X$Tgamma, c(2,4))] <- X$Initial[is.element(X$Tgamma, c(2,4))] * scale
            }
          }
        }
        else {
          X$Initial[is.element(X$Tgamma, c(2,4))] <- X$Initial[is.element(X$Tgamma, c(2,4))] * scale
        }
      }
      L2[[n]]$facnam <- ifelse(is.null(at.nam),X$FacNam,paste(at.nam,X$FacNam,sep=":"))
      L2[[n]]$model <- X$Fun
      names(L2[[n]]$model) <- X$Obj
      L2[[n]]$levels <- X$Lvls
      L2[[n]]$initial <- as.double(X$Initial)
      names(L2[[n]]$initial) <- paste(term, X$Lab,sep="") #paste(gam.name,X$Lab,sep="")
      L2[[n]]$tgamma <- X$Tgamma
      L2[[n]]$tgamma[X$Tgamma < 3] <- ifelse(scale == 1, 2, 2) #1=variance, 2=gamma
      storage.mode(L2[[n]]$tgamma) <- "integer"
      L2[[n]]$con <- X$Con
      L2[[n]]$struc <- X$Struc
      L2[[n]]$struc[1] <- length(getLevels(X$Lvls))
      storage.mode(L2[[n]]$struc) <- "integer"
      L2[[n]]$bounds <- X$Bounds
      dimnames(L2[[n]]$bounds)[[1]] <- paste(term,dimnames(L2[[n]]$bounds)[[1]],sep="")
      isVar <- isVar + as.numeric(thisVar)
    }
    L2$variance$bounds <- matrix(c(NA,NA),ncol=2)
    dimnames(L2$variance$bounds) <- list("variance",c("LB","UB"))
    if(is.na(dispersion)) {
      if(isVar > 0) {
        L2$variance$model <- "id"
        names(L2$variance$model) <- "scale"
        L2$variance$initial <- as.double(NA)
        L2$variance$tgamma <- as.integer(ifelse(scale==1.0,2,1))
        L2$variance$con <- "F"
        L2$variance$struc <- as.integer(c(1,rep(0,15)))
        L2$variance$bounds[,c(1,2)] <- as.double(c(1.0,1.0))
      }
      else {
        L2$variance$model <- "idv"
        names(L2$variance$model) <- "scale"
        L2$variance$initial <- as.double(0.1 * scale)
        L2$variance$tgamma <- as.integer(ifelse(scale==1.0,2,1))
        L2$variance$con <- "P"
        L2$variance$struc <- as.integer(c(1,1,rep(0,14)))
        L2$variance$bounds[,c(1,2)] <- as.double(c(0.0001,1e37))
      }
    }
    else { ## -K ??
      L2$variance$model <- "idv"
      names(L2$variance$model) <- "scale"
      L2$variance$initial <- as.double(dispersion)
      L2$variance$tgamma <- as.integer(1)
      L2$variance$con <- "F"
      L2$variance$struc <- as.integer(c(1,1,rep(0,14)))
      L2$variance$bounds[,c(1,2)] <- as.double(c(dispersion, dispersion))
    }
    names(L2$variance$initial) <- term #gam.name
    dimnames(L2$variance$bounds)[[1]] <- term
    L2
  }

  ## START -------------------------------->
  if(is.null(attr(mf,"model.terms")$random))
    return(NULL)
  X <- attr(mf,"model.terms")$random$Terms.obj
  V <- attr(mf,"model.terms")$random$Var

  scale <- {if(attr(mf, "scale.fit") == "gamma")
              1.0
            else
              var(as.vector(as.matrix(mf[,response.col(mf),with=FALSE])), na.rm=TRUE)/2.0
          }
  ## Walk along the random formula (str() terms are preserved in random)
  tl <- attr(X,"term.labels")
  Glist <- list()
  for(z in seq(along=tl)) {
    ## trm.vars should match names(Var) for the duration
    ## replace with facnam
    trm.vars <- terms.variables(tl[z])
    ## special cases
    is.and <- sapply(V[trm.vars],function(x){x$Fun=="and"})
    trm.vars <- trm.vars[!is.and]
    if(length(trm.vars) == 0) next
    is.at <- sapply(V[trm.vars],function(x){x$Fun=="at"})
    if(sum(as.numeric(is.at)) > 1)
      stop("Multiple at() functions")
    is.str <- sapply(V[trm.vars],function(x){x$Fun=="str"})
    if(any(is.str)) {## should only be one str in a term
      str.lst <- lapply(V[trm.vars[is.str]],function(x)x$Call)[[1]]
    }
    trm.names <- do.call("cbind",lapply(V[trm.vars],function(x)x$FacNam))

    if(any(is.at)) {
      for(i in seq(1,nrow(trm.names))) {
        at.nam <- trm.names[i, is.at]
        if(any(is.str)) {
          Glist[[paste(trm.names[i,],collapse=":")]] <- g2(paste(trm.names[i,],collapse=":"),
                                       str.lst,NA,scale,at.nam, mf)
        }
        else {
          trm.V <- dimnames(trm.names)[[2]][!is.at]
          Glist[[paste(trm.names[i,],collapse=":")]] <- g2(paste(trm.names[i, is.at],
                                       paste(trm.names[1,!is.at],collapse=":"),
                                       sep=":"),
                                       V[trm.V],NA,scale,at.nam, mf) #trm.names[i,!is.at]
        }
      }
    }
    else if(any(is.str)) {
      if(length(trm.names) > 1) {
        Glist[[paste(trm.names, collapse=":")]] <- g2(paste(trm.names, collapse=":"),
                                                      c(V[trm.vars[!is.str]],str.lst),NA,scale,
                                                      paste(trm.names, collapse=":"), mf)
      }
      else
        Glist[[trm.names]] <- g2(trm.names, str.lst,NA,scale,NULL, mf)
    }
    else {
      Glist[[paste(trm.names,collapse=":")]] <- g2(paste(trm.names,collapse=":"),
                                                   V[trm.vars],NA,scale,NULL, mf)
    }
  }
  #new.names <- unlist(lapply(Glist, function(x) {
  #  paste(sapply(x[2:length(x)], function(y){y$facnam}),collapse=":")}))
  #names(Glist) <- new.names

  Glist
}
updateV <- function(dflt, param, which, update.con=FALSE, convert=FALSE) {
  rgupdt <- function(dflt, gammas, gmcstr, update.con, convert) {
    ## Update G or R structure list from a vector of gammas
    ## dflt is either R.param or G.param

    if(length(dflt)==0)
      return(NULL)

    up <- lapply(dflt,function(x,gammas,gmcstr,convert) {
      lapply(x,function(y,gammas,gmcstr,convert) {
        tmp <- names(y$initial)
        ## Only update those that match!
        i <- match(tmp,names(gammas),nomatch=NA)
        ii <- !is.na(i)
        i <- i[ii]
        if(length(i) > 0 && !is.na(y$initial[1])) {
          z <- y$initial
          z[ii] <- gammas[i]
          y$initial <- switch(y$model,
                              ante = {if(convert) udu(z) else z},
                              chol = {if(convert) ldl(z) else z},
                              cholc = {if(convert) ldl(z) else z},
                              id = {if(!is.na(y$initial)) z else NA},
                              z)
          if(!is.element(y$model, c('ante','chol',"cholc")) && update.con) {
            cc <- casefold(substr(gmcstr[i],1,1),upper=TRUE)
            upd <- cc != "?"
            if(is.element(y$model, c('fa','rr','sfa','facv')) && asreml.options()$rotate.fa) {
              var <- rep(FALSE, length(upd))
              var[grep("!var", names(y$initial)[ii])] <- TRUE
              upd <- upd & var
            }
            y$con[ii][upd] <- cc[upd]
            }
          names(y$initial) <- tmp
        }
        y
      },gammas,gmcstr,convert)
    },gammas,gmcstr,convert)
    up
  }

  ## If param is mode character then assume a filename:
  ##    csv file with header c("Component","Value","Constraint")
  ## If is.data.frame(param)
  ##    just call asreml.rupdt()
  ## If param is mode list:
  ##    Look for a component named "R/G.param"
  ##    If no component named "R/G.param" asume it is a R.param or G.param list object

  ## Match names and overwrite initial values of those parameters that match

  if(mode(param) == "character")
    param <- read.table(param,header=TRUE,sep=",",as.is=TRUE)
  if(is.data.frame(param)) {
    if(any(is.na(match(c('Component','Value','Constraint'),names(param)))))
      stop(as.character(substitute(param)),
           " must have names 'Component','Value','Constraint'")
    gammas <- param$Value
    gmcstr <- param$Constraint
    names(gammas) <- param$Component
    names(gmcstr) <- param$Component
    return(rgupdt(dflt,gammas,gmcstr,update.con,convert))
  }
  ## list form
  if(inherits(param, "asreml")) {
    param <- param[[paste0(which,".param")]]
  }
  else if(is.list(param)) {
    if(!is.na(match(paste0(which,".param"),names(param))))
      param <- param[[paste0(which, ".param")]]
  }
  else
    stop(as.character(substitute(param)),"Invalid mode for intial values argument.")
  nt <- length(param)
  gammas <- numeric(0)
  gmcstr <- character(0)
  for(n in seq(1,nt)) {
    nf <- length(param[[n]])
    for(j in 1:nf) {
      gammas <- c(gammas,param[[n]][[j]]$initial)
      gmcstr <- c(gmcstr,param[[n]][[j]]$con)
    }
  }
  names(gmcstr) <- names(gammas)
  not.id <- !is.na(gammas)
  gammas <- gammas[not.id]
  gmcstr <- gmcstr[not.id]
  return(rgupdt(dflt,gammas,gmcstr,update.con,convert))
}
udu <- function(gammas)
{
  ## For ante:
  ## gammas is length n(n+1)/2 with ANTE solutions in the appropriate
  ## n(q+1)-q(q+1)/2 positions

  N <- length(gammas)
  which <- rep(1,N)
  which[grep("<NotEstimated>$",names(gammas))] <- 0
  if(sum(which) == N)
    return(gammas)
  n <- (sqrt(8*N+1)-1)/2
  n <- floor(n+0.5)
  q <- ((2*n-1)-sqrt((2*n+1)^2-8*length(gammas[which==1])))/2
  q <- floor(q+0.5)
  U <- D <- matrix(0,nrow=n,ncol=n)
  xx <- 0 <= (col(U)-row(U)) & (col(U)-row(U)) <= q
  U[xx] <- gammas[which==1]
  diag(D) <- diag(U)
  diag(U) <- 1
  V <- solve(U %*% D %*% t(U))
  V[!lower.tri(V)]
}
ldl <- function(gammas)
{
  ## For chol:
  ## gammas is length n(n+1)/2 with CHOL solutions in the appropriate
  ## n(q+1)-q(q+1)/2 positions
  ##

  N <- length(gammas)
  which <- rep(1,N)
  which[grep("<NotEstimated>$",names(gammas))] <- 0
  if(sum(which) == N)
    return(gammas)
  n <- (sqrt(8*N+1)-1)/2
  q <- ((2*n-1)-sqrt((2*n+1)^2-8*length(gammas[which==1])))/2
  L <- D <- matrix(0,nrow=n,ncol=n)
  xx <- 0 <= (row(L)-col(L)) & (row(L)-col(L)) <= q
  L[xx] <- gammas[which==1]
  diag(D) <- diag(L)
  diag(L) <- 1
  V <- L %*% D %*% t(L)
  V[!lower.tri(V)]
}
resetCon <- function(obj, mf) {
  ## An R list
  ## We are here because options$gammaPar == TRUE
  ## if >1 sections return
  ## if one section AND S2 is F AND another variance is P
  ##    then set S2==P and fix the other at 1.0
  ##
  if(length(obj) > 1) return(obj)
  if(obj[[1]]$variance$con == "F") {
    vv <- which(unlist(lapply(obj[[1]][-1], function(x){ # which term
      any(x$tgamma == 1)
    }))) + 1
    if(length(vv) > 1) return(obj) #stop("Found more than one variance term")
    if(length(vv) == 0) return(obj)
    wp <- which(obj[[1]][[vv]]$tgamma == 1)[1]
    if(obj[[1]][[vv]]$con[wp] != "P") return(obj)
    obj[[1]]$variance$con <- "P"
    ni <- names(obj[[1]]$variance$initial)
    obj[[1]]$variance$initial <- 1.0
    names(obj[[1]]$variance$initial) <- ni
    ni <- names(obj[[1]][[vv]]$initial)[wp]
    obj[[1]][[vv]]$initial[wp] <- 1.0
    names(obj[[1]][[vv]]$initial[wp]) <- ni
    obj[[1]][[vv]]$con[wp] <- "F"
    setattr(mf, "scale.fit", "gamma")
  }
  return(obj)
}
resetPar <- function(R, mf) {
  if(length(R) > 1)
    return()
  fam <- attr(mf, "family")
  distbn <- unlist(lapply(fam,function(x)x$id))[1]
  setattr(mf, "scale.fit", {if(R[[1]]$variance$con == "F" && distbn == 1)
                              "sigma"
                            else
                              "gamma"})
}
us_vcov <- function(data, x) {
  ## data is a data.table & doesn't play well with tapply & cov
  ## x is a vector of strings (the classifiers) (2 only)
  ##   with the structure ident 2nd to save a t()
  y <- attr(data, "Response.col")
  ## Multivariate
  if(x[2] == "trait" && length(y) > 1) {
    df <- as.data.frame(data[, x[1], with=FALSE], stringsAsFactors=TRUE)
    tab <- tapply(data[[y[1]]], df, mean, na.rm=TRUE)
    for(i in 2:length(y))
      tab <- cbind(tab, tapply(data[[y[i]]], df, mean, na.rm=TRUE))
    tab[is.nan(tab)] <- NA
    vcov <- stats::cov(tab, use="pairwise.complete.obs")
  }
  else {
    df <- as.data.frame(data[, x, with=FALSE], stringsAsFactors=TRUE)
    tab <- tapply(data[[y]], df[x], mean, na.rm=TRUE)
    vcov <- stats::cov(tab, use="pairwise.complete.obs")
  }
  return(vcov)
}
us_init <- function(data, x) {
  vcov <- us_vcov(data, x)
  vec <- as.vector(t(vcov))[as.vector(upper.tri(vcov, diag=TRUE))]
  fix <- is.na(vec)
  vec[fix] <- 0.0001
  attr(vec,"fix") <- fix
  return(vec)
}
diag_init <- function(data, x) {
  vec <- diag(us_vcov(data, x))
  vec[is.na(vec)] <- 0.1
  return(vec)
}
fa_init <- function(data, x, k=1, sf=0.1, reverse=FALSE)
{
  ## y is a string (the response)
  ## x is a vector (max 2) of strings (the classifiers)
  vcov <- us_vcov(data, x) * sf
  vcov[is.na(vcov)] <- 0.001
  method <- 0 # correlation method
  fa <- .Call("us2fa", vcov, k, method, PACKAGE="asreml")
  if(is.null(fa)) {
    return(NULL)
  }
  if(reverse) { # sfa & facv are loadings then specific variances
    n <- dim(vcov)[1]
    fa <- fa[c(seq(n+1,length(fa)), seq(1,n))]
  }
  fa[is.na(fa)] <- 0.1
  return(fa)
}
# corgh_init <- function(data, x, sf=0.1) {
#   vcov <- cov2cor(us_vcov(data, x))
#   vec <- c(as.vector(t(vcov))[as.vector(upper.tri(vcov, diag=FALSE))], diag(vcov)*sf)
#   vec[is.na(vec)] <- 0.1
#   return(vec)
# }
# corgv_init <- function(data, x, sf=0.1) {
#   vcov <- cov2cor(us_vcov(data, x))
#   vec <- c(as.vector(t(vcov))[as.vector(upper.tri(vcov, diag=FALSE))], mean(diag(vcov))*sf)
#   vec[is.na(vec)] <- 0.1
#   return(vec)
# }
corgh_init <- function(data, x, sf=0.1) {
  vcov <- us_vcov(data, x)
  rcov <- cov2cor(vcov)
  vec <- c(as.vector(t(rcov))[as.vector(upper.tri(rcov, diag=FALSE))], diag(vcov)*sf)
  vec[is.na(vec)] <- 0.1
  return(vec)
}
corgv_init <- function(data, x, sf=0.1) {
  vcov <- us_vcov(data, x)
  rcov <- cov2cor(vcov)
  vec <- c(as.vector(t(rcov))[as.vector(upper.tri(rcov, diag=FALSE))], mean(diag(vcov))*sf)
  vec[is.na(vec)] <- 0.1
  return(vec)
}

#' Factor analytic initial values
#'
#' Estimate initial parameter values for factor analytic models from
#' the observed variance-covariance matrix.
#'
#' @param data
#'
#' A data frame containing the response and the base factors in the
#' factor analytic (compound) model term.
#'
#' @param model
#'
#' A two sided formula with the response on the left and a first order
#' interaction with a factor analytic model term on the right. Valid
#' factor analytic model functions are \code{"sfa"}, \code{"facv"},
#' \code{"fa"} or \code{rr} with an optional argument \code{k} specifying
#' the order of the factor analytic model. Other model functions are not
#' allowed.
#'
#' @param scale
#'
#' Scales the variance-covariance matrix prior to calculating the
#' parameter estimates (default is 1.0).
#'
#' @return
#'
#' A numeric vector of specific variances followed by the loadings if
#' the factor analytic function is \code{fa} or \code{rr}, otherwise
#' a numeric vector of loadings followed by the specific variances.
#'
#' @examples
#'
#' \dontrun{
#' init <- fa.init(data, fa(site,2):variety)
#' }
#'
fa.init <- function(data, model, scale=1.0) {
  ## model can have sfa/facv/fa/rr

  if(length(model) != 3)
    stop("'model' must be a two sided formula")

  tt <- terms(model, specials=c('sfa','facv','fa','rr'))
  vv <- dimnames(attr(tt, 'factors'))[[1]]
  fa <- which(unlist(lapply(attr(tt,'specials'), function(x){!is.null(x)})))
  if(length(fa)==0)
    stop("No fa term specified")
  if(length(fa) > 1)
    stop("Too many fa terms")

  faterm <- attr(tt,'specials')[[fa]]
  fafun <- names(attr(tt, 'specials'))[fa]
  vvexp <- parse(text=vv[faterm])[[1]]
  fafac <- all.vars(vvexp)[1]

  y <- vv[1]
  x <- c(vv[-c(1,faterm)], fafac)

  if(any(!is.element(c(y,x), names(data))))
    stop("Response or model factors not in the data")
  k <- 1
  if(length(vvexp) == 3)
    k <- vvexp[[3]]

  tab <- tapply(data[[y]], data[x], mean, na.rm=TRUE)
  vcov <- stats::cov(tab, use="pairwise.complete.obs") * scale
  vcov[is.na(vcov)] <- 0.001
  method <- 0 # correlation method
  fa <- .Call("us2fa", vcov, k, method, PACKAGE="asreml")
  if(is.element(fafun, c('sfa','facv'))) {
    n <- dim(vcov)[1]
    fa <- fa[c(seq(n+1, length(fa)), seq(1,n))]
  }
  return(fa)
}
trimSpc <- function(tt) {
  fun <- attr(tt,"specials")
  which <- sapply(fun, function(x){!is.null(x)})
  if(any(which))
    attr(tt,"specials") <- fun[which]
  else
    attr(tt,"specials") <- list()
  return(tt)
}
#' Read in a data frame.
#'
#' Reads in a file in table format and creates a data frame with the
#' same number of rows as there are lines in the file, and the same
#' number of variables as there are fields in the
#' file. Variables whose names begin with a capital letter are
#' converted to factors.
#'
#' @param ...
#'
#' Arguments to be passed to \code{\link[utils]{read.table}}.
#'
asreml.read.table <- function(...) {
  x <- read.table(...)
   if(any(dim(x) == 0))
    stop("Empty data frame")
  what <- which(regexpr("[A-Z]",substr(names(x),1,1)) > 0)
  if(length(what)) {
    for(i in what) {
      if(!is.factor(x[[i]])) x[[i]] <- factor(x[[i]])
    }
  }
  invisible(x)
}

prdStruc <- function(predict,mf,inter,glm)
{
  ## V4: glm is a list
  ##
  ## INTER[3] is a BASE 0 address into the data
  ## NPFACT[2] is an address in the data relative to 1
  ##
  ## predict structures
  ##
  ##  NPTABL 1 1=!DEC
  ##         2 0=!EST   1=!NONEST !PRE  1=!EST  -1=!FULL/!STAR/!ALIASED
  ##         3 !TURNPT
  ##         4 !PAR
  ##         5 !MAR
  ##         6 !SED=2 + !VPV=1  +TWOSTAGE/HERON=4  + TDIFF=8
  ##         7 !PLOT
  ##         8 !PRWTS   Multiway table weights      # !was !TAB
  ##         9 !ASSOCIATE
  ##        10 !AVER
  ##        11 RETRAN
  ##        12            holds number of predictions requested
  ##        13 !        INRANDOM, EXRANDOM
  ##        14 !IGNORE/!USE/!ONLY/!EXCEPT
  ##        15 !DEBUG
  ##           !SCALEMMAP

  #  npfact[1,     factor number
  #         2,     address : 0 for mu/trait
  #         3,     fn if used as a variate x  lin(a)  spl(a)  spl(x)
  #         4,     fn if used as a fixed factor  a  fac(x)
  #         5,     fn if factor random
  #         6,     fn if used as spline
  #         7]     1 for first parallel factor, -1 for subsequent
  #  -3     -4     -5     -6     -7     -8
  #  spl     mv    fac           pol     tr
  #                dev

  ## NULL predict
  if(is.null(predict)) {
    npred <- 0
    nfinmd <- 0
    baseFac <- 0
    npfact <- 0
    nptabl <- 0
    ivals <- 0
    pvals <- 0
    lpvals <- 0
    lnpvec <- 0
    lpwts <- 0
    lenPV <- 0
    lenPrdvals <- 1
    ptrPrdvals <- matrix(c(0,1),nrow=1,ncol=2)
    lenVpvals <- 1
    ptrVpvals <- matrix(c(0,1,0,1),nrow=1,ncol=4)
    prdLabels <- list()

    storage.mode(nptabl) <- "integer"
    storage.mode(npfact) <- "integer"
    storage.mode(ivals) <- "integer"
    storage.mode(pvals) <- "double"

    return(list(npred=npred, prdLabels=prdLabels, nfinmd=nfinmd,
                npfact=npfact, nptabl=nptabl, ivals=ivals, pvals=pvals,
                lpvals=lpvals, lnpvec=lnpvec, lpwts=lpwts, lenPrdvals=lenPrdvals,
                ptrPrdvals=ptrPrdvals, lenVpvals=lenVpvals, ptrVpvals=ptrVpvals))
  }

  ## Bug in R: Assigning a matrix of one element in code loses its attributes!!
  ##           Works at the command line matrix(1, ncol=1)

  ## Step 1: Build (half of) npfact and nptabl
  ## Base terms are in the dataframe inter$baseFac (baseFun & baseObj)

  uBase <- unique(inter$baseFac$baseObj)
  nfinmd <- length(uBase)
  npred <- 1 # retain in case ever revert back to V2 behaviour
  nptabl <- matrix(0, nrow=16, ncol=npred) # keep as a matrix so easier to extend
  npfact <- matrix(0, nrow=8, ncol=nfinmd*2)
  dimnames(npfact) <- list(c('facnum','address','var','fixed','ran','spl','parl','ord'),
                           c(uBase, uBase))

  ## Loop over rows of baseFac
  for(i in seq(1, nrow(inter$baseFac))) {
    ij <- inter$baseFac$facNum[i]
    ib <- match(inter$baseFac$baseObj[i], inter$baseFac$baseFun)
    if(is.na(ib)) { 
      ib <- ij
    } else {
      ib <- inter$baseFac$facNum[ib]
    }
    b <- match(inter$baseFac$baseObj[i], uBase) # may have time & spl(time) in model
    ## originally used ij here to get addr
    ## don't remember when & why changed!!
    addr <- inter$inter[3, match(inter$baseFac$baseObj[i], inter$facnam)]+1
    if(is.na(addr)) {
      addr <- inter$inter[3, match(inter$baseFac$baseFun[i], inter$facnam)]+1
    }
    if(is.na(addr)) {
      stop("Cannot get data column for ", inter$baseFac$baseObj[i])
    }
    if(inter$baseFac$baseFun[i] == inter$baseFac$baseObj[i])
      npfact[1,b] <- ij
    else if(npfact[1,b] == 0) # else a term like con(x) or lin(x)
      npfact[1,b] <- ij
    if(inter$inter[1, ij] == -8) { #Intercept
      npfact[3, b] <- inter$flev[ij]
      npfact[c(2,4,5,6,7,8), b] <- rep(0,6)
    }
    else {
      #npfact[c(3,4,5,6,7,8), b] <- rep(0,6)
      npfact[2, b] <- addr #inter[3] is base 0, this is base 1
      ## Special cases
      if(inter$nlev[ij] > 1) { # Group
        if(abs(inter$inform[ij]) == 2) # random
          npfact[5, b] <- -inter$nlev[ij]
        else
          npfact[4, b] <- -inter$nlev[ij]
      }
      else if(inter$inter[1,ij] == -3 ||  # spl
              inter$inter[1,ij] == -7 ||  # pol
              inter$inter[1,ij] == -13)   # leg
        npfact[6, b] <- ij
      else if(inter$inter[1,ij] == -5) #dev
        npfact[5, b] <- ij
      else if(inter$flev[ij] == 1 &&
              (inter$inter[3, ij] + 1) > 0 &&
              inter$inter[1, ij] != -15)
        npfact[3, b] <- ij
      else if(abs(inter$inform[ij]) == 2) {
        npfact[5, b] <- ib #should get base obj for at()
      }
      else {
        npfact[4, b] <- ib 
      }
      ## A term may appear in fixed & in random in an interaction
      if(all(npfact[3:6, b] == 0)) { # #npfact[6, b] == 0
        for(ff in seq(along=inter$facnam)) {
          if(length(grep(":", inter$facnam[ff])) > 0 ) { # an interaction
            tt <- as.character(attr(Terms(formula(paste("~", inter$facnam[ff]))), "variables")[-1])
            if(any(is.element(inter$baseFac[i, c(2,3)], tt))) {
              if(abs(inter$inform[ff]) == 2)
                npfact[5, b] <- ij
              else
                npfact[4, b] <- ij
            }
          }
        }
      }
      # may be referenced by an mbf()
      mbf <- which(inter$inter[1,] == -24)
      if(length(mbf) > 0) {
        mbf.src <- which(ij == inter$inter[4,mbf])
        if(length(mbf.src)) {
          npfact[6, b] = mbf[mbf.src[1]]
        }
      }
    }
  }

  pvals <- vector(mode="double")
  prdLabels <- list() # label the output

  howMany <- 0
  ivals <- 0
  lpvals <- 1
  livals <- 1
  lenPrdvals <- 0
  numnest <- 0

  ptrPrdvals <- c(0,0)
  vPtr <- 1
  lenVpvals <- 0
  ptrVpvals <- c(0,0,0,0)
  names(ptrVpvals) <- c('locVar','lenVar','locSed','lenSed')

  Pf <- predict$classify
  Pnames <- as.character(attr(Terms(formula(paste("~", Pf))), "variables")[-1])
  Pnames[Pnames == "Intercept"] <- "(Intercept)"

  nptabl[16, 1] <- nfinmd
  nptabl[1:15, 1] <- rep(0,15)

  nptabl[1, 1] <- -1

  if(length(predict$present) > 0)
    nptabl[2, 1] <- 0
  if(length(predict$estimable) > 0)
    nptabl[2, 1] <- 1

  nptabl[3, 1] <- 0
  nptabl[7, 1] <- 0
  nptabl[11, 1] <- unlist(lapply(glm, function(x)x$link))[1]
  if(nptabl[11, 1] == 1) nptabl[11, 1] <- 0
  nptabl[12, 1] <- 0
  nptabl[15, 1] <- 0

  nptabl[2, 1] <- as.numeric(predict$estimable)
  if(nptabl[2, 1] == 0) {
    a <- predict$aliased
    nptabl[2, 1] <- if(is.logical(a)) -2*as.numeric(a) else a
  }
  nptabl[5, 1] <- as.numeric(predict$margin) # not in V4
  prdLabels$margin <- as.numeric(predict$margin)
  nptabl[6, 1] <- 2*as.numeric(predict$sed) + as.numeric(predict$vcov)
  nptabl[13, 1] <- as.numeric(predict$inrandom)
  if(length(predict$exrandom) > 0 && predict$exrandom == TRUE)
    nptabl[13, 1] <- -1

  ## Parallel List (disallow margin) (in V3 only)
  parList <- NULL
  if(predict$parallel) {
    if(nptabl[5, 1] > 0)
      stop("Cannot mix margin and parallel in predict.", call.=FALSE)

    parList <- Pnames
    px <- match(parList, uBase)
    if(any(is.na(match(parList,Pnames))))
      stop("Terms in parallel list not in classify set.", call.=FALSE)
    if(any(is.na(px)))
      stop("Term(s) in parallel list not in the model.", call.=FALSE)
    if(length(px) < 2)
      stop("Parallel list must be at least length 2.", call.=FALSE)
    prdLabels$parallel <- parList

    nptabl[4, 1] <- px[1]
    flag <- 1
    for(ipx in px) {
      npfact[7, nfinmd+ipx] <- flag
      flag <- -1
    }
    if(length(predict$levels) && any(is.na(match(parList,names(predict$levels)))))
      stop("Must specify levels for all parallel terms.", call.=FALSE)
  }

  tmpIvals <- NULL
  ## Ignore
  ## If units in model then ignore for prediction
  igList <- newFacNam(predict$ignore, inter)

  ufac <- grep("units",inter$facnam)
  if(length(ufac) > 0)
    igList <- c(igList,inter$facnam[ufac])

  if(length(igList) > 0) {
    nptabl[14, 1] <- livals
    tmpIvals <- match(inter$facnam[inter$neword], igList, nomatch = -1)
    tmpIvals[tmpIvals < 0] <- 0
    tmpIvals[tmpIvals > 0] <- -1
  }
  ## Use
  if(length(uList <- newFacNam(predict$use, inter)) > 0) {
    nptabl[14, 1] <- livals
    tmpIvals <- match(inter$facnam[inter$neword], uList, nomatch = 0)
    tmpIvals[tmpIvals > 0] <- 1
  }
  ## Except
  if(length(eList <- newFacNam(predict$except, inter)) > 0) {
    nptabl[14, 1] <- livals
    tmpIvals <- match(inter$facnam[inter$neword], eList, nomatch = NA)
    tmpIvals[!is.na(tmpIvals)] <- -1
    tmpIvals[is.na(tmpIvals)] <- 1
  }
  ## Only
  if(length(oList <- newFacNam(predict$only, inter)) > 0) {
    nptabl[14, 1] <- livals
    tmpIvals <- match(inter$facnam[inter$neword], oList, nomatch = -1)
    tmpIvals[tmpIvals > 0] <- 1
  }
  ## Ignore/Use/Except/Only
  if(!is.null(tmpIvals)) {
    ivals <- c(ivals, tmpIvals)
    livals <- length(ivals)
  }

  ## Associate/Nest
  ## nest is a list of up to 2 associate groups
  ## ASReml allows for a max of 10 factors across both groups ?????

  if(length(nList <- predict$associate) > 0) {
    nptabl[9, 1] <- livals+1

    ## up to two groups
    if(length(nList[[1]]) == 0)
      stop("Empty associate list.")
    ## How to check if nested hierarchy is in order?????
    tmpNvals <- match(nList[[1]],  uBase)
    if(any(is.na(tmpNvals)))
      stop(nList[[1]][is.na(tmpNvals)]," is not in the set of base terms.")
    numnest <- numnest * 10 + length(tmpNvals)
    ivals <- c(ivals, numnest, tmpNvals)
    ## component 2
    if(length(nList[[2]]) > 0) {
      tmpNvals <- match(nList[[2]],  uBase)
      if(any(is.na(tmpNvals)))
        stop(nList[[2]][is.na(tmpNvals)]," is not in the set of base terms.")
      numnest <- numnest*10 + length(tmpNvals)
      ivals[livals+1] <- numnest
      ivals <- c(ivals,tmpNvals)
    }
    livals <- length(ivals)
  }

  buff <- rep(0,8)

  ## Classify List

  parFlag <- 1 #for parallel if necessary
  if(nptabl[4, 1])
    parFlag <- -1 #set already
  prOrd <- 0

  ## design.points
  is2d <- 1
  dp <- getPpoints(mf, NA, 1)
  if(prod(dim(dp)) > 0) {
    dp <- dp[Pnames[which(is.element(Pnames, dimnames(dp)[[1]]))],,drop=FALSE]
    if((is2d <- nrow(dp)) > 1) {
      predict$parallel <- TRUE
    }
  }
  for(fac in Pnames) {
    ##Check in baseFac & baseFun
    if(is.na(match(fac, uBase))) {
      if(is.na(ji <- match(fac,inter$baseFac$baseFun))) {
        stop("Predict: ",fac," not in the model.", call.=FALSE)
      }
      else {
        Pfac <- inter$baseFac$baseObj[ji] # set to base FAC
        Pfun <- inter$baseFac$baseFun[ji]
      }
    }
    else {
      Pfac <- fac # keep as Pname
      Pfun <- inter$baseFac$baseFun[match(fac, inter$baseFac$baseObj)] #only gets first!!
    }
    fn <- npfact[1, Pfac]
    is.vm <- substr(Pfun,1,2) == "vm"

    ## Intiialise prdLabels$var[[Pfac]] to a 2x2 matrix to work around R bug
    prdLabels$var[[Pfac]] <- matrix(0.0, nrow=2, ncol=2)

    ## PVfac = fac name to look for in varLevels
    ## Do this to find things like "giv(variety)"
    ## Always choose the function levels if vm()
    if(is.vm) {
      PVfac <- Pfun
    }
    else if(is.na(match(Pfac, names(inter$varLevels)))) {
      if(is.na(match(Pfun, names(inter$varLevels))))
        stop("Predict: Cannot get levels for ",Pfac, " (",Pfun,")", call.=FALSE)
      else
        PVfac <- Pfun
    }
    else {
      PVfac <- Pfac
    }

    ## 'fix' names of predict components ($levels)
    ## doing this so either ped(cross) or 'cross' can be used
    ##    base fac is 'cross'

    if(length(predict$levels) > 0) {
      nn <- names(predict$levels)
      if(!is.na(match(fac,nn))) {
        nn[nn==fac] <- Pfac
        names(predict$levels) <- nn
      }
    }

    ##Pp <- inter$facnam[inter$baseFac$facNum[ji]]
    ##ij <- match(Pp, inter$facnam)
    ij <- fn
    buff[1] <- fn

    npcol <- match(Pfac, uBase)
    if(is.na(npcol))
      stop(paste(sQuote(Pfac)," not found in base factor table."))
    ##==================================================================

    ## Find if predictpoints set
    ##   determine if 2d (need to set parallel)
    ##   ignore for spline & pol - use attr(mf,"model.terms")$random$Vars[[x]]$Coords
    ##                             from spl() evaluation. (was "nuxPoints")
    ##   ignore if levels set
    ##   else set parallel & levels
    spline <- npfact[6, npcol]
    if(spline > 0 && inter$inter[1, spline] == -24) { #mbf
      spline <- 0
    }
    noskip <- TRUE
    if(spline > 0)
      noskip <- !is.element(inter$inter[1,spline],c(-3,-7))

    if(prod(dim(dp)) > 0 && is.element(Pfac, dimnames(dp)[[1]]))
      pp <- dp[Pfac,]
    else
      pp <- NULL

    if(is2d > 0) {
      if(is.null(predict$levels[[Pfac]]) && noskip) {
        predict$levels[[Pfac]] <- pp
        if(is2d > 1) {
          parList <- c(parList,Pfac)
          prdLabels$parallel <- c(prdLabels$parallel,Pfac)
          npfact[7,nfinmd+npcol] <- parFlag
          parFlag <- -1
        }
      }
    }

    ##===================================================================
    fixfac <- npfact[4,npcol]
    ranfac <- npfact[5,npcol]
    if(length(predict$levels[[Pfac]]) > 0) {
      if(ranfac < 0 || fixfac < 0) { # Group
        which <- inter$varLevels[[ inter$facnam[ij] ]]
        Plevs <- predict$levels[[Pfac]]
        if(is.matrix(Plevs)) {
          if(ncol(Plevs) != length(which))
            stop(paste("Matrix of values for ",Pfac," must have ",length(which)," columns."))
          prdLabels$var[[Pfac]] <- Plevs
          if(is.null(dimnames(Plevs)[[1]]))
            dimnames(prdLabels$var[[Pfac]]) <- list(seq(1,nrow(Plevs)),which)
          Plevs <- as.vector(t(Plevs))
        }
        else {
          if(length(Plevs)%%length(which) != 0)
            stop("Number of values for ",Pfac," must be a multiple of ",
                       length(which),".")
          nr <- length(Plevs)/length(which)
          prdLabels$var[[Pfac]] <- matrix(Plevs, nrow=nr, byrow=TRUE, dimnames=list(seq(1,nr),which))
          Plevs <- as.vector(Plevs)
        }
      }
      else if(is.numeric(predict$levels[[Pfac]])) {
        Plevs <- predict$levels[[Pfac]]
        if(length(inter$varLevels[[PVfac]]) > 1) { # a factor
          if(max(Plevs) > length(inter$varLevels[[PVfac]]))
            stop("Predict levels out of range: ", PVfac, call.=FALSE)
        }
        if(inter$flev[match(PVfac,inter$facnam)] > 1)
          Plabs <- inter$varLevels[[PVfac]][Plevs]
        else
          Plabs <- Plevs

        prdLabels$var[[Pfac]] <- matrix(Plevs, ncol=1, dimnames=list(Plabs,Pfac))
      }
      else {
        Plevs <- match(predict$levels[[Pfac]],inter$varLevels[[PVfac]])
        if(any(is.na(Plevs)))
          stop("Predict levels not in ",PVfac, call.=FALSE)
        prdLabels$var[[Pfac]] <- matrix(Plevs, ncol=1, dimnames=list(predict$levels[[Pfac]],Pfac))
      }
      pvals <- c(pvals, Plevs)
    }
    else {
       if(spline > 0) {
        if(is.element(inter$inter[1,spline], c(-3, -7, -13))) { #Spline, Pol, Leg
          ## get points from the function evaluation (aispline.f)
          ## located with function call (spl(x)) not object (x)
          ## should be only one.
          pv <- lapply(attr(mf, "model.terms")[c('fixed','mixed')],function(x,n){
                         x$Vars[[n]]$Coords},inter$facnam[spline])
          if(length(pvi <- which(unlist(lapply(pv,function(x)!is.null(x))))) > 1)
            stop("Error locating spl/pol/leg term in predict.")
          pv <- pv[[pvi]]
          pvals <- c(pvals,pv)
          prdLabels$var[[Pfac]] <- matrix(pv, ncol=1, dimnames=list(pv,Pfac))
        }
        else {
          dat <- mf[[inter$inter[3,spline] + 1]]
          if(is.factor(dat)) dat <- as.numeric(dat)
          pv <- c(min(dat,na.rm=TRUE),mean(dat,na.rm=TRUE),max(dat,na.rm=TRUE))
          pvals <- c(pvals,pv)
          prdLabels$var[[Pfac]] <- matrix(pv, ncol=1, dimnames=list(pv,Pfac))
        }
      }
      else if(inter$inter[1,ij] == -8) { # Intercept/trait
        pv <- seq(1,length(inter$varLevels[[PVfac]]))
        pvals <- c(pvals, pv)
        prdLabels$var[[Pfac]] <- matrix(pv, ncol=1, dimnames=list(inter$varLevels[[PVfac]],Pfac))
      }
      else if(inter$flev[ij] == 1 & inter$inter[4,ij] <= 0) { #Covariate
        ## possible error here with factors that have only 1 level
        if(length(levels(mf[[inter$inter[3,ij]+1]])) > 0) {
          stop(inter$facnam[ij]," has only one level.")
        }
        pv <- mean(mf[[inter$inter[3,ij]+1]],na.rm=TRUE)
        pvals <- c(pvals,pv)
        prdLabels$var[[Pfac]] <- matrix(pv, ncol=1, dimnames=list(pv,Pfac))
      }
      else if(inter$inter[4,ij] == -1) { #Con
        pv <- seq(1,inter$flev[ij]+1)
        pvals <- c(pvals,pv)
        lvCon <- levels(mf[[inter$inter[3,ij]+1]])
        prdLabels$var[[Pfac]] <- matrix(pv, ncol=1, dimnames=list(lvCon,Pfac))
      }
      else if(ranfac < 0 || fixfac < 0) { # Group
        if(length(inter$coords[[Pfac]]) > 0) {
          which <- inter$varLevels[[ inter$facnam[ij] ]]
          what <- matrix(inter$coords[[Pfac]][1,],nrow=1)
        }
        else {
          which <- inter$varLevels[[ inter$facnam[ij] ]]
          what <- matrix(apply(mf[,which,with=FALSE],2,mean,na.rm=TRUE),nrow=1)
        }
        dimnames(what) <- list("Average",which)
        pvals <- c(pvals,what[1,])
        prdLabels$var[[Pfac]] <- what
      }
      else { #Factor
        pv <- seq(1,length(inter$varLevels[[PVfac]]))
        pvals <- c(pvals,pv)
        prdLabels$var[[Pfac]] <- matrix(pv, ncol=1, dimnames=list(inter$varLevels[[PVfac]],Pfac))
       }
    }
    prOrd <- prOrd+1
    buff[8] <- prOrd
    buff[7] <- npfact[7,nfinmd+npcol]
    buff[2] <- lpvals
    buff[3] <- length(pvals)-lpvals+1
    lpvals <- length(pvals)+1
    npfact[, nfinmd+npcol] <- buff
  }
  ## Work out length of return vectors

  xLevs <- sapply(prdLabels$var,function(x) {
    if(is.vector(x))
      return(length(x))
    else
      return(nrow(x))
  })

  if(is.null(prdLabels$parallel))
    pll <- rep(FALSE, length(xLevs))
  else
    pll <- !is.na(match(names(prdLabels$var),prdLabels$parallel))

  howMany <- ie(sum(xLevs[!pll])==0,0,prod(xLevs[!pll])) +
    sum(xLevs[!pll])*prdLabels$margin +
      ie(length(xLevs[pll])==0,0,xLevs[pll][1])

  if(length(parList) > 0 & (nptabl[4, 1] == 0))
    nptabl[4, 1] <- match(parList[1], uBase)

  ptrPrdvals[1] <- lenPrdvals+1

  ptrPrdvals[2] <- howMany
  lenPrdvals <- lenPrdvals + howMany

  if(nptabl[6, 1]==1 | nptabl[6, 1] == 3) {
    ptrVpvals[1] <- vPtr
    ptrVpvals[2] <- howMany*(howMany+1)/2
    vPtr <- vPtr + ptrVpvals[2]
    lenVpvals <- vPtr-1
  }
  if(nptabl[6, 1]==2 | nptabl[6, 1]==3) {
    ptrVpvals[3] <- vPtr
    ptrVpvals[4] <- howMany*(howMany-1)/2
    vPtr <- vPtr + ptrVpvals[4]
    lenVpvals <- vPtr-1
  }
  if(nptabl[6, 1]==0) {
    ptrVpvals[1] <- vPtr
    ptrVpvals[2] <- 0
    ptrVpvals[3] <- vPtr
    ptrVpvals[4] <- 0
  }

  ## Present List
  buff <- rep(0,8)
  ##may be a single vector or list of 2 vectors for second present clause
  prsList <- predict$present
  if(length(prsList) > 0) {
    tmpList <- list()
    if(is.list(prsList))
      tmpList <- prsList
    else {
      tmpList[[1]] <- prsList
      names(tmpList) <- Pf
    }
    for(L in 1:length(tmpList)) {
      if(casefold(names(tmpList)[L]) == "prwts") {
        ## Work out how many weights there should be
        ## Weights refer to first present list
        which <- seq(1,length(tmpList))[-L][1]
        ij <- match(tmpList[[which]],inter$facnam)
        if(any(is.na(ij)))
          stop("Not all factors in present list are in the model\n")
        kk <- prod(inter$flev[ij])
        if(length(tmpList[[L]]) != kk)
          stop(paste("Expected",kk,"weights for present list","\n"))
        pvals <- c(pvals,tmpList[[L]])
        nptabl[8, 1] <- lpvals
        lpvals <- length(pvals)+1
      }
      else {
        for(LL in 1:length(tmpList[[L]])) {
          Pfac <- tmpList[[L]][LL]
          if(is.na(match(Pfac,inter$facnam)))
            Pfac <- ambiguous(Pfac, inter$baseFac)
          Plevs <- NULL
          if(!is.null(predict$levels[[Pfac]])) {
            if(is.numeric(predict$levels[[Pfac]]))
              Plevs <- predict$levels[[Pfac]]
            else
              Plevs <- match(predict$levels[[Pfac]],inter$varLevels[[PVfac]])
          }
          npcol <- match(Pfac, uBase)
          if(is.na(npcol))
            npcol <- match(aka(Pfac, inter$baseFac), uBase)
          where <- nfinmd+npcol
          buff <- npfact[,where]
          buff[4] <- -LL-((L-1)*100)
          ## Done before??
          if(buff[1] == 0) {
            ij <- match(Pfac,inter$facnam)
            if(is.null(Plevs))
              Plevs <- seq(1,inter$flev[ij])
            pvals <- c(pvals,Plevs)
            buff[2] <- lpvals
            buff[3] <- length(pvals)-lpvals+1
            lpvals <- length(pvals)+1
          }
          npfact[,where] <- buff
        }
      }
    }
  }

  ## Average List
  ## may be a list for weights vectors
  prsList <- predict$average
  lvec <- 0
  if(length(prsList) > 0) {
    for(L in 1:length(prsList)) {
      Plevs <- NULL
      if(is.list(prsList)) {
        if(is.list(prsList[[L]]))
          stop("Average must be a vector of variate names or a list of weight vectors\n")
        Pfac <- names(prsList)[L]
        Plevs <- prsList[[L]]
        lvec <- length(Plevs)
      }
      else
        Pfac <- prsList[L]

      if(is.na(match(Pfac, inter$facnam)))
        Pfac <- ambiguous(Pfac, inter$baseFac)
      ij <- match(Pfac,inter$facnam)
      npcol <- match(Pfac, uBase)
      ## Might be an fa or something
      if(is.na(npcol))
        npcol <- match(aka(Pfac, inter$baseFac), uBase)
      where <- nfinmd+npcol
      buff <- npfact[,where]

      if(is.null(Plevs)) {
        Plevs <- c(rep(1,inter$flev[ij])/inter$flev[ij],
                   rep(0.0,max(0,inter$flev[ij]-inter$flev[ij])))
      }
      if(length(Plevs) != inter$flev[ij]) {
        warning(paste(Pfac,"has",inter$flev[ij],"levels; extra weights ignored",
                      "or missing weights treated as zero.\n"))
        Plevs <- c(Plevs,rep(0.0,max(0,inter$flev[ij]-length(Plevs))))
      }
      pvals <- c(pvals,Plevs[1:inter$flev[ij]])
      buff[4] <- lpvals
      buff[5] <- lvec ##length(pvals)-lpvals+1
      lpvals <- length(pvals)+1
      npfact[,where] <- buff
    }
  }

  wFun <- function(x) {
    obj <- inter$baseFac$baseObj[is.element(inter$baseFac$baseFun, x)]
    return(which(is.element(uBase, obj)))
  }
  ## Set the order of terms in pvals dataframe
  ## If 'trait' or a function of it eg lin(trait) in the classify set make it last

  if(!is.na(w <- match('trait', unlist(lapply(Pnames, function(x){all.vars(parse(text=x))})))))
    clas <- c(Pnames[-w],Pnames[w])
  else
    clas <- Pnames

  w <- match(clas, uBase)
  if(length(wna <- which(is.na(w))) > 0) {
    w[wna] <- wFun(clas)[wna]
  }
  vec <- seq(1,nfinmd)
  ord <- c(w,vec[-w])
  vec[ord] <- vec

  names(ptrPrdvals) <- c('loc','len')

  npfact[8,] <- c(rep(0,nfinmd),order(vec)) #vec

  if(length(ivals)==0) ivals <- 0
  lpwts <- length(pvals)+1
  pvals <- c(pvals,rep(0.0,(2*nfinmd+1)))
  ## from asreml.call v3
  lpvals <- length(pvals)
  pvals <- c(pvals,rep(0.0,sum(inter$flev)))
  lnpvec <- length(pvals)
  ##
  ## Set nptabl(12)
  pflag <- FALSE
  nptabl[12] <- 1
  for(i in 1:nfinmd) {
    if(npfact[1, i+nfinmd] == 0) {
      next
    }
    k <- npfact[3, i+nfinmd]
    if(k == 0) {
      next
    }
    if(npfact[2, i] > 0) { # not mu
      k <- k / inter$nlev[npfact[1, i]] # group
    }
    nptabl[12] <- nptabl[12] * k
    if(npfact[7, i+nfinmd] != 0) { # parallel
      if(pflag) {
        nptabl[12] <- nptabl[12] / k
      } else {
        pflag <- TRUE
      }
    }
  }
  
  storage.mode(nptabl) <- "integer"
  storage.mode(npfact) <- "integer"
  storage.mode(ivals) <- "integer"
  storage.mode(pvals) <- "double"

  return(list(npred=npred, prdLabels=prdLabels, nfinmd=nfinmd,
             npfact=npfact, nptabl=nptabl, ivals=ivals, pvals=pvals,
             lpvals=lpvals, lnpvec=lnpvec, lpwts=lpwts, lenPrdvals=lenPrdvals,
             ptrPrdvals=ptrPrdvals,lenVpvals=lenVpvals, ptrVpvals=ptrVpvals,
             predict=predict))
}

aka <- function(x, baseFac) {
  ## We are here because x was not found in uBase (vec of unique base objects)
  ## Find it in baseFun and return baseObj
  ## Ambiguous if more than one match - stop.

  if(length(e <- which(is.element(baseFac$baseFun, x))) > 1)
    stop("Predict: ", x, " is ambiguous.", call.=FALSE)

  if(length(e) == 0)
    stop("Predict: ", x, " not found.", call.=FALSE)

  return(baseFac$baseObj[e])
}
ambiguous <- function(x, baseFac) {
  ## We are here because x was not found in facnam.
  ## Perhaps because function forms like vm() & ide() are in the model

  if(length(e <- which(is.element(baseFac$baseObj, x))) > 1)
    stop("Predict: ", x, " is ambiguous.")

  if(length(e) == 0)
    stop("Predict: ", x, " not found.", call.=FALSE)

  return(baseFac$baseFun[e])
}
newFacNam <- function(x, inter) {
  ## check if elements of x in facnam & replace if possible
  if(length(x) == 0)
    return(x)
  e <- which(!is.element(x, inter$facnam))
  if(length(e) == 0)
    return(x)

  x[e] <- unlist(lapply(x[e], function(a) {ambiguous(a, inter$baseFac)}))

  return(x)
}

ie <- function(test,altT,altF)
{
  if(test)
    altT
  else
    altF
}

getOp <- function(expr, op)
{
  ## return the expressions separated by the operator character
  ## eg: pipe (|) or plus (+)
  ## on first entry, expr is usually the expression on the right of "~"
  if (is.name(expr) || !is.language(expr)) return(NULL)
  if (expr[[1]] == as.name("(")) return(getOp(expr[[2]],op))
  if (!is.call(expr)) stop("expr must be of class call")
  if (expr[[1]] == as.name(op)) return(expr)
  if (length(expr) == 2) return(getOp(expr[[2]],op))
  c(getOp(expr[[2]],op), getOp(expr[[3]],op))
}
getPpoints <- function(data, term, type=NA)
{
  ## return coordinate points in a matrix by rows
  ## type 1 = design points
  ##      2 = knot points
  ##      3 = 1-d power model coords

  points <- attr(data, "points.env")
  addrs <- points$addrs

  if(!is.na(type)) { #why doesn't 'subset' work here???????????
    if(!is.na(term))
      addrs <- addrs[(addrs$type==type & addrs$term == term),]
    else
      addrs <- addrs[addrs$type==type,]
  }
  else
    stop("'type' is NA")

  pp <- matrix(0.0, nrow=0, ncol=0)

  if((pdim <- nrow(addrs)) > 0) {
    pp <- matrix(points$points[seq(addrs$index[1],addrs$index[1]+sum(addrs$n)-1)],
                 nrow=pdim,byrow=TRUE)
    dimnames(pp) <- list(addrs$dimension, dimnames(pp)[[2]])
  }
  return(pp)
}
getIBV <- function(data, obj)
{
  ## get a 'column' of IBV
  ibv <- attr(data, "points.env")$IBV
  if(is.na(match(obj,dimnames(ibv)[[2]]))) {
    x <- rep(0,4)
    names(x) <- dimnames(ibv)[[1]]
  }
  else
    x <- ibv[,obj]

  return(x)
}
getJBV <- function(data, obj)
{
  ## get a 'column' of JBV
  jbv <- attr(data, "points.env")$JBV

  if(is.na(match(obj,dimnames(jbv)[[2]]))) {
    x <- rep(0,4)
    names(x) <- dimnames(jbv)[[1]]
  }
  else
    x <- jbv[,obj]

  return(x)
}
locKnots <- function(data, term)
{
  ## return position & length of knot points
  ## these go in inter[2] and inter[4]
  points <- attr(data, "points.env")
  addrs <- points$addrs[(points$addrs$type == 2 & points$addrs$term == term), ]
  if(nrow(addrs) == 0)
    return(c(0,0))
  else if(nrow(addrs) == 1) {
    x <- unlist(addrs[1, c(3,4)])
    return(x - c(1,0)) # -c(1,0) inter[2] is a base address in asreml???????
  }
  else
    stop("Duplicate knot point vectors")
}
Fown <- function(ftest, inter)
{
  ## must be a formula like ~ A | B + C
  if(length(as.formula(ftest)) !=2)
    stop("Expression for F test must be a formula (with no response variate)")

  ## not set
  if(length(ftest[[2]]) == 0)
    return(0)

  ## separate based on the pipe symbol
  ff <- getOp(ftest[[2]], '|')

  if(is.null(ff)) {
    ## no pipe
    ffL <-  attr(Terms(ftest),'term.labels')
    ffR <- character(0)
  }
  else {
    ffL <- attr(Terms(formula(paste("~",my.dparse(ff[[2]])))),'term.labels')
    tt <- Terms(formula(paste("~",my.dparse(ff[[3]]))))
    ffR <- ie(attr(tt,'intercept'),
              c("(Intercept)",attr(tt,'term.labels')),
              attr(tt,'term.labels'))
  }
  if(length(ffL) !=1)
    stop("Only a single term can be tested in 'Ftest'")

  ownvec <- c(0,0,match(ffL,inter$facnam),-match(ffR,inter$facnam))
  if(any(is.na(ownvec)))
    stop("term in 'Ftest' does not appear in the model")
  ## ASReml addresses
  ownvec[1] <- length(ownvec)
  ownvec[2] <- ownvec[1]-2
  return(ownvec)
}
prdList <- function(prdStruc,prdvals,vpvmat,avsed)
{
  #
  # make list from predictions, se's etc
  #
  ltri <- function(npv, x) {
    # n <- (1+sqrt(8*length(x)+1))/2
    m <- npv * (npv + 1) / 2
    z <- seq(1, m)
    vec <- rep(NA, m)
    vec[-z*(z+1)/2] <- x
    return(vec)
  }

  typeConvert <- function(x, keep.char) {
    if(is.numeric(x) || is.factor(x) || keep.char)
      return(x)
    else
      return(type.convert(x,as.is=TRUE))
  }

  prdLabels <- prdStruc$prdLabels
  npred <- prdStruc$npred
  prd <- vector(mode="list",length=npred)
  estim <- c('NA','Estimable','Not Estimable','Aliased')

  baseNames <- (dimnames(prdStruc$npfact)[[2]])[1:prdStruc$nfinmd]
  vpvBase <- 0

  Pnames <- names(prdLabels$var)
  ## Order these in npfact[8] order
  ## npfact[8,nfinmd] is in order of column numbers
  bn <- baseNames[prdStruc$npfact[8, seq(prdStruc$nfinmd+1, 2*prdStruc$nfinmd)]]
  Pnames <- bn[is.element(bn, Pnames)]

  ## Parallel ?
  PA <- prdStruc$predict$parallel

  Pgrid <- vector(length=length(Pnames), mode="list")
  names(Pgrid) <- Pnames

  sed <- prdStruc$nptabl[6]
  margin <- prdStruc$nptabl[5] == 1
  if(margin)
    stop("'margin' option not available\n", call. = FALSE)

  for(Pfac in Pnames)
    Pgrid[[Pfac]] <- typeConvert(dimnames(prdLabels$var[[Pfac]])[[1]],
                                 keep.char = ((prdStruc$npfact[3, Pfac] + 
                                               prdStruc$npfact[6, Pfac]) == 0)) #used as factor

  prd <- list()
  if(!prdStruc$predict$aliased)
    prdvals[,c(1,2)][prdvals[,3]==3] <- c(NA,NA)
  avsed[avsed > 9e36] <- NA
  prd$pvals <- cbind(asr_expandGrid(Pgrid, PA),data.frame(prdvals), stringsAsFactors=TRUE)
  prd$pvals$status <- estim[prdvals[,3]+1]
  attr(prd$pvals, "heading") <- attr(prdvals,"heading")
  class(prd$pvals) <- c("asreml.predict","data.frame")

  all.aliased <- (all(prdvals[,3] == 3) && !prdStruc$predict$aliased)
  if(!all.aliased) {
    ##vpv or sed matrix
    npv <- prdStruc$lenPrdvals
    if(sed==1 || sed==3) {
      vpvmat[vpvmat > 9.9e36] <- NA
      prd$vcov <- new("dspMatrix",uplo="U", Dim=as.integer(c(npv,npv)), x=vpvmat)
    }
    if(sed==2 || sed==3) {
      vpvmat[vpvmat > 9.9e36] <- NA
      prd$sed <- new("dspMatrix",uplo="U", Dim=as.integer(c(npv,npv)),
                    x=ltri(npv, vpvmat))
    }
   if(sed==0)
      prd$avsed <- avsed[1]
    else {
      prd$avsed <- avsed[2:4]
    }
  }
  return(prd)
}
asr_expandGrid <- function(flist, parallel)
{

  ## make a data frame from factor list

  asr.expand.grid <- function (...) {
    nargs <- length(args <- list(...))
    if (!nargs)
      return(as.data.frame(list(), stringsAsFactors=TRUE))
    if (nargs == 1 && is.list(a1 <- args[[1]]))
      nargs <- length(args <- a1)
    if (nargs == 0)
      return(as.data.frame(list(), stringsAsFactors=TRUE))
    cargs <- args
    nmc <- paste("Var", 1:nargs, sep = "")
    nm <- names(args)
    if (is.null(nm))
      nm <- nmc
    else if (any(ng0 <- nchar(nm) > 0))
      nmc[ng0] <- nm[ng0]
    names(cargs) <- nmc
    rep.fac <- 1
    d <- sapply(args, length)

    orep <- prod(d)
    for (i in seq(nargs,1,-1)) {
      x <- args[[i]]
      nx <- length(x)
        orep <- orep/nx
      x <- x[rep.int(rep.int(seq(1,nx), rep.int(rep.fac,nx)), orep)]
      if (!is.factor(x) && is.character(x))
        x <- factor(x, levels = unique(x))
      cargs[[i]] <- x
      rep.fac <- rep.fac * nx
    }
    rn <- as.integer(seq(1,prod(d))) #.set_row_names(as.integer(prod(d)))
    structure(cargs, class = "data.frame", row.names = rn)
  }

  if(!parallel) return(asr.expand.grid(flist))

  if(length(flist) == 1 && is.list(flist[[1]]))
    flist <- flist[[1]]

  dim <- sapply(flist, length)
  if(all(dim == 0)) {
    result <- do.call("data.frame", flist)
  }
  len <- max(dim)
  result <- vector("list", ndim <- length(dim))
  out.names <- names(flist)
  if(length(out.names) == 0.)
    out.names <- paste("Var", seq(length = ndim), sep = "")
  names(result) <- out.names

  for(i in seq(length = ndim)) {
    this <- flist[[i]]
    if(isnum <- is.numeric(this))
      labels <- format(this)
    else {
      flabels <- levels(this)
      labels <- as.character(this)
      if(length(flabels) == 0) {
        flabels <- unique(labels)
        this <- match(this, flabels)
      }
    }
    vari <- rep(this, length=len)
    result[[i]] <- if(isnum) vari else factor(vari, levels = seq(
                                                      flabels), labels = flabels)
  }

  return(data.frame(result, stringsAsFactors = TRUE))
}
#' Check a pedigree
#'
#' Checks a pedigree for consistency, adds missing founders and
#' sorts so that founders appear before individuals.
#'
#' @param pedigree
#'
#' A data frame where the first three columns correspond to the
#' identifiers for the individual, male parent and female parent,
#' respectively. The row giving the pedigree of an individual must
#' appear before any row where that individual appears as a
#' parent. Founders use 0 (zero) or NA in the parental columns.
#'
#' @param fgen
#'
#' An optional list of length 2 where \code{fgen[[1]]} is a character
#' string naming the column in \code{pedigree} that contains the level
#' of selfing or the level of inbreeding of an individual. In
#' \code{pedigree[,fgen[[1]]]}, 0 indicates a simple cross, 1
#' indicates selfed once, 2 indicates selfed twice, etc. A value
#' between 0 and 1 for a base individual is taken as its inbreeding
#' value. If the pedigree has implicit individuals (they appear as
#' parents but not as individuals), they will be assumed base
#' non-inbred individuals unless their inbreeding level is set with
#' \code{fgen[[2]]}, where \code{0 < fgen[[2]] < 1} is the inbreeding
#' level of such individuals.
#'
#' @param gender
#'
#' An optional character string naming the column of \code{pedigree}
#' that codes for the gender of an individual. \code{pedigree[,
#' gender]} is coerced to a factor and must only have two (arbitrary)
#' levels, the first of which is taken to mean "male". An inverse
#' relationship matrix is formed for the X chromosome as described by
#' \cite{Fernando and Grossman, 1990} for species where the male is XY
#' and the female is XX.
#'
#' @param mv
#'
#' A character vector of missing value indicators; elements of
#' \code{pedigree} that exactly match any of the members of \code{mv}
#' are treated as missing.
#'
#' @return
#' The pedigree in a data frame, reordered and expanded if necessary.
#'
chkPed <- function(pedigree,fgen=list(character(0),0.01),
                          gender=character(0), mv=c("0","*"," "))
{
  is.missing <- function(pcol,mv) {
    isna <- is.na(pcol) | is.element(as.character(pcol),mv) | trimws(as.character(pcol)) == ""
    return(isna)
  }
  if(any(dup <- duplicated(as.character(pedigree[,1])))) {
    stop(cat("Duplicated individuals","\n",as.character(pedigree[,1])[dup],"\n"))
  }
  which <- seq(1,nrow(pedigree))[as.character(pedigree[,1])==as.character(pedigree[,2]) |
                                 as.character(pedigree[,1])==as.character(pedigree[,3])]
  if(length(which <- which[!is.na(which)])) {
    cat(paste(which,pedigree[,1][which]),sep="\n")
    stop("Individuals appear as their own parent")
  }

  fmode <- FALSE
  col4 <- -1
  col4Name <- NULL
  col4Type <- character(0)
  fg <- as.double(fgen[[2]])

  if(length(fgen[[1]]) > 0) {
    if(length(col4 <- pedigree[,fgen[[1]]]) == 0)
      stop("Argument 'fgen' specifies a non-existent dataframe column.")
    else {
      fmode <- TRUE
      col4Name <- fgen[[1]]
      col4Type <- "fgen"
      w <- is.na(pedigree[,col4Name])
      if(sum(as.numeric(w)) > 0) {
        if(sum(as.numeric(!(is.missing(pedigree[w,2],mv) |
                            is.missing(pedigree[w,3],mv)))) > 0)
          stop("fgen is 'NA' for non-base individuals")
      }
    }
  }
  if(length(gender) > 0) {
    if(fmode) stop("Cannot specify both 'fgen' and 'gender'")
    xlink <- TRUE
    if(length(pedigree[,gender]) == 0)
      stop("Argument 'gender' specifies non-existent dataframe column.")
    else if(!is.factor(pedigree[,gender]))
      pedigree[,gender] <- factor(pedigree[,gender])
    sx <- levels(pedigree[,gender])
    if(length(sx) != 2)
      stop("'gender' must only have two levels.")
    col4 <- as.numeric(pedigree[,gender])
    col4Name <- gender
    col4Type <- "gender"
  }

  lped <- nrow(pedigree)

  ## Get levels ignoring missing value character(s)
  charPed <- c(as.character(pedigree[,1]),
               as.character(pedigree[,2]),
               as.character(pedigree[,3]))
  lvls <- unique(charPed)
  lvls <- lvls[!is.missing(lvls,mv)]
  charPed <- NULL

  nan <- length(lvls)
  ## convert to integer
  memumdad <- names(pedigree)[1:3]
  pedigree <- matrix(c(match(pedigree[,1],lvls,nomatch=0),
                       match(pedigree[,2],lvls,nomatch=0),
                       match(pedigree[,3],lvls,nomatch=0)),nrow=lped,byrow=FALSE)
  xtras <- numeric(0)
  if(lped < nan) {
    xmum <- match(pedigree[,2],pedigree[,1])
    xmum <- unique(pedigree[is.na(xmum),2])
    xmum <- xmum[!is.na(xmum) & xmum > 0]
    xdad <- match(pedigree[,3],pedigree[,1])
    xdad <- unique(pedigree[is.na(xdad),3])
    xdad <- xdad[!is.na(xdad) & xdad > 0]
    xtras <- unique(c(xmum,xdad))
    nxtra <- length(xtras)
    ## check
    if(nxtra != nan-lped)
      stop("programming error in chkPed")
    xtra <- matrix(c(xtras,rep(0,2*nxtra)),nrow=nxtra,ncol=3,byrow=FALSE)
    pedigree <- rbind(xtra,pedigree)
    if(fmode) col4 <- c(rep(fg,(nan-lped)),col4)
  }
  ## No need for insertions (now, lped==nan) but "sortPed" puts founders before offspring
  ## stop on error
  params <- list(levels=lvls,fg=fg,col4=col4)
  out <- .Call("sortped", params, pedigree, PACKAGE="asreml")
  pedigree <- matrix(out[[1]], ncol=3, byrow=FALSE)
  col4 <- out[[2]]
  which <- pedigree > 0
  pedigree[which] <- lvls[pedigree[which]]
  pedigree <- data.frame(pedigree, stringsAsFactors=FALSE)
  names(pedigree) <- memumdad

  if(length(col4Name)) {
    pedigree[[col4Name]] <- col4
    if(fmode) {
      pedigree[is.na(pedigree[,4]),4] <- fg
      x <- pedigree[,4]>1 & (as.character(pedigree[,2]) == "0" | as.character(pedigree[,3]) == "0")
      if(length(x)) pedigree[x,4] <- 1.0 - 0.5^pedigree[x,4]
    }
  }

  attr(pedigree,"rowNames") <- pedigree[,1]
  if(length(col4Type))
    attr(pedigree,"col4Type") <- col4Type
  if(length(xtras)) attr(pedigree,"Insertions") <- lvls[xtras]
  return(pedigree)
}
#' Calculate an inverse relationship matrix.
#'
#' Generates an inverse relationship matrix in sparse triplet form
#' from a pedigree data frame.
#'
#' Uses the method of \cite{Meuwissen and Luo, 1992} to compute the inverse
#' relationship matrix directly from the pedigree.
#'
#' @param pedigree
#'
#' A data frame where the first three columns correspond to the
#' identifiers for the individual, male parent and female parent,
#' respectively. The row giving the pedigree of an individual must
#' appear before any row where that individual appears as a
#' parent. Founders use 0 (zero) or NA in the parental columns.
#'
#' @param fgen
#'
#' An optional list of length 2 where \code{fgen[[1]]} is a character
#' string naming the column in \code{pedigree} that contains the level
#' of selfing or the level of inbreeding of an individual. In
#' \code{pedigree[,fgen[[1]]]}, 0 indicates a simple cross, 1
#' indicates selfed once, 2 indicates selfed twice, etc. A value
#' between 0 and 1 for a base individual is taken as its inbreeding
#' value. If the pedigree has implicit individuals (they appear as
#' parents but not as individuals), they will be assumed base
#' non-inbred individuals unless their inbreeding level is set with
#' \code{fgen[[2]]}, where \code{0 < fgen[[2]] < 1} is the inbreeding
#' level of such individuals.
#'
#' @param gender
#'
#' An optional character string naming the column of \code{pedigree}
#' that codes for the gender of an individual. \code{pedigree[,
#' gender]} is coerced to a factor and must only have two (arbitrary)
#' levels, the first of which is taken to mean "male". An inverse
#' relationship matrix is formed for the X chromosome as described by
#' \cite{Fernando and Grossman, 1990} for species where the male is XY
#' and the female is XX.
#'
#' @param groups
#'
#' An integer scalar (\emph{g}) indicating genetic groups in the
#' pedigree. The first \emph{g} lines of the pedigree identify the
#' genetic groups (with zero in both the male and female parent
#' columns). All other rows must specify one of the genetic groups as
#' the male or female parent if the actual parent is unknown. The
#' default is \eqn{g=0}.
#'
#' @param groupOffset
#'
#' A numeric scalar \emph{e > 0} added to the diagonal elements of
#' \eqn{A^{-1}} pertaining to \code{groups}, shrinking the group
#' effects by \eqn{e}. When a constant is added, no adjustment of the
#' degrees of freedom is made for genetic groups.  Set to -1 to add no
#' offset but to suppress insertion of constraints where empty groups
#' appear; the empty groups are then not counted in the degress of
#' freedom adjustment. The default is \eqn{e=0}.
#'
#' @param selfing
#'
#' A numeric scalar (\emph{s}) allowing for partial selfing when the
#' third field of \code{pedigree} is unknown. It indicates that
#' progeny from a cross where the male parent is unknown is assumed to
#' be from selfing with probability \emph{s} and from outcrossing with
#' probability \emph{(1-s)}. This is appropriate in some forestry tree
#' breeding studies where seed collected from a tree may have been
#' pollinated by the mother tree or pollinated by some other tree
#' (\cite{Dutkowski and Gilmour, 2001}). Do not use the \code{selfing}
#' argument in conjunction with \code{inBreed} or \code{mgs}.
#'
#' @param inBreed
#'
#' A numeric scalar (default \code{NA}) giving the inbreeding
#' coefficient for \emph{base} individuals. This argument generates
#' the numerator relationship matrix for inbred lines. Each cross is
#' assumed to be selfed several times to stabilize as an inbred line
#' as is usual for cereal crops, for example, before being evaluated
#' or crossed with another line.  Since inbreeding is usually
#' associated with strong selection, it is not obvious that a pedigree
#' assumption of covariance of 0.5 between parent and offspring
#' actually holds. The \code{inBreed} argument cannot be used in
#' conjunction with \code{selfing} or \code{mgs}.
#'
#' @param mgs
#'
#' If \code{TRUE} (default \code{FALSE}), the third identity in the
#' pedigree is the male parent of the female parent (maternal
#' grand-sire) rather than the female parent.
#'
#' @param mv
#'
#' A character vector of missing value indicators; elements of
#' \code{pedigree} that exactly match any of the members of \code{mv}
#' are treated as missing.
#'
#' @param psort
#'
#' If \code{TRUE} (default \code{FALSE}), the pedigree data frame is
#' returned in founder order after any insertions and permutations.
#'
#' @return
#'
#' A three-column matrix with class \code{ginv} holding the lower
#' triangle of the inverse relationship matrix in sparse form. The
#' first 2 columns are the \emph{row} and \emph{column} indices,
#' respectively, and the third column holds the inverse matrix element
#' itself. Sort order is columns within rows, that is, the lower
#' triangle row-wise. This matrix has attributes:
#'
#' \describe{
#'
#' \item{\code{rowNames}}{A character vector of identifiers for the
#' rows of the matrix.}
#'
#' \item{\code{inbreeding}}{A numeric vector containing the
#' inbreeding coefficient for each individual, calculated as
#' \code{diag(A-I)}.}
#'
#' \item{\code{geneticGroups}}{A numeric vector of length 2 containing
#' the \code{groups} and \code{groupOffset} arguments.}
#'
#' \item{\code{logdet}}{The log determinant.}
#'
#' }
#'
#' @examples
#'
#' \dontrun{
#'
#' # Simple pedigree
#'
#' ped <- data.frame(me = c(1,2,3,4,5,6,7,8,9,10),
#'                   dad = c(0,0,0,1,1,2,4,5,7,9),
#'                   mum = c(0,0,0,1,1,2,6,6,8,9))
#' p.ai <- ainverse(ped)
#'
#' # Known filial generation
#'
#' pdfg <- data.frame(me = c(1,2,3,4,5,6,7),
#'                    dad = c(0,0,1,1,1,1,1),
#'                    mum = c(0,0,0,2,2,2,2),
#'                    fgen = c(NA,0.8,0.0,2.0,0.0,2.0,3.0))
#' pdfg.ai <- ainverse(pdfg,fgen=list('fgen',0.4))
#' pdfg.mat <- sp2mat(pdfg.ai)
#' zapsmall(solve(pdfg.mat))
#' zapsmall(cbind(pdfg.a$inbreeding,diag(pdfg.mat)))
#' }
#'
#' @references
#' % bibentry: Dutkowski:2001
#' % bibentry: Fernando:1990
#' % bibentry: Meuwissen:1992
#'
ainverse <- function(pedigree,fgen=list(character(0),0.01),
                 gender=character(0), groups=0, groupOffset=0.0,
                 selfing=NA, inBreed=NA, mgs=FALSE,
                 mv=c("NA","0","*"), psort=FALSE)
{
  ## Apparently pedigree being a data.table or a tibble breaks this function
  pedigree <- as.data.frame(pedigree, stringsAsFactors=FALSE)
  method <- 0 ## meurwissen
  newped <- chkPed(pedigree, fgen, gender, mv)
  if(psort)
    return(newped)
  ##
  nan <- nrow(newped)
    if((!is.na(selfing)) & (!is.na(inBreed)))
    stop("Cannot specify both partial selfing and inbreeding coefficient\n")
  if(is.na(selfing))
    selfing <- 0.0
  ibl <- 1
  if(is.na(inBreed)) {
    inBreed <- 0.0
    ibl <- 0
  }

  fgsx <- rep(0.0,nan)
  fmode <- FALSE
  xlink <- FALSE
  if(ncol(newped) == 4) {
    fgsx <- newped[,4]
    if(attr(newped, "col4Type") == "fgen")
      fmode <- TRUE
    else if(attr(newped, "col4Type") == "gender")
      xlink <- TRUE
  }

  ## Convert to pmat for g5vaig
  lvls <- attr(newped,"rowNames")
  idx <- vector(mode="numeric",length=nan)
  pmat <- matrix(0,nrow=nan,ncol=2)
  vped <- matrix(match(c(newped[,1],newped[,2],newped[,3]),lvls,nomatch=0),
                 ncol=3,byrow=FALSE)

  rowNo <- rep(-1,nan)
  rowNo[vped[,1]] <- seq(1,nan)
  ## Can't happen??
  if(any(rowNo == -1))
    stop("Internal error: pedigree mismatch")
  for(col in 1:2) {
    which <- (vped[,col+1] > 0)
    pmat[which,col] <- rowNo[vped[which,col+1]]
  }
  idx[rowNo] <- seq(1,nan)
  pmat <- t(pmat)

  if(mgs)
    mgs <- 1
  else
    mgs <- 0
  debug <- 0

  params <- list(fmode=as.numeric(fmode), xlink=as.numeric(xlink), fgsx=fgsx,
                 pmat=pmat, nan=nan, groups=groups, inBreed=inBreed, groupOffset=groupOffset,
                 method=method, selfing=selfing, ibl=ibl, mgs=mgs, debug=debug)
  ginv <- .Call("ainverse", params, PACKAGE="asreml")

  dimnames(ginv)[[2]] <- c("Row","Column","Ainverse")
  inbreeding <- attr(ginv,"inbreeding")
  names(inbreeding) <- lvls
  attr(ginv,"inbreeding") <- inbreeding
  attr(ginv,"rowNames") <- lvls
  attr(ginv,"geneticGroups") <- c(groups, groupOffset)
  class(ginv) <- c(class(ginv),"ginv")

  return(ginv)
}

#' Convert sparse matrix.
#'
#' Convert a sparse matrix in three column coordinate form to a dense
#' matrix.
#'
#' If the sparse matrix inherits class \code{ginv}, the returned matrix
#' preserves the \eqn{A^{-1}} attributes.
#'
#' @param x
#'
#' A three column matrix containing the row and column indices and the
#' matrix element, respectively.
#'
sp2mat <- function(x)
{
  ## sparse form is 3 col matrix or dataframe
  ## row,col,value

  nrow <- max(x[,1])
  y <- rep(0,nrow * nrow)
  y[(x[,2]-1)*nrow+x[,1]] <- x[,3]
  y[(x[,1]-1)*nrow+x[,2]] <- x[,3]
  A <- matrix(y, nrow=nrow, ncol=nrow, byrow=FALSE)

  if(inherits(x, "ginv")) {
    dimnames(A) <- list(attr(x, "rowNames"), attr(x, "rowNames"))
    class(A) <- c(class(A), "ginv")
    attr(A,"INVERSE") <- TRUE
    for(i in c("inbreeding","logdet","geneticGroups"))
      attr(A,i) <- attr(x,i)
  }
  else {
    att <- c("rowNames", "INVERSE")
    w <- which(is.element(att, names(attributes(x))))
    if(length(w) > 0) {
      for(i in w) {
        if(i == 1)
          dimnames(A) <- list(attr(x, "rowNames"), attr(x, "rowNames"))
        else
          attr(A, att[i]) <- attr(x, att[i])
      }
    }
  }
  return(A)
}
#' Convert sparse matrix.
#'
#' Convert a sparse matrix in three column coordinate form to a
#' \code{Matrix} object.
#'
#' If the sparse matrix inherits class \code{ginv}, the returned object
#' preserves the \eqn{A^{-1}} attributes.
#'
#' @param x
#'
#' A three column matrix containing the row and column indices and the
#' matrix element, respectively, of the sparse matrix.
#'
#' @param dense
#'
#' If \code{TRUE} (the default is \code{FALSE}), the result is stored
#' as a dense symmetric \code{dspMatrix} object, otherwise a sparse
#' symmetric matrix.
#'
#' @param triplet
#'
#' If \code{TRUE} (the default is \code{FALSE}), the result is a
#' \code{CsparseMatrix}, otherwise a \code{TsparseMatrix} (triplet
#' form).
#'
sp2Matrix <- function(x, dense=FALSE, triplet = FALSE)
{
  ## if triplet store as "dgTMatrix"
  ## Assumes symmetry
  A <- sparseMatrix(x[,1], x[,2], x=x[,3], giveCsparse=!triplet, symmetric=TRUE)
  if(dense)
    A <- as(A, "dspMatrix")

  if(inherits(x, "ginv")) {
    dimnames(A) <- list(attr(x,"rowNames"), attr(x, "rowNames"))
    attr(A,"INVERSE") <- TRUE
    for(i in c("inbreeding","logdet","geneticGroups"))
      attr(A,i) <- attr(x,i)
  }
  else {
    att <- c("rowNames", "INVERSE")
    w <- which(is.element(att, names(attributes(x))))
    if(length(w) > 0) {
      for(i in w) {
        if(i == 1)
          dimnames(A) <- list(attr(x, "rowNames"), attr(x, "rowNames"))
        else
          attr(A, att[i]) <- attr(x, att[i])
      }
    }
  }
  return(A)
}
#' Specify constraints among variance parameters.
#'
#' Construct a constraints matrix that specifies linear constraints
#' among variance parameters.
#'
#' Variance parameter constraints are specified through a design
#' matrix \eqn{M} from a simple linear model. Let \eqn{\kappa} be the
#' \eqn{r}-vector of original variance parameters (for either the
#' sigma or gamma parameterisation) from which we wish to specify
#' linear relationships of the form \eqn{\kappa = M \kappa_n}, where
#' \eqn{\kappa_n} is the \eqn{c}-vector of parameters in the new
#' set. In the simple case where the \eqn{r} parameters are
#' constrained to be equal, \eqn{c = 1}, the \eqn{r} original
#' parameters are all equal to the one new parameter and \eqn{M} will
#' contain a column of ones.
#'
#' The matrix \eqn{M} is given as the value to the \code{vcm}
#' argument of \code{asreml}. \eqn{M} must have a \code{dimnames}
#' attribute with the names of \eqn{\kappa}{K} as its row names.
#'
#' A data frame containing a factor, \code{Vparameter}, whose levels
#' are the \eqn{r} names of the variance parameters is returned by
#' \code{asreml} when \code{start.values=TRUE}. The matrix \eqn{M} is
#' obtained from a call to \code{model.matrix} using \code{form} and
#' additional factors derived from or interacting with
#' \code{Vparameter}.
#'
#' @param form
#'
#' A model formula including at least one factor with up to
#' \eqn{n_c} levels, where \eqn{n_c} is the number of variance
#' parameters to be considered in the constrained set.
#'
#' @param data
#'
#' A data frame with a factor \code{Vparameter}, whose levels are taken
#' from the full set of variance parameters, in which to resolve the
#' names in \code{form}.
#'
#' @param drop.unused.levels
#'
#' If \code{TRUE} (the default), unused levels in factors are removed.
#'
#' @param intercept
#'
#' if \code{FALSE} (the default), the intercept is not included in the
#' call to \code{model.matrix} when forming the constraints matrix.
#'
#' @param na.action
#'
#' The default, \code{na.fail}, is to terminate abnormally if missing
#' values are present.
#'
#' @return
#'
#' A \eqn{r \times c} matrix \eqn{M} specifying the variance parameter
#' constraints where \eqn{c} is the length of the reduced vector of
#' variance parameters. In a simple case with \eqn{r} parameters and
#' the \eqn{r-1} and \eqn{r} parameters are constrained to be equal,
#' then \eqn{c = r-1} and the \eqn{j^{th}} \eqn{(1, = j < c)} column
#' of \eqn{M} has 1 in the \eqn{j^{th}} row and zero elsewhere; the
#' \eqn{c^{th}} column has 1 in the \eqn{c = (r-1)} and r rows and
#' zero elsewhere.
#'
#' @examples
#'
#' # Suppose there are 4 variance parameters: g1, g2, g3, and g4,
#' # and we wish to constrain 2 & 3 to be equal
#'
#' # generate gg as though from asreml(..., start.values=TRUE)
#'
#' gg <- data.frame(Vparameter = c('g1','g2','g3','g4'),
#'                         fac = factor(c(1,2,2,3)))
#' M <- vcm.lm(~fac, data=gg)
#' # M
#' #    fac1 fac2 fac3
#' # g1    1    0    0
#' # g2    0    1    0
#' # g3    0    1    0
#' # g4    0    0    1
#'

vcm.lm <- function(form, data,
                           drop.unused.levels=TRUE, intercept=FALSE,
                           na.action=na.fail)
{
  ## set up constraints matrix for variance components
  ## using a linear model and model.matrix

  call <- match.call()

  if(is.null(call$form)) {
    M <- matrix(0)
    dimnames(M) <- list('old','new') # just to pass initial check
    return(M)
  }
  if(is.null(call$data))
    stop("\nmissing data frame argument.")
  gg <- NULL
  if(!is.null(data$Vparameter))
    gg <- as.character(data$Vparameter)
  if(!is.null(data$Component))
    gg <- as.character(data$Component)
  if(is.null(gg))
    stop("'data' must be a data frame with a component named 'Vparameter' or 'Component'\n")
  if(!inherits(form, "formula"))
    stop("\nArgument must be a formula")

  tt <- Terms(form)

  if(attr(tt,"intercept") == 1 && !intercept)
    form <- update.formula(form, ~.-1)

  Mf <- model.frame.default(form,
                            data=data,
                            drop.unused.levels=drop.unused.levels,
                            na.action=na.action)

  M <- model.matrix(form,data=Mf)
  dimnames(M) <- list(gg, dimnames(M)[[2]])
  return(M)
}
family.apply <- function(family, y, fun) {
  ## must have for bivariate glm
  ## apply a different function to elements of y for each family
  ## used in fitted() and resid()
  family.matrix <- function(family, x) {
    ## make x a matrix with column nos in row 1 (workaround in apply)
    matrix(c(seq(1,length(family)), x), ncol=length(family), byrow=TRUE)
  }
  as.vector(t(apply(family.matrix(family, y), 2, function(x,f){f[[ x[1] ]](x[2:length(x)])},
                    lapply(family,function(z)z[[fun]]))))
}
#' Extract fitted values.
#'
#' Extracts fitted values from an \code{asreml} object.
#'
#' @param object
#'
#' An \code{asreml} object.
#'
#' @param type
#'
#' if \code{"link"}, the linear fit on the link scale, otherwise, if
#' \code{"response"}, the fitted values obtained by transforming the
#' linear predictors by the inverse link function.
#'
#' @param value
#' 
#' if \code{type ="response"} and \code{object} is a multinomial threshold model, then
#' \code{value="cell"} returns cell probabilities, else if \code{value="cumulative"}
#' then cumulative probabilities are returned.
#' 
#' @param \dots Additional arguments.
#'
#' @return
#'
#' A numeric vector of fitted values.
#'
#' @examples
#'
#' \dontrun{
#' data(oats)
#' oats.asr <- asreml(yield ~ Variety*Nitrogen, random = ~ Blocks/Wplots, data=oats)
#' fitted(oats.asr)
#' }
#'
#' @export
#'
fitted.asreml <- function(object, type = c("response", "link" ), value = c("cell", "cumulative"), ...)
{
  ## family is a list
  family <- getFamily(object$call$family)

  type <- match.arg(type)
  value <- match.arg(value)

  switch(type,
         link = object$linear.predictors,
         response = {
                      fv <- family.apply(family, object$linear.predictors, "inverse")
                      if(unlist(lapply(attr(object$mf,"family"), function(x)x$id))[1] == 9 && value == "cell") {
                        fv <- matrix(fv, nrow=attr(object$mf, "traits")$thrlevels)
                        fv[2:nrow(fv),] <- diff(fv)
                        fv <- as.vector(fv)
                      }
                      fv
                    }
         )
}
#' Extract model coefficients
#'
#' Extract model coefficients from an \code{asreml} object.
#'
#' @param object
#'
#' An \code{asreml} object.
#'
#' @param list
#'
#' If \code{TRUE}, the coefficients are returned in a named list of
#' length the number of terms in the model; default \code{FALSE}.
#'
#' @param pattern
#'
#' A term in the model as a one sided formula. A regular
#' expression is constructed from \code{pattern} to extract a subset of
#' coefficients.
#'
#' @param \dots Additional arguments.
#'
#' @return
#'
#' If neither \code{pattern} nor \code{list} is set, then a list of
#' length 3 with the following components:
#'
#' \describe{
#'
#' \item{fixed}{solutions to the mixed model equations for the fixed
#' (dense) terms.}
#'
#' \item{random}{E-BLUPs for the effects in the random model.}
#'
#' \item{sparse}{solutions to the mixed model equations for the fixed
#' sparse-stored terms.}
#' }
#' where each component is a matrix with a \code{dimnames} attribute.
#'
#' If \code{list=TRUE}, a list object where each component is a single
#' column matrix corresponding to a term in the model; othwerwise a
#' single column matrix of effects as specified by \code{pattern}.
#'
#' @examples
#'
#' \dontrun{
#' data(oats)
#' oats.asr <- asreml(yield ~ Variety*Nitrogen, random = ~ Blocks/Wplots, data=oats)
#' coef(oats.asr)
#' coef(oats.asr, list=TRUE)
#' coef(oats.asr, pattern = ~Blocks:Wplots)
#' }
#'
#' @aliases coef
#'
coef.asreml <- function(object, list=FALSE, pattern=~NULL, ...)
{
  ## coef method for objects inheriting from the asreml class
  ## if pattern specified then just those coefficients are returned
  ##    irrespective of fixed, random or sparse.

  if(list) {
    x <- do.call("rbind", object$coefficients)
    a <- do.call("rbind", lapply(object$coefficients[c('fixed','random','sparse')],
                                 function(x){attr(x,"terms")}))
    a$start <- c(0, cumsum(a$n[seq(1, nrow(a)-1)])) + 1
    row.names(a) <- a$tname

    effects <- vector(mode="list",length=length(a$tname))
    names(effects) <- a$tname
    for(la in a$tname) {
      effects[[la]] <- x[seq(a[la,'start'], length.out=a[la, 'n']),,drop=FALSE]
      dimnames(effects[[la]])[[2]] <- "effect"
    }
  }
  else if(inherits(pattern, "formula") && length(attr(terms(pattern), "factors"))==0) {
    return(lapply(object$coefficients, function(x){
                    if(!is.null(x)) {
                      attr(x, "terms") <- NULL
                      dimnames(x)[[2]] <- "effect"
                      x
                    }
                    else
                      NULL}))
  }
  else {
    trms <- dimnames(attr(terms(pattern), "factors"))[[1]]
    ## make a pattern & get coefficients
    if(length(trms) == 1)
      pattern <- paste(trms,".*[^:]",sep="")
    else
     pattern <- paste(trms, collapse=".*:")
    if(length(trms) > 1) {
      pattern <- paste0(pattern, ".*")
    }
    effects <- lapply(object$coefficients, function(x,pattern)
                      {
                        nn <- dimnames(x)[[1]]
                        which <- grep(pattern, nn)
                        nn <- nn[which]
                        x <- x[which]
                        names(x) <- nn
                        x
                      },pattern)
    ## unlist adds "random." etc to names
    effects <- c(effects$fixed, effects$random, effects$sparse)
    nn <- names(effects)
    effects <- matrix(effects,ncol=1)
    dimnames(effects) <- list(nn,"effect")
  }
  effects
}
#' Extract model residuals.
#'
#' Extracts residuals from \code{asreml} objects.
#'
#' For multinomial threshold models with \emph{t} thresholds, cell residuals are
#' returned in a vector ordered as \emph{t} thresholds within units.
#' 
#' @param object
#'
#' An \code{asreml} object.
#'
#' @param type
#'
#' Type of residuals: \code{"working"}, \code{"deviance"}, \code{stdDeviance}, 
#' \code{"pearson"},
#' \code{"response"}, or \code{"stdCond"}. Default is \code{"working"}.
#'
#' @param spatial
#'
#' If a second independent error term has been fitted by including
#' \code{units} in the random formula, the residuals will have the
#' \code{units} E-BLUPs added if \code{spatial = "plot"}; the default
#' is \code{spatial = "trend"}.
#'
#' @param \dots Additional arguments.
#'
#' @return
#'
#' A numeric vector containing the model residuals.
#'
#' @aliases resid
#'
residuals.asreml <- function(object,
                             type = c("working", "deviance", "stdDeviance", "pearson", "response", "stdCond"),
                             spatial = c("trend", "plot"), ...)
{
  ## resid() method for asreml objects
  family.deviance <- function(family, mu, y, w) { # residuals = TRUE, phi = family$phi)
    mm <- function(x) { matrix(x, ncol=length(family), byrow=TRUE) }
    rr <- matrix(nrow=length(y)/length(family), ncol=length(family))
    for(i in 1:length(family)) {
      rr[,i] <- family[[i]]$deviance(mm(mu)[,i], mm(y)[,i], mm(w)[,i],
                                     residuals = TRUE, family[[i]]$phi)
    }
    as.vector(t(rr))
  }
  family.stdDeviance <- function(family, mu, y, w, h) { # residuals = TRUE, phi = family$phi)
    mm <- function(x) { matrix(x, ncol=length(family), byrow=TRUE) }
    sdr <- matrix(nrow=length(y)/length(family), ncol=length(family))
    for(i in 1:length(family)) {
      rr <- family[[i]]$deviance(mm(mu)[,i], mm(y)[,i], mm(w)[,i],
                                     residuals = TRUE, family[[i]]$phi)
      dv <- family[[i]]$deriv(mm(mu)[,i])
      vv <- family[[i]]$variance(mm(mu)[,i])
      q <- mm(h)[,i] / (vv * dv * dv)
      if(is.null(family[[i]]$phi)) {
        phi <- 1
      } else {
        phi <- family[[i]]$phi
      }
      sdr[,i] = rr / sqrt(phi * (1-q))
    }
    as.vector(t(sdr))
  }
  
  ## need the response from 'data'
  if(is.null(mf <- object$mf)) {
    if(is.null(object$RDS)) {
      stop(object, "is missing model frame and has no RDS component.")
    }
    else
      mf <- readRDS(object$RDS)
  }
  ## code around missing values in covariates; mf not expanded
  rcol <- attr(mf, "Response.col")
  if(length(rcol) > 1 && attr(mf,"traits")$family == "multinomial") { # tabular multinomial
    rcol <- rcol[-length(rcol)]
    traits <- attr(mf,"traits")$lhs[1:attr(mf,"traits")$thrlevels]
  }
  if(length(rcol) == 1) {
    yy <- mf[[rcol]]
    if(!is.factor(yy)) {
      yy <- matrix(yy, ncol=1) # not multinomial
    } 
  } else {
    yy <- as.matrix(mf[, rcol, with=FALSE])
  }
  plr <- FALSE
  if(length(rcol) == 1 && is.factor(yy)) {
    # multinomial with factor response
    # make a matrix of observed probabilities
    foo <- function(x,cat) {
        do.call("[", c(list(tb), as.list(c(cat,x)))) / do.call("[", c(list(tbs), as.list(x)))
    }
    bar <- function(x,cat) {
        do.call("[", c(list(tbs), as.list(x)))
    }
    plr <- TRUE
    mvars <- unique(c(all.vars(attr(object$formulae$fixed, "variables")),
              all.vars(attr(object$formulae$random, "variables")),
              all.vars(attr(object$formulae$sparse, "variables"))))
    ## get rid of trait
    mvars <- mvars[-match("trait", mvars)]
    ## only factors for tabulation
    mvars <- mvars[which(sapply(mvars, function(x)is.factor(mf[[x]])))]
    resp <- names(mf)[rcol]
    xs <- mvars[-match(resp, mvars)]
    tb <- table(mf[, mvars, with=FALSE])
    tbs <- apply(tb, match(xs,mvars), sum)
    prob <- as.data.frame(mf[, xs, with=FALSE], stringsAsFactors=TRUE)
    traits <- levels(mf[[rcol]])[-length(levels(mf[[rcol]]))]
    for(i in 1:length(traits)) {
        prob[[ traits[i] ]] <- apply(prob[,xs,drop=FALSE],1,foo,traits[i])
        prob[[ paste0("W",i) ]] <- apply(prob[,xs,drop=FALSE],1,bar,traits[i])
    }
    yy <- as.matrix(prob[,traits])
  }
  type <- match.arg(type)
  if(type == "stdCond") {
    if(length(object$aom) > 0 )
      rw <- object$aom$R[,'stdCondRes']
    else {
      rw <- object$residuals
      type <- "deviance"
    }
  }
  else
    rw <- as.vector(object$residuals)

  if(unlist(lapply(attr(mf,"family"), function(x)x$id))[1] == 1) { # gaussian
    spatial <- match.arg(spatial)
    rw <- switch(spatial,
                 trend = rw,
                 plot = {
                   type <- "working"
                   if(length(attr(mf, "model.terms")$random$Vars) == 0)
                     rw
                   else {
                     units <- coef(object)$random
                     i <- grep("^units_.*",dimnames(units)[[1]])
                     if(length(i) > 0) {
                       ncol <- length(rw)/length(i)
                       (rw + rep(units[i,1],each=ncol))
                     }
                     else
                       rw
                   }
                 } )
  }

  y <- matrix(NA, nrow=length(attr(mf, "keep")), ncol=ncol(yy))
  y[attr(mf,"rkeep"), ] = yy

  if(ncol(y) > 1)
    y <- as.vector(t(y))
  else
    y <- as.vector(y)
  N <- length(y)

  family <- getFamily(object$call$family)
  mu <- fitted.asreml(object) # default is response, cell if multinomial
  if(plr) {
    w <- as.vector(t(as.matrix(prob[, paste0("W",1:length(traits))])))
  } else {
    w <- matrix(1.0,nrow=length(y)/length(family),ncol=length(family))
    if(any(!is.na(wt <- attr(mf, "Weights.col"))))
      w[,which(!is.na(wt))] <- as.matrix(mf[, wt[!is.na(wt)], with=FALSE ])
    w <- as.vector(t(w))
  }
  rr <- switch(type,
               stdCond = rw,
               working = rw,
               pearson = sqrt(w)*rw / family.apply(family, mu, "deriv") / sqrt(family.apply(family, mu, "variance")),
               deviance = {
                 where <- is.na(y) | is.na(mu)
                 keep <- which(!where)
                 y <- y[keep]
                 mu <- mu[keep]
                 w <- w[keep]
                 rr1 <- family.deviance(family, mu, y, w)
                 rr <- rep(NA, length(where))
                 rr[keep] <- rr1
                 rr
               },
               stdDeviance = {
                 where <- is.na(y) | is.na(mu)
                 keep <- which(!where)
                 y <- y[keep]
                 mu <- mu[keep]
                 w <- w[keep]
                 h <- object$hat[keep]
                 rr1 <- family.stdDeviance(family, mu, y, w, h)
                 rr <- rep(NA, length(where))
                 rr[keep] <- rr1
                 rr
               },
               response = rw / family.apply(family, mu, "deriv")
               )
  rr
}
## multipage used in 'plot' and 'tr'
multipage <- function(..., plotlist=NULL) {
  plots <- c(list(...), plotlist)
  print(plots[[1]])
  if(length(plots) > 1) {
    for(i in 2:length(plots)) {
      if(!is.null(plots[[i]])) {
        dev.new()
        print(plots[[i]])
      }
    }
  }
}
#' Plot diagnostics for an asreml object.
#'
#' Four plots are generated: a histogram of the residuals, a Normal
#' Q-Q plot, a plot of residuals against fitted values and a plot of
#' residuals against unit number.
#'
#' If the residual structure of the model contains multiple sections,
#' the default plots are conditioned on the factor whose levels define
#' the sections; normal Q-Q plots are only produced if \code{facet=TRUE}. 
#' For multivariate analyses, the plots are conditioned
#' on \code{trait}.
#'
#' @param x
#'
#' An \code{asreml} object.
#'
#' @param
#'
#' res
#'
#' The type of residuals; see \code{\link{residuals.asreml}}.
#'
#' @param spatial
#'
#' If \code{"plot"} and an independent error has been fitted with
#' \code{units} in the random formula, these are added to the
#' residuals, otherwise if \code{"trend"} (the default) then
#' \code{units} are not added even if present in the model.
#'
#' @param facet
#'
#' If \code{TRUE} (the default), multi-panel conditioning plots are produced for
#' models with multi-section residual structures.
#'
#' @param distribution
#'
#' A character string specifing the distribution for q-q plots. Density and quantile functions for 
#' many standard probability
#' distributions are available in the \code{"stats"} package. The distribution name 
#' is automatically prefixed with \code{"d"} and \code{"q"}; the default is
#' \code{"norm"}.
#'
#' @param conf
#' 
#' Confidence interval.
#'
#' @param labels
#'
#' if \code{TRUE} (the default is \code{FALSE}) points are labelled by 
#' unit number.
#'
#' @param \dots 
#' 
#' Additional arguments.
#'
#' @return
#'
#' An invisible list of \code{ggplot2} objects.
#'
#' @aliases plot
#'
#' @export
#'
plot.asreml <- function(x, res="default", spatial="trend", facet=TRUE, 
                        distribution = "norm", conf = 0.95, labels=FALSE, ...)
{

  ## Multiple plot function
  ##
  ## ggplot objects can be passed in ..., or to plotlist (as a list of ggplot objects)
  ## - cols:   Number of columns in layout
  ## - layout: A matrix specifying the layout. If present, 'cols' is ignored.
  ##
  ## If the layout is something like matrix(c(1,2,3,3), nrow=2, byrow=TRUE),
  ## then plot 1 will go in the upper left, 2 will go in the upper right, and
  ## 3 will go all the way across the bottom.
  ##
  multiplot <- function(..., plotlist=NULL, cols=1, layout=NULL) {
    requireNamespace("grid", quietly=FALSE)

    ## Make a list from the ... arguments and plotlist
    plots <- c(list(...), plotlist)

    numPlots = length(plots)

    ## If layout is NULL, then use 'cols' to determine layout
    if (is.null(layout)) {
      ## Make the panel
      ## ncol: Number of columns of plots
      ## nrow: Number of rows needed, calculated from # of cols
      layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                       ncol = cols, nrow = ceiling(numPlots/cols))
    }

    if (numPlots==1) {
      print(plots[[1]])

    } else {
      ## Set up the page
      grid::grid.newpage()
      grid::pushViewport(grid::viewport(layout = grid::grid.layout(nrow(layout), ncol(layout))))

      ## Make each plot, in the correct location
      for (i in 1:numPlots) {
        ## Get the i,j matrix positions of the regions that contain this subplot
        matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE), stringsAsFactors=TRUE)

        print(plots[[i]], vp = grid::viewport(layout.pos.row = matchidx$row,
                            layout.pos.col = matchidx$col))
      }
    }
  } ## end multiplot
  ## service functions for qqplot
  qq_dat <- function (vec, grp, distribution, conf, ...) {
    df <- data.frame(x=rep(0, length(vec)),
                     y=rep(0, length(vec)),
                     a=rep(0, length(vec)),
                     b=rep(0, length(vec)),
                     lower=rep(0, length(vec)),
                     upper=rep(0, length(vec)),
                     stringsAsFactors=TRUE)
    for(i in unique(as.character(grp))) {
      w <- (as.character(grp) == i)
      df[w,] <- qq_asr(vec[w], distribution, conf, ...)
    }
  return(df)
  }

  ## plot method for objects of class asreml

  if(!inherits(x, "asreml"))
    stop("\nObject must be of class asreml\n")

  ## Hack to suppress R check warnings
  Fitted <- Residuals <- Units <- NULL

  ## despite hadley wickham's recommendation, use 'requireNamespace' to avoid
  ##   peppering the code with "ggplot2::" etc for every call
  if(!requireNamespace("ggplot2", quietly=TRUE)) {
    install.packages("ggplot2", repos = "http://cran.r-project.org")
    if(!requireNamespace("ggplot2", quietly = TRUE))
      stop("Failed to install 'ggplot2'; this is a required package for the plot method.")
  }
  args <- list(...)

  if(is.null(mf <- x$mf)) {
    if(is.null(x$RDS)) {
      stop(x, "is missing model frame and has no RDS component.")
    }
    else
      mf <- readRDS(x$RDS)
  }

  U <- attr(mf,"model.terms")$residual$Terms.obj
  V <- attr(mf,"model.terms")$residual$Var

  sect <- attr(U,"specials")$dsum
  if(length(sect) > 0) {
    cf <- attr(V[[1]]$Call,"conditioning.factor")
    nsect <- length(x$R.param)
    ndim <- length(x$R.param[[1]])-1
  }
  else {
    nsect <- 1
    uname <- sections <- paste(unlist(sapply(V,function(a)a$Argv)),collapse=":")
    ndim <- length(dims <- vapply(V[terms.variables(U)],function(a){a$Obj},character(1)))
  }

  ## what sort of residuals?
  aom <- (length(x$aom) > 0)
  fam <- unlist(lapply(attr(mf,"family"), function(a)a$id))

  if(res == "default") {
    if(fam[1] == 1) {
      res <- 'working'
      caption <- captions[res]
    }
    else {
      res <- 'deviance'
      caption <- captions[res]
    }
  }
  else {
    if(!is.element(res, names(captions)))
      stop("Unrecognised residual type.")
    if(!aom && (res == "stdCond"))
      stop("'stdCond' selected but 'aom' not set.")
    caption <- captions[res]
  }

  ## Fitted values as cell or cumulative probabilities for multinomials
  if(!is.null(fv.val <- args$value)) {
    if(!is.element(fv.val, c("cell", "cumulative"))) {
      stop("'value' argument to fitted.asreml must be one of 'cell' or 'cumulative'")
    }
  } else {
    fv.val = "cell"
  }

  ## Residuals and fitted values
  keep <- as.logical(attr(mf,"keep"))
  rr <- resid(x, type=res, spatial=spatial)
  fv <- fitted(x, value = fv.val)
  rl <-  rep(NA,length(keep))
  rl[keep] <- as.numeric(mf$units)

  trellis.obj <- vector(length=4,mode="list")
  names(trellis.obj) <- c('histogram','qq','fitted','rowlabels')

  ## Colour blind friendly palette with black:
  cbfPal <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442",
              "#0072B2", "#D55E00", "#CC79A7")
  ## Axis text font scale factor
  atsf <- asreml.options()$font.scale

  ## Part 1: no sections, not multivariate
  ##         or aom==true or a glm
  ##         and form==null
  ##points(quantile(chi_scores,c(.25,.75)),
  ##       quantile(mah_scores,c(.25,.75)),col="blue",cex=2,bg="blue",pch=21)
  ## 30 bins for histogram
  bs <- diff(range(rr,na.rm=TRUE))/30

  y <- b <- a <- lower <- upper <- NULL # for Rcheck
  if((nsect==1) && !is.multivariate(mf)) {
    df <- data.frame(Residuals=rr, Fitted=fv, Units=rl, stringsAsFactors=TRUE)[!is.na(rr),]
    qq <- qq_asr(df$Residuals, distribution, conf, ...)
    df <- cbind(df, qq)

    gg <- ggplot(df) + theme(axis.title.x = element_text(size=rel(0.66*atsf)),
                             axis.title.y = element_text(size=rel(0.66*atsf)),
                             axis.text.x = element_text(size=rel(0.66*atsf)),
                             axis.text.y = element_text(size=rel(0.66*atsf))) +
      scale_fill_manual(values=cbfPal)+scale_colour_manual(values=cbfPal)

    trellis.obj[['qq']] <- gg + #stat_qq(aes(sample=Residuals),shape=1, size=rel(1)) +
      geom_point(aes(x=x, y=y), shape=1, size=rel(atsf)) +
      geom_abline(aes(slope = b, intercept = a), colour="#0072B2", size=0.5) +
      geom_ribbon(aes(x=x, ymin = lower, ymax = upper), alpha=0.2) +
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      geom_hline(aes(yintercept=0), colour="white") + geom_vline(aes(xintercept=0), colour="white") +
      xlab("Theoretical") + ylab("Sample")
      if(labels) {
        trellis.obj[['qq']] <- trellis.obj[['qq']] + 
        geom_text(aes(x=x, y=y, label = Units), size=rel(2.5*atsf), vjust = 0, nudge_y=0.1)
      }

    trellis.obj[['histogram']] <- gg +
    geom_histogram(aes(x=Residuals), fill="#0072B2",colour="white",binwidth=bs) +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    labs(x=caption, y="Count")
    trellis.obj[['fitted']] <- gg + geom_point(aes(x=Fitted, y=Residuals), shape=1, size=rel(1)) +
    geom_hline(aes(yintercept=0), colour="grey50") +
    labs(x="Fitted", y=caption)
    if(labels) {
      trellis.obj[['fitted']] <- trellis.obj[['fitted']] + 
      geom_text(aes(x=Fitted, y=Residuals, label = Units), size=rel(2.5*atsf), vjust = 0, nudge_y=0.1)
    }

    trellis.obj[['rowlabels']] <- gg + geom_point(aes(x=Units, y=Residuals), shape=1, size=rel(1)) +
      geom_hline(aes(yintercept=0), colour="grey50") +
        labs(x="Units", y=caption)
    ## graph it
    multiplot(plotlist=trellis.obj, cols=2)
  }
  else if(is.multivariate(mf)) {
    ## part 2: multi-variate
    tr <- attr(mf, "traits")
    if(tr$mvar.method == "ASMV")
      df <- data.frame(Residuals=rr, Fitted=fv, Units=rl, Trait=mf[[attr(mf,"Trait.col")]], stringsAsFactors=TRUE)[!is.na(rr),]
    else
      df <- data.frame(Residuals=rr, Fitted=fv, Units=rep(rl, each=length(tr$lhs)),
                       Trait=rep(tr$lhs, length=length(rr)), stringsAsFactors=TRUE)[!is.na(rr),]

    if(nsect == 1) {
      df <- cbind(df, qq_dat(df$Residuals, df$Trait, distribution, conf, ...))
      gg <- ggplot(df) + theme(axis.title.x=element_text(size=rel(0.75*atsf)),
                               axis.title.y=element_text(size=rel(0.75*atsf)),
                               axis.text.x=element_text(size=rel(0.66*atsf)),
                               axis.text.y=element_text(size=rel(0.66*atsf))) +
        scale_fill_manual(values=cbfPal)+scale_colour_manual(values=cbfPal)

       ## Plots
      trellis.obj[['qq']] <- gg + geom_point(aes(x=x, y=y), shape=1, size=rel(atsf)) + 
        geom_abline(aes(slope = b, intercept = a), colour="#0072B2", size=0.5) +
        geom_ribbon(aes(x=x, ymin = lower, ymax = upper), alpha=0.2) +
        xlab("Theoretical") + ylab("Sample") +
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
        geom_hline(aes(yintercept=0), colour="white") + geom_vline(aes(xintercept=0), colour="white") +
        facet_wrap(~Trait)
        if(labels) {
          trellis.obj[['qq']] <- trellis.obj[['qq']] + 
          geom_text(aes(x=x, y=y, label = Units), size=rel(2.5*atsf), vjust = 0, nudge_y=1)
        }

      trellis.obj[['histogram']] <- gg +
        geom_histogram(aes(x=Residuals), fill="#0072B2",colour="white",binwidth=bs) +
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
            facet_wrap(~Trait) + labs(x=caption, y="Count")

      trellis.obj[['fitted']] <- gg + geom_point(aes(x=Fitted, y=Residuals), shape=1, size=rel(1)) +
        geom_hline(aes(yintercept=0), colour="grey50") +
          facet_wrap(~Trait, scales="free") + labs(x="Fitted", y=caption)
        if(labels) {
          trellis.obj[['fitted']] <- trellis.obj[['fitted']] + 
          geom_text(aes(x=Fitted, y=Residuals, label = Units), size=rel(2.5*atsf), vjust = 0, nudge_y=1)
        }

      trellis.obj[['rowlabels']] <- gg + geom_point(aes(x=Units, y=Residuals), shape=1, size=rel(1)) +
        geom_hline(aes(yintercept=0), colour="grey50") +
          facet_wrap(~Trait, scales="free") + labs(x="Units", y=caption)
    }
    else {
      ## multi-variate, multi-section
      df$cf <- rep(mf[[cf]], each=length(tr$lhs))[!is.na(rr),]
      df <- cbind(df, qq_dat(df$Residuals, paste(df$cf,df$Trait), distribution, conf, ...))

      ramp <- colorRampPalette(cbfPal)(length(unique(mf[[cf]]))*length(tr$lhs))
      gg <- ggplot(df) + theme(axis.title.x=element_text(size=rel(0.75*atsf)),
                               axis.title.y=element_text(size=rel(0.75*atsf)),
                               axis.text.x=element_text(size=rel(0.66*atsf)),
                               axis.text.y=element_text(size=rel(0.66*atsf))) +
        scale_fill_manual(values=ramp)+scale_colour_manual(values=ramp)

      trellis.obj[['qq']] <- gg + geom_point(aes(x=x, y=y), shape=1, size=rel(1)) + 
        geom_abline(aes(slope = b, intercept = a), colour="#0072B2", size=0.5) +
        geom_ribbon(aes(x=x, ymin = lower, ymax = upper), alpha=0.2) +
        xlab("Theoretical") + ylab("Sample") +
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
        geom_hline(aes(yintercept=0), colour="white") + geom_vline(aes(xintercept=0), colour="white") +
        facet_grid(cf ~ Trait)
        if(labels) {
          trellis.obj[['qq']] <- trellis.obj[['qq']] + 
          geom_text(aes(x=x, y=y, label = Units), size=rel(2.5*atsf), vjust = 0, nudge_y=1)
        }

      trellis.obj[['histogram']] <- gg +
        geom_histogram(aes(x=Residuals), fill="#0072B2",colour="white",binwidth=bs) +
          theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
            facet_grid(cf ~ Trait) + labs(x=caption, y="Count")

      trellis.obj[['fitted']] <- gg + geom_point(aes(x=Fitted, y=Residuals), shape=1, size=rel(1)) +
        geom_hline(aes(yintercept=0), colour="grey50") +
          facet_grid(cf ~ Trait) + labs(x="Fitted", y=caption)
        if(labels) {
          trellis.obj[['fitted']] <- trellis.obj[['fitted']] + 
          geom_text(aes(x=Fitted, y=Residuals, label = Units), size=rel(2.5*atsf), vjust = 0, nudge_y=1)
        }

      trellis.obj[['rowlabels']] <- gg + geom_point(aes(x=Units, y=Residuals), shape=1, size=rel(1)) +
        geom_hline(aes(yintercept=0), colour="grey50") +
          facet_grid(cf ~ Trait) + labs(x="Units", y=caption)
    }
    multipage(plotlist=trellis.obj)
  }
  else { ## multi section
    df <- data.frame(Residuals=rr, Fitted=fv, Units=rl, cf=mf[[cf]], stringsAsFactors=TRUE)[!is.na(rr),]
    df <- cbind(df, qq_dat(df$Residuals, df$cf, distribution, conf, ...))
    ramp <- colorRampPalette(cbfPal)(length(unique(mf[[cf]])))
    gg <- ggplot(df) + theme(axis.title.x = element_text(size=rel(0.75*atsf)),
                             axis.title.y = element_text(size=rel(0.75*atsf)),
                             axis.text.x = element_text(size=rel(0.66*atsf)),
                             axis.text.y = element_text(size=rel(0.66*atsf)),
                             legend.key.size = grid::unit(0.3,"cm"),
                             legend.text=element_text(size=rel(0.6))) +
    scale_fill_manual(values=ramp)+scale_colour_manual(values=ramp)

    if(facet) {
      nc <- trunc(sqrt(length(unique(df$cf))-1))+1
      trellis.obj[['qq']] <- gg + geom_point(aes(x=x, y=y), shape=1, size=rel(1)) + 
      geom_abline(aes(slope = b, intercept = a), colour="#0072B2", size=0.5) +
      geom_ribbon(aes(x=x, ymin = lower, ymax = upper), alpha=0.2) +
      xlab("Theoretical") + ylab("Sample") +
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      geom_hline(aes(yintercept=0), colour="white") + geom_vline(aes(xintercept=0), colour="white") +
      facet_wrap(~cf, scales = "free", ncol=nc)
      if(labels) {
        trellis.obj[['qq']] <- trellis.obj[['qq']] + 
        geom_text(aes(x=x, y=y, label = Units), size=rel(2.5*atsf), vjust = 0, nudge_y=.1)
      }

      trellis.obj[['histogram']] <- gg + geom_boxplot(aes(x=cf, y=Residuals)) +
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
          labs(x=cf, y=caption)
      trellis.obj[['fitted']] <- gg + geom_point(aes(x=Fitted, y=Residuals),size=1.0) +
        facet_wrap(~cf, scales = "free", ncol=nc) + labs(x="Fitted", y=caption)
      if(labels) {
        trellis.obj[['fitted']] <- trellis.obj[['fitted']] + 
        geom_text(aes(x=Fitted, y=Residuals, label = Units), size=rel(2.5*atsf), vjust = 0, nudge_y=0.1)
      }

      trellis.obj[['rowlabels']] <- gg + geom_point(aes(x=Units, y=Residuals),size=1.0) +
        facet_wrap(~cf, scales = "free", ncol=nc) + labs(x="Units", y=caption)
    }
    else {
      trellis.obj[['qq']] <- gg + #stat_qq(aes(sample=Residuals),shape=1, size=rel(1)) +
      geom_point(aes(x=x, y=y, colour=cf), shape=1, size=rel(atsf)) +
      geom_abline(aes(slope = b, intercept = a, group=cf, colour=cf),  size=0.5) + #colour="#0072B2",
      geom_ribbon(aes(x=x, ymin = lower, ymax = upper, fill=cf), alpha=0.2) +
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
      geom_hline(aes(yintercept=0), colour="white") + geom_vline(aes(xintercept=0), colour="white") +
      xlab("Theoretical") + ylab("Sample")
      if(labels) {
        trellis.obj[['qq']] <- trellis.obj[['qq']] + 
        geom_text(aes(x=x, y=y, label = Units), size=rel(2.5*atsf), vjust = 0, nudge_y=.1)
      }

      trellis.obj[['histogram']] <- gg + geom_boxplot(aes(x=cf, y=Residuals)) +
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
          labs(x=cf, y=caption)
      trellis.obj[['fitted']] <- gg + geom_point(aes(x=Fitted, y=Residuals, colour=cf),size=1.0) +
        guides(colour=guide_legend(title=NULL)) + labs(x="Fitted", y=caption)
      if(labels) {
        trellis.obj[['fitted']] <- trellis.obj[['fitted']] + 
        geom_text(aes(x=Fitted, y=Residuals, label = Units), size=rel(2.5*atsf), vjust = 0, nudge_y=0.1)
      }

      trellis.obj[['rowlabels']] <- gg + geom_point(aes(x=Units, y=Residuals, colour=cf),size=1.0) +
        guides(colour=guide_legend(title=NULL)) + labs(x="Units", y=caption)
    }
    multipage(plotlist=trellis.obj)
  }
  return(invisible(trellis.obj))
}
#' Update an asreml model.
#'
#' Extract and evaluate the \code{call} from the fitted object,
#' replacing any arguments with changed values. In particular,
#' \code{G.param} and \code{R.param} are automatically updated with
#' those stored in the object.
#'
#' In addition to any other changes, \code{update.asreml} replaces the
#' arguments \code{R.param} and \code{G.param} with
#' \code{object\$R.param} and \code{object\$G.param}, respectively,
#' creating a new fitted object when run using the parameter values
#' from a previous model as initial values.
#'
#' @param object
#'
#' A valid \code{asreml} object with a \code{call} component, the
#' expression used to create itself.
#'
#' @param fixed.
#'
#' Changes to the fixed formula. This is a two sided formula where
#' \code{"."} is substituted for existing components in the
#' \code{fixed} component of \code{object$call}.
#'
#' @param random.
#'
#' Changes to the random formula. This is a one sided formula where
#' \code{"."} is substituted for existing components in the right hand
#' side of the \code{random} component of \code{object$call}.
#'
#' @param sparse.
#'
#' Changes to the sparse formula. This is a one sided formula where
#' \code{"."} is substituted for existing components in the right hand
#' side of the \code{sparse} component of \code{object$call}.
#'
#' @param residual.
#'
#' Changes to the residual formula. This is a one sided formula where
#' \code{"."} is substituted for existing components in the right hand
#' side of the \code{residual} component of \code{object$call}.
#'
#' @param keep.order
#'
#' If \code{TRUE} (the default) the ordering of terms is retained in
#' the updated formulae.
#'
#' @param \dots
#'
#' Additional arguments to the call, or arguments with changed values.
#'
#' @param evaluate
#'
#' If \code{TRUE} (the default) the new call is evaluated; otherwise
#' the call is returned as an unevaluated expression.
#'
#' @return
#'
#' Either a new updated \code{asreml} object, else an unevaluated
#' expression for creating such an object.
#'
#' @examples
#'
#' \dontrun{
#' data(oats, package="asreml")
#' oats.asr <- asreml(yield ~ Variety+Nitrogen,
#'                   random = ~ Blocks/Wplots, data=oats)
#' oats2.asr <- update(oats.asr, fixed = . ~ . + Variety:Nitrogen)
#' }
#'
#' @method update asreml
#' @aliases update
#'
update.asreml <- function(object, fixed., random., sparse., residual., keep.order=TRUE,
                          evaluate = TRUE, ...)
{
  my.update.formula <- function(old, new, keep.order=TRUE, ...) {
    env <- environment(as.formula(old))
    ## Package "stats" not "asreml"
    tmp <- .Call(stats:::C_updateform, as.formula(old), as.formula(new))
    out <- formula(terms.formula(tmp, simplify = TRUE, keep.order=keep.order))
    environment(out) <- env
    return(out)
  }
  ## UPDATE.ASREML
  if(is.null(newcall <- object$call) && is.null(newcall <- attr(object,"call")))
    stop("need an object with call component or attribute")

  tempcall <- list(...)

  ## step.size
  if(!is.null(tempcall$step.size)) {
    newcall$step.size <- tempcall$step.size
    tempcall$step.size <- NULL
  }
  else if(asreml.options()$update.step.size != 0.316) {
    newcall$step.size <- asreml.options()$update.step.size
  }
  ## Flag if a change to random or residual
  ## If so then don't pickup R.param or G.param as the constraints may be inappropriate
  RGupdt <- TRUE
  ## formulae may be in variables
  if(length(newcall$fixed)) newcall$fixed <- eval(newcall$fixed, parent.frame())
  if(length(newcall$random)) newcall$random <- eval(newcall$random, parent.frame())
  if(length(newcall$sparse)) newcall$sparse <- eval(newcall$sparse, parent.frame())
  if(length(newcall$residual)) newcall$residual <- eval(newcall$residual, parent.frame())

  if(!missing(fixed.))
    newcall$fixed <- my.update.formula(as.formula(newcall$fixed), fixed., keep.order=keep.order)
  if(!missing(random.)) {
    RGupdt <- FALSE
    newcall$random <- {if(length(newcall$random))
                         my.update.formula(as.formula(newcall$random), random.,
                                           keep.order=keep.order)
                       else
                         random.}
  }
  if(!missing(sparse.))
    newcall$sparse <- {if(length(newcall$sparse))
                         my.update.formula(as.formula(newcall$sparse), sparse.,
                                           keep.order=keep.order)
                       else
                         sparse.}
  if(!missing(residual.)) {
    RGupdt <- FALSE
    newcall$residual <- {if(length(newcall$residual))
                       my.update.formula(as.formula(newcall$residual), residual., keep.order=keep.order)
                     else
                       residual.}
  }

  if(length(tempcall)) {
    what <- !is.na(match(names(tempcall), names(newcall)))
    for (z in names(tempcall)[what]) newcall[[z]] <- tempcall[[z]]
    if (any(!what)) {
      newcall <- c(as.list(newcall), tempcall[!what])
      newcall <- as.call(newcall)
    }
  }

  ## Don't want any of these with an intercept only
  if(length(newcall$random) && length(attr(Terms(as.formula(newcall$random)),"factors"))==0)
    newcall$random <- NULL
  if(length(newcall$sparse) && length(attr(Terms(as.formula(newcall$sparse)),"factors"))==0)
    newcall$sparse <- NULL
  if(length(newcall$residual) && length(attr(Terms(as.formula(newcall$residual)),"factors"))==0)
    newcall$residual <- NULL

  if(RGupdt) {
    newcall$R.param <- call("$",as.name(deparse(substitute(object))),"R.param")
    newcall$G.param <- call("$",as.name(deparse(substitute(object))),"G.param")
  }
  if(evaluate)
    eval(newcall, sys.parent())
  else newcall
}

#' Wald statistics method.
#'
#' Generic function to calculate Wald statistics for a fitted
#' model. The available method is for \code{asreml} class objects.
#'
#' @param object An object of class \code{asreml}.
#'
#' @param \dots Arguments to \code{wald.asreml}
#'
#' @seealso \code{\link{wald.asreml}}
#'
wald <- function(object, ...)
{
  if(!inherits(object,"asreml"))
    stop("object must be of class 'asreml'\n")
  UseMethod("wald")
}
#' Wald test constructor for asreml objects.
#'
#' Pseudo analysis of variance using incremental Wald statistics or
#' conditional F-tests.
#'
#' \code{wald.asreml()} produces two styles of analysis of variance
#' table depending on the settings of \code{denDF} and
#' \code{ssType} on the \code{asreml} function call. 
#' If \code{denDF = "none"} and \code{ssType = "incremental"} 
#' (the defaults), a pseudo analysis of variance table
#' is returned based on incremental sums of squares with rows
#' corresponding to each of the fixed terms in the object, plus an
#' additional row for the residual. The model sum of squares is
#' partitioned into its fixed term components, and the sum of squares
#' for each term listed in the table of Wald statistics is adjusted
#' for the terms listed in the rows above. The denominator degrees of
#' freedom are not computed and consequently Wald tests are provided.
#'
#' If either \code{denDF} or \code{ssType} are not set at their
#' default values, a data frame is returned that will include columns
#' for the approximate denominator degrees of freedom and incremental
#' and conditional F statistics depending on the combination of
#' options chosen. \code{update.asreml} is called to complete the
#' calculations.
#'
#' The principle used in determining the conditional tests is that a
#' term cannot be adjusted for another term which encompasses it
#' explicitly (for example, \bold{A:C} cannot be adjusted for
#' \bold{A:B:C}) or implicitly (for example, \bold{REGION} cannot be
#' adjusted for \bold{LOCATION} when locations are nested in regions
#' although coded independently). See the vignette for further
#' information.
#'
#' The numerator degrees of freedom for each term is determinaed as
#' the number of non-singular equations involved in the term. However,
#' the calculation of the denominator df is in general not trivial and
#' is computationally expensive. Numerical derivatives require an
#' extra evaluation of the mixed model equations for every variance
#' parameter while algebraic derivatives require a large dense matrix,
#' potentially of order the number of equations plus the number of
#' observations. The calculations are supressed by default.
#'
#' @param object An \code{asreml} object.
#' 
#' @param incr
#' 
#' If \code{TRUE} (the default is \code{FALSE}) only incremental
#' Wald tests are returned irrespective of the \code{asreml}
#' argument \code{ssType}.
#' 
#'
#' @return
#'
#' A list with class \code{wald} with the following components:
#' \describe{
#'
#' \item{wald}{An \code{anova} object if \code{denDF="none"} and
#' \code{ssType = "incremental"}, or a data frame otherwise.}
#'
#' \item{stratumVariances}{If \code{denDF} is not \code{"none"}, a
#' matrix of approximate stratum variances, degrees of freedom and
#' component coefficients is returned for simple variance component
#' models.}
#'
#' }
#'
#' @references
#'
#' % bibentry: Kenward:1997
#'
#' @method wald asreml
#'
wald.asreml <- function(object, ..., incr = FALSE)
{

  ## anova() type method for asreml objects
  trim0 <- function(x) {
    kpr <- apply(x,1,function(y){!all(y == 0.0)})
    kpc <- apply(x,2,function(y){!all(y == 0.0)})
    return(x[kpr, kpc, drop=FALSE])
  }
  if(missing(object))
    stop("Missing asreml object\n")
  if(!inherits(object,"asreml"))
    stop("object must be of class 'asreml'\n")

  ## May be an empty table
  if(sum(object$aov[,"id"]) == 0) {
    message("No terms in aov table.")
    return(NULL)
  }
  args <- list(...)
  if(length(args) == 0) {
    wald.arg <- object$call$wald
    if(is.null(wald.arg$Ftest)) {
      Ftest <- formula("~NULL")
    } else {
    Ftest <- wald.arg$Ftest
    }
    denDF <- ifelse(is.null(wald.arg$denDF), "none", wald.arg$denDF)
    ssType <- ifelse(is.null(wald.arg$ssType), "incremental", wald.arg$ssType)
  } else {
    Ftest <- args$Ftest
    if(is.null(Ftest)) {
      Ftest <- formula("~NULL")
    }
    denDF <- ifelse(is.null(args$denDF), "none", args$denDF)
    ssType <- ifelse(is.null(args$ssType), "incremental", args$ssType)
    kenadj = "none"
  }
  ## get the model frame for family id & link
  if(is.null(mf <- object$mf)) {
    if(is.null(object$RDS)) {
      stop(object, "is missing model frame and has no RDS component.")
    }
    else
      mf <- readRDS(object$RDS)
  }
  glm <- any(unlist(lapply(attr(mf,"family"),function(x)x$id)) > 1 |
               unlist(lapply(attr(mf,"family"),function(x)x$link)) > 1)

  ## Old behaviour for seq wald tests

  if((ssType == "incremental" && denDF == "none") || incr) {
    zdf <- attr(object$aov, "zerodf")
    s2 <- object$sigma2
    nsect <- length(object$R.param)
    ## find the possible scale parameter(s)
    xx <- which(object$vparameters.type == 1) # a vector
    ## trt == 1 for multivariate (== !asuv in asreml)
    ntrt <- 1

    if(ntrt+nsect == 2)
      convrt <- sum(object$vparameters[xx] == 1.0 & object$vparameters.con[xx] == 1) == 1
    else
      convrt <- FALSE
    ## Check!
    if(convrt && attr(mf,"scale.fit") == "sigma")
      stop("Internal conflict in wald method.")
    ss <- 1.0
    if(convrt) ss <- s2

    trms <- dimnames(object$aov)[[1]]
    nfact <- length(trms)
    aod <- matrix(nrow=nfact, ncol=4)
    aod[,1] <- object$aov[seq(1,nfact), "df"]
    aod[,2] <- object$yssqu[trms]
    aod[,3] <- aod[,2]/ss
    aod[,4] <- 1-pchisq(aod[,3],aod[,1])
    aod <- rbind(aod,c(NA,object$sigma2,NA,NA))
    heading <- c("Wald tests for fixed effects.",
                 paste("Response:",
                       deparse(object$formulae$fixed[[2]])),
                 "Terms added sequentially; adjusted for those above.")
    if(glm) {
      heading <- c(heading,
                   paste("Note: These Wald statistics are based on the working variable",
                         "and are not equivalent to an Analysis of Deviance.", sep="\n"))
    }
    attr(aod, "heading") <- heading
    dimnames(aod) <- list(c(trms,"residual (MS)"),
                          c("Df","Sum of Sq","Wald statistic","Pr(Chisq)"))
    if(!is.null(zdf)) attr(aod, "zerodf") <- zdf
    oldClass(aod) <- c("wald", class(aod))
    return(aod)
  }
  if(length(args) > 0) {
    newcall <- eval(as.call(c(list(update.asreml, object=substitute(object),
                                   wald=list(denDF=denDF, ssType=ssType, Ftest=Ftest, kenadj=kenadj),
                                   evaluate=FALSE),
                                   list(...))), parent.frame())
    object <- eval(newcall, parent.frame())
  }
  aov <- object$aov
  zdf <- attr(object$aov, "zerodf")

  aov[,3] <- round(aov[,3],1)
  aov[,4] <- signif(aov[,4],4)
  aov[,5] <- signif(aov[,5],4)

  heading <- c("\nWald tests for fixed effects.",
               paste("Response:",
                     my.dparse(object$formulae$fixed[[2]])))

  if(length(Ftest[[2]]) > 0) {
    x <- as.integer(aov[,6])
    x[x==0] <- -32
    cstr <- rawToChar(as.raw(x+64))
    temp <- substring(cstr, 1:nchar(cstr), 1:nchar(cstr))
    which<- seq(1,length(x))[temp == "O"] # uppercase o
    if(length(which) == 0) {
      ## Ftest N/A - df may change - just return full table
      heading <- c(heading,
                   paste("An Ftest test is not calculated if any term in the test model",
                         "(tested or background), would have changed the numerator df.", sep="\n"),
                   paste("The test ", my.dparse(Ftest), " is not performed."),
                   "Consider reordering terms in the model.")

      aod <- data.frame(Df=aov[,2],denDF=aov[,3],Finc=aov[,4],Fcon=aov[,5],
                        Margin=aov[,6],Pr=aov[,7], stringsAsFactors=TRUE)
      aod[,5][aod[,5]==0] <- -32
      cstr <- rawToChar(as.raw(aod[,5]+64))
      aod[,5] <- substring(cstr, 1:nchar(cstr), 1:nchar(cstr))
      attr(aod, "names") <- c("Df","denDF","F.inc","F.con","Margin","Pr")
      attr(aod,"heading") <- heading
      if(!is.null(zdf)) attr(aod, "zerodf") <- zdf
      class(aod) <- c("wald",class(aod))
      return(aod)
    }
    else {
      aod <- matrix(nrow=2,ncol=3)
      aod[,1] <- c(aov[which,2],aov[which,3])
      aod[,2] <- c(aov[which,5],NA)
      aod[,3] <- c(1-pf(aod[1,2],aod[1,1],aod[2,1]),NA)

      heading <- c(heading,paste(as.character(my.dparse(Ftest))))
      if(glm) {
        heading <- c(heading,
                     paste("Note: These Wald F statistics are based on the working variable",
                           "and are not equivalent to an Analysis of Deviance.", sep="\n"))
      }
      attr(aod,"heading") <- heading
      dimnames(aod) <- list(c(dimnames(aov)[[1]][which], "Residual"),
                            c("DF","Conditional F","Pr(F)"))
      if(!is.null(zdf)) attr(aod, "zerodf") <- zdf
      class(aod) <- c("wald",class(aod))
      return(aod)
    }
  }
  if((ssType == "conditional") && (denDF != "none")) {
  #  //           write(7,2178)'NumDF    DenDF_con F_inc    F_con M P_con'
  #  // 2178      format(/' Analysis of Variance',14X,A)
    aod <- data.frame(Df=aov[,2],denDF=aov[,3],Finc=aov[,4],Fcon=aov[,5],
                      Margin=aov[,6],Pr=aov[,7], stringsAsFactors=TRUE)
    aod[,5][aod[,5]==0] <- -32
    cstr <- rawToChar(as.raw(aod[,5]+64))
    aod[,5] <- substring(cstr, 1:nchar(cstr), 1:nchar(cstr))
    attr(aod, "names") <- c("Df","denDF","F.inc","F.con","Margin","Pr")
  }
  else if(ssType == "conditional") {
    # //           write(7,2178)'NumDF              F_inc    F_con'
    aod <- data.frame(Df=aov[,2],
                      Finc=aov[,4] * aov[,2],
                      Pinc=1 - pchisq(aov[,4] * aov[,2], aov[,2]),
                      Fcon=aov[,5] * aov[,2],
                      Pcon=1 - pchisq(aov[,5] * aov[,2], aov[,2]),
                      Margin=aov[,6], stringsAsFactors=TRUE)
    aod$Margin[aod$Margin==0] <- -32
    cstr <- rawToChar(as.raw(aod$Margin+64))
    aod$Margin <- substring(cstr, 1:nchar(cstr), 1:nchar(cstr))
    attr(aod, "names") <- c("Df","Wald(inc)","Pr(chisq)","Wald(con)","Pr(chisq)","Margin")
  }
  else if(denDF != "none") {
   # //           write(7,2178)'NumDF     DenDF    F_inc             Prob'
    aod <- data.frame(Df=aov[,2],denDF=aov[,3],Finc=aov[,4],Pr=aov[,7], stringsAsFactors=TRUE)
    attr(aod, "names") <- c("Df","denDF","F.inc","Pr")
  }
  if(glm) {
    heading <- c(heading,
                 paste("Note: These Wald F statistics are based on the working variable",
                       "and are not equivalent to an Analysis of Deviance.", sep="\n"))
  }
  attr(aod, "heading") <- heading
  if(!is.null(zdf)) attr(aod, "zerodf") <- zdf
  attr(aod, "row.names") <- dimnames(aov)[[1]]
  class(aod) <- c("wald", class(aod))

  list(Wald=aod, stratumVariances = {
         if(is.matrix(object$appstvar))
           trim0(object$appstvar[,2:ncol(object$appstvar)])
         else
           NULL})
}
# #' Wald test constructor for asreml objects.
# #'
# #' Pseudo analysis of variance using incremental Wald statistics or
# #' conditional F-tests.
# #'
# #' \code{wald.asreml()} produces two styles of analysis of variance
# #' table depending on the settings of \code{denDF} and
# #' \code{ssType}. If \code{denDF = "none"} and \code{ssType =
# #' "incremental"} (the defaults), a pseudo analysis of variance table
# #' is returned based on incremental sums of squares with rows
# #' corresponding to each of the fixed terms in the object, plus an
# #' additional row for the residual. The model sum of squares is
# #' partitioned into its fixed term components, and the sum of squares
# #' for each term listed in the table of Wald statistics is adjusted
# #' for the terms listed in the rows above. The denominator degrees of
# #' freedom are not computed and consequently Wald tests are provided.
# #'
# #' If either \code{denDF} or \code{ssType} are not set at their
# #' default values, a data frame is returned that will include columns
# #' for the approximate denominator degrees of freedom and incremental
# #' and conditional F statistics depending on the combination of
# #' options chosen. \code{update.asreml} is called to complete the
# #' calculations.
# #'
# #' The principle used in determining the conditional tests is that a
# #' term cannot be adjusted for another term which encompasses it
# #' explicitly (for example, \bold{A:C} cannot be adjusted for
# #' \bold{A:B:C}) or implicitly (for example, \bold{REGION} cannot be
# #' adjusted for \bold{LOCATION} when locations are nested in regions
# #' although coded independently). See the vignette for further
# #' information.
# #'
# #' The numerator degrees of freedom for each term is determinaed as
# #' the number of non-singular equations involved in the term. However,
# #' the calculation of the denominator df is in general not trivial and
# #' is computationally expensive. Numerical derivatives require an
# #' extra evaluation of the mixed model equations for every variance
# #' parameter while algebraic derivatives require a large dense matrix,
# #' potentially of order the number of equations plus the number of
# #' observations. The calculations are supressed by default.
# #'
# #' @param object An \code{asreml} object.
# #'
# #' @param Ftest
# #'
# #' A one sided formula of the form \code{~ test-term |
# #' background-terms} specifying a conditional Wald test of the
# #' contribution of \code{test-term} conditional on those listed in
# #' \code{background-terms}, and the those in the \code{random} and
# #' \code{sparse} model formulae.
# #'
# #' @param denDF
# #'
# #' Compute approximate denominator degrees of freedom: can be
# #' \code{"none"} (the default) to suppress the computations,
# #' \code{"numeric"} for numerical methods, \code{"algebraic"} for
# #' algebraic methods or \code{"default"} to autommatically choose
# #' numeric or algebraic computations depending on problem size. The
# #' denominator degrees of freedom are calculated according to
# #' \cite{Kenward and Roger (1997)} for fixed terms in the dense part
# #' of the model.
# #'
# #' @param ssType
# #'
# #' Can be \code{"incremental"} for incremental sum of squares (the
# #' default) or \code{"conditional"} for F-tests that respect both
# #' structural and intrinsic marginality.
# #'
# #' @param kenadj
# #'
# #' Can be \code{"none"} (the default) to compute Wald statistics using an
# #' unadjusted
# #' variance matrix for the fixed effects, \code{"expected"} to adjust
# #' for \emph{expected} information, or \code{"observed"} to adjust for
# #' \emph{observed} information.
# #'
# #' @param \dots
# #'
# #' Arguments to \code{asreml} can be passed through
# #' \code{update.asreml} if \code{ssType} is not \code{"incremental"}.
# #'
# #' @return
# #'
# #' A list with class \code{wald} with the following components:
# #' \describe{
# #'
# #' \item{wald}{An \code{anova} object if \code{denDF="none"} and
# #' \code{ssType = "incremental"}, or a data frame otherwise.}
# #'
# #' \item{stratumVariances}{If \code{denDF} is not \code{"none"}, a
# #' matrix of approximate stratum variances, degrees of freedom and
# #' component coefficients is returned for simple variance component
# #' models.}
# #'
# #' }
# #'
# #' @references
# #'
# #' % bibentry: Kenward:1997
# #'
# #' @method wald asreml
# #'
# wald.old.asreml <- function(object,
#                         Ftest = formula("~NULL"),
#                         denDF = c("none","default","numeric","algebraic"),
#                         ssType = c("incremental","conditional"),
#                         kenadj = c("none","expected","observed"), ...)
# {

#   ## anova() type method for asreml objects
#   trim0 <- function(x) {
#     kpr <- apply(x,1,function(y){!all(y == 0.0)})
#     kpc <- apply(x,2,function(y){!all(y == 0.0)})
#     return(x[kpr, kpc, drop=FALSE])
#   }
#   if(missing(object))
#     stop("Missing asreml object\n")
#   if(!inherits(object,"asreml"))
#     stop("object must be of class 'asreml'\n")

#   ## May be an empty table
#   if(sum(object$aov[,"id"]) == 0) {
#     message("No terms in aov table.")
#     return(NULL)
#   }

#   ## get the model frame for family id & link
#   if(is.null(mf <- object$mf)) {
#     if(is.null(object$RDS)) {
#       stop(object, "is missing model frame and has no RDS component.")
#     }
#     else
#       mf <- readRDS(object$RDS)
#   }
#   glm <- any(unlist(lapply(attr(mf,"family"),function(x)x$id)) > 1 |
#                unlist(lapply(attr(mf,"family"),function(x)x$link)) > 1)

#   mc <- match.call(expand.dots=TRUE)
#   denDF <- match.arg(denDF)
#   ssType <- match.arg(ssType)
#   kenadj <- match.arg(kenadj)
#   ## Dec 2016
#   if(kenadj != "none") {
#     warning("Option 'kenadj' not available.")
#   }

#   if(length(Ftest[[2]]) > 0) {
#       ssType <- "conditional"
#       denDF <- "default"
#       kenadj <- "none"
#   }

#   ## Old behaviour for seq wald tests

#   if(ssType == "incremental" && denDF == "none") {
#     zdf <- attr(object$aov, "zerodf")
#     s2 <- object$sigma2
#     nsect <- length(object$R.param)
#     ## find the possible scale parameter(s)
#     xx <- which(object$vparameters.type == 1) # a vector
#     ## trt == 1 for multivariate (== !asuv in asreml)
#     ntrt <- 1

#     if(ntrt+nsect == 2)
#       convrt <- sum(object$vparameters[xx] == 1.0 & object$vparameters.con[xx] == 1) == 1
#     else
#       convrt <- FALSE
#     ## Check!
#     if(convrt && attr(mf,"scale.fit") == "sigma")
#       stop("Internal conflict in wald method.")
#     ss <- 1.0
#     if(convrt) ss <- s2

#     trms <- dimnames(object$aov)[[1]]
#     nfact <- length(trms)
#     aod <- matrix(nrow=nfact, ncol=4)
#     aod[,1] <- object$aov[seq(1,nfact), "df"]
#     aod[,2] <- object$yssqu[trms]
#     aod[,3] <- aod[,2]/ss
#     aod[,4] <- 1-pchisq(aod[,3],aod[,1])
#     aod <- rbind(aod,c(NA,object$sigma2,NA,NA))
#     heading <- c("Wald tests for fixed effects.",
#                  paste("Response:",
#                        deparse(object$formulae$fixed[[2]])),
#                  "Terms added sequentially; adjusted for those above.")
#     if(glm) {
#       heading <- c(heading,
#                    paste("Note: These Wald statistics are based on the working variable",
#                          "and are not equivalent to an Analysis of Deviance.", sep="\n"))
#     }
#     attr(aod, "heading") <- heading
#     dimnames(aod) <- list(c(trms,"residual (MS)"),
#                           c("Df","Sum of Sq","Wald statistic","Pr(Chisq)"))
#     if(!is.null(zdf)) attr(aod, "zerodf") <- zdf
#     oldClass(aod) <- c("wald", class(aod))
#     return(aod)
#   }
#   newcall <- eval(as.call(c(list(update.asreml, object=substitute(object),
#                                  wald=list(denDF=denDF, ssType=ssType, Ftest=Ftest, kenadj=kenadj),
#                                  evaluate=FALSE),
#                                  list(...))), parent.frame())
#   object <- eval(newcall, parent.frame())

#   if(length(mc$debug) > 0 && mc$debug) return(object)

#   aov <- object$aov
#   zdf <- attr(object$aov, "zerodf")

#   aov[,3] <- round(aov[,3],1)
#   aov[,4] <- signif(aov[,4],4)
#   aov[,5] <- signif(aov[,5],4)

#   heading <- c("\nWald tests for fixed effects.",
#                paste("Response:",
#                      my.dparse(object$formulae$fixed[[2]])))

#   if(length(Ftest[[2]]) > 0) {
#     x <- as.integer(aov[,6])
#     x[x==0] <- -32
#     cstr <- rawToChar(as.raw(x+64))
#     temp <- substring(cstr, 1:nchar(cstr), 1:nchar(cstr))
#     which<- seq(1,length(x))[temp == "O"] # uppercase o
#     if(length(which) == 0) {
#       ## Ftest N/A - df may change - just return full table
#       heading <- c(heading,
#                    paste("An Ftest test is not calculated if any term in the test model",
#                          "(tested or background), would have changed the numerator df.", sep="\n"),
#                    paste("The test ", my.dparse(Ftest), " is not performed."),
#                    "Consider reordering terms in the model.")

#       aod <- data.frame(Df=aov[,2],denDF=aov[,3],Finc=aov[,4],Fcon=aov[,5],
#                         Margin=aov[,6],Pr=aov[,7], stringsAsFactors=TRUE)
#       aod[,5][aod[,5]==0] <- -32
#       cstr <- rawToChar(as.raw(aod[,5]+64))
#       aod[,5] <- substring(cstr, 1:nchar(cstr), 1:nchar(cstr))
#       attr(aod, "names") <- c("Df","denDF","F.inc","F.con","Margin","Pr")
#       attr(aod,"heading") <- heading
#       if(!is.null(zdf)) attr(aod, "zerodf") <- zdf
#       class(aod) <- c("wald",class(aod))
#       return(aod)
#     }
#     else {
#       aod <- matrix(nrow=2,ncol=3)
#       aod[,1] <- c(aov[which,2],aov[which,3])
#       aod[,2] <- c(aov[which,5],NA)
#       aod[,3] <- c(1-pf(aod[1,2],aod[1,1],aod[2,1]),NA)

#       heading <- c(heading,paste(as.character(my.dparse(Ftest))))
#       if(glm) {
#         heading <- c(heading,
#                      paste("Note: These Wald F statistics are based on the working variable",
#                            "and are not equivalent to an Analysis of Deviance.", sep="\n"))
#       }
#       attr(aod,"heading") <- heading
#       dimnames(aod) <- list(c(dimnames(aov)[[1]][which], "Residual"),
#                             c("DF","Conditional F","Pr(F)"))
#       if(!is.null(zdf)) attr(aod, "zerodf") <- zdf
#       class(aod) <- c("wald",class(aod))
#       return(aod)
#     }
#   }
#   if((ssType == "conditional") && (denDF != "none")) {
#   #  //           write(7,2178)'NumDF    DenDF_con F_inc    F_con M P_con'
#   #  // 2178      format(/' Analysis of Variance',14X,A)
#     aod <- data.frame(Df=aov[,2],denDF=aov[,3],Finc=aov[,4],Fcon=aov[,5],
#                       Margin=aov[,6],Pr=aov[,7], stringsAsFactors=TRUE)
#     aod[,5][aod[,5]==0] <- -32
#     cstr <- rawToChar(as.raw(aod[,5]+64))
#     aod[,5] <- substring(cstr, 1:nchar(cstr), 1:nchar(cstr))
#     attr(aod, "names") <- c("Df","denDF","F.inc","F.con","Margin","Pr")
#   }
#   else if(ssType == "conditional") {
#     # //           write(7,2178)'NumDF              F_inc    F_con'
#     aod <- data.frame(Df=aov[,2],Finc=aov[,4],Fcon=aov[,5],Margin=aov[,6], stringsAsFactors=TRUE)
#     aod[,4][aod[,4]==0] <- -32
#     cstr <- rawToChar(as.raw(aod[,4]+64))
#     aod[,4] <- substring(cstr, 1:nchar(cstr), 1:nchar(cstr))
#     attr(aod, "names") <- c("Df","F.inc","F.con","Margin")
#   }
#   else if(denDF != "none") {
#    # //           write(7,2178)'NumDF     DenDF    F_inc             Prob'
#     aod <- data.frame(Df=aov[,2],denDF=aov[,3],Finc=aov[,4],Pr=aov[,7], stringsAsFactors=TRUE)
#     attr(aod, "names") <- c("Df","denDF","F.inc","Pr")
#   }
#   if(glm) {
#     heading <- c(heading,
#                  paste("Note: These Wald F statistics are based on the working variable",
#                        "and are not equivalent to an Analysis of Deviance.", sep="\n"))
#   }
#   attr(aod, "heading") <- heading
#   if(!is.null(zdf)) attr(aod, "zerodf") <- zdf
#   attr(aod, "row.names") <- dimnames(aov)[[1]]
#   class(aod) <- c("wald", class(aod))

#   list(Wald=aod, stratumVariances = {
#          if(is.matrix(object$appstvar))
#            trim0(object$appstvar[,2:ncol(object$appstvar)])
#          else
#            NULL})
# }
#' Print a wald object.
#'
#' Print method similar to \code{print.anova} for objects with class
#' \code{wald}.
#'
#' @param x
#'
#' An object with class \code{wald} from a call to \code{\link{wald.asreml}}.
#'
#' @param digits
#'
#' Numeric precision.
#'
#' @param signif.stars
#'
#' Controls printing of stars indicating significance in the summary tables of coefficients. The
#' default is \code{getOption("show.signif.stars")}.
#'
#' @param \dots
#'
#' Additional arguments to be passed to \code{stats::printCoefmat}.
#'
#' @method print wald
#'
print.wald <- function (x, digits = max(getOption("digits") - 2L, 3L),
                        signif.stars = getOption("show.signif.stars"), ...)
{
    if (!is.null(heading <- attr(x, "heading")))
      cat(colourise(heading, "blue"), sep = "\n")
    cat("\n")

    if(is.data.frame(x)) {
      attr(x, "heading") <- NULL
      d <- dim(x)
      for(i in 1:d[2]) {
        xx <- x[[i]]
        if(!length(levels(xx)) && is.numeric(xx)) {
          xx <- format(zapsmall(xx, digits))
          x[[i]] <- xx
        }
      }
      return(invisible(NextMethod("print")))
    }
    nc <- dim(x)[2L]
    if (is.null(cn <- colnames(x)))
        stop("'wald' object must have colnames")
    has.P <- grepl("^(P|Pr)\\(", cn[nc])
    zap.i <- 1L:(if (has.P)
        nc - 1
    else nc)
    i <- which(substr(cn, 2, 7) == " value")
    i <- c(i, which(!is.na(match(cn, c("F", "Cp", "Chisq")))))
    if (length(i))
        zap.i <- zap.i[!(zap.i %in% i)]
    tst.i <- i
    if (length(i <- grep("Df$", cn)))
        zap.i <- zap.i[!(zap.i %in% i)]
    printCoefmat(x, digits = digits, signif.stars = signif.stars,
        has.Pvalue = has.P, P.values = has.P, cs.ind = NULL,
        zap.ind = zap.i, tst.ind = tst.i, na.print = "", ...)
    invisible(x)
}
#' Predict linear functions of effects.
#'
#' An instance of the generic method \code{predict} for objects of
#' class \code{asreml}. Forms a linear function of the vector of fixed
#' and random effects in the linear model to obtain an estimated or
#' predicted value.
#'
#' The prediction process forms a linear function of the vector of
#' fixed and random effects in the linear model to obtain a predicted
#' value for a quantity of interest.  It is primarily used for
#' predicting tables of adjusted means. If the table is based on a
#' subset of the explanatory variables then the other variables need
#' to be accounted for. It is usual to form a predicted value either
#' at specified values of the remaining variables, or averaging over
#' them in some way.
#'
#' Prediction equations are formed just prior to the final iteration
#' in \code{asreml}. The \code{predict.asreml} method passes the list
#' of user specifications for the prediction design matrix to the
#' \code{REML} routines through the \code{predict} argument of
#' \code{asreml}. Predicted values and standard errors are returned in
#' the \code{predictions} component of the \code{asreml} object. In
#' forming the predictions, \code{predict.asreml} calls
#' \code{update.asreml} to re-run the model from its previous
#' solution.
#'
#' @param object An \code{asreml} object.
#'
#' @param classify
#'
#' A character string giving the variables that define the margins of
#' the multiway table to be predicted. Multiway tables are specified
#' by forming an interaction type term from the classifying variables,
#' that is, separating the variable names with the ":" operator.
#'
#' @param levels
#'
#' A list, named by the margins of the classifying table, of vectors
#' specifying the levels at which predictions are required. If
#' omitted, factors are predicted at each level, simple covariates are
#' predicted at their overall mean and covariates used as a basis for
#' splines or orthogonal polynomials are predicted at their design
#' points. Additional prediction points for spline terms should be
#' included in the design matrix with the \code{asreml}
#' \code{knot.points} argument and included in the predict set with
#' the \code{predict} \code{design.points} argument. The factors
#' \code{mv} and \code{units} are always ignored.
#'
#' @param present
#'
#' A character vector specifying which variables to include in the
#' \code{present} averaging set. The \code{present} set is used when
#' averaging is to be based only on cells with data.  The
#' \code{present} set may include variables in the classify set but
#' not those in the \code{average set}.
#'
#'  If a list, there can be a maximum of two components, each a
#' character vector of variable names, representing non-overlapping
#' \code{present} categorisations and one optional component named
#' \code{prwts} containing a vector of weights to be used for
#' averaging the \bold{first} present table only.  The vector(s) of
#' names may include variables in the classify set but not those in
#' the average set.
#'
#' @param ignore
#'
#' A character vector specifying which variables to ignore in forming
#' the predictions.
#'
#' @param use
#'
#' A character vector specifying which variables to add to the
#' prediction model after the default rules have been invoked.
#'
#' @param except
#'
#' A character vector specifying which variables to exclude in the
#' prediction process. That is, the prediction model includes all
#' fitted model terms not in the \code{except} list.
#'
#' @param only
#'
#' A character vector specifying which variables (only) form the
#' prediction model, that is, the default rules are not invoked.
#'
#' @param associate
#'
#' A one-sided formula specifying terms in up to two independent
#' nested hierarchies. The factors in each hierarchy are written as a
#' compound term separated by the \code{":"} operator and in
#' \emph{left-to-right} outer to inner nesting order. Nested
#' hierarchies are separated by the \code{"+"} operator; only one
#' \code{"+"} operator is currently permitted, giving a maximum of two
#' \code{associate} \emph{lists}.
#'
#' @param average
#'
#' A list, named by the margins of the classifying table, specifying
#' which variables to include in the averaging set. Optionally, each
#' component of the list is a vector specifying the weights to use in
#' the averaging process. If omitted, equal weights are used.
#'
#' @param vcov
#'
#' If \code{TRUE} (default \code{FALSE}), the full variance-covariance
#' matrix of the predicted values is returned in a component
#' \code{vcov}.
#'
#' @param sed
#'
#' If \code{TRUE} (default \code{FALSE}), the full standard error of
#' difference matrix of the predicted values is returned in a
#' component \code{sed}.
#'
#' @param parallel
#'
#' If \code{TRUE} (default \code{FALSE}), the levels of the
#' \code{classify} factors given in the \code{levels} list are
#' expanded in parallel; in this case levels must be specified for all
#' factors in the classify set, and they must be of equal length.
#'
#' @param aliased
#'
#' If \code{TRUE} (default \code{FALSE}), the predicted values are
#' returned for non-estimable functions.
#'
#' @param design.points
#'
#' A list with named components where each component is a list or
#' matrix (for two dimensions), or vector (single dimension) of user
#' supplied prediction design points for \code{spl()}, \code{pol()},
#' \code{dev()} or metric type models. If an element of this list is a
#' list of length 2 then the first vector component is taken as the
#' \emph{x} coordinates and the second as the \emph{y}
#' coordinates. If a component is a matrix, then it is assumed that
#' the (\emph{x}, \emph{y}) coordinates occupy columns 1 and 2,
#' respectively. The names of \code{design.points} must match exactly
#' those used in the model functions.
#'
#' @param evaluate
#'
#' If \code{FALSE} (the default is \code{TRUE}), an unevaluated call
#' to \code{\link{update.asreml}} is returned, otherwise the call is
#' evaluated. Setting \code{evaluate =} \code{FALSE} returns a list
#' that may be used with the \code{predict} argument in a call to
#' \code{asreml}.
#'
#' @param \dots
#'
#' Additional arguments to \code{asreml}.
#'
#' @return
#'
#' The full \code{asreml} object is not returned, only the
#' \code{predictions} element containing the following components:
#'
#' \describe{
#'
#' \item{pvals}{A data frame of predicted values with class
#' \code{asreml.predict}.}
#'
#' \item{sed}{Optional matrix of class \code{dspMatrix} of standard
#' errors of difference.}
#'
#' \item{vcov}{Optional variance-covariance matrix of class
#' \code{dspMatrix} of the predicted values.}
#'
#' \item{avsed}{Summary standard error of difference.}
#'
#' }
#'
#' @references
#'
#' % bibentry: Welham:2004
#'
#' @method predict asreml
#'
predict.asreml <- function(object = NULL,
                           classify = character(0),
                           levels = list(),
                           present = list(),
                           ignore = character(0),
                           use = character(0),
                           except = character(0),
                           only = character(0),
                           associate = formula("~NULL"),
                           average = list(),
                           vcov = FALSE,
                           sed = FALSE,
                           parallel = FALSE,
                           aliased = FALSE,
                           design.points = list(),
                           evaluate = TRUE,
                           ...)
{
  ## probably called by asreml with no args
  if(is.null(object) && length(classify) == 0) {
    return(NULL)
  }

  if(!is.null(object)) {
    if(!inherits(object, "asreml"))
      stop(object," not of class 'asreml'")
    if(length(as.character(classify)) == 0) {
      message("Empty 'classify' set.")
      return(NULL)
    }
  }

  ## Old stuff
  as.average <- list()
  inrandom  <- TRUE
  exrandom  <- FALSE
  estimable  <- FALSE

  dbg <- is.element("debug", names(list(...)))
  if(is.element("margin", names(list(...))))
    stop("Option 'margin' not available.", call.=FALSE)

  if(length(classify) > 1)
    stop("The classify argument must be of length 1\n")
  if(mode(classify) == "list")
    stop("The 'classify' argument must be a character string")
  Pnames <- strsplit(classify, split=":", fixed=TRUE)[[1]]
  if(length(Pnames) > 1) {
    if(mode(levels) != "list")
      stop("\nlevels argument must be of mode list\n")
    if(any(is.na(match(names(levels),Pnames))))
      stop(paste("\n'levels' must be a list with component names a subset of",
                 paste(Pnames,collapse=",")))
  }
  else if(!is.list(levels)){
    ## make it a list (easier later)
    levels <- list(x=levels)
    names(levels) <- Pnames
  }

  ## average may be a dataframe
  ## coerce it to a list for later
  if(is.data.frame(average))
    average <- as.list(average)
  if(is.data.frame(as.average))
    as.average <- as.list(as.average)

  ## associate
  ## if A+B then implies 2 associate 'lists'
  ## store as a list of up to 2 character vectors
  if(!inherits(associate,"formula"))
    stop("'associate' must be a formula\n")

  if(length(associate[[2]]) == 0)
    associate <- list()
  else {
    ff <- getOp(associate[[2]],'+')
    if(is.null(ff)) {
      ## no plus
      ffL <-  dimnames(attr(Terms(associate),'factors'))[[1]]
      ffR <- character(0)
    }
    else {
      ffL <- dimnames(attr(Terms(formula(paste("~",my.dparse(ff[[2]])))),'factors'))[[1]]
      ffR <- dimnames(attr(Terms(formula(paste("~",my.dparse(ff[[3]])))),'factors'))[[1]]
    }
    associate <- list(ffL,ffR)
  }

  if(length(parallel) && mode(parallel) != "logical")
      stop("'parallel' must be a logical variable")
  if(length(parallel)==0)
    parallel <- FALSE

  if(vcov && sed)
    stop("Specify one of 'vcov' or 'sed'.")

  prd <- list(classify=classify,
              levels = levels,
              present= present,
              ignore =ignore,
              use = use,
              except = except,
              only =only,
              associate= associate,
              margin = FALSE,
              average = average,
              as.average = as.average,
              vcov = vcov,
              sed = sed,
              parallel = parallel,
              inrandom = ie(length(inrandom)==0,TRUE,inrandom),
              exrandom = exrandom,
              aliased = aliased,
              estimable = estimable,
              design.points = design.points)

  if(is.null(object) || !evaluate)
    return(prd)

  if(is.call(substitute(object)))
    stop("object is of mode call, please simplify.")

  newcall <- eval(as.call(c(list(update.asreml, object=substitute(object), predict=prd, evaluate=FALSE),
                                 list(...))), parent.frame())

  if((is.logical(dbg) && dbg) || dbg > 0)
    return(eval(newcall, parent.frame()))
  else
    return(eval(newcall, parent.frame())$predictions)
}
#' Print predictions.
#'
#' A \code{print} method for \code{asreml.predict} objects.
#'
#' @method print asreml.predict
#'
#' @param x An object of class \code{asreml.predict} from a call to
#' \code{\link{predict.asreml}}.
#'
#' @param digits Numeric precision.
#'
#' @param \dots Additional arguments.
#'
print.asreml.predict <- function(x, digits = getOption("digits"), ...)
{
  heading <- attr(x, "heading")
  if(!is.null(heading))
    cat("\nNotes:", colourise(heading, "blue"), sep = "\n")
  attr(x, "heading") <- NULL
  d <- dim(x)
  for(i in 1:d[2]) {
    xx <- x[[i]]
    if(!length(levels(xx)) && is.numeric(xx)) {
      xx <- format(zapsmall(xx, digits))
      x[[i]] <- xx
    }
  }

  invisible(NextMethod("print"))
}
#' Functions of variance parameters.
#'
#' Form functions of variance components from an \code{asreml} object.
#'
#' The standard error of the computed value is calculated using the
#' \emph{delta} method using \code{deriv()}, which calculates
#' algebraic derivatives for a wide range of expressions. The variance
#' components are represented in the expression by \code{"V1"},
#' \code{"V2"}, \code{"V3"}, etc.
#'
#' @param object An \code{asreml} object.
#'
#' @param xform
#'
#' A two-sided formula, where the left-hand side labels the estimate.
#' The right-hand side defines the derived parameter as an algebraic
#' expression. Any of the estimated parameters can be included,
#' represented as \code{"V1"}, \code{"V2"}, \code{"V3"}, \dots in the
#' order they appear in \code{object$vparameters}. Parentheses, and
#' simple functions like \code{log}, \code{exp}, \code{sqrt} are
#' allowed.
#'
#' @return
#'
#' A single-row data frame with components:
#'
#' \describe{
#' \item{Estimate}{The result of the algebraic expression.}
#' \item{SE}{The estimated standard error.}
#' }
#'
vpredict <- function (object, xform) {
  ## pin files for asreml-R objects
  ## credit to Ian White's pin.R function
  ## uses 'deriv' which accepts a structure or the rhs of a formula

  if(!inherits(object, "asreml"))
    stop("Argument must be an asreml object")

  pframe <- as.list(object$vparameters)
  names(pframe) <- paste("V", seq(1, length(pframe)), sep = "")
  tvalue <- eval(deriv(xform[[length(xform)]], names(pframe)),
                 pframe)
  X <- matrix(as.vector(attr(tvalue, "gradient")), ncol=1)

  ## Name the result
  tname <- if (length(xform) == 3)
             xform[[2]]
           else
             deparse(xform[[2]])

  ## This for V3 with ai as a vector (lower tri row major)
  ##n <- length(pframe)
  ##i <- rep(1:n, 1:n)
  ##j <- sequence(1:n)
  ##k <- 1 + (i > j)
  ##se <- sqrt(sum(object$ai[!lower.tri(object$ai)] * X[i] * X[j] * k))
  se <- as.vector(sqrt(t(X) %*% object$ai %*% X))
  data.frame(row.names = tname, Estimate = tvalue, SE = se, stringsAsFactors=TRUE)
}
#' Summarize an asreml object
#'
#' A \code{summary} method for objects inheriting from class
#' \code{asreml}.
#'
#' @param object
#'
#' An \code{asreml} object.
#'
#' @param param
#'
#' if \code{"sigma"} (the default), random parameter values are
#' reported on the \emph{sigma} scale only, otherwise, if
#' \code{"gamma"}, an additional column of variance ratios is
#' returned.
#'
#' @param coef
#'
#' If \code{TRUE} (default is \code{FALSE}), the coefficients and
#' their standard errors are included in the return object.
#'
#' @param vparameters
#'
#' If \code{TRUE} (default is \code{FALSE}), the variance parameters
#' are included in the return object in list form.
#'
#' @param \dots Additional arguments.
#'
#' @return
#'
#' A list of class \code{summary.asreml} with the following components:
#'
#' \describe{
#'
#' \item{call}{The \code{call} component from \code{object}.}
#'
#' \item{loglik}{The \code{loglik} component from \code{object}.}
#'
#' \item{nedf}{The \code{nedf} component from \code{object}.}
#'
#' \item{sigma}{\code{sqrt(object\$sigma2)}.}
#'
#' \item{varcomp}{A dataframe summarising the random parameter vector
#' (\code{object$vparameters}). Variance component ratios are included if
#' \code{param="gamma"}, and a measure of precision is included along
#' with boundary constraints at termination and the percentage change
#' in the final iteration.}
#'
#' \item{aic}{Akaike information criterion.}
#'
#' \item{bic}{Bayesian information criterion.}
#'
#' \item{distribution}{A character string identifying the error
#' distribution(s) if \code{object$deviance != 0}.}
#'
#' \item{link}{A character string identifying the link function(s) if
#' \code{object$deviance != 0}.}
#'
#' \item{deviance}{The deviance from the fit if \code{object$deviance
#' != 0}.}
#'
#' \item{heterogeneity}{Variance heterogeneity (\code{deviance/nedf})
#' if \code{object$deviance != 0}. }
#'
#' \item{coef.fixed}{A matrix of coefficients and their standard errors
#' for fixed effects if \code{coef=TRUE}.}
#'
#' \item{coef.random}{A matrix of coefficients and their standard errors
#' for random effects if \code{coef=TRUE}.}
#'
#' \item{coef.sparse}{A matrix of coefficients and their standard
#' errors for sparse-fixed effects if \code{coef=TRUE}.}
#'
#' \item{vparameters}{A list of variance structures with matrices converted
#' to full dense form. For \code{ante} and \code{chol} models the
#' components are given in \code{varcomp} and returned in
#' \code{gammas} in variance-covariance form.}
#'
#' }
#'
#' @method summary asreml
#' @aliases summary
#'
summary.asreml <- function(object, param=c("sigma","gamma"), coef=FALSE,
                           vparameters=FALSE, ...)
{
  ## Summary method for objects of class "asreml"

  safeSqrt <- function(x) {
    x[!is.na(x) & x > 0] <- sqrt(x[!is.na(x) & x > 0])
    x[!is.na(x) & x < 0] <- NA
    x
  }
  cv <- function(ai,x,i,g,s) {
    ## x is locs2
    ## i is gam index
    ## g is gam
    ## s is sigma2 or sqrt(sigma2)
    return(g^2 * ai[x,x] + 2 * s * g * ai[x,i] + s^2 * ai[i,i])
  }

  if(!inherits(object, "asreml"))
    stop("Argument must be an asreml class object")
  ## need the response from 'data'

  if(is.null(object$mf)) {
    if(is.null(object$RDS)) {
      stop("object is missing model frame (mf) and has no RDS component.")
    }
    else {
      mf <- readRDS(object$RDS)
    }
  } else {
    mf <- object$mf
  }
  tr <- attr(mf,"traits")
  mv <- tr$mvar.method
  ## ISUV --> std univariate
  ## ASUV --> fit mv; can have residual other than IxUS
  ## ASMV --> asmv factor replaces 'trait'; fit mv
  ## ISMV --> residual must be IxUS; do not include mv
  ## ASMN --> univariate multinomial with response in a factor

  ntrt <- {if(is.element(mv, c("ISUV", "ASMV")))
             1
           else
             length(tr$lhs)}

  ## The notes in a4scor say
  ##    tgamma   1=variance 2=gamma
  ##             3=correlation 4=covariance 5=postve corr 6=Factor loading
  ##             7=Unrestricted   8=Kriging Range 9 Kriging general

  ## Do gammas/components first (in the spirit of Asreml)
  ## If param="gamma" and convrt==TRUE then output has gamma
  ##    and component columns,
  ## else
  ##    one component column only.

  param <- match.arg(param)
  ng <- length(object$vparameters)
  s2 <- object$sigma2
  nsect <- length(object$R.param)

  ## Get row(s) of sigma2
  xx <- which(object$vparameters == 1.0 &
              object$vparameters.type == 1 &
              object$vparameters.con == 1)
  ## Last one should be s2
  x <- xx[length(xx)]
  ## CHECK multinomial ???
  convrt <- attr(mf, "scale.fit") == "gamma" || attr(mf, "scale.fit") == "ratio"
  ## Something dodgey via gammaPar?
  if(convrt && length(xx) == 0) convrt <- FALSE
  if(!convrt) s2 <- 1.0
##  if(ntrt + nsect == 2)
##    convrt <- object$vparameters[x] == 1.0 && object$vparameters.con[x] != 4
##  else {
##    convrt <- FALSE
##    s2 <- 1.0
##  }
  sigma <- sqrt(s2)
  both <- convrt && (param == "gamma")
  ## ai is symmetric stored in Matrix object
  v <- vector(mode="numeric",length=ng)
  if(convrt) {
    ## fitted on gamma scale; not all "gammas" have type=2
    for(i in seq(1,ng)){
      if(object$vparameters.type[i] > 6 || object$vparameters.type[i] == 5)
        object$vparameters.type[i] <- 3 # corr

      if(object$vparameters.type[i] == 6) {      ## loading
        v[i] <- cv(object$ai, x, i, object$vparameters[i]*0.5/sigma, sigma)
      }
      else if(object$vparameters.type[i] %% 3 == 0) { ## correlation
        v[i] <- object$ai[i,i]
      }
      else if(i == x) {
        v[i] <- object$ai[i,i]
      }
      else if(object$vparameters.con[i] == 4) {
        next
      }
      else {
        v[i] <- cv(object$ai, x, i, object$vparameters[i], s2)
      }
    }

    theta <- rep(s2,ng)
    theta[which(is.element(object$vparameters.type, c(3,5)))] <- 1.0
    ##theta[which(object$vparameters.con == 4)] <- 1.0
    if(length(w <- which(object$vparameters.type == 6)) > 0) {
      theta[w] <- sigma
    }
  }
  else {
    v <- Matrix::diag(object$ai)
    theta <- rep(1.0, ng)
  }

  v[v == 0.0] <- NA
  v <- safeSqrt(v)
  comp <- object$vparameters*theta
  tval <- comp/v
  if(both) {
    varcomp <- matrix(nrow=ng, ncol=4)
    varcomp <- cbind(object$vparameters,comp,v,tval)
    dimnames(varcomp) <- list(names(object$vparameters),
                              c("gamma","component","std.error","z.ratio"))
  }
  else {
    varcomp <- matrix(nrow=ng, ncol=3)
    varcomp <- cbind(comp,v,tval)
    dimnames(varcomp) <- list(names(object$vparameters),
                              c("component","std.error","z.ratio"))
  }
  constraint <- matrix(guzpfx(object$vparameters.con),ncol=1)
  dimnames(constraint) <- list(names(object$vparameters),"bound")
  if(length(bnd <- which(constraint == "B")) > 0) {
    varcomp[bnd, 'std.error'] <- NA
    varcomp[bnd, 'z.ratio'] <- NA
  }
  if(coef) {
    ndense <- length(object$coefficients$fixed)
    fix.nam <- dimnames(object$coefficients$fixed)[[1]]
    if(convrt)
      ss <- s2
    else
      ss <- 1.0
    fixed <- matrix(nrow=ndense,ncol=3)
    fixed[,1] <- object$coefficients$fixed
    fixed[,2] <- safeSqrt(ss*object$vcoeff$fixed)
    fixed[,2][fixed[,2]==0] <- NA
    fixed[,3] <- fixed[,1]/fixed[,2]
    dimnames(fixed) <- list(fix.nam,
                            c("solution","std error","z.ratio"))

    if(length(object$coefficients$random) > 0 ) {
      random <- matrix(nrow=length(object$coefficients$random),ncol=3)
      random[,1] <- object$coefficients$random
      random[,2] <- safeSqrt(ss*object$vcoeff$random)
      random[,2][random[,2]==0] <- NA
      random[,3] <- random[,1]/random[,2]
      dimnames(random) <- list(dimnames(object$coefficients$random)[[1]],
                               c("solution","std.error","z.ratio"))
    }
    else
      random <- NULL

    if(length(object$coefficients$sparse) > 0 ) {
      sparse <- matrix(nrow=length(object$coefficients$sparse),ncol=3)
      sparse[,1] <- object$coefficients$sparse
      sparse[,2] <- safeSqrt(ss*object$vcoeff$sparse)
      sparse[,2][sparse[,2]==0] <- NA
      sparse[,3] <- sparse[,1]/sparse[,2]
      dimnames(sparse) <- list(dimnames(object$coefficients$sparse)[[1]],
                               c("solution","std.error","z.ratio"))
    }
    else
      sparse <- NULL
  }

  sum.object <- vector(mode="list")
  sum.object$call <- object$call
  sum.object$loglik <- object$loglik
  sum.object$nedf <- object$nedf
  sum.object$sigma <- safeSqrt(s2)
  pc <- matrix(round(object$vparameters.pc, 1), ncol=1)
  dimnames(pc) <- list(names(object$vparameters), "%ch")
  sum.object$varcomp <- cbind(data.frame(varcomp, stringsAsFactors=TRUE),constraint,pc)
  ## AIC, BIC
  m <- sum(as.numeric(!is.element(substring(constraint[,1],1,1), c("F", "C"))))
  if(m > 0) {
    sum.object$bic <- m * log(object$nedf) - 2 * object$loglik
    sum.object$aic <- m * 2 - 2 * object$loglik
  }
  else {
    sum.object$bic <- NA
    sum.object$aic <- NA
  }
  attr(sum.object$bic, "parameters") <- m
  attr(sum.object$aic, "parameters") <- m

  if(object$deviance != 0) {
    sum.object$distribution <- names(object$distribution)
    sum.object$link <- names(object$link)
    sum.object$deviance <- object$deviance
    sum.object$heterogeneity <- abs(object$deviance/object$nedf)
  }

  if(coef) {
    sum.object$coef.fixed <- fixed
    sum.object$coef.random <- random
    sum.object$coef.sparse <- sparse
  }

  if(vparameters)
    sum.object$vparameters <- asr_niceGammas(object)

  class(sum.object) <- "summary.asreml"
  sum.object
}
#' Marker effects.
#'
#' Generic function to compute genetic marker effects for a fitted
#' model and matrix of marker scores. The available method is for
#' \code{asreml} class objects.
#'
#' @param object An object of class \code{asreml}.
#'
#' @param \dots Arguments to \code{mef.asreml}
#'
#' @seealso \code{\link{meff.asreml}}
#'
meff <- function(object, ...)
{
  if(!inherits(object,"asreml"))
    stop("object must be of class 'asreml'\n")
  UseMethod("meff")
}
#' Marker effects.
#'
#' Calculate regressor (marker) effects using the original regressor
#' scores and an \code{asreml} fit using the known subject
#' relationship matrix.
#'
#' @param object An \code{asreml} object.
#'
#' @param effects
#'
#' A one sided formula giving the terms in the model (separated by
#' \code{"+"}) for which marker effects are to be calculated. If
#' \code{~NULL}, the default, the term associated with the first
#' variance matrix in the \code{mef} list will be used.
#'
#' @param mef
#'
#' A list associating a known relationship matrix (\code{rm}) used in
#' the model with a matrix of regressor scores, with components in the
#' form \code{rm = "regressor-scores"}.
#'
#' @param se
#'
#' If \code{TRUE}, calculate the standard errors of the effects;
#' default \code{FALSE}.
#'
#' @param evaluate
#'
#' If \code{TRUE} (the default), evaluate the effects by a call to
#' \code{\link{update.asreml}}, otherwise return the unevaluated call.
#'
#' @param \dots
#'
#' Additional arguments to \code{asreml}.
#'
#' @return
#'
#' An \code{asreml} object with a component \code{mef}, a list with
#' \code{length(mef)} components containing the matrices of regressor
#' effects and (optional) standard errors.
#'
#' @method meff asreml
#'
meff.asreml <- function(object, effects = ~NULL, mef = list(), se = FALSE,
                       evaluate = TRUE, ...) {
  ## method for marker effects from genomic random regression

  if(length(mef) == 0)
    stop("mef list is of length zero.", call.=FALSE)

  if(length(effects[[2]]) == 0) { ## default
    if(is.null(mf <- object$mf)) {
      if(is.null(object$RDS)) {
        stop(object, "is missing model frame and has no RDS component.")
      }
      else
        mf <- readRDS(object$RDS)
    }
    if(length(attr(mf,"model.terms")$mixed)) {
      src <- lapply(attr(mf,"model.terms")$mixed$Vars,function(x){
                      if(x$Fun=="vm")
                        c(attributes(x$Call)$Source, x$FacNam)
                      else
                        NULL})
      src <- src[sapply(src, function(x)!is.null(x))]
      if(length(src) == 0)
        stop("No vm() terms found.")
      for(s in seq(along=src)) {
        if(src[[s]][1] == names(mef)[1]) {
          effects <- src[[s]][2]
          break
        }
      }
    }
    if(inherits(effects,"formula"))
      stop("No model terms found for ",names(mef)[1])
  }
  else
    effects <- attr(terms(effects), "term.labels")

  mef$effects <- effects
  mef$se <- se

  if(is.null(object))
    return(mef)

  if(!inherits(object, "asreml"))
    stop("'object' must be an asreml object.", call.=FALSE)

  newcall <- eval(as.call(c(list(update.asreml, object=substitute(object), maxit=1, mef=mef, evaluate=FALSE),
                                 list(...))), parent.frame())
  if(evaluate)
    return(eval(newcall, parent.frame()))
  else
    return(newcall)
}
#' Empirical variogram method.
#'
#' Generic function to calculate an empirical variogram. The available
#' method is for \code{asreml} class objects.
#'
#' @param object An object of class \code{asreml}.
#'
#' @param \dots Arguments to \code{varioGram.asreml}
#'
#' @return
#'
#' A data frame including the following components:
#'
#' \describe{
#' \item{x}{The original \emph{x} coordinates.}
#' \item{y}{The original \emph{y} coordinates.}
#' \item{gamma}{The variogram estimate.}
#' \item{distance}{The average distance for pairs in the lag.}
#' \item{np}{The number of pairs in the lag.}
#' \item{angle}{Direction if not a regular grid.}
#' }
#' @seealso \code{\link{varioGram.asreml}}
#'
varioGram <- function(object, ...)
{
  if(!inherits(object,"asreml"))
    stop("object must be of class 'asreml'\n")
  UseMethod("varioGram")
}
#' Empirical variogram constructor.
#'
#' Calculate the empirical variogram from an \code{asreml} object.
#'
#' Calls \code{\link{asr_varioGram}} to calculate the empirical
#' semi-variogram.
#'
#' @param object An object of class \code{asreml}.
#'
#' @param type Type of residuals, see \code{\link{residuals.asreml}}.
#'
#' @param spatial Whether to include a nugget effect; see
#' \code{\link{residuals.asreml}}.
#'
#' @param formula An optional model formula designed to extract
#' \emph{residuals} from the \emph{random} component of the model
#' rather than the \emph{residual} component. This is a two sided
#' formula where the response is a pattern in the style required by
#' the \code{pattern} argument of \code{\link{coef.asreml}}.
#'
#' @param composite The argument to \code{\link{asr_varioGram}}.
#' @param model The argument to \code{\link{asr_varioGram}}.
#' @param metric The argument to \code{\link{asr_varioGram}}.
#' @param angle The argument to \code{\link{asr_varioGram}}.
#' @param angle.tol The argument to \code{\link{asr_varioGram}}.
#' @param nlag The argument to \code{\link{asr_varioGram}}.
#' @param maxdist The argument to \code{\link{asr_varioGram}}.
#' @param xlag The argument to \code{\link{asr_varioGram}}.
#' @param lag.tol The argument to \code{\link{asr_varioGram}}.
#' @param grid The argument to \code{\link{asr_varioGram}}.
#'
#' @param \dots Additional arguments.
#'
#' @return
#'
#' A data frame including the following components:
#'
#' \describe{
#' \item{x}{The original \emph{x} coordinates.}
#' \item{y}{The original \emph{y} coordinates.}
#' \item{gamma}{The variogram estimate.}
#' \item{distance}{The average distance for pairs in the lag.}
#' \item{np}{The number of pairs in the lag.}
#' \item{angle}{Direction if not a regular grid.}
#' }
#'
#' @examples
#' \dontrun{
#' data(barley)
#' shf.asr <- asreml(yield ~ Variety, residual = ~ ar1(Row):ar1(Column),
#'                   data=shf)
#' varioGram(shf.asr)
#' }
#'
#' @method varioGram asreml
#' 
#' @seealso
#' 
#' \code{\link{asr_varioGram}}
#' 
varioGram.asreml <- function(object, type="default", spatial="trend",
                             formula = ~NULL,
                             composite = TRUE,
                             model = c("empirical"),
                             metric=c("euclidean","manhattan"),
                             angle = 0, angle.tol = 180,
                             nlag=20, maxdist=0.5, xlag=NA,
                             lag.tol = 0.5, grid=TRUE, ...)
{
  ## variogram method for asreml class
  ## formula is to get stuff out of G
  ## eg, row:column ~ row+column

  if(!inherits(object,"asreml"))
    stop("\nObject must be of class asreml\n")

  if(is.null(mf <- object$mf)) {
    if(is.null(object$RDS)) {
      stop(object, "is missing model frame and has no RDS component.")
    }
    else
      mf <- readRDS(object$RDS)
  }
  if(is.multivariate(mf))
    stop("No variogram method for multivariate analysis")

  U <- attr(mf,"model.terms")$residual$Terms.obj
  V <- attr(mf,"model.terms")$residual$Vars

  sect <- attr(U,"specials")$dsum

  if(length(sect) > 0) {
    outer <- attr(V[[1]]$Call,"outer")
    cf <- attr(V[[1]]$Call,"conditioning.factor")
    nsect <- length(object$R.param)
    sections <- names(object$R.param)
    section.term <- rbindlist(lapply(V,function(x)attr(x$Call, "section.term")))
    ## get the dimensions from model frame
    ## easiest (?) way to recover power models
    ## Should be one of 'dims' for each dsum function
    d1 <- lapply(lapply(V,function(x){x$Call}),function(y)attr(y,"model.terms")$Vars)
    dims <- lapply(d1,function(z){unlist(lapply(z,function(a){a$Argv}))})
    ndim <- unique(unlist(lapply(dims,function(x)length(x))))
    ## This shouldn't happen
    if(length(ndim) > 1) stop("Inconsistent number of dimensions")
    if(nsect == 1)
      dimensions <- unlist(dims)
  }
  else {
    outer <- FALSE
    nsect <- 1
    dimensions <- unlist(lapply(V,function(a)a$Argv))
    ndim <- length(dimensions)
    uname <- sections <- paste(unlist(sapply(V,function(x)x$Argv)),collapse=":")
  }

  ## what sort of residuals?
  aom <- (length(object$aom) > 0)
  fam <- unlist(lapply(attr(mf,"family"), function(x)x$id))

  if(type == "default") {
    if(fam[1] == 1) {
      type <- 'working'
      caption <- captions[type]
    }
    else {
      type <- 'deviance'
      caption <- captions[type]
    }
  }
  else {
    if(!is.element(type, names(captions)))
      stop("Unrecognised residual type.")
    if(!aom && (type == "stdCond"))
      stop("'stdCond' selected but 'aom' not set.")
    caption <- captions[type]
  }

  ## No formula
  ## Use sections/dimensions

  rr <- residuals(object, type=type, spatial=spatial)

  if(length(formula[[2]]) == 0) {
    vg <- NULL
    grp <- NULL
    if(nsect==1) {
      if(!outer) {
        vg <- asr_varioGram(x=mf[, dimensions, with=FALSE],
                            z=rr,
                            composite = composite,
                            model = model,
                            metric=metric,
                            angle = angle, angle.tol = angle.tol,
                            nlag=nlag, maxdist=maxdist, xlag=xlag,
                            lag.tol = lag.tol, grid=grid)
      }
      else {
        for(i in unique(as.character(mf[[cf]]))) {
          which <- (as.character(mf[[cf]]) == i)
          vg <- rbind(vg,
                      asr_varioGram(x=subset(mf, which, select=dimensions),
                                    z=rr[which],
                                    composite = composite,
                                    model = model,
                                    metric=metric,
                                    angle = angle, angle.tol = angle.tol,
                                    nlag=nlag, maxdist=maxdist, xlag=xlag,
                                    lag.tol = lag.tol, grid=grid))
          grp <- c(grp,as.character(subset(mf, which, select=cf)[[1]]))
        }
        vg[["groups"]] <- grp
      }
    }
    else {
      for(i in unique(as.character(mf[[cf]]))) {
        which <- (as.character(mf[[cf]]) == i)
        dimensions <- unlist(lapply(dims[section.term$fun[as.character(section.term$section) == i]],
                                    function(x)x))

         vg <- rbind(vg,
                    asr_varioGram(x=subset(mf, which, select=dimensions),
                                  z=rr[which],
                                  composite = composite,
                                  model = model,
                                  metric=metric,
                                  angle = angle, angle.tol = angle.tol,
                                  nlag=nlag, maxdist=maxdist, xlag=xlag,
                                  lag.tol = lag.tol, grid=grid))
        grp <- c(grp, as.character(subset(mf, which, select=cf)[[1]]))
      }
      vg[["groups"]] <- grp
    }
  }
  else {
    rmatch <- function(x,y) {
      ## match for string x within y from the right
      nx <- nchar(x)
      ny <- nchar(y)
      for(i in seq(ny-nx+1,1,-1)) {
        if(x == substring(y,i,i+nx-1))
           return(i)
      }
      return(NA)
    }
    ## G formula
    if(length(formula) != 3)
      stop("'formula' must be of the form 'response ~ predictors'")
    rsp <- dimnames(attr(Terms(formula),"factors"))[[1]][1]
    rr <- coef(object, pattern = formula(paste("~",rsp)))
    ## get primary factors and grouping factor(s)
    ff <- getOp(formula[[3]], '|')
    if(!is.null(ff)) {
      dimensions <- attr(Terms(formula(paste("~",deparse(ff[[2]])))),'term.labels')
      section <- attr(Terms(formula(paste("~",deparse(ff[[3]])))),'term.labels')
      if(length(section) > 1)
        stop("Only one grouping variable permitted")
    }
    else {
      dimensions <- attr(Terms(formula),"term.labels")
      section <- character(0)
      nsect <- 1
    }
    ndim <- length(dimensions)
    df <- list()

    for(i in c(section,dimensions)) {
      v <- sapply(strsplit(dimnames(rr)[[1]],":",fixed=TRUE),function(x,i){
        y <- x[grep(i,x)]
        y <- substring(y,rmatch(i,y),nchar(y))
        y},i)
      df[[i]] <- substring(v,grep("_",substring(v[1],1:nchar(v[1]),1:nchar(v[1])))[1]+1)
    }
    names(df) <- c(section,dimensions)
    df <- data.frame(df, stringsAsFactors=TRUE)
    if(length(section))
      nsect <- length(unique(df[[section]]))

    vg <- NULL
    grp <- NULL

    ##### TODO - REMOVE LEVELS NOT IN DATA

    if(nsect == 1) {
      vg <- asr_varioGram(x=df[,dimensions],
                             z=rr,
                             composite = composite,
                             model = model,
                             metric=metric,
                             angle = angle, angle.tol = angle.tol,
                             nlag=nlag, maxdist=maxdist, xlag=xlag,
                             lag.tol = lag.tol, grid=grid)
    }
    else {
      for(i in unique(as.character(df[,section]))) {
        which <- (as.character(df[,section]) == i)
        vg <- rbind(vg,
                    asr_varioGram(x=df[which,dimensions],
                                     z=rr[which],
                                     composite = composite,
                                     model = model,
                                     metric=metric,
                                     angle = angle, angle.tol = angle.tol,
                                     nlag=nlag, maxdist=maxdist, xlag=xlag,
                                     lag.tol = lag.tol, grid=grid))
        grp <- c(grp,as.character(df[which,section]))
      }
      vg[["groups"]] <- grp
    }
  }

  vg <- data.frame(as.list(vg), stringsAsFactors=TRUE)
  grid <- is.na(match("angle",names(vg)))
  if(grid) {
    ## x,y,group names
    if(ndim == 1)
      vv.names <- c(dimensions,"y","gamma","np")
    else
      vv.names <- c(dimensions[1],dimensions[2],"gamma","np")
    if(length(grp) > 0)
      vv.names <- c(vv.names,"vv.groups")
    names(vg) <- vv.names
  }
  class(vg) <- c("varioGram","data.frame")
  vg
}
#' Plot a variogram.
#'
#' A \code{plot} method for \code{varioGram} objects returned from a
#' call to \code{varioGram.asreml}.
#'
#' @param x An \code{asreml} object.
#'
#' @param npanels
#'
#' The number of \code{lattice} panels. If \code{NA}, it is set to the
#' number of groups in the object.
#'
#' @param scale
#'
#' If \code{TRUE} and there are multiple groups in the object, the
#' response in all groups is scaled relative to the maximum.
#'
#' @param \dots
#'
#' Arguments to be passed to the \code{lattice} functions
#' \code{xyplot} or \code{wireframe}.
#'
#' @return
#'
#' An invisible \code{lattice} object.
#'
#' @method plot varioGram
#'
plot.varioGram <- function(x, npanels=NA, scale=TRUE, ...)
{
  ## plot method for objects of class varioGram
  if(!requireNamespace("lattice", quietly=TRUE))
    stop("Variogram plot method requires package 'lattice'")

  if(!inherits(x,"varioGram"))
    stop("\nObject must be of class varioGram\n")

  if(scale && !is.null(x$vv.groups))
    x$gamma <- unlist(tapply(x$gamma,x$vv.groups,
                               function(a)a/max(a))[unique(x$vv.groups)],use.names=FALSE)

  grid <- is.na(match("angle",names(x)))
  onepage <- TRUE

  if(grid) {
    tmp <- names(x)
    xlab <- tmp[1]
    ylab <- tmp[2]
    tmp[1] <- 'x'
    tmp[2] <- 'y'
    names(x) <- tmp
    if(!is.null(x$vv.groups) & is.na(npanels))
      npanels <- length(unique(x$vv.groups))
    if(!is.null(x$vv.groups) && ceiling(length(unique(x$vv.groups))/npanels) > 1)
      onepage <- FALSE
    nd <- 2 - as.numeric(all(x$y == 0))
    if(nd == 1) {
      if(is.null(x$vv.groups))
        trellis.obj <- lattice::xyplot(gamma ~ x, xlab=paste(xlab,"(lag)"), data=x, ...)
      else
        trellis.obj <- lattice::xyplot(gamma ~ x|vv.groups, scales=list(relation='free', cex=0.6),
                                       data=x, xlab=list(paste(xlab,"(lag)"),cex=0.7),
                                       ylab=list(cex=0.7), layout=c(0,npanels), cex=0.6,
                                       par.strip.text=list(cex=0.7), ...)
    }
    else {
       settings <- list(axis.line = list(col=if(is.null(x$vv.groups)) "transparent" else "black"),
                        box.3d = list(col=c("black","black","grey","grey","black","grey",
                                        "black","black","black")),
                        layout.heights = list(strip=0.7))
      if(is.null(x$vv.groups))
        trellis.obj <- lattice::wireframe(gamma ~ x*y, data=x,
                                          xlab=list(label=paste(xlab,"\n(lag)"),cex=0.66),
                                          ylab=list(label=paste(ylab,"\n(lag)"),cex=0.66),
                                          screen=list(z=30,x=-60,y=0), aspect=c(1,0.66),
                                          scales=list(distance=c(1.3,1.3,1),arrows=FALSE,cex=0.66,
                                            col="black"), zlab="",col="transparent",
                                          shade=TRUE, light.source=c(0,0,10),
                                          shade.colors=function(irr,ref,height,w=0.4){
                                            grey(w*irr+(1-w)*(1-(1-ref)^0.4))},
                                          par.settings = settings, ...)
      else
        trellis.obj <- lattice::wireframe(gamma ~ x*y|vv.groups, data=x,
                                          xlab=list(label=paste(xlab,"\n(lag)"),cex=0.66),
                                          ylab=list(label=paste(ylab,"\n(lag)"),cex=0.66),
                                          screen=list(z=30,x=-60,y=0), aspect=c(1,0.66),
                                          scales=list(distance=c(1.3,1.3,1),arrows=FALSE,cex=0.66,
                                            col="black"), zlab="", col="transparent",
                                          shade=TRUE, light.source=c(0,10,0),
                                          shade.colors=function(irr,ref,height,w=0.4){
                                            grey(w*irr+(1-w)*(1-(1-ref)^0.4))},
                                          relation='free', layout=c(0,npanels),
                                          strip=function(..., par.strip.text) {
                                            lattice::strip.default(..., par.strip.text=list(cex=0.6))},
                                          par.settings = settings, ...)
    }
  }
  else {
    if(is.na(npanels))
      npanels <- length(unique(x$angle))
    if(!is.null(x$vv.groups) &&
       ceiling(length(unique(x$angle))*length(unique(x$vv.groups))/npanels) > 1)
      onepage <- FALSE

    if(is.null(x$vv.groups))
      trellis.obj <- lattice::xyplot(gamma ~ distance|angle, scales=list(relation='free'),
                                     xlab="Distance", data=x, layout=c(0,npanels), ...)
    else
      trellis.obj <- lattice::xyplot(gamma ~ distance|angle*groups, scales=list(relation='free'),
                                     xlab="Distance", data=x, layout=c(0,npanels), ...)
  }

  ## kick it
  if(onepage)
    print(trellis.obj)
  else {
    grDevices::devAskNewPage(TRUE)
    print(trellis.obj)
    grDevices::devAskNewPage(FALSE)
  }

  invisible(trellis.obj)
}
#' Trace convergence.
#'
#' Generic function to graph convergence history for a fitted
#' model. The available method is for \code{asreml} class objects.
#'
#' @param object An object of class \code{asreml}.
#'
#' @param \dots Arguments to \code{tr.asreml}
#'
#' @seealso \code{\link{tr.asreml}}
#'
tr <- function(object, ...)
{
  if(!inherits(object,"asreml"))
    stop("object must be of class 'asreml'\n")
  UseMethod("tr")
}
#' Convergence trace for asreml objects.
#'
#' Scatter plots of component value against iteration for each random
#' component.
#'
#' Values are extracted from the \code{trace} matrix of an
#' \pkg{asreml} fitted object. The (first) four rows of this matrix
#' corresponding to \code{LogLik}, \code{Sigma2}, \code{DF} and
#' \code{stepsz}, respectively, are not plotted by default.
#'
#' @param object An \code{asreml} object.
#'
#' @param components
#'
#' A numeric vector of row numbers of the \code{trace} matrix to
#' include; default is all rows excluding rows 1, 2, 3 and 4.
#'
#' @param iter
#'
#' A numeric vector of iteration numbers to include; default is all
#' columns of \code{trace}.
#'
#' @param \dots
#'
#' Additional arguments.
#'
#' @return
#'
#' An invisible list of \code{ggplot2} objects.
#'
#' @method tr asreml
#'
tr.asreml <- function(object, components = seq(5, nrow(object$trace)),
                         iter = seq(1,ncol(object$trace)), ...)
{
  if(!inherits(object,"asreml"))
    stop("Object must be of class asreml.")

  ## Hack to suppress R check warnings
  Y <- Iteration <- NULL

  which <- dimnames(object$trace)[[1]][components]

  df <- data.frame(Iteration = rep(iter, each=length(which)),
                   Component = rep(which, length(iter)),
                   Y = as.vector(object$trace[which, iter]),
                   stringsAsFactors=TRUE)

  ## 5 per 'page'
  np <- trunc(length(which)/5 + 0.5)
  who <- rep(1:np, each=5, length.out=length(which))
  monitor <- vector(mode="list", length=np)

  for(i in 1:np) {

    monitor[[i]] <- ggplot(df[is.element(df$Component, which[who==i]),], aes(x=Iteration, y=Y)) +
      scale_x_continuous(breaks=unique(df$Iteration)) + geom_line() + geom_point() +
        facet_grid(Component~., scales="free_y") +
          theme(strip.text = element_text(size = rel(0.66)),
                strip.background = element_rect(fill = "#E69F00", colour="black",size=0.5),
                axis.title.x = element_text(size=rel(0.75)),
                axis.title.y = element_text(size=rel(0.75)),
                axis.text.x = element_text(colour="black", size=rel(0.75)),
                axis.text.y = element_text(colour="black", size=rel(0.75)),
                panel.grid.major = element_blank(),
                panel.grid.minor = element_blank())
  }
  multipage(plotlist=monitor)

  invisible(monitor)
}
## Colourise text for display in the terminal.
##
## If R is not currently running in a system that supports terminal colours
## the text will be returned unchanged.
##
## Allowed colours are: black, blue, brown, cyan, dark gray, green, light
## blue, light cyan, light gray, light green, light purple, light red,
## purple, red, white, yellow
##
## @param text character vector
## @param fg foreground colour, defaults to white
## @param bg background colour, defaults to transparent
## @export
## @examples
## print(colourise("Red", "red"))
## cat(colourise("Red", "red"), "\n")
## cat(colourise("White on red", "white", "red"), "\n")
colourise <- function(text, fg = "black", bg = NULL) {
  term <- Sys.getenv()["TERM"]
  env <- names(Sys.getenv())

  colour_terms <- c("xterm-color","xterm-256color", "screen", "screen-256color")

  ## Emacs reports dumb terminal but does do colour
  ## Rstudio reports NA for term (not set)
  if(length(grep("^EMACS", names(Sys.getenv()))) != 0)
    colour_terms <- c(colour_terms, "dumb")

  if(rcmd_running() || !any(term %in% colour_terms, na.rm = TRUE) || !asreml.options()$colourise) {
    return(text)
  }

  col_escape <- function(col) {
    paste0("\033[", col, "m")
  }

  col <- .fg_colours[tolower(fg)]
  if (!is.null(bg)) {
    col <- paste(col, .bg_colours[tolower(bg)], sep = ";")
  }

  init <- col_escape(col)
  reset <- col_escape("0")
  paste0(init, text, reset)
}

.fg_colours <- c(
  "black" = "0;30",
  "blue" = "0;34",
  "green" = "0;32",
  "cyan" = "0;36",
  "red" = "0;31",
  "magenta" = "0;35",
  "brown" = "0;33",
  "light gray" = "0;37",
  "dark gray" = "1;30",
  "light blue" = "1;34",
  "light green" = "1;32",
  "light cyan" = "1;36",
  "light red" = "1;31",
  "light purple" = "1;35",
  "yellow" = "1;33",
  "white" = "1;37"
)

.bg_colours <- c(
  "black" = "40",
  "red" = "41",
  "green" = "42",
  "brown" = "43",
  "blue" = "44",
  "magenta" = "45",
  "cyan" = "46",
  "light gray" = "47"
)

.bold <- c(
  "black" ='1;30',
  "red" ='1;31',
  "green" ='1;32',
  "yellow" ='1;33',
  "blue" ='1;34',
  "magenta" ='1;35',
  "cyan" ='1;36',
  "white" ='1;37'
  )
rcmd_running <- function() {
  nchar(Sys.getenv('R_TESTS')) != 0
}

#' Likelihood ratio tests.
#'
#' Generic function to calculate likelihood ratio statistics for
#' fitted models. The available method is for \code{asreml} class
#' objects.
#'
#' @param \dots A sequence of \code{asreml} objects as comma separated names.
#'
#' @seealso \code{\link{lrt.asreml}}
#'
lrt <- function(...) {
  UseMethod("lrt")
}
#' REML Likelihood ratio tests
#'
#' Extracts the REML log likelhood and numbers of variance parameters
#' from a sequence of \code{asreml} objects, and computes a sequence
#' of pairwise likelihood ratio tests.
#'
#' The models are arranged in increasing order of number of variance
#' parameters and assumed nested in this sequence. If the reduced
#' model is obtained by setting positively-constrained variance
#' parameters in the full model to zero, set \code{boundary} to
#' \code{TRUE}. In this case the probability is computed using a
#' mixture of chi-square distributions as described in Self and Liang
#' (1987).
#'
#' @param \dots A sequence of asreml objects assumed nested when
#' arranged in increasing order of number of parameters.
#'
#' @param boundary If \code{TRUE} (the default) hypothesized parameter
#' values being tested lie on the boundary of the parameter space.
#'
#' @return
#'
#' A data frame with a row for each successive pairwise test, and
#' columns for the likelihood ratio statistic, degrees of freedom and
#' number of parameters.
#'
#' @references
#' % bibentry: Self:1987
#'
#' @method lrt asreml
#'
lrt.asreml <- function(..., boundary = TRUE)
{
  args <- list(...)

  if(length(args) < 2)
    stop("Must specify at least 2 objects of class 'asreml'")

  ## call should be a list of asreml objects
  lapply(args,function(x){
    if(!inherits(x,"asreml"))
      stop("Arguments must be of class 'asreml'")
    invisible(NULL)
  })
  n <- length(args)

  ## fixed models must be the same
  fixed.labels <- lapply(args, function(x) {
                           attr(x$formulae$fixed, "term.labels")
                         })
  sparse.labels <- lapply(call, function(x) {
                            attr(x$formulae$sparse, "term.labels")
                          })
  mu <- unlist(lapply(call, function(x) {
                        attr(x$formulae$fixed, "intercept")
                      }))

  ## check intercept
  if(!(sum(mu) == 0 || sum(mu) == n))
    stop("fixed models differ - (Intercept)")

  ## check fixed
  trms <- length(unique(unlist(lapply(fixed.labels, function(x)x))))
  nt <- unlist(lapply(fixed.labels, function(x)length(x)))
  if(!all(nt == trms))
    stop("fixed models differ")

  ## check sparse
  trms <- length(unique(unlist(lapply(sparse.labels, function(x)x))))
  nt <- unlist(lapply(sparse.labels, function(x)length(x)))
  if(!all(nt == trms))
    stop("sparse models differ")

  pchisq.mixture <- function(x, n=2) {
    df <- 0:n
    mixprobs <- dbinom(df, size=n, prob=0.5)
    p <- c()
    for (i in 1:length(x)){
      p[i] <- sum(mixprobs*pchisq(x[i], df))
    }
    p
  }

  objs <- all.vars(match.call())
  LL <- sapply(args, function(x)x$loglik)
  np <- sapply(args, function(x){
    length(x$vparameters)})

  ## Increasing order of number or parameters
  idx <- base::order(np)
  D <- df <- prob <- numeric(n-1)
  models <- character(n-1)
  ## do successive pairs
  for(i in seq(1,n-1)) {
    ii <- idx[i]   # reduced
    jj <- idx[i+1] # full
    D[i] <- -2*(LL[ii]-LL[jj])
    df[i] <- np[jj]-np[ii]
    constraint <- guzpfx(args[[jj]]$vparameters.con)
    df[i] <- df[i] - sum(as.numeric(constraint == "F"))
    df[i] <- df[i] - sum(as.numeric(constraint == "C"))
    df[i] <- df[i] - sum(as.numeric(constraint == "S"))
    constraint <- guzpfx(args[[ii]]$vparameters.con)
    df[i] <- df[i] + sum(as.numeric(constraint == "F"))
    df[i] <- df[i] + sum(as.numeric(constraint == "C"))
    df[i] <- df[i] + sum(as.numeric(constraint == "S"))

    if(df[i] == 0)
      warning(ii," vs ",jj,": same number of parameters.")

    if(boundary) {
      if(df[i] == 1)
        prob[i] <- 0.5 * (1 - pchisq(D[i],df[i]))
      else
        prob[i] <- 1 - pchisq.mixture(D[i],df[i])
    }
    else
      prob[i] <- 1 - pchisq(D[i],df[i])
    models[i] <- paste(objs[jj],"/",objs[ii],sep="")
  }
  tab <- matrix(nrow=n-1,ncol=3)
  tab[,1] <- df
  tab[,2] <- D
  tab[,3] <- prob
  tab <- data.frame(tab, stringsAsFactors=TRUE)
  heading <- "Likelihood ratio test(s) assuming nested random models.\n"
  if(boundary)
    heading <- paste(heading,
                     "(See Self & Liang, 1987)\n",sep="")
  attr(tab, "heading") <- heading
  attr(tab, "names") <- c("df","LR-statistic","Pr(Chisq)")
  attr(tab, "row.names") <- models
  class(tab) <- c("anova","data.frame")
  return(tab)
}

#' Approximate stratum variances method.
#'
#' Generic function to calculate approximate stratum variances,
#' degrees of freedom and coefficients for
#' variance component models. The available method is for \code{asreml}
#' class objects.
#'
#' @param object An object of class \code{asreml}.
#'
#' @param \dots Arguments to \code{asv.asreml}
#'
#' @seealso \code{\link{asv.asreml}}
#'
asv <- function(object, ...)
{
  if(!inherits(object,"asreml"))
    stop("Object must be of class 'asreml'")
  UseMethod("asv")
}
#' Approximate stratum variances.
#'
#' Function to compute the approximate stratum variances, degrees of
#' freedom and coefficients for simple
#' variance component models.
#'
#' Approximate stratum variances and degrees of freedom for simple
#' variance components models are returned. For the linear mixed-effects
#' model, it is often possible to consider a natural ordering of the
#' variance component parameters, including the residual. Based on an
#' idea due to \cite{Thompson, 1980}, \code{asreml} computes approximate
#' stratum degrees of freedom and stratum variances by a modified
#' Cholesky diagonalisation of the average information matrix.
#'
#' @param object An object of class \code{asreml}.
#'
#' @param order
#'
#' The sequence in which to consider the random terms: may
#' be one of \code{"as.is"} or \code{"noeff"} for the order as given
#' in the \code{asreml} object, or ordered by increasing
#' number of effects, respectively. The default is \code{"as.is"}.
#' Note that the default ordering for random terms in \code{asreml}
#' is \code{"noeff"}.
#'
#' @param vvp
#'
#' If \code{TRUE} (the default is \code{FALSE}) the inverse of the
#' average information matrix for the variance components (sigma scale)
#' is returned.
#'
#' @param \dots
#'
#' Any additional arguments.
#'
#' @return
#'
#' If \code{vvp} is \code{FALSE}, a rectangular matrix containing the
#' degrees of freedom, approximate variances and the component coefficients
#' for each random term. If \code{vvp} is \code{TRUE}, a list of length two
#' containing the matrix of approximate stratum variances and the inverse
#' average information matrix of the variance components in list components
#' \code{asv} and \code{vvp}, respectively.
#'
#' @references
#' % bibentry: Thompson:1980
#'
asv.asreml <- function(object, order=c("as.is", "noeff"), vvp = FALSE, ...)
{
  ## ai is the inverse information matrix on the fitted scale
  ## that is, either gammas or components depending on model

  order <- match.arg(order)
  ng <- length(object$vparameters)
  s2 <- object$sigma2
  ## Get row(s) of sigma2
  x <- which(object$vparameters.type == 1 & object$vparameters == asreml.options()$scale)
  if(length(x) > 0) {
    x <- x[length(x)]
    convrt <- object$vparameters.con[x] != 4
  } else if(length(x) == 0) {
    stop("S2 cannot be identified (multiple sections?).")
  }
  else
    convrt <- FALSE
  object$vparameters[object$vparameters.con == 7] <- 0.0
  ## av information matrix on the component scale
  ## ai is a dspMatrix; get lower.tri in row major order
  ## 16/2/17 NOTE: coerce to matrix as upper.tri breaks when run using Rscript!!!
  ai <- as.matrix(object$ai)
  if(convrt) {
    aiv <- as.vector(ai)[as.vector(upper.tri(ai, diag=TRUE))]
    ai <- .Call("aimatrix", object, aiv, x, PACKAGE="asreml")
    ai <- ltri2mat(ai)
  }

  ## reorder ?
  idx <- switch(order,
                as.is = seq(along=object$vparameters),
                noeff = {
                  v <- 1:ng
                  v[-x] <- (v[-x])[base::order(object$noeff[match(names(object$vparameters)[-x],
                                                        names(object$noeff))])]
                  match(1:ng,v)
                },
                stop("order must be one of 'as.is' or 'noeff'") )

  if(length(idx) > ng || max(idx) > ng)
    stop("'order' too long or elements out of range")

  if(convrt) {
    scale <- rep(s2,ng)
    scale[object$vparameters.type == 3 | object$vparameters.type == 5] <- 1.0
  }
  else
    scale <- rep(1.0,ng)
  comp <- (object$vparameters * scale)[idx]

  gg <- names(object$vparameters)[idx]

  ai <- ai[idx,idx]
  which <- !apply(ai,1,function(x){all(abs(x) < 1e-10)})
  gg <- gg[which]
  comp <- comp[which]

  ff <- ai[which,which]
  F <- solve(ff)
  U <- chol(F)
  Dc <- diag(1/U[,ncol(U)])
  Uc <- Dc %*% U

  eta <- Uc %*% comp
  df <- 2*(eta / diag(Dc))^2
  svtable <- cbind(df,eta,Uc)
  dimnames(svtable) <- list(gg,c('df','variance',gg))
  if(vvp)
    return(list(asv = zapsmall(svtable), vvp = ff))
  else
    return(zapsmall(svtable))
}
##The original inverse of the Average Information matrix contains the vari-
##ances and covariances of [σ 2 φ γi ]. This is converted into Var([σ 2 φ σi2 ])
##using formulae
##Cov(σ 2 , σ 2 γi ) = γi Var(σ 2 ) + σ 2 Cov(σ 2 , γi )
##Cov(φ, σ 2 γi ) = γi Cov(σ 2 , φ) + σ 2 Cov(φ, γi )
##Cov(σ 2 γi , σ 2 γj ) = γi γj Var(σ 2 ) + σ 2 γi Cov(σ 2 , γj ) + σ 2 γj Cov(σ 2 , γi )
##                  + σ 4 Cov(γi , γj ) - Cov(σ 2 , γi ) Cov(σ 2 , γj )
##Var(σ 2 γi ) = γi2 Var(σ 2 ) + 2σ 2 γi Cov(σ 2 , γi ) + σ 4 Var(γi )

#' Spline knot points.
#'
#' Return the spline knot points generated via the \code{spl()} model
#' function.
#'
#' @param x A numeric vector.
#'
#' @param k The number of equally spaced knot points for a cubic
#'   smoothing spline. If zero (the default) or omitted, \code{k} is
#'   set to \code{asreml.options()$knots}, in which case the number of
#'   knot points used will be \code{min(unique(x),
#'   asreml.options()$knots)}.
#'
#' @param predict.points An optional vector of points to be included
#'   in the design matrix for prediction.
#'
#' @return
#'
#' A list including the following components:
#'
#' \describe{
#' \item{knotpoints}{The knot points generated by \code{ASReml}.}
#' \item{zknots}{The spline design matrix at the knot points.}
#' }
#'
splinek <- function(x, k=0, predict.points=NULL)
{
  nux <- length(unique(x))
  knots <- asreml.options()$knots ## def is 50
  ## inter(4) takes priority

  kl <- 0
  kptr <- 0

  ## Argument takes precedence
  i4 <- k

  inter <- c(-3, 0, 0, i4)

  # Levels
  if(i4 > 0) {
    ncz <- i4 - 2
  }
  else {
    ncz <- min(knots, nux) - 2
  }
  if(ncz < 1)
    stop("Insufficient points for spline.")

  splstp <- rep(0,10)
  splstp[c(3,5,7)] <- unlist(asreml.options()$spline.step)

  N <- min(splstp[3], length(unique(x))) +  max(k, knots) + asreml.options()$nsppoints

  Z <- .Call("spl_knots",list(x=x, inter=inter, splstp=splstp, knots=knots,
                            nsppoints=asreml.options()$nsppoints,
                            splinescale=asreml.options()$spline.scale,
                            N=N), PACKAGE="asreml")
  return(Z)
}
qq_asr <- function(x, distribution = "norm", conf = 0.95, ...){
  q.function <- eval(parse(text = paste0("q", distribution)))
  d.function <- eval(parse(text = paste0("d", distribution)))
  x <- na.omit(x)
  ord <- order(x)
  n <- length(x)
  P <- ppoints(length(x))
  ord.x = x[ord]
  z = q.function(P, ...)
  
  Q.x <- quantile(ord.x, c(0.25, 0.75))
  Q.z <- q.function(c(0.25, 0.75), ...)
  b <- diff(Q.x)/diff(Q.z)
  coef <- c(Q.x[1] - b * Q.z[1], b)
  
  zz <- qnorm(1 - (1 - conf)/2)
  SE <- (coef[2]/d.function(z)) * sqrt(P * (1 - P)/n)
  fit.value <- coef[1] + coef[2] * z
  upper <- fit.value + zz * SE
  lower <- fit.value - zz * SE
  
  # if(!is.null(labels)){
  #   df$label <- labels[ord]
  # }
  
  # p <- ggplot(df, aes(x=z, y=ord.x)) +
  #   geom_point() +
  #   geom_abline(intercept = coef[1], slope = coef[2]) +
  #   geom_ribbon(aes(ymin = lower, ymax = upper), alpha=0.2)
  # if(!is.null(labels)) {
  #   p <- ggplot(df, aes(x=z, y=ord.x)) +
  #     geom_point(alpha=0.5,size=1,color='blue') +
  #     geom_abline(intercept = coef[1], slope = coef[2]) +
  #     geom_ribbon(aes(ymin = lower, ymax = upper), alpha=0.2) +
  #     geom_text( aes(label = label))
  # }
  # p
  return(data.frame(
    x = z, y = ord.x,
    a = rep(coef[1], length(z)), b = rep(coef[2], length(z)),
    lower = lower, upper = upper, stringsAsFactors = TRUE))
}

#' Plot method for model coefficients.
#'
#' Function to extract and plot the fitted coefficients from
#' an \code{asreml} object. 
#'
#' @param object An object of class \code{asreml}.
#'
#' @param \dots Arguments to \code{plot_coef.asreml}
#'
#' @seealso \code{\link{plot_coef.asreml}}
#'
plot_coef <- function(object, ...)
{
  if(!inherits(object,"asreml"))
    stop("object must be of class 'asreml'\n")
  UseMethod("plot_coef")
}

#' Plot constructor for \code{plot_coef}
#'
#' Q-Q plot of coefficients from the fitted model.
#'
#' @param object An object of class \code{asreml}.
#'
#' @param formula 
#'
#' A one-sided formula identifying the model term.
#'
#' @param distribution
#'
#' A character string specifing the distribution. Density and quantile functions for 
#' many standard probability
#' distributions are available in the \code{"stats"} package. The distribution name 
#' is automatically prefixed with \code{"d"} and \code{"q"}; the default is
#' \code{"norm"}.
#'
#' @param conf
#' 
#' Confidence interval.
#'
#' @param labels
#'
#' if a logical and \code{TRUE} (the default) points are labelled from the 
#' \code{dimnames} attribute of the coefficients. If \code{labels} is a vector
#' the elements are used to label the points.
#'
#' @param ...
#'
#' Additional arguments.
#'
#' @method plot_coef asreml
#'
plot_coef.asreml <- function(object, formula, 
                             distribution = "norm", 
                             conf = 0.95,
                             labels=TRUE, ...) {

  if(!inherits(formula, "formula") || length(formula) != 2) {
    stop("'formula' must be a one-sided formula")
  }
  if(is.null(mf <- object$mf)) {
    if(is.null(object$RDS)) {
      stop(object, "is missing model frame and has no RDS component.")
    } else {
      mf <- readRDS(object$RDS)
    }
  }

  #U <- attr(mf,"model.terms")$residual$Terms.obj
  #V <- attr(mf,"model.terms")$residual$Var
  x <- coef.asreml(object, pattern = formula)
  lab <- dimnames(x)[[1]]
  x <- as.vector(x)
  if(is.logical(labels)) {
    if(!labels) {
      lab <- character(0)
    }
  } else {
    lab = labels
  }
  ## Colour blind friendly palette with black:
  cbfPal <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442",
              "#0072B2", "#D55E00", "#CC79A7")
  atsf <- asreml.options()$font.scale

  df <- qq_asr(x, distribution=distribution, conf=conf, ...)

  y <- b <- a <- lower <- upper <- NULL # for Rcheck

  gg <- ggplot(df, aes(x=x, y=y)) + theme(axis.title.x = element_text(size=rel(0.66*atsf)),
                                          axis.title.y = element_text(size=rel(0.66*atsf)),
                                          axis.text.x = element_text(size=rel(0.66*atsf)),
                                          axis.text.y = element_text(size=rel(0.66*atsf))) +
        scale_fill_manual(values=cbfPal)+scale_colour_manual(values=cbfPal)

  gg <- gg +
  geom_point(shape=16, size=rel(atsf)) +
  geom_abline(aes(slope = b, intercept = a), colour="#0072B2", size=0.5) +
  geom_ribbon(aes(ymin = lower, ymax = upper), alpha=0.2) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
  geom_hline(aes(yintercept=0), colour="white") + geom_vline(aes(xintercept=0), colour="white") +
  xlab("Theoretical") + ylab("Sample")
  if(length(lab)> 0) {
    gg <- gg + geom_text(aes(label = lab), size=rel(2.5*atsf), vjust = 0, nudge_y=5)
  }

  print(gg)
  return(invisible(gg))
}## setdiff is (annoyingly) asymmetrical
symdiff <- function( x, y) { setdiff( union(x, y), intersect(x, y))}
my.dparse <- function(x) {
  return(paste(deparse(x, 500),collapse=""))
}
utils::globalVariables(c("vsni.asreml_r_license"))

decode_json <- function(rv)
{
  if(!is.null(rv$rv_json) && rv$rv_json != ""){
    lic_doc <- jsonlite::fromJSON(rv$rv_json)
    lic_doc$online <- 0
    lic_doc$offline <- 0
    if(is.element(rv$online, c(0,1)))
        lic_doc$online <- rv$online
    if(is.element(rv$offline, c(0,1)))
        lic_doc$offline <- rv$offline
    if (rv$status == -43)
        rv$statusMessage <- lic_doc$statusMessage
	rv$statusContext <- lic_doc$statusContext
  }
  assign("vsni.asreml_r_license", rv, .GlobalEnv )
}

#' Check the status of the asreml license.
#'
#' Checks the status of the asreml license and reports any errors.
#'
#' @param quiet
#'
#' If \code{FALSE} (the default) a string containing the license
#' details is echoed to the console.
#'
#' @param task
#'
#' A character string specifying the task used when checking the license.
#'
#' @param json
#'
#' A character string specifying additional parameters for the license check in json format.
#'
#' @details
#'
#' Checks the status of the asreml license and displays details
#' about the license owner, expiry date and time remaining. 
#' 
#' @return
#'
#' The result of the license status is silently returned.
#'
asreml.license.status <- function(quiet=FALSE, task="checkout", json="")
{
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    install.packages("jsonlite", repos = "http://cran.r-project.org")
    testload <- requireNamespace("jsonlite", quietly = TRUE)
    if (!testload) stop("Failed to install the 'jsonlite' package, this is a mandatory requirement for the correct operation of the asreml package.")
  }
  
  ## don't set proxy or server for getinfo
  args <- list(command = task, info = "", assets = "", json=json)
  rv <- .Call("R_check_lic", args, PACKAGE="asreml")
  decode_json(rv)
  if (quiet)
    return(invisible(rv))
  if(is.element(rv$status, c(0))) { # success or valid
    if(task != "deactivate")
      message(format_lic(rv))
  } else {
    if (rv$status == -1 || rv$status == -18)
		message(paste(rv$statusMessage,"\nTo activate a license use the call asreml.license.activate()."))
	else
		message(rv$statusContext)
  }
  return(invisible(rv))
}

#' Activates an asreml license.
#'
#' Prompt the user for an activation code and activate the license 
#'
#' @details
#'
#' This displays a prompt where an activation code can be entered to activate an asreml license.
#' IT Security measures can sometimes block connections when trying to activate a license. 
#'
#' @return
#'
#' The result of the license activation is silently returned.
#'
asreml.license.activate <- function() 
{
  lic <- asreml.license.status(quiet=TRUE)
  assign("vsni.asreml_r_license", lic, .GlobalEnv )
  if (!is.null(lic$contract) && lic$contract != "Device Edition" && lic$offline == 1)
  {
    rv <- list(status = -999, activation_code = "")
    message("A license is being used offline. The license must be returned online using asreml.license.online() before activating a new license.")
  } else {
    rv <- textDialog() 
    if(is.null(rv$status) || rv$status == -999) 
    {
	  if (!is.null(rv$statusMessage) && length(rv$activation_code) != 0 && nchar(rv$activation_code) != 0)
	  {
		message(paste("No valid license found;", rv$statusContext, separator=" "))
	  }
    } else if(!is.element(rv$status, c(0))) {
      message(rv$statusContext)
    } else {
	  asreml.license.status()
	}
  }
  return(invisible(rv))
}

#' Request an asreml license to be used offline.
#'
#' This will default to 2 days and may be set to a maximum of 30 days.
#'
#' @param how_many_days
#'
#' An integer specifying the number of days to use the asreml license offline.
#'
#' @details
#'
#' You can call this method to request to use one of the license entitlements offline.
#' When a license is set to be used offline it will reduce the number of online license entitlements by 1. A license can be
#' used offline for a maximum of 30 days and can be returned at any point during that period. You can
#' return a license to online usage using asreml.license.online(). This feature is not available when running ASReml-R
#' on a virtual machine.
#' 
asreml.license.offline <- function( how_many_days=2) {
  lic <- asreml.license.status(quiet=TRUE)
  assign("vsni.asreml_r_license", lic, .GlobalEnv )
  if (lic$status < 0)
  {
    message("No valid license found.\nTo activate a license use the call asreml.license.activate().")
  } else {
      if(lic$online == 1){
        offline_limit <- ifelse(lic$expiryDays < lic$maxRoam, lic$expiryDays, lic$maxRoam)
        if(offline_limit > 1 && offline_limit > (how_many_days-1) && how_many_days > 1){
          message("Applying for a ", how_many_days, " day offline license.")
          asreml.license.status(task="go_offline", json=paste0("{\"how_many_days\":",how_many_days - 1,"}"))
	      if (vsni.asreml_r_license$offline == 1)
            message("The asreml license has been successfully set to use offline.")
	      else
            message("Unable to set the asreml license to use offline.")
        }
        else{
          message("The number of offline days must be between 2 and ", offline_limit, " days")
        }
      }
      else{
        message("The asreml license is already being used offline.")
      }
  }
}

#' Request an asreml license to be used online
#'
#' Return a license that is currently offline to be used online.
#'
#' @details
#'
#' When asreml is being used offline you can return the license to online usage by calling this method.
#' This feature is not available when running ASReml-R on a virtual machine.
#'
asreml.license.online <- function() {
  lic <- asreml.license.status(quiet=TRUE)
  assign("vsni.asreml_r_license", lic, .GlobalEnv )
  if (lic$status < 0)
  {
    message("No valid license found.\nTo activate a license use the call asreml.license.activate().")
  } else {
      if(vsni.asreml_r_license$offline == 1){
        asreml.license.status(task="go_online")
	    if (vsni.asreml_r_license$offline == 0)
          message("The asreml license has been successfully returned to use online.")
	    else
          message("Unable to set the asreml license to use online.")
      }
      else{
        message("The asreml license is already being used online.")
      }
  }
}

format_lic <- function(rv)
{
  vof <- "VOFXXXX"
  if (!is.null(rv$options))
  {
    if(nchar(rv$options) > 0 ){
      vof_doc <- jsonlite::fromJSON(rv$options)
      if(!is.null(vof_doc$vof)) 
         vof <- vof_doc$vof
	}
  }
  if (rv$contract == "Device Edition"){
    colourise(paste("License: Device Edition\nRef: ",vof," Expires: ",
                rv$expiry,", ",rv$expiryDays," days.",sep=""), "light red", "light gray")
  } else {
	state <- ifelse((rv$online == 1),""," ( Offline )")
    colourise(paste("Licensed to ",iconv(rv$customer, from="UTF8"),"\nRef: ",vof," Expires: ",
                rv$expiry,", ",rv$expiryDays," days.",state,sep=""), "light red", "light gray")
  }
}

VSNConnect <- function(page="/") {
  curInet <- getOption("internet.info")
  on.exit(options(internet.info=curInet), add=TRUE)
  options(internet.info=3)   ## Stifle the "connected to www.... garbage output
  ## First check to make sure they have HTTP capability.
  ## If not, there is no point to this exercise.
  http <- as.logical(capabilities(what="http/ftp"))
  if (http == FALSE)
    return(FALSE)
  lic <- vsni.asreml_r_license
  gateway_url <- vsni.asreml_r_license$gateway_url
  ## Now check to see if we can connect to the vsni website
  vsnPage <- url(gateway_url)
  options(show.error.messages=FALSE)
  test <- try(readLines(vsnPage, n=1)[1])
  options(show.error.messages=TRUE)
  if (inherits(test,"try-error"))
    return(FALSE)
  else
    close(vsnPage)
  return(TRUE)
}
textDialog <- function()
{
  activDlg <- function() {
    acode <- "x"
    last_act <- ""
	lastStatusMessage <- ""
    try_static_page <- function() {
        ## Cannot connect directly so lets ask our default browser to make the activation request.
        assets <- paste0(dirname(dirname(attributes(packageDescription("asreml"))$file)),"/assets")
        args <- list(command = "build_request_url", info = acode, assets = assets, json="" )
        rv <- .Call("R_check_lic", args, PACKAGE="asreml")
        decode_json(rv)
		if (nchar(rv$rv_url) > 0)
		{
			message("Could not activate via direct internet connection.\nAttempting to open default browser to activate license.")
			browseURL(rv$rv_url)
			stop("Run asreml.license.activate() again and try the new code displayed by the web page.", call.=FALSE)
		} else{
			stop("Unable to establish a connection to the license gateway to activate license. Cannot resolve hostname to license gateway or there is not an internet connection.", call.=FALSE)
		}
    }
    while(acode != "0" || trimws(acode) != "") {
      acode <- readline("Please enter your activation code (RET or 0 to exit): ")
      if(acode == "0" || trimws(acode) == "") {
        rv <- list(status = -999, activation_code = last_act, statusMessage = lastStatusMessage) #return without submit
        break
      }
      last_act <- acode

    ## Check connection to vsn if this looks like a gateway activation code.
    if(nchar(acode) == 19 && !VSNConnect()) {
      try_static_page()
    }

      args <- list(command = "activate", info = acode , assets = "", json="")
      rv <- .Call("R_check_lic", args, PACKAGE="asreml")
      decode_json(rv)
      rv$activation_code <- acode
##    check whether activated license has been checked out
      if(is.element(rv$rv, c(2))) {
        message("License activation successful")
        break
      }
      else{
        if(rv$status == -908) {
          try_static_page()
        }
        message(paste0("License activation unsuccessful \n","Reason: ", iconv(rv$rv_text, from="UTF8")))
      }
      lastStatusMessage = rv$rv_text
    }
    return(rv)
  }
  rv <- activDlg()
  if (rv$status == -999)
    rv$activation_code = ""
  rv
}
where.env <- function(name, env = parent.frame()) {
  stopifnot(is.character(name), length(name) == 1)
  ##env <- to_env(env)
  if (identical(env, emptyenv())) {
    stop("Can't find ", name, call. = FALSE)
  }
  if (exists(name, env, inherits = FALSE)) {
    env
  }
  else {
    where.env(name, parent.env(env))
  }
}
#' Empirical variogram.
#'
#' Calculates the empirical variogram from regular or irregular one or
#' two dimensional data.
#'
#' For one dimensional data the \emph{y} coordinates need not be
#' supplied and a vector of ones is generated. The function identifies
#' data on a complete regular array and in such cases only computes
#' polar variograms If \code{grid = FALSE}. The data is assumed sorted
#' with the \emph{x} coordinates changing the fastest; the data is
#' sorted internally if this is not the case.
#'
#' @param x
#'
#' Numeric vector of \emph{x} coordinates, may also be a matrix or
#' data frame with 2 or 3 columns. If \code{ncol(x)} is 3, the columns
#' are taken to be the \emph{x} and \emph{y} coordinates and the
#' response (\emph{z}), respectively. If \code{ncol(x)} is 2, the
#' columns are taken to be the \emph{x} coordinates and the response,
#' respectively. In this case the \emph{y} coordinates are generated
#' as \code{rep(1,nrow(x))}.
#'
#' @param y
#' 
#' Numeric vector of \emph{y} coordinates.
#' 
#' @param z 
#' 
#' The response vector.
#' 
#' @param composite
#'
#' For data on a regular grid. If \code{TRUE}, the average of the
#' variograms in quadrants \emph{(x,y)} and \emph{(x,-y)} is
#' returned. Otherwise, both variograms are returned and identified as
#' quadrants 1 and 4.
#'
#' @param model 
#' 
#' Can only be \code{"empirical"} at present.
#' 
#' @param metric
#'
#' The distance between \emph{(x,y)} points. Valid measures are
#' \code{"euclidean"} or \code{"manhattan"}.
#'
#' @param angle
#'
#' A vector of directions. Angles are measured in degrees
#' anticlockwise from the \emph{x} axis. Default is 0.
#'
#' @param angle.tol
#'
#' The angle subtended by each direction. That is, an arc 
#' \code{angle +- angle.tol/2}. Default is 180 which gives an omnidirectional
#' variogram.
#'
#' @param nlag 
#' 
#' The maximum number of lags; default is 20.
#' 
#' @param maxdist
#'
#' The fraction of the maximum distance to include in the
#' calculation. The default is half the maximum distance in the data.
#'
#' @param xlag
#'
#' The width of the lags. If missing, \code{xlag} is set to
#' \code{maxdist/nlag}.
#'
#' @param lag.tol
#'
#' The distance tolerance. If missing, \code{lag.tol} is set to
#' \code{xlag/2}.
#'
#' @param grid
#'
#' If FALSE, forces polar variograms if \emph{(x,y)} specifies a
#' regular grid; default is \code{TRUE}.
#'
#' @return
#'
#' A data frame including the following components:
#'
#' \describe{
#' \item{x}{The original \emph{x} coordinates.}
#' \item{y}{The original \emph{y} coordinates.}
#' \item{gamma}{The variogram estimate.}
#' \item{distance}{The average distance for pairs in the lag.}
#' \item{np}{The number of pairs in the lag.}
#' \item{angle}{Direction if not a regular grid.}
#' }
#'
#' @references
#' % bibentry: Webster:2001
#'
asr_varioGram <- function(x,y,z,
                           composite = TRUE,
                           model = c("empirical"),
                           metric=c("euclidean","manhattan"),
                           angle = 0, angle.tol = 180,
                           nlag=20, maxdist=0.5, xlag=NA,
                           lag.tol = 0.5, grid=TRUE)
{
  xyz <- function(x, n) {
    if(is.data.table(x) || is.data.frame(x)) {
      return(as.numeric(x[[n]]))
    }
    else {
      return(as.numeric(x[,n]))
    }
  }
  ## calc empirical variogram

  model <- match.arg(model)
  metric <- match.arg(metric)

  # Arguments to variogrm.c are x,y,r,vg
  # Major,minor sort key order is y,x so y should correspond to the
  # outer factor (usually columns) and x to the inner (usually rows)

  if(missing(x))
    stop("x is a required argument.\n")

  if(is.data.table(x) || is.data.frame(x) || is.matrix(x)) {
    if(ncol(x) == 3) {
      y <- xyz(x, 2)
      if(missing(z))
        z <- xyz(x ,3)
      x <- xyz(x, 1)
      n <- length(z)
    }
    else if(ncol(x) == 2) {
      if(missing(z)) {
        z <- xyz(x, 2)
        x <- xyz(x, 1)
        n <- length(z)
        y <- rep(1,n)
      }
      else {
        y <- xyz(x, 2)
        x <- xyz(x, 1)
        n <- length(z)
      }
    }
    else if(ncol(x) == 1) {
      x <- xyz(x, 1)
      n <- length(z)
      y <- rep(1,n)
    }
    else
      stop('x must be a data table, data frame or matrix with 1, 2 or 3 columns\n')
  }
  else {
    x <- as.numeric(x)
    n <- length(z)
    if(missing(y))
      y <- rep(1,n)
  }
  nlag <- min(n,nlag)
  ux <- sort(unique(x))
  uy <- sort(unique(y))
  nux <- length(ux)
  nuy <- length(uy)

  regular <- FALSE
  if(nux > 1 & nuy > 1) {
    if(nux*nuy == n)
      regular <- TRUE
  }
  else if(nuy == 1) {
    if(sum(diff(diff(ux))) == 0)
      regular <- TRUE
  }
  else if(nux == 1) {
    if(sum(diff(diff(uy))) == 0)
      regular <- TRUE
  }
  regular <- (regular & grid)
  if(regular) {
    u <- 0
    type <- 1
    if(!composite)
      type <- 2
    # Sort
    idx <- base::order(y,x)
    x <- x[idx]
    y <- y[idx]
    z <- z[idx]
  }
  else {
    u <- dist(cbind(x,y),method=metric)
    if(any(u == 0.0))
       warning("Apparently duplicate points")
    type <- 0
    maxdist <- max(u)*maxdist
    if(is.na(xlag))
      xlag <- maxdist/nlag
    else
      nlag <- min(nlag, floor(maxdist/xlag))
    lag.tol <- xlag*lag.tol
    nu <- attr(u, "Size")
    full <- matrix(0, nu, nu)
    full[lower.tri(full)] <- u
    u <- full[lower.tri(full, diag=TRUE)]

  }

  params <- list(x=x, y=y, z=z, u=u, angle=angle, angle.tol=angle.tol,
                 n=n, nlag=nlag, xlag=xlag, type=type, maxdist=maxdist,
                 lag.tol=lag.tol)

  vgram <- .Call("asrvgram",params, PACKAGE="asreml")

  return(as.data.frame(vgram, stringsAsFactors=TRUE))
}
## Document the returned object
##
#' ASReml object
#'
#' This (S3) class object contains a fitted linear mixed model from
#' the \code{asreml()} function. Objects of this class have methods
#' for the generic functions \code{wald()}, \code{coef()},
#' \code{fitted()}, \code{plot()}, \code{predict()}, \code{resid()},
#' \code{summary()} and \code{update()}.
#'
#' @return
#'
#' A list object with class \code{asreml}; the following components
#' are included in a valid \code{asreml} object:
#'
#' \describe{
#'
#' \item{loglik}{The loglikelihood at completion of the \code{asreml} call.}
#'
#' \item{vparameters}{The vector of variance parameter estimates from the
#' fit.}
#'
#' \item{vparameters.con}{A numeric vector identifying the boundary constraint
#' applied to each variance parameter at termination. Common values are 1, 3 and 4
#' for \bold{P}ositive, \bold{U}nconstrained and \bold{F}ixed, respectively. The
#' function \code{vpc.char} can be used to interpret the numeric values as per
#' \code{summary.asreml}.}
#'
#' \item{vparameters.type}{A numeric vector identifying the variance parameter types.
#' Numeric values are used internally and the character codes as used by the \code{own()} 
#' variance model can be obtained from the function \code{vpt.char}. }
#'
#' \item{vparameters.pc}{Percentage change in \code{gammas} on the last iteration.}
#'
#' \item{score}{The score vector of length number of random
#' parameters.}
#'
#' \item{coefficients}{A list with three components named
#' \code{fixed}, \code{random} and \code{sparse} containing the
#' solutions to the mixed model equations corresponding to the fixed
#' effects, the E-BLUPs of the random effects, and the solutions
#' corresponding to the sparse fixed effects, respectively. The
#' coefficients are labelled by a concatenation of factor name and
#' level separated by \code{"_"}. }
#'
#' \item{vcoeff}{ A list with three components named \code{fixed},
#' \code{random} and \code{sparse} containing the unscaled variances
#' of the coefficients. The actual variances are calculated as
#' \code{vcoeff*object\$sigma2} and returned by the
#' \code{\link{summary}} function.  }
#'
#' \item{predictions}{ If \code{predict} is not \code{NULL}, a list
#' object with components \code{pvals, sed, vcov} and
#' \code{avsed}. The \code{predictions} component only is returned by
#' the \code{predict} method for \code{asreml} objects. }
#'
#' \item{fitted.values}{ A vector containing the fitted values from
#' the model, obtained by transforming the linear predictors by the
#' inverse of the link function.  }
#'
#' \item{linear.predictors}{ The linear fit on the link scale.}
#'
#' \item{residuals}{A single column matrix containing the residuals from the model.}
#'
#' \item{hat}{The diagonal elements of the matrix \eqn{W C^{-1} W^T},
#' the \emph{extended} hat matrix. This is the linear mixed effects
#' model analogue of \eqn{ X(X^T X)^{-1} X^T} for ordinary linear
#' models.}
#'
#' \item{sigma2}{ The REML estimate of the scale parameter. }
#'
#' \item{deviance}{The deviance from the fit.}
#'
#' \item{nedf}{The residual degrees of freedom,
#' \code{length(y)-rank(X)}.  }
#'
#' \item{nwv}{The number of working variables.}
#'
#' \item{noeff}{A vector containing the number of effects for each
#' term.}
#'
#' \item{yssqu}{A vector of incremental sums of squares for (dense)
#' fixed terms.}
#'
#' \item{ai}{The inverse average information matrix of the variance
#' parameters. A \code{Matrix} class object, sub-class
#' \code{dspMatrix}.}
#'
#' \item{Cfixed}{ Reflexive generalised inverse of the coefficient
#' matrix of the mixed model equations relating to the dense fixed
#' effects (if \code{asreml.options()$Cfixed=TRUE}). A matrix of class
#' \code{Matrix}, sub-class \code{dspMatrix}.  }
#'
#' \item{Csparse}{If \code{asreml.options()$Csparse} is not
#' \code{NULL}, the non-zero elements of the reflexive generalised
#' inverse matrix of the coefficient matrix for the sparse stored
#' model terms nominated in the \code{Csparse} formula. A matrix in
#' triplet form giving the row, column and non-zero element.}
#'
#' \item{design}{The design matrix as a sparse \code{Matrix} of class
#' \code{dgCMatrix} if \code{asreml.options(design=TRUE)}.}
#'
#' \item{call}{An image of the \code{asreml} function call.  }
#'
#' \item{trace}{A numeric matrix recording the convergence sequence
#' for each random component, as well as the log-likelihood, residual
#' variance and residual degrees of freedom.}
#'
#' \item{license}{A character string containing the license
#' information. The string has embedded new-line characters and is
#' best formatted through \code{cat()}.  }
#'
#'
#' \item{G.param}{A list object containing the constraints and final
#' estimates of the variance parameters relating to the random part of
#' the model. This object may be used as the value of the
#' \code{G.param} argument to provide initial parameter estimates to
#' \code{asreml}. }
#'
#' \item{R.param}{A list object containing the constraints and final
#' estimates of the variance parameters relating to the error
#' structure of the model. This object may be used as the value of the
#' \code{R.param} argument to provide initial parameter estimates to
#' \code{asreml}.}
#'
#' \item{formulae}{A list object containing the \code{fixed},
#' \code{random}, \code{sparse} and \code{residual} formula arguments
#' to \code{asreml}. }
#'
#' \item{factor.names}{A character vector of term names appearing in
#' the model.}
#'
#' \item{meff}{Regressor scores (marker effects) if nominated in the
#' \code{mef} list argument.}
#'
#' \item{mf}{The model frame with the data as a \code{data.table}
#' object with numerous attributes from the model
#' specification. Inspect \code{names(attributes(object$mf))} for
#' details.}
#'
#' }
#'
#' @name asreml.object
NULL
ltri2mat <- function(vec,diag=TRUE,cor=TRUE) {
  ## vec is assumed lower triangle row-wise
  ## diag:
  ##   logigal
  ##     TRUE: us type matrix
  ##     FALSE corg type
  ##   numeric
  ##     diag gives elements of vec that form the diagonal

  makeMat <- function(v,m,diagonal) {
    mat <- matrix(nrow=m,ncol=m)
    mat[t(lower.tri(mat, diagonal))] <- v
    mat <- t(mat)
    mat[!lower.tri(mat, TRUE)] <- t(mat)[!lower.tri(mat,TRUE)]
    mat
  }
  if(is.logical(diag)) {
    n <- length(vec)
    dii <- numeric(0)
    if(diag)
      m <- (sqrt(8*n+1)-1)/2
    else {
      m <- (sqrt(8*n+1)+1)/2
      dii <- rep(ifelse(cor,1,0),m)
    }
    mat <- makeMat(vec,m,diag)
  }
  else if(is.numeric(diag)) {
    nd <- length(diag)
    n <- length(vec)-nd
    dii <- {if(nd==1)
              rep(vec[diag],n)  ## corgv type
    else
      vec[diag]}        ## corgh type
    m <- (sqrt(8*n+1)+1)/2
    mat <- makeMat(vec[1:n],m,FALSE)
  }
  if(length(dii))
    diag(mat) <- dii

  return(mat)
}
asr_niceGammas <- function(obj)
{
  ## Both G & R
  ## "nice" summary of gammas

  ## vList & unlist just used here so define locally


  asr.vList <- function(GR) {
    if(is.null(GR))
      return(NULL)
    out <- lapply(GR,function(z) {
      asr.uList(z)})

    ## Simplify where possible
    out <- lapply(out,function(x){
                    if(length(x) == 1) {
                      return(x[[1]])
                    }
                    else if(all(unlist(lapply(x,function(y){length(y)==1}))))
                      return(unlist(x))
                    else
                      return(x)
                  })

    out
  }
  asr.uList <- function(LL) {
    ## LL is a section
    ## LL[[1]] is "variance"
    ## if v_model is idv then other terms are all cor
    ##

    v <- list(v_model = LL[[1]]$model,
              v_val = LL[[1]]$initial,
              v_constr = LL[[1]]$con)

    out <- lapply(LL[1:length(LL)],function(x,v) {

      switch(x$model,
             ## special cases
             id = NULL,
             idv = x$initial,
             vm = {if(all(is.na(x$initial)))
                     y <- NULL
             else
               y <- x$initial
                   y},
             ide = {if(all(is.na(x$initial)))
                      y <- NULL
             else
               y <- x$initial
                    y},
             us= {y <- ltri2mat(x$initial)
                  dimnames(y) <- list(x$levels,x$levels)
                  y},
             ante= {y <- ltri2mat(x$initial)
                    dimnames(y) <- list(x$levels,x$levels)
                    y},
             chol= {y <- ltri2mat(x$initial)
                    dimnames(y) <- list(x$levels,x$levels)
                    y},
             cholc= {y <- ltri2mat(x$initial)
                    dimnames(y) <- list(x$levels,x$levels)
                    y},
             corv= {n <- length(x$levels)*(length(x$levels)-1)/2
                    vec <- c(rep(x$initial[1],n),rep(x$initial[2],length(x$levels)))
                    y <- ltri2mat(vec,seq(n+1,length(vec)))
                    dimnames(y) <- list(x$levels,x$levels)
                    y},
             corh= {n <- length(x$levels)*(length(x$levels)-1)/2
                    vec <- c(rep(x$initial[1],n),x$initial[-1])
                    y <- ltri2mat(vec,seq(n+1,length(vec)))
                    dimnames(y) <- list(x$levels,x$levels)
                    y},
             corg= {y <- ltri2mat(x$initial,diag=FALSE)
                    dimnames(y) <- list(x$levels,x$levels)
                    y},
             corgv= {y <- ltri2mat(x$initial,diag=length(x$init))
                     dimnames(y) <- list(x$levels,x$levels)
                     y},
             corgh= {y <- ltri2mat(x$initial,
                                   seq(length(x$initial)-length(x$levels)+1,
                                       length(x$initial)))
                     dimnames(y) <- list(x$levels,x$levels)
                     y},
             x$initial)},v)

    out <- out[!unlist(lapply(out,function(x)is.null(x)))]


    return(out)
  }
  ## do it
  out <- c(asr.vList(obj$G.param),
           asr.vList(obj$R.param))
  out

}
## cor2cov = function(corMat, varVec) {
##   n = nrow(corMat)
##   if (!is.null(dim(varVec))) {
##     if (length(dim(varVec)) != 2) stop("'varVec' should be a vector")
##     if (any(dim(varVec)==1)) stop("'varVec' cannot be a matrix")
##     varVec = as.numeric(varVec) # convert row or col matrix to a vector
##   }
##   if (!all(diag(corMat) == 1)) stop("correlation matrices have 1 on the diagonal")
##   if (any(corMat < -1 | corMat > +1))
##     stop("correlations must be between -1 and 1")
##   if (any(varVec <= 0)) stop("variances must be non-negative")
##   if (length(varVec) != n) stop("length of 'varMat' does not match 'corMat' size")
##
##   # Compute the covariance
##   sdMat = diag(sqrt(varVec))
##   rtn = sdMat %*% corMat %*% t(sdMat)
##   if (det(rtn)<=0) warning("covariance matrix is not positive definite")
##   return(rtn)
## }
makeCaptions <- function() {
  captions <- c("Residuals",
                "Deviance residuals",
                "Standardized deviance residuals",
                "Pearson residuals",
                "Response residuals",
                "Studentised conditional residuals")
  names(captions) <- c("working", "deviance", "stdDeviance", "pearson", "response", "stdCond")
  invisible(captions)
}
## captions is saved by dump.R
captions <- makeCaptions()
#' Univariate data frame.
#'
#' Make a univariate dataframe from a multi-variate one.
#'
#' This is a stack operation on the multi-variate data frame based on
#' the nominated response columns. These are concatenated into a
#' vector and the remaining columns of the input data frame repeated
#' accordingly. A \code{"trait"} column is created from the names of
#' the multi-variate response columns.
#'
#' @param stack
#'
#' A character or numeric vector identifying the columns that form the
#' multi-variate response. These columns are concatenated into a vector.
#'
#' @param data
#'
#' The multi-variate data frame.
#'
#' @param response
#'
#' A character string to be used as the name of the concatenated
#' response vector; the default is \code{"y"}.
#'
#' @param traitName
#'
#' A character string to name the resulting column of multi-variate
#' response names; the default is \code{"trait"}.
#'
#' @param traitsWithinUnits
#'
#' The sort order of the returned data frame. The default,
#' \code{TRUE}, orders the data as multi-variate response traits
#' nested within experimental units.
#'
#' @return
#'
#' The stacked data frame.
#'
asuv <- function(stack, data, response="y", traitName="trait", traitsWithinUnits=TRUE)
{

  ## Utility to create a univariate data frame from a multi-variate one
  ## ## stack nominates the columns for the vec() operation
  ##          can be:
  ##          a character vector of column names
  ##          or numeric vector of column numbers
  ## Function can be extended to work with ragged arrays

  if(is.character(stack)) {
    stack <- match(stack,names(data))
    if(any(is.na(stack)))
      stop("names in stack not matched")
  }
  if(max(stack) > ncol(data))
    stop("Column in stack out of range")

  if(length(colClass <- unique(sapply(data[, stack, drop = FALSE],
                                      data.class))) != 1)
    stop("All columns to be stacked must be of the same type.")
  ## Nothing fancy in this version
  if(colClass != "numeric")
    stop("Stack columns must be numeric")

  trait <- names(data)[stack]
  noStack <- seq(1,ncol(data))[-stack]
  nRows <- sapply(data[, stack], length)

  if(traitsWithinUnits) {
    ## Restrict to equal lengths in this version
    if(length(unique(nRows)) != 1)
      stop("Unequal length columns")
    n <- nRows[1]
    vec <- data.frame(V1=as.vector(t(as.matrix(data[,stack]))),V2=rep(trait,n), stringsAsFactors=TRUE)
    rep.vec <- rep(1:n,rep(length(nRows),n))
  }
  else {
    vec <- data.frame(V1=as.vector(as.matrix(data[,stack])),
                      V2=rep(trait,nRows),
                      stringsAsFactors=TRUE)
    rep.vec <- unlist(lapply(nRows,function(x){seq(1,x)}))
  }
  if(is.null(response)) {
    repData <- as.data.frame(cbind(vec$V2,data[rep.vec, noStack, drop = FALSE]), stringsAsFactors=TRUE)
    names(repData) <- c(traitName,names(data)[noStack])
  } else {
    repData <- as.data.frame(cbind(vec,data[rep.vec, noStack, drop = FALSE]), stringsAsFactors=TRUE)
    names(repData) <- c(response,traitName,names(data)[noStack])
  }
  return(repData)
}
#' Asreml object size.
#'
#' List the sizes of the components in an \code{asreml} object.
#'
#' @param object
#'
#' An \code{asreml} object.
#'
#' @return
#'
#' A data frame summarising the components of an asreml object.
#'
lsasr <- function(object) {
  napply <- function(object, names, fn) sapply(names, function(x)
    fn(object[[x]]))

  names <- names(object)
  obj.class <- napply(object, names, function(x) as.character(class(x))[1])
  obj.mode <- napply(object, names, mode)
  obj.type <- ifelse(is.na(obj.class), obj.mode, obj.class)
  obj.size <- napply(object, names, object.size)
  obj.dim <- t(napply(object, names, function(x)
    as.numeric(dim(x))[1:2]))
  vec <- is.na(obj.dim)[, 1] & (obj.type != "function")
  obj.dim[vec, 1] <- napply(object, names, length)[vec]
  out <- data.frame(obj.type, obj.size, obj.dim, stringsAsFactors=TRUE)
  names(out) <- c("Type", "Size", "Rows", "Columns")

  out
}
